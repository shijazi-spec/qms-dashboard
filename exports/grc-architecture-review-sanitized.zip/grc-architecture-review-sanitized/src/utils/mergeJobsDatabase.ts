import { pool } from "./duplicateRadarDatabase";

export interface MergeJob { id: number; cluster_id: number; module: string; status: "queued"|"running"|"done"|"partial"|"failed"; total: number; processed: number; tagged: number; reparented: number; errors: number; error_message: string | null; master_CRMProvider_id: string | null; created_by: string | null; started_at: string | null; last_progress_at: string | null; finished_at: string | null; created_at: string; include_CRMProvider_ids: string | null; link_account_CRMProvider_id: string | null; force_merge: boolean; }

const STALE_MS = 90_000;

export function mergeJobStatusFor(input: { errors: number; finished: boolean }): "running" | "done" | "partial" {
  if (!input.finished) return "running";
  return input.errors > 0 ? "partial" : "done";
}

export function isMergeJobStale(job: Pick<MergeJob,"status"|"last_progress_at">, nowMs: number, thresholdMs: number = STALE_MS): boolean {
  if (job.status !== "running") return false;
  if (!job.last_progress_at) return true;
  return nowMs - Date.parse(job.last_progress_at) > thresholdMs;
}

export async function createMergeJob(input: { clusterId: number; module: string; total: number; masterCRMProviderId: string | null; createdBy: string | null; includeCRMProviderIds: string[] | null; linkAccountCRMProviderId: string | undefined; forceMergeContacts: boolean }): Promise<MergeJob> {
  const includeCRMProviderIds = input.includeCRMProviderIds ? JSON.stringify(input.includeCRMProviderIds) : null;
  // NULL = not provided (route default-suggests); '' = explicit "don't link"; id = link.
  const linkAccountCRMProviderId = input.linkAccountCRMProviderId === undefined ? null : input.linkAccountCRMProviderId;
  const r = await pool.query(
    `INSERT INTO merge_jobs (cluster_id, module, status, total, processed, tagged, reparented, errors, master_CRMProvider_id, created_by, started_at, last_progress_at, include_CRMProvider_ids, link_account_CRMProvider_id, force_merge)
     VALUES ($1,$2,'running',$3,0,0,0,0,$4,$5, NOW(), NOW(), $6,$7,$8) RETURNING *`,
    [input.clusterId, input.module, input.total, input.masterCRMProviderId, input.createdBy, includeCRMProviderIds, linkAccountCRMProviderId, input.forceMergeContacts],
  );
  return r.rows[0] as MergeJob;
}

export async function updateMergeJobProgress(id: number, p: { processed: number; tagged: number; reparented: number; errors: number }): Promise<void> {
  await pool.query(
    `UPDATE merge_jobs SET processed=$2, tagged=$3, reparented=$4, errors=$5, last_progress_at=NOW() WHERE id=$1`,
    [id, p.processed, p.tagged, p.reparented, p.errors],
  );
}

export async function finishMergeJob(id: number, input: { status: "done"|"partial"|"failed"; errorMessage?: string | null }): Promise<void> {
  await pool.query(
    `UPDATE merge_jobs SET status=$2, error_message=$3, finished_at=NOW(), last_progress_at=NOW() WHERE id=$1`,
    [id, input.status, input.errorMessage ?? null],
  );
}

export async function getActiveOrLatestMergeJob(clusterId: number, module: string): Promise<MergeJob | null> {
  const r = await pool.query(
    `SELECT * FROM merge_jobs WHERE cluster_id=$1 AND module=$2 ORDER BY (status IN ('queued','running')) DESC, created_at DESC LIMIT 1`,
    [clusterId, module],
  );
  return (r.rows[0] as MergeJob) ?? null;
}

export async function getMergeJobById(id: number): Promise<MergeJob | null> {
  const r = await pool.query(`SELECT * FROM merge_jobs WHERE id=$1`, [id]);
  return (r.rows[0] as MergeJob) ?? null;
}
