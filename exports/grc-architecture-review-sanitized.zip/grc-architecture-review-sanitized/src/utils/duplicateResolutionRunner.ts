/**
 * Autonomous Duplicate Resolution — THE 6-HOURLY TICK (core orchestration).
 *
 * One `runAutonomousResolution()` call is a complete pass: for every active
 * cluster × module-present, it builds the deterministic merge plan, consults
 * learned rules, runs the "1% doubt" risk gate, and then — gated by the
 * operating mode — either AUTO-APPLIES the safe tier (on behalf of Sample User) or
 * ENQUEUES the doubtful ones to the AI Approvals screen with their reasons.
 * Finally it logs a grade snapshot for the learning curve.
 *
 * This core is intentionally framework-free so the Inngest cron, the
 * in-process fallback (scheduledJobs), and a manual "Run now" admin endpoint
 * can all share it. Every external call is guarded; a single bad cluster never
 * aborts the run.
 *
 * Modes (AUTONOMOUS_RESOLUTION_MODE):
 *   shadow     → dry-run everything, queue everything, WRITE NOTHING to CRMProvider.
 *   assisted   → auto-apply the safe tier; queue the rest.
 *   autonomous → same as assisted (steady state; kept distinct for clarity/telemetry).
 * Kill switch: AUTONOMOUS_RESOLUTION_ENABLED=false → the runner performs no
 * CRMProvider writes regardless of mode (still computes verdicts + snapshots in shadow
 * semantics so the learning curve keeps moving).
 */

import {
  getAllClusters,
  getRecordsByClusterId,
  getClusterMixedSignal,
  getClusterById,
  captureClusterSnapshot,
  updateClusterStatus,
  getClusterSummary,
  getKPIMetrics,
  recordExecBriefSnapshot,
  getPreviousExecBriefSnapshot,
  pool,
  type DuplicateCluster,
  type DuplicateRecord,
} from "./duplicateRadarDatabase";
import { buildMergePlan, type CrmModule, type MergePlan } from "./duplicateMergePlanner";
import { executeMergePlan, CRMProviderWritesAllowedInEnv } from "./duplicateMergeExecutor";
import {
  evaluateResolutionRisk,
  getResolutionPolicyConfig,
  type ResolutionRiskInput,
  type ResolutionRiskVerdict,
} from "./duplicateResolutionPolicy";
import { evaluateRules } from "./duplicateResolutionRules";
import { recordResolutionEvent } from "./duplicateResolutionLearning";
import { snapshotGrades, getGradeHistory } from "./duplicateResolutionGrades";
import {
  enqueuePendingAction,
  initAIApprovalTable,
  findOpenOrRejectedResolutionAction,
} from "./aiApprovalDatabase";
import { fetchRecordAttachments, removeCRMProviderTags } from "./CRMProviderCRM";
import { logger } from "./logger";

/**
 * Inspect the to-be-tagged duplicates for CRMProvider attachments. Returns one entry
 * per duplicate that carries evidence (count = -1 means "couldn't verify" — a
 * CRMProvider error, treated conservatively as evidence-present so a hiccup never
 * green-lights a merge that might drop a contract). Bounded: called ONLY for
 * clusters the agent would otherwise auto-apply. `module` is the CRMProvider module
 * name (Accounts/Leads/Deals/Contacts).
 */
async function attachmentsOnDuplicates(
  module: CrmModule,
  duplicateCRMProviderIds: string[],
): Promise<Array<{ CRMProviderId: string; count: number }>> {
  const found: Array<{ CRMProviderId: string; count: number }> = [];
  for (const id of duplicateCRMProviderIds) {
    if (!id) continue;
    try {
      const atts = await fetchRecordAttachments(module, id);
      if (atts && atts.length > 0) found.push({ CRMProviderId: id, count: atts.length });
    } catch (e) {
      found.push({ CRMProviderId: id, count: -1 }); // unknown → conservative
      logger.warn("[dup-resolution-runner] attachment check failed (treating as has-files)", {
        module,
        recordId: id,
        error: e instanceof Error ? e.message : String(e),
      });
    }
  }
  return found;
}

export type ResolutionMode = "shadow" | "assisted" | "autonomous";

export interface ModuleBreakdownRow {
  module: CrmModule;
  total: number;
  solved: number;
  rest: number;
  /**
   * Clusters that carry a REAL merge action (duplicates actually tagged
   * Duplicate-Delete in CRMProvider via an Apply). This is the honest "data merged"
   * figure — distinct from `solved`, which also counts status='resolved'.
   */
  applied: number;
  /**
   * Clusters marked status='resolved' but with NO merge action recorded —
   * i.e. closed WITHOUT an actual CRMProvider merge. Includes legacy clusters from
   * the now-removed high-confidence auto-resolve, plus manual "Mark resolved".
   * These were NOT merged; do not report them as merged data.
   */
  markedOnly: number;
}

/**
 * Per-module duplicate scoreboard counted in CLUSTERS (= the decisions to make,
 * one per cluster), not raw records. total = clusters containing that module;
 * solved = resolved; rest = still active. Drives the "By module" list on the
 * screen and the ChatProvider run summary. Best-effort → zeros on any error.
 */
export async function getModuleResolutionBreakdown(): Promise<ModuleBreakdownRow[]> {
  const order: Array<{ col: string; module: CrmModule }> = [
    { col: "total_leads", module: "Leads" },
    { col: "total_deals", module: "Deals" },
    { col: "total_contacts", module: "Contacts" },
    { col: "total_accounts", module: "Accounts" },
  ];
  const rows: ModuleBreakdownRow[] = order.map((o) => ({
    module: o.module,
    total: 0,
    solved: 0,
    rest: 0,
    applied: 0,
    markedOnly: 0,
  }));
  try {
    // "solved" = the agent ACTED on the cluster — either it's fully resolved,
    // OR it carries a merge action (duplicates tagged Duplicate-Delete, pending
    // the CRMProvider admin's hard-delete: the "AI-Applied · pending CRMProvider delete"
    // state shown in the radar tabs). Two bugs this fixes:
    //   1) Counting only status='resolved' made every cross-module/partial
    //      apply show as "remaining" even though the agent had done the work
    //      (Accounts showed ~10 AI-applied but "2 solved").
    //   2) rest was status='active' only, so clusters in any OTHER status
    //      (ignored/dismissed/…) fell into a gap → total ≠ solved + rest.
    // rest is now derived as total − solved, so the three ALWAYS add up.
    // "solved" now has a THIRD, DURABLE source: the resolution ledger (keyed by
    // stable CRMProvider identity, NOT cluster_id). dc.status + duplicate_merge_actions
    // are both reset/cascade-deleted by "Rebuild Clusters", so before the ledger
    // every rebuild collapsed solved → 0. The ledger persists, and because the
    // survivor's CRMProvider id reappears in whatever cluster it lands in after the
    // rescan, a per-module ledger match re-credits the cluster as solved.
    const lgCol: Record<string, string> = {
      total_leads: "lg_leads",
      total_deals: "lg_deals",
      total_contacts: "lg_contacts",
      total_accounts: "lg_accounts",
    };
    // Merge-action attribution must be MODULE-SCOPED, not cluster-scoped: a
    // whole-cluster 'resolve' credits every module present (ma.r_all), but a
    // per-module 'module_resolved' must credit ONLY its own module, derived
    // from the primary record's record_type (same mapping the backfill uses).
    // Cluster-scoping here would over-credit untouched modules in a mixed
    // cross-module cluster.
    const maCol: Record<string, string> = {
      total_leads: "mr_leads",
      total_deals: "mr_deals",
      total_contacts: "mr_contacts",
      total_accounts: "mr_accounts",
    };
    const selects = order
      .map((o) => {
        // MERGED (the honest "data merged" figure): a recorded merge action for
        // this module OR a durable ledger entry — i.e. duplicates were actually
        // tagged Duplicate-Delete in CRMProvider. A bare dc.status='resolved' does NOT
        // count here (it can be a legacy auto-resolve / manual close with no
        // merge). This is the figure to report when asked "how much was merged".
        const merged = `(COALESCE(ma.r_all, 0) > 0 OR COALESCE(ma.${maCol[o.col]}, 0) > 0 OR COALESCE(lg.${lgCol[o.col]}, 0) > 0)`;
        // SOLVED = the agent acted at all — also counts a bare resolved status.
        const solved = `(dc.status = 'resolved' OR ${merged})`;
        // `> 1`, not `> 0`. A cross-module cluster holding ONE lead and one
        // account is not a lead duplicate, but `> 0` counted it as one for
        // every module present — so the ChatProvider digest reported ~58k clusters
        // "left" while the radar's own true-duplicate count was 10,327, and
        // the same message contradicted itself: "Duplicate groups to review
        // (matches the tab footers): 3,034 total" sat directly above
        // "Clusters per module: 58,476 left". Every other surface in the
        // platform (getSummary, trueDuplicateClusters, the per-module tabs,
        // getSegmentLeadDuplicateCount) uses `> 1`; this was the outlier.
        return `COUNT(*) FILTER (WHERE dc.${o.col} > 1)::int AS ${o.col}_t,
           COUNT(*) FILTER (WHERE dc.${o.col} > 1 AND ${solved})::int AS ${o.col}_s,
           COUNT(*) FILTER (WHERE dc.${o.col} > 1 AND ${merged})::int AS ${o.col}_a`;
      })
      .join(",\n");
    const r = await pool.query(
      `SELECT ${selects}
         FROM duplicate_clusters dc
         LEFT JOIN (
           SELECT ma.cluster_id,
                  COUNT(*) FILTER (WHERE ma.action_type = 'resolve') AS r_all,
                  COUNT(*) FILTER (WHERE ma.action_type = 'module_resolved' AND pr.record_type = 'lead')    AS mr_leads,
                  COUNT(*) FILTER (WHERE ma.action_type = 'module_resolved' AND pr.record_type = 'deal')    AS mr_deals,
                  COUNT(*) FILTER (WHERE ma.action_type = 'module_resolved' AND pr.record_type = 'contact') AS mr_contacts,
                  COUNT(*) FILTER (WHERE ma.action_type = 'module_resolved' AND pr.record_type = 'account') AS mr_accounts
             FROM duplicate_merge_actions ma
             LEFT JOIN duplicate_records pr ON pr.id = ma.primary_record_id
            WHERE ma.action_type IN ('resolve','module_resolved')
            GROUP BY ma.cluster_id
         ) ma ON ma.cluster_id = dc.id
         LEFT JOIN (
           SELECT dr.cluster_id,
                  COUNT(*) FILTER (WHERE lg.module = 'Leads')    AS lg_leads,
                  COUNT(*) FILTER (WHERE lg.module = 'Deals')    AS lg_deals,
                  COUNT(*) FILTER (WHERE lg.module = 'Contacts') AS lg_contacts,
                  COUNT(*) FILTER (WHERE lg.module = 'Accounts') AS lg_accounts
             FROM duplicate_records dr
             JOIN duplicate_resolution_ledger lg
               ON lg.master_CRMProvider_id = dr.CRMProvider_record_id
            WHERE dr.CRMProvider_record_id IS NOT NULL
            GROUP BY dr.cluster_id
         ) lg ON lg.cluster_id = dc.id
         -- Only REAL duplicate clusters (≥2 records); exclude 1-record singletons
         -- so per-module totals match the tabs (Sample User 2026-06-28).
         WHERE (COALESCE(dc.total_leads,0)+COALESCE(dc.total_deals,0)+COALESCE(dc.total_contacts,0)+COALESCE(dc.total_accounts,0)) >= 2`,
    );
    const row = r.rows[0] || {};
    order.forEach((o, i) => {
      const t = Number(row[`${o.col}_t`] || 0);
      const s = Number(row[`${o.col}_s`] || 0);
      const a = Number(row[`${o.col}_a`] || 0);
      rows[i].total = t;
      rows[i].solved = s;
      rows[i].rest = Math.max(0, t - s); // invariant: total = solved + rest
      rows[i].applied = a; // real CRMProvider merges
      rows[i].markedOnly = Math.max(0, s - a); // resolved but never merged
    });
  } catch (e) {
    logger.warn("[dup-resolution-runner] module breakdown failed (non-fatal)", {
      error: e instanceof Error ? e.message : String(e),
    });
  }
  return rows;
}

/**
 * REAL merge activity over a recent window, sourced from the append-only
 * resolution feedback log — NOT cluster status (which a "Rebuild Clusters" wipes
 * back to 'active'). This is the HONEST "is there progress?" figure: how many
 * Applies actually happened, who did them, how many duplicates were tagged. In
 * shadow mode this is typically 0 (the agent makes no CRMProvider writes). Use this to
 * answer progress/comparison questions — never cluster resolved-count deltas,
 * which swing to 0 on a rebuild without anything actually being un-merged.
 */
export async function getRecentApplyStats(sinceHours: number): Promise<{
  sinceHours: number;
  applies: number;
  agentApplies: number;
  humanApplies: number;
  duplicatesTagged: number;
  undos: number;
}> {
  const out = {
    sinceHours,
    applies: 0,
    agentApplies: 0,
    humanApplies: 0,
    duplicatesTagged: 0,
    undos: 0,
  };
  try {
    const r = await pool.query(
      `SELECT
         COUNT(*) FILTER (WHERE event_type='applied' AND COALESCE(performed_by,'') NOT ILIKE 'UNDO%')::int AS applies,
         COUNT(*) FILTER (WHERE event_type='applied' AND COALESCE(performed_by,'') NOT ILIKE 'UNDO%'
                          AND (COALESCE(performed_by,'') ILIKE '%GRQ Assistant%' OR COALESCE(performed_by,'') ILIKE '%Autonomous Agent%'))::int AS agent_applies,
         COALESCE(SUM(duplicates_tagged) FILTER (WHERE event_type='applied'),0)::int AS tagged,
         COUNT(*) FILTER (WHERE COALESCE(performed_by,'') ILIKE 'UNDO%')::int AS undos
       FROM duplicate_resolution_feedback
      WHERE created_at > NOW() - ($1 || ' hours')::interval`,
      [String(sinceHours)],
    );
    const row = r.rows[0] || {};
    out.applies = Number(row.applies || 0);
    out.agentApplies = Number(row.agent_applies || 0);
    out.humanApplies = Math.max(0, out.applies - out.agentApplies);
    out.duplicatesTagged = Number(row.tagged || 0);
    out.undos = Number(row.undos || 0);
  } catch (e) {
    logger.warn("[dup-resolution-runner] recent apply stats failed (non-fatal)", {
      error: e instanceof Error ? e.message : String(e),
    });
  }
  return out;
}

/**
 * The private resolution channel: #grq-platform-assistant (Sample User + the agent +
 * her manager). Overridable via env if the channel ever moves. The QMS ChatProvider
 * bot must be a member of this channel and ChatProvider_BOT_TOKEN must be set.
 */
export const RESOLUTION_ChatProvider_CHANNEL_DEFAULT = "C0B93BCJFFV";
export function getResolutionChatProviderChannel(): string {
  return process.env.AUTONOMOUS_RESOLUTION_ChatProvider_CHANNEL || RESOLUTION_ChatProvider_CHANNEL_DEFAULT;
}
export function isResolutionChatProviderConfigured(): boolean {
  return !!process.env.ChatProvider_BOT_TOKEN && !!getResolutionChatProviderChannel();
}

/** Resolve the public base URL: explicit env first, else HostingPlatform's domain. */
function publicBaseUrl(): string {
  const explicit = (process.env.PUBLIC_BASE_URL || "").trim().replace(/\/+$/, "");
  if (explicit) return explicit;
  const HostingPlatform = (process.env.HostingPlatform_DOMAINS || "").split(",")[0]?.trim();
  return HostingPlatform ? `<REDACTED_URL>` : "";
}

/**
 * ChatProvider mrkdwn for the screen link. Only emits a `<url|text>` hyperlink when we
 * have a real https base — otherwise plain text, so we never render a broken
 * `</autonomous-resolution|…>` when no base URL is configured.
 */
function resolutionScreenLink(): string {
  const base = publicBaseUrl();
  return base
    ? `<${base}/autonomous-resolution|Open the Autonomous Resolution screen>`
    : "Open it: Quality → Autonomous Resolution.";
}

/**
 * Per-tick ping to the private resolution ChatProvider channel. No-op unless
 * ChatProvider_BOT_TOKEN is set (the bot must be a member of the channel). Stays quiet
 * on empty ticks to avoid 6-hourly noise.
 */
async function pingResolutionChatProvider(summary: ResolutionRunSummary): Promise<void> {
  try {
    const token = process.env.ChatProvider_BOT_TOKEN;
    const channel = getResolutionChatProviderChannel();
    if (!token || !channel) return;
    if (summary.clustersScanned === 0) return;
    // Quiet unless the agent actually DID something (Sample User 2026-06-20). In shadow
    // mode `applied` is always 0, so a per-tick ping just repeats "applied 0 · 0
    // solved" — pure zero-noise. The backlog / queued items are already reported
    // by the twice-daily digest + the Autonomous Resolution screen, so only ping
    // when there were real applies or errors. Once in assisted mode (applied>0)
    // the per-tick ping returns automatically with real numbers.
    if (summary.applied === 0 && summary.errors === 0) return;

    const icon = summary.errors > 0 ? "🔴" : summary.queued > 0 ? "🟡" : "🟢";
    let breakdownText = "";
    try {
      const rows = await getModuleResolutionBreakdown();
      const lines = rows
        .filter((b) => b.total > 0)
        .map((b) => `›  *${b.module} Duplicates* — ${b.total} clusters · ${b.solved} solved · ${b.rest} left`);
      if (lines.length) breakdownText = `\n\n*By module:*\n${lines.join("\n")}`;
    } catch {
      /* breakdown is best-effort */
    }
    // Error reasons (Sample User 2026-07-19): "errors N" alone is undiagnosable. Group
    // the failed items by module + a normalised message and show the top few with
    // counts, so every run explains WHY it errored instead of just how many.
    let errorText = "";
    if (summary.errors > 0) {
      const groups = new Map<string, { n: number; sample: string }>();
      for (const it of summary.items) {
        if (it.action !== "error") continue;
        const msg = (it.detail || (it.reasons && it.reasons.join("; ")) || "unknown error")
          .toString()
          .replace(/#?\d+/g, "#")          // fold ids so "cluster #123" groups
          .replace(/\s+/g, " ")
          .trim()
          .slice(0, 160);
        const key = `<REDACTED_SECRET>`;
        const g = groups.get(key) || { n: 0, sample: `${it.module} — ${(it.detail || "").toString().slice(0, 200)}` };
        g.n++;
        groups.set(key, g);
      }
      const top = [...groups.entries()]
        .sort((a, b) => b[1].n - a[1].n)
        .slice(0, 3)
        .map(([key, g]) => `›  (${g.n}×) ${key}`);
      if (top.length) {
        errorText =
          `\n\n*Top error reasons (${summary.errors} total):*\n${top.join("\n")}` +
          (groups.size > 3 ? `\n›  …+${groups.size - 3} more reason(s)` : "");
      }
    }
    const text =
      `${icon} *Autonomous Resolution — ${summary.mode} run* ` +
      (summary.writesAllowed ? "" : "(shadow: no CRMProvider writes) ") +
      `\nScanned ${summary.clustersScanned} · applied ${summary.applied} · ` +
      `queued ${summary.queued} · errors ${summary.errors}` +
      (summary.queued > 0 ? `\n${summary.queued} item(s) need your call.` : "") +
      errorText +
      breakdownText +
      `\n${resolutionScreenLink()}`;

    const { WebClient } = await import("@ChatProvider/web-api");
    await new WebClient(token).chat.postMessage({ channel, text });
  } catch (e) {
    logger.warn("[dup-resolution-runner] ChatProvider ping failed (non-fatal)", {
      error: e instanceof Error ? e.message : String(e),
    });
  }
}

/**
 * One-off cleanup (Sample User 2026-06-20): delete the bot's OWN zero-progress
 * "Autonomous Resolution — … applied 0 …" pings from the resolution channel.
 * Best-effort: needs the bot to have history scope on the channel and chat:write
 * to delete its own messages. Returns counts + any ChatProvider error so the operator
 * knows if a scope is missing (then they can delete the few manually).
 */
export async function cleanupZeroResolutionPings(opts?: {
  limit?: number;
}): Promise<{ scanned: number; deleted: number; error?: string }> {
  const token = process.env.ChatProvider_BOT_TOKEN;
  const channel = getResolutionChatProviderChannel();
  if (!token || !channel) return { scanned: 0, deleted: 0, error: "ChatProvider not configured" };
  const max = Math.max(1, Math.min(Math.floor(opts?.limit || 500), 1000));
  let scanned = 0;
  let deleted = 0;
  try {
    const { WebClient } = await import("@ChatProvider/web-api");
    const ChatProvider = new WebClient(token);
    let cursor: string | undefined;
    // Page through recent history; match the bot's own zero-apply pings.
    while (scanned < max) {
      const resp: any = await ChatProvider.conversations.history({
        channel,
        limit: 200,
        cursor,
      });
      const msgs: any[] = resp?.messages || [];
      for (const m of msgs) {
        scanned++;
        const text: string = m?.text || "";
        const isResolutionPing =
          text.includes("Autonomous Resolution —") &&
          /applied\s+0\b/.test(text); // zero-apply tick
        if (!isResolutionPing) continue;
        try {
          await ChatProvider.chat.delete({ channel, ts: m.ts });
          deleted++;
        } catch (delErr: any) {
          // Can't delete others' messages / rate limited — keep going.
          logger.warn("[dup-resolution-runner] chat.delete failed", {
            error: delErr?.data?.error || String(delErr),
          });
        }
      }
      cursor = resp?.response_metadata?.next_cursor;
      if (!cursor) break;
    }
    return { scanned, deleted };
  } catch (e: any) {
    return {
      scanned,
      deleted,
      error: e?.data?.error || (e instanceof Error ? e.message : String(e)),
    };
  }
}

/**
 * Post a one-off test message to the resolution channel — powers the
 * "Send test ping" button so the channel wiring can be confirmed on demand.
 * Surfaces the exact ChatProvider error (e.g. not_in_channel, invalid_auth) so the
 * operator knows precisely what to fix.
 */
export async function sendResolutionChatProviderTest(
  triggeredBy = "operator",
): Promise<{ ok: boolean; channel: string | null; error?: string }> {
  const token = process.env.ChatProvider_BOT_TOKEN;
  const channel = getResolutionChatProviderChannel();
  if (!token) return { ok: false, channel, error: "ChatProvider_BOT_TOKEN is not set." };
  if (!channel) return { ok: false, channel: null, error: "No resolution ChatProvider channel configured." };
  try {
    const { WebClient } = await import("@ChatProvider/web-api");
    await new WebClient(token).chat.postMessage({
      channel,
      text:
        `✅ *Autonomous Resolution — test ping*\n` +
        `Channel wiring confirmed by ${triggeredBy}. You'll get a summary here after each 6h run.` +
        `\n${resolutionScreenLink()}`,
    });
    return { ok: true, channel };
  } catch (e) {
    return { ok: false, channel, error: e instanceof Error ? e.message : String(e) };
  }
}

/** Post an arbitrary message to the resolution ChatProvider channel (e.g. a
 *  manually-triggered executive brief). Best-effort. */
export async function postResolutionMessage(
  text: string,
): Promise<{ ok: boolean; channel: string | null; error?: string }> {
  const token = process.env.ChatProvider_BOT_TOKEN;
  const channel = getResolutionChatProviderChannel();
  if (!token) return { ok: false, channel, error: "ChatProvider_BOT_TOKEN is not set." };
  if (!channel) return { ok: false, channel: null, error: "No resolution ChatProvider channel configured." };
  try {
    const { WebClient } = await import("@ChatProvider/web-api");
    await new WebClient(token).chat.postMessage({ channel, text });
    return { ok: true, channel };
  } catch (e) {
    return { ok: false, channel, error: e instanceof Error ? e.message : String(e) };
  }
}

// Channels the WEEKLY leadership brief posts to. Defaults: #grq-assistant
// (resolution channel) + #automatic-audits. Override via env (comma-separated
// channel ids). The bot must be a MEMBER of each channel to post.
const WEEKLY_BRIEF_CHANNELS_DEFAULT = ["C0B93BCJFFV", "C0AS5G4UN91"];
function getWeeklyBriefChannels(): string[] {
  const env = (process.env.AUTONOMOUS_WEEKLY_BRIEF_CHANNELS || "").trim();
  if (env) return env.split(",").map((s) => s.trim()).filter(Boolean);
  return Array.from(new Set(WEEKLY_BRIEF_CHANNELS_DEFAULT));
}

/**
 * Build the board-ready executive brief text DETERMINISTICALLY from real
 * aggregate figures (no LLM). Shared by the on-demand button and the weekly
 * leadership digest. With `withTrend`, prepends a week-over-week line vs the
 * last recorded snapshot.
 */
export async function buildExecutiveBriefText(
  opts: { withTrend?: boolean } = {},
): Promise<{ brief: string; metrics: any }> {
  const cfg = await resolveResolutionRunConfig();
  const agg = await getClusterSummary().catch(() => null);
  const breakdown = await getModuleResolutionBreakdown().catch(() => [] as any[]);
  const kpi = await getKPIMetrics().catch(() => null);
  // The Empty/Orphaned cleanup is a SEPARATE workflow from duplicate-cluster
  // merges (it tags empty/test records Empty-Delete, not duplicates). Surface it
  // so leadership sees the full cleanup picture, not just merges (Sample User 2026-06-28).
  const emptyStatus = await (await import("./emptyRecordsDatabase"))
    .getTaggedStatus()
    .catch(() => null);
  const emptyTagged = emptyStatus?.counts?.tagged || 0;
  const emptyDeleted = emptyStatus?.counts?.deleted || 0;
  const grades = await getGradeHistory(undefined, 4 * 8).catch(() => []);
  const latestByModule: Record<string, any> = {};
  for (const g of grades) if (!latestByModule[g.module]) latestByModule[g.module] = g;

  const totalClusters = agg?.totalClusters || 0;
  const resolved = agg?.resolvedCount || 0;
  const open = agg?.activeCount || 0;
  const exposure = agg?.estimatedPipelineInflation || 0;
  const dupRate = kpi ? Math.max(kpi.duplicateLeadRate || 0, kpi.duplicateDealRate || 0) : null;
  const clearedPct = totalClusters > 0 ? (resolved / totalClusters) * 100 : 0;

  const modePlain =
    cfg.mode === "shadow"
      ? "observing only — making no changes to the CRM yet"
      : cfg.mode === "assisted"
        ? "assisting — auto-clearing safe cases, queuing the rest for review"
        : "autonomous — clearing safe cases on its own";
  const maturity = ["Accounts", "Leads", "Deals", "Contacts"]
    .map((m) => {
      const lvl = latestByModule[m]?.grade ?? 1;
      const plain = lvl >= 4 ? "trusted" : lvl >= 3 ? "reliable" : lvl >= 2 ? "developing" : "still learning";
      return `${m}: ${plain}`;
    })
    .join(" · ");
  const moduleLines = breakdown
    .map((b: any) => `   • ${b.module}: ${b.total.toLocaleString()} clusters · ${b.solved.toLocaleString()} cleared · ${b.rest.toLocaleString()} remaining`)
    .join("\n");

  let trendLine = "";
  if (opts.withTrend) {
    const prev = await getPreviousExecBriefSnapshot().catch(() => null);
    if (prev) {
      const dResolved = resolved - (prev.resolved_count || 0);
      const dRate = dupRate != null && prev.dup_rate != null ? dupRate - prev.dup_rate : null;
      // No exposure delta — see the note on `brief` below. A week-over-week
      // move on an unstable figure reads as a trend when it is re-clustering
      // noise, which is worse than not reporting it.
      trendLine =
        `\n*This week:* ${dResolved >= 0 ? "+" : ""}${dResolved.toLocaleString()} clusters cleared` +
        (dRate != null ? ` · duplicate rate ${dRate <= 0 ? "down" : "up"} ${Math.abs(dRate)} pts` : "") +
        ".\n";
    } else {
      trendLine = `\n_First weekly baseline — week-over-week trend starts next week._\n`;
    }
  }

  // NO SAR EXPOSURE FIGURE IN THIS BRIEF (Sample User 2026-08-23).
  //
  // Two reasons, and both matter:
  //
  //  1. Standing rule — nothing goes to leadership except the KPIs agreed with
  //     them. That set is the four codes in leadershipPush's DEFAULT_MAP
  //     (QM-KPI-002/008/015, GRC-KPI-008). Amount at risk is not among them,
  //     and this brief is board-framed and posted on a timer, so it was a
  //     second, unreviewed channel to the same audience.
  //  2. The figure is not stable enough to report. estimatedPipelineInflation
  //     read 172,480 → 479,480 → 90,640 → 397,640 within one day (2026-08-23);
  //     it is gated on `total_deals > 1` in ACTIVE clusters and currently rests
  //     on 1–2 deals, so ordinary re-clustering swings it several-fold. A
  //     week-over-week delta on that is noise wearing the costume of a trend.
  //
  // The brief keeps what IS sound: cluster counts, cleared progress, and the
  // duplicate rate against its 2% target. `exposure` is still computed and
  // returned in `metrics` for the snapshot table so history is unbroken — it
  // is simply not published.
  const brief =
    `*GRQ — CRM Duplicate Health (Executive Brief)*\n\n` +
    `*Bottom line:* ${totalClusters.toLocaleString()} duplicate clusters tracked; ${clearedPct < 1 ? "under 1%" : clearedPct.toFixed(0) + "%"} cleared so far.\n` +
    trendLine +
    `\n` +
    (dupRate != null ? `• *Duplicate rate:* ~${dupRate}% vs the 2% target — our biggest data-quality gap.\n` : "") +
    `• *Progress (merges):* ${resolved.toLocaleString()} duplicate clusters resolved · ${open.toLocaleString()} still open.\n` +
    (emptyTagged > 0
      ? `• *Progress (empty/test cleanup):* ${emptyTagged.toLocaleString()} empty/test records tagged Empty-Delete${emptyDeleted > 0 ? ` · ${emptyDeleted.toLocaleString()} deleted by admin` : " · pending admin delete"}.\n`
      : "") +
    `• *Clean-up AI:* ${modePlain}.\n` +
    `• *AI maturity by module:* ${maturity}.\n\n` +
    `*By module* (a cross-module cluster appears under each module it touches — do not add these up):\n${moduleLines}\n\n` +
    `*Recommendation:* ${cfg.mode === "shadow"
      ? "validate the AI's judgement in observe-only mode; once agreement holds, approve moving the strongest module to assisted (auto-clear safe cases, human-review the rest)."
      : "continue assisted clean-up; review the override rate weekly and tighten thresholds as agreement improves."}`;

  return {
    brief,
    metrics: { totalClusters, resolvedCount: resolved, activeCount: open, exposure, dupRate },
  };
}

/**
 * Weekly leadership digest — posts the executive brief (with week-over-week
 * trend) to the configured channels, then records this week's snapshot so the
 * NEXT week can show the delta. Scheduled Sunday 06:00 KSA (03:00 UTC).
 */
export async function postWeeklyExecBrief(
  opts: { recordSnapshot?: boolean } = {},
): Promise<{
  ok: boolean;
  posted: string[];
  errors: string[];
}> {
  // The scheduled Sunday run records a snapshot (= next week's trend baseline).
  // A MANUAL "send now" passes recordSnapshot:false so ad-hoc sends (e.g. for a
  // meeting) don't pollute the week-over-week math, which must stay Sunday-anchored.
  const recordSnapshot = opts.recordSnapshot !== false;
  // Comprehensive ghost purge BEFORE the audit is computed (Sample User 2026-07-13:
  // "checked before we send the automatic-audits / ChatProvider heads-up"). Removes
  // ALL data deleted in CRMProvider — any module, any type — so the weekly brief and
  // #automatic-audits reflect clean numbers, not lingering ghosts. Non-fatal:
  // a sweep failure must never block the brief. Disable via env RADAR_WEEKLY_
  // DELETION_SWEEP=false.
  if (process.env.RADAR_WEEKLY_DELETION_SWEEP !== "false") {
    try {
      const { runComprehensiveDeletionSweep } = await import(
        "./emptyRecordsDatabase"
      );
      const sweep = await runComprehensiveDeletionSweep();
      logger.info(
        `[exec-brief] pre-brief deletion sweep: feed-removed ${sweep.feedRemoved}, live-pruned ${sweep.verifiedPruned}`,
      );
    } catch (e) {
      logger.warn("[exec-brief] pre-brief deletion sweep failed (non-fatal)", {
        error: e instanceof Error ? e.message : String(e),
      });
    }
  }
  const { brief, metrics } = await buildExecutiveBriefText({ withTrend: true });
  if (recordSnapshot) {
    // Snapshot AFTER building (build reads the PRIOR snapshot for the delta).
    try {
      await recordExecBriefSnapshot({
        totalClusters: metrics.totalClusters,
        resolvedCount: metrics.resolvedCount,
        activeCount: metrics.activeCount,
        exposure: metrics.exposure,
        dupRate: metrics.dupRate,
        metricsJson: metrics,
      });
    } catch (e) {
      logger.warn("[exec-brief] snapshot record failed (non-fatal)", {
        error: e instanceof Error ? e.message : String(e),
      });
    }
  }
  const token = process.env.ChatProvider_BOT_TOKEN;
  const posted: string[] = [];
  const errors: string[] = [];
  if (!token) return { ok: false, posted, errors: ["ChatProvider_BOT_TOKEN not set"] };
  const text = `📊 *Weekly Leadership Brief*\n\n${brief}\n${resolutionScreenLink()}`;
  const { WebClient } = await import("@ChatProvider/web-api");
  const ChatProvider = new WebClient(token);
  for (const ch of getWeeklyBriefChannels()) {
    try {
      await ChatProvider.chat.postMessage({ channel: ch, text });
      posted.push(ch);
    } catch (e) {
      errors.push(`${ch}: ${e instanceof Error ? e.message : String(e)}`);
    }
  }
  logger.info(`📊 [exec-brief] weekly brief posted to ${posted.length} channel(s)`, { posted, errors });
  return { ok: posted.length > 0, posted, errors };
}

/**
 * SINGLE SOURCE OF TRUTH for AssistantPersona's scheduled notifications. Drives the
 * platform "Notification Schedule" card, the monthly review post, and what
 * AssistantPersona tells people about his own cadence. To change a timing, edit the
 * matching env var (envKey) — review this monthly. Times are KSA (UTC+3).
 */
export interface NotificationScheduleEntry {
  time: string;
  cron: string;
  envKey?: string;
  channel: string;
  what: string;
  postsToChatProvider: boolean;
}
// Chronological — mirrors the "daily rhythm" table Sample User.
export const ADAM_NOTIFICATION_SCHEDULE: NotificationScheduleEntry[] = [
  { time: "03:00 / 09:00 / 15:00 / 21:00 KSA", cron: "0 */6 * * *", envKey: "<REDACTED_SECRET>", channel: "— (background)", what: "Every-6h incremental CRM sync — keeps data fresh round the clock", postsToChatProvider: false },
  { time: "07:00 KSA · daily", cron: "0 4 * * *", envKey: "<REDACTED_SECRET>", channel: "— (background)", what: "Pre-shift incremental sync — radar current before your shift", postsToChatProvider: false },
  { time: "02:00 KSA · Sat & Tue", cron: "0 23 * * 1,5", envKey: "<REDACTED_SECRET>", channel: "— (background)", what: "Twice-weekly FULL rebuild — clean wipe + re-fetch + re-score off-hours", postsToChatProvider: false },
  { time: "09:00 & 17:00 KSA · daily", cron: "0 6,14 * * *", envKey: "<REDACTED_SECRET>", channel: "#grq-assistant", what: "Operational apply digest — what the agent applied/queued this shift", postsToChatProvider: true },
  { time: "Sunday 06:00 KSA · weekly", cron: "0 3 * * 0", envKey: "<REDACTED_SECRET>", channel: "#grq-assistant + #automatic-audits", what: "Weekly leadership brief — cluster counts, dup-rate vs 2%, week-over-week trend, recommendation (NO SAR exposure: leadership sees only the agreed KPIs)", postsToChatProvider: true },
  { time: "Every 6h (:30)", cron: "30 */6 * * *", channel: "#grq-assistant", what: "Autonomous resolution tick (shadow) — per-tick summary, quiet when nothing changed", postsToChatProvider: true },
  { time: "1st of month · 09:00 KSA", cron: "0 6 1 * *", envKey: "<REDACTED_SECRET>", channel: "#grq-assistant", what: "Monthly review of THIS notification schedule — edit timings if needed", postsToChatProvider: true },
];

/** Render the schedule as a ChatProvider-friendly list. */
export function buildNotificationScheduleText(): string {
  const lines = ADAM_NOTIFICATION_SCHEDULE.map(
    (e) => `• *${e.time}* — ${e.what}` + (e.postsToChatProvider ? ` → ${e.channel}` : ` _(background)_`),
  ).join("\n");
  return `*AssistantPersona — Notification Schedule (KSA)*\n${lines}`;
}

/** Monthly review post: shows the schedule and invites timing changes. */
export async function postMonthlyScheduleReview(): Promise<{ ok: boolean; channel: string | null; error?: string }> {
  const text =
    `🗓️ *Monthly notification-schedule review*\n\n` +
    buildNotificationScheduleText() +
    `\n\nReply here if any timing should change and we'll update it. ${resolutionScreenLink()}`;
  return postResolutionMessage(text);
}

export const AGENT_PERFORMED_BY =
  "AssistantPersona — GRQ Assistant (on behalf of Sample User)";

/**
 * Twice-daily APPLY DIGEST posted to the resolution ChatProvider channel — at 09:00
 * (start of day) and 17:00 (end of day) KSA. Replaces the per-apply ping:
 * instead of one message per merge, it batches all AI solves/migrations in the
 * window into a single morning/evening summary. Best-effort; always posts (a
 * "nothing applied" line is a useful heartbeat). `sinceHours` covers back to the
 * previous digest (16h for the 9AM run, 8h for the 5PM run).
 */
/**
 * Per-tab status board for the Duplicate Radar — appended to the twice-daily
 * digest so each shift sees the health of every key tab, not just the agent's
 * applies. Each line best-effort; a failing query just drops its line.
 */
export async function buildRadarTabStatus(): Promise<string> {
  const parts: string[] = [];
  const n = (x: number) => Math.round(x || 0).toLocaleString();
  // Pull the durable per-module breakdown ONCE — used for both the Overview
  // "merged" total and the per-module line. `applied` = real CRMProvider merges that
  // survive a Rebuild (ledger-backed); `solved` also counts a bare resolved
  // status (rebuild-fragile). We report the DURABLE figure so the digest never
  // falsely shows "0 done" just because a Rebuild reset cluster statuses.
  let bd: ModuleBreakdownRow[] = [];
  try {
    bd = await getModuleResolutionBreakdown();
  } catch { /* skip */ }
  // Executive Summary / Cross-Module — overall clusters + SAR exposure.
  try {
    const agg = await getClusterSummary();
    if (agg) {
      // "merged so far" MUST be the DISTINCT resolved-cluster count
      // (agg.resolvedCount — ledger-durable, one row per cluster), NOT the sum of
      // the per-module `applied` counts. Summing double-counts every cross-module
      // cluster (it's counted under each module it touches), which inflated the
      // headline to ~4,300 when the true distinct figure is ~1,600 and made the
      // digest contradict its own "do not add these up" rule and the weekly brief
      // (Sample User 2026-07-19).
      parts.push(
        // "incl. singletons" was wrong even before today: getClusterSummary has
        // excluded 1-record clusters since 2026-06-28. It now also excludes
        // cross-module links, so this figure is genuinely duplicate clusters
        // and matches the module tabs.
        `›  *Duplicate clusters:* ${n(agg.totalClusters)} · ~SAR ${n(agg.estimatedPipelineInflation)} exposure at risk · ${n(agg.resolvedCount)} merged so far`,
      );
    }
  } catch { /* skip */ }
  // Real merge activity in the last 24h, from the append-only feedback log
  // (survives rebuilds). The honest "is anything actually happening?" line —
  // 0 in shadow mode, which is the truth, not an error.
  try {
    const recent = await getRecentApplyStats(24);
    parts.push(
      `›  *Merges applied (real, last 24h):* ${n(recent.applies)}` +
        (recent.applies > 0
          ? ` (${n(recent.agentApplies)} agent · ${n(recent.humanApplies)} people · ${n(recent.duplicatesTagged)} duplicates tagged)`
          : " — nothing merged in this window"),
    );
  } catch { /* skip */ }
  // ACTIONABLE duplicate GROUPS per module — the SAME genuine count each tab
  // footer shows (Untouched view, after the genuine-duplicate + queued-for-
  // deletion filters). Reported up top so the digest matches what operators see
  // on screen, instead of the raw record/cluster totals (which include singletons
  // + non-duplicate group members and made the headline look 10x too big).
  try {
    const { getDuplicateRecordsByType } = await import("./duplicateRadarDatabase");
    const mods: Array<[string, string]> = [
      ["lead", "Leads"], ["deal", "Deals"], ["contact", "Contacts"], ["account", "Accounts"],
    ];
    const counts = await Promise.all(
      mods.map(async ([rt, label]) => {
        try {
          const res = await getDuplicateRecordsByType(rt, { ai_status: "active", limit: 1, offset: 0 });
          return { label, total: res?.total || 0 };
        } catch {
          return { label, total: 0 };
        }
      }),
    );
    const totalGroups = counts.reduce((a, c) => a + c.total, 0);
    parts.push(
      `›  *Duplicate groups to review (Untouched — matches the tab footers):* ` +
        counts.map((c) => `${c.label} ${n(c.total)}`).join(" · ") +
        ` — ${n(totalGroups)} total`,
    );
  } catch { /* skip */ }
  // Lead / Deal / Contact / Account Duplicates — remaining vs MERGED (durable).
  try {
    const ml = bd
      .filter((b) => b.total > 0)
      .map((b) => `${b.module} ${n(b.rest)} left/${n(b.applied)} merged`)
      .join(" · ");
    // These are CLUSTER counts (remaining vs durably merged), the same figures
    // as the "By module" breakdown — NOT record counts. Labelled accordingly
    // (Sample User 2026-07-19: the old "Records per module (raw count)" label was
    // wrong and made leadership read them as record totals).
    if (ml) parts.push(`›  *Clusters per module (remaining / merged):* ${ml}`);
  } catch { /* skip */ }
  // Per-tab PROGRESS burndown (Sample User 2026-06-17) — total / solved / left per
  // module with the day-over-day change, from the daily snapshot table. This is
  // the "progress of each duplication tab" line: how many duplicates there are
  // and how many got solved, tracked over time (not reset by a Rebuild — older
  // days stay frozen as history).
  try {
    const { getDuplicateProgressSeries } = await import("./duplicateRadarDatabase");
    const prog = await getDuplicateProgressSeries(2);
    const pl = (["Leads", "Deals", "Contacts", "Accounts"] as const)
      .map((m) => {
        const b = prog.byModule[m];
        const l = b?.latest;
        if (!l || l.total === 0) return null;
        const prevSolved = b?.previous?.solved ?? l.solved;
        const delta = l.solved - prevSolved;
        const arrow = delta > 0 ? ` (+${n(delta)} today)` : "";
        return `${m} ${n(l.solved)}/${n(l.total)} solved${arrow}`;
      })
      .filter(Boolean)
      .join(" · ");
    if (pl) parts.push(`›  *Progress (solved/total):* ${pl}`);
  } catch { /* skip */ }
  // Rejection patterns (Sample User 2026-06-20) — what operators keep rejecting, so
  // the team knows what to teach AssistantPersona / which threshold to tune.
  try {
    const { analyzeRejectionPatterns } = await import("./rejectionPatterns");
    const rp = await analyzeRejectionPatterns(7);
    if (rp.totalRejected > 0) {
      const top = rp.patterns
        .slice(0, 3)
        .map((p) => `${p.label} ${p.sharePct}%`)
        .join(" · ");
      parts.push(
        `›  *Rejections (last 7d):* ${n(rp.totalRejected)}` +
          (top ? ` — top: ${top}` : "") +
          ` — review/teach on the Autonomous Resolution screen`,
      );
    }
  } catch { /* skip */ }
  // Account Hints — pending / applied / dismissed.
  try {
    const { listAccountInferenceHints } = await import("./accountInference");
    const h = await listAccountInferenceHints({ status: "pending", limit: 1 });
    parts.push(
      `›  *Account Hints:* ${n(h.summary.pending)} pending · ${n(h.summary.applied)} applied · ${n(h.summary.dismissed)} dismissed`,
    );
  } catch { /* skip */ }
  // Deal Compliance — compliant vs missing docs (of deals scanned).
  try {
    const { getDealDocCompliance } = await import("./duplicateRadarDatabase");
    const rows = await getDealDocCompliance();
    const checked = rows.length;
    if (checked) {
      const compliant = rows.filter((r: any) => r.compliant).length;
      parts.push(
        `›  *Deal Compliance:* ${n(compliant)} compliant · ${n(checked - compliant)} missing docs (of ${n(checked)} checked)`,
      );
    }
  } catch { /* skip */ }
  // Pending CRMProvider admin delete — AI-Applied clusters whose Duplicate-Delete
  // records the admin hasn't deleted yet. The actionable backlog: once the
  // admin clears them, "Verify in CRM" marks them Resolved.
  try {
    const r = await pool.query(
      `SELECT COUNT(*)::int AS n FROM duplicate_clusters dc
        WHERE dc.status = 'active'
          AND EXISTS (
            SELECT 1 FROM duplicate_merge_actions ma
             WHERE ma.cluster_id = dc.id
               AND ma.action_type IN ('resolve','module_resolved'))`,
    );
    const pend = Number(r.rows?.[0]?.n || 0);
    if (pend > 0) {
      parts.push(
        `›  *Pending CRMProvider admin delete:* ${n(pend)} AI-Applied cluster(s) awaiting the admin's delete → then Verify in CRM`,
      );
    }
  } catch { /* skip */ }
  // Cross-Module overlaps — same company across ≥2 modules (CONVERT/LINK/CLOSE).
  try {
    const r = await pool.query(
      `SELECT COUNT(*)::int AS n, COALESCE(SUM(estimated_pipeline_value),0)::float AS arr
         FROM duplicate_clusters
        WHERE status = 'active'
          AND ((CASE WHEN total_leads    > 0 THEN 1 ELSE 0 END
              + CASE WHEN total_contacts > 0 THEN 1 ELSE 0 END
              + CASE WHEN total_accounts > 0 THEN 1 ELSE 0 END
              + CASE WHEN total_deals    > 0 THEN 1 ELSE 0 END) >= 2)`,
    );
    const cm = Number(r.rows?.[0]?.n || 0);
    const cmArr = Number(r.rows?.[0]?.arr || 0);
    if (cm > 0) {
      parts.push(`›  *Cross-Module:* ${n(cm)} overlap(s) · ~SAR ${n(cmArr)} pipeline`);
    }
  } catch { /* skip */ }
  // CS Pipeline Overlap — an open Sales deal coexisting with a CS handoff deal.
  try {
    const { getCsOverlapVerdictCounts } = await import("./duplicateRadarDatabase");
    const v = await getCsOverlapVerdictCounts();
    if (v && (v.block || v.review || v.warn)) {
      parts.push(
        `›  *CS Pipeline Overlap:* ${n(v.block)} block · ${n(v.review)} review · ${n(v.warn)} warn`,
      );
    }
  } catch { /* skip */ }
  return parts.length ? `\n*Radar status by tab:*\n${parts.join("\n")}` : "";
}

/**
 * Post the morning/evening digest AT MOST ONCE per slot per day (Sample User
 * 2026-06-22 — fix for the digest posting twice).
 *
 * The digest has TWO triggers — the Inngest cron AND the in-process fallback —
 * which previously didn't share a guard, so both could fire minutes apart with
 * slightly different data. This claims the slot ATOMICALLY via a primary-key
 * insert: the first caller to insert the (slot, UTC-date) key wins and posts;
 * any concurrent/later caller gets rowCount 0 and skips. Both triggers MUST call
 * this instead of postResolutionDigest directly.
 */
export async function postResolutionDigestOncePerSlot(
  slot: "morning" | "evening",
): Promise<{ posted: boolean; reason?: string }> {
  try {
    await pool.query(
      `CREATE TABLE IF NOT EXISTS digest_post_claims (
         claim_key  VARCHAR(160) PRIMARY KEY,
         claimed_at TIMESTAMP NOT NULL DEFAULT NOW()
       )`,
    );
    const ymd = new Date().toISOString().slice(0, 10); // UTC date
    const key = `<REDACTED_SECRET>`;
    const claim = await pool.query(
      `INSERT INTO digest_post_claims (claim_key) VALUES ($1)
       ON CONFLICT (claim_key) DO NOTHING`,
      [key],
    );
    if ((claim.rowCount ?? 0) === 0) {
      return { posted: false, reason: "already posted this slot today" };
    }
    await postResolutionDigest({
      label: slot === "morning" ? "Start of day (9 AM KSA)" : "End of day (5 PM KSA)",
      sinceHours: slot === "morning" ? 16 : 8,
    });
    return { posted: true };
  } catch (e) {
    logger.warn("[dup-resolution-runner] postResolutionDigestOncePerSlot failed", {
      error: e instanceof Error ? e.message : String(e),
    });
    return { posted: false, reason: e instanceof Error ? e.message : String(e) };
  }
}

export async function postResolutionDigest(opts: {
  label: string;
  sinceHours: number;
}): Promise<void> {
  try {
    const token = process.env.ChatProvider_BOT_TOKEN;
    const channel = getResolutionChatProviderChannel();
    if (!token || !channel) return;

    let agentApplies = 0;
    let humanApplies = 0;
    let tagged = 0;
    let fields = 0;
    let undos = 0;
    const perModule: Record<string, number> = {};
    try {
      const r = await pool.query(
        `SELECT plan_json->>'module' AS module,
                COUNT(*) FILTER (WHERE event_type='applied' AND COALESCE(performed_by,'') NOT ILIKE 'UNDO%')::int AS applies,
                COUNT(*) FILTER (WHERE event_type='applied' AND COALESCE(performed_by,'') NOT ILIKE 'UNDO%'
                                 AND (COALESCE(performed_by,'') ILIKE '%GRQ Assistant%' OR COALESCE(performed_by,'') ILIKE '%Autonomous Agent%'))::int AS agent_applies,
                COALESCE(SUM(duplicates_tagged) FILTER (WHERE event_type='applied'),0)::int AS tagged,
                COALESCE(SUM(fields_migrated) FILTER (WHERE event_type='applied'),0)::int AS fields,
                COUNT(*) FILTER (WHERE COALESCE(performed_by,'') ILIKE 'UNDO%')::int AS undos
           FROM duplicate_resolution_feedback
          WHERE created_at > NOW() - ($1 || ' hours')::interval
          GROUP BY plan_json->>'module'`,
        [String(opts.sinceHours)],
      );
      for (const row of r.rows) {
        const a = Number(row.applies || 0);
        agentApplies += Number(row.agent_applies || 0);
        humanApplies += a - Number(row.agent_applies || 0);
        tagged += Number(row.tagged || 0);
        fields += Number(row.fields || 0);
        undos += Number(row.undos || 0);
        if (row.module && a > 0) perModule[row.module] = (perModule[row.module] || 0) + a;
      }
    } catch {
      /* digest aggregation best-effort */
    }
    const totalApplies = agentApplies + humanApplies;

    // Per-tab status of the whole Duplicate Radar (overview + duplicates +
    // account hints + deal compliance) — so each shift sees every tab's health.
    let scoreboard = "";
    try {
      scoreboard = await buildRadarTabStatus();
    } catch {
      /* non-fatal */
    }

    const byModule = Object.keys(perModule).length
      ? "\nBy module: " +
        Object.entries(perModule)
          .map(([m, n]) => `${m} ${n}`)
          .join(" · ")
      : "";

    const head =
      totalApplies > 0
        ? `📋 *Resolution digest — ${opts.label}* (last ${opts.sinceHours}h)\n` +
          `${totalApplies} merge(s) applied · ${tagged} tagged · ${fields} field(s) migrated` +
          (undos ? ` · ${undos} undone` : "") +
          `\n  by AssistantPersona (the agent): ${agentApplies} · by people: ${humanApplies}` +
          byModule
        : `📋 *Resolution digest — ${opts.label}* (last ${opts.sinceHours}h)\n` +
          `No merges applied in this window.`;

    const text = head + scoreboard + `\n${resolutionScreenLink()}`;
    const { WebClient } = await import("@ChatProvider/web-api");
    await new WebClient(token).chat.postMessage({ channel, text });
  } catch (e) {
    logger.warn("[dup-resolution-runner] digest failed (non-fatal)", {
      error: e instanceof Error ? e.message : String(e),
    });
  }
}

const RECORD_TYPE_TO_MODULE: Record<string, CrmModule> = {
  account: "Accounts",
  lead: "Leads",
  deal: "Deals",
  contact: "Contacts",
};

export interface ResolutionRunConfig {
  enabled: boolean;
  mode: ResolutionMode;
  /** Max clusters to process per tick (cost guard). */
  maxClusters: number;
}

/** Env-only baseline (the deploy default). */
export function getResolutionRunConfig(): ResolutionRunConfig {
  const mode = (process.env.AUTONOMOUS_RESOLUTION_MODE || "shadow").toLowerCase();
  const safeMode: ResolutionMode =
    mode === "assisted" || mode === "autonomous" ? (mode as ResolutionMode) : "shadow";
  const max = Number(process.env.AUTONOMOUS_RESOLUTION_MAX_CLUSTERS);
  return {
    enabled: process.env.AUTONOMOUS_RESOLUTION_ENABLED === "true",
    mode: safeMode,
    maxClusters: Number.isFinite(max) && max > 0 ? Math.floor(max) : 100,
  };
}

// ── In-platform mode override (DB-backed; overlays the env baseline) ───────────
// Lets an admin promote shadow → assisted → autonomous (and the kill switch)
// from the dashboard WITHOUT editing HostingPlatform env / republishing — it takes effect
// on the next tick. The agent never changes its own mode (segregation of duties).

let _settingsReady = false;
async function ensureResolutionSettingsTable(): Promise<void> {
  if (_settingsReady) return;
  await pool.query(`
    CREATE TABLE IF NOT EXISTS autonomous_resolution_settings (
      id INTEGER PRIMARY KEY DEFAULT 1,
      enabled BOOLEAN,
      mode VARCHAR(16),
      updated_by VARCHAR(255),
      updated_at TIMESTAMP DEFAULT NOW(),
      CONSTRAINT autonomous_resolution_settings_singleton CHECK (id = 1)
    );
  `);
  _settingsReady = true;
}

export interface ResolutionSettingOverride {
  enabled: boolean | null;
  mode: ResolutionMode | null;
  updatedBy: string | null;
  updatedAt: string | null;
}

export async function getResolutionSettingOverride(): Promise<ResolutionSettingOverride | null> {
  try {
    await ensureResolutionSettingsTable();
    const r = await pool.query(
      `SELECT enabled, mode, updated_by, updated_at FROM autonomous_resolution_settings WHERE id = 1`,
    );
    if (!r.rows.length) return null;
    const row = r.rows[0];
    const mode =
      row.mode === "shadow" || row.mode === "assisted" || row.mode === "autonomous"
        ? (row.mode as ResolutionMode)
        : null;
    return {
      enabled: row.enabled === null || row.enabled === undefined ? null : !!row.enabled,
      mode,
      updatedBy: row.updated_by ?? null,
      updatedAt: row.updated_at ? new Date(row.updated_at).toISOString() : null,
    };
  } catch (e) {
    logger.warn("[dup-resolution-runner] getResolutionSettingOverride failed (non-fatal)", {
      error: e instanceof Error ? e.message : String(e),
    });
    return null;
  }
}

/** Persist an in-platform mode / kill-switch change. */
export async function setResolutionSetting(
  patch: { enabled?: boolean; mode?: ResolutionMode },
  updatedBy: string,
): Promise<ResolutionSettingOverride | null> {
  await ensureResolutionSettingsTable();
  const current = (await getResolutionSettingOverride()) || {
    enabled: null,
    mode: null,
    updatedBy: null,
    updatedAt: null,
  };
  const nextEnabled = patch.enabled === undefined ? current.enabled : patch.enabled;
  const nextMode = patch.mode === undefined ? current.mode : patch.mode;
  await pool.query(
    `INSERT INTO autonomous_resolution_settings (id, enabled, mode, updated_by, updated_at)
     VALUES (1, $1, $2, $3, NOW())
     ON CONFLICT (id) DO UPDATE
       SET enabled = EXCLUDED.enabled, mode = EXCLUDED.mode,
           updated_by = EXCLUDED.updated_by, updated_at = NOW()`,
    [nextEnabled, nextMode, updatedBy],
  );
  return getResolutionSettingOverride();
}

/** Effective config = env baseline with the DB override applied per-field. */
export async function resolveResolutionRunConfig(): Promise<
  ResolutionRunConfig & { source: "env" | "override"; updatedBy: string | null; updatedAt: string | null }
> {
  const base = getResolutionRunConfig();
  const ov = await getResolutionSettingOverride();
  if (!ov || (ov.enabled === null && ov.mode === null)) {
    return { ...base, source: "env", updatedBy: null, updatedAt: null };
  }
  return {
    enabled: ov.enabled === null ? base.enabled : ov.enabled,
    mode: ov.mode === null ? base.mode : ov.mode,
    maxClusters: base.maxClusters,
    source: "override",
    updatedBy: ov.updatedBy,
    updatedAt: ov.updatedAt,
  };
}

/**
 * Hard environment guardrail. The agent must NEVER mutate the SHARED live CRMProvider
 * org from a non-production environment, even when the kill switch is on and the
 * mode is assisted/autonomous. Dev and prod share the same CRMProvider credentials but
 * run on SEPARATE databases, so a dev tick (or a dev operator flipping the
 * toggle) could otherwise tag/merge real CRM records. Live writes therefore
 * require BOTH `NODE_ENV=production` AND the operator's explicit kill-switch +
 * mode. Set `RESOLUTION_ALLOW_WRITES_OUTSIDE_PROD=true` only for a dedicated
 * non-prod org that does NOT share production's CRMProvider creds.
 */
export function liveWritesPermitted(
  cfg: { enabled: boolean },
  mode: ResolutionMode,
): boolean {
  return (
    CRMProviderWritesAllowedInEnv() &&
    cfg.enabled &&
    (mode === "assisted" || mode === "autonomous")
  );
}

// ── Pure: build the risk-gate input from a cluster + its records + the plan ───

/** Stages we treat as "active" (anything not explicitly lost/dead/junk). */
function isActiveStage(stage: string | null | undefined): boolean {
  if (!stage) return false;
  return !/lost|dead|junk|disqualif/i.test(stage);
}

export interface BuildRiskInputArgs {
  module: CrmModule;
  cluster: Pick<
    DuplicateCluster,
    | "confidence_score"
    | "cs_overlap_verdict"
    | "estimated_pipeline_value"
    | "arr_exposure"
    | "verification_state"
    | "total_leads"
    | "total_deals"
    | "total_contacts"
    | "total_accounts"
  >;
  /** The DuplicateRecords of THIS module's record type (for stage inspection). */
  moduleRecords: Pick<DuplicateRecord, "stage">[];
  plan: MergePlan;
  mixed: { domains: string[]; phones: string[] };
  /** Epoch ms — injectable for tests. */
  nowMs: number;
  /** Count of to-be-tagged duplicates carrying CRMProvider attachments (default 0). */
  duplicatesWithAttachments?: number;
}

export function buildResolutionRiskInput(args: BuildRiskInputArgs): ResolutionRiskInput {
  const { module, cluster, moduleRecords, plan, mixed, nowMs } = args;
  const included = plan.records.filter((r) => r.included);
  const master = plan.records.find((r) => r.isMaster);

  const presentTypes = [
    cluster.total_leads || 0,
    cluster.total_deals || 0,
    cluster.total_contacts || 0,
    cluster.total_accounts || 0,
  ].filter((n) => n > 0).length;

  const owners = new Set(
    included.map((r) => (r.owner || "").trim()).filter((o) => o !== ""),
  );
  const layouts = new Set(
    included.map((r) => (r.layout || "").trim()).filter((l) => l !== ""),
  );

  let minDays = Infinity;
  for (const r of included) {
    if (!r.modifiedDate) continue;
    const t = Date.parse(r.modifiedDate);
    if (Number.isNaN(t)) continue;
    const days = (nowMs - t) / 86_400_000;
    if (days < minDays) minDays = days;
  }

  return {
    module,
    confidenceScore: cluster.confidence_score ?? 0,
    mixedDomains: mixed.domains.length,
    mixedPhones: mixed.phones.length,
    csOverlapVerdict: cluster.cs_overlap_verdict ?? null,
    pipelineValue: cluster.estimated_pipeline_value ?? 0,
    arrExposure: cluster.arr_exposure ?? 0,
    verificationFailed: cluster.verification_state === "failed",
    conflictCount: plan.fieldDecisions.filter((d) => d.action === "conflict").length,
    hasCustomFieldAssumption: plan.warnings.some((w) => /custom field/i.test(w)),
    anyMissingCRMProviderId: plan.masterCRMProviderId == null || included.some((r) => !r.hasCRMProviderId),
    masterCompleteness: master?.completeness ?? 0,
    distinctOwners: owners.size,
    distinctLayouts: layouts.size,
    minDaysSinceModified: minDays,
    anyActiveDealStage:
      module === "Deals" && moduleRecords.some((r) => isActiveStage(r.stage)),
    isCrossModule: presentTypes > 1,
    duplicatesWithAttachments: args.duplicatesWithAttachments ?? 0,
  };
}

/** Compact, normalized features for rule-matching (what Sample User's rules key on). */
export function buildRuleFeatures(
  input: ResolutionRiskInput,
): Record<string, unknown> {
  return {
    module: input.module,
    mixedDomains: input.mixedDomains >= 2,
    mixedPhones: input.mixedPhones >= 2,
    layoutSplit: input.distinctLayouts >= 2,
    multiOwner: input.distinctOwners > 1,
    crossModule: input.isCrossModule,
    csOverlap: input.csOverlapVerdict,
    hasPipeline: input.pipelineValue > 0 || input.arrExposure > 0,
  };
}

// ── Run summary ───────────────────────────────────────────────────────────────

export interface ResolutionRunItem {
  clusterId: number;
  module: CrmModule;
  verdict: "auto" | "escalate";
  ruleOverride: "auto" | "escalate" | null;
  reasons: string[];
  action: "applied" | "queued" | "shadow_queued" | "skipped" | "error";
  detail?: string;
}

export interface ResolutionRunSummary {
  startedAt: string;
  finishedAt: string;
  mode: ResolutionMode;
  enabled: boolean;
  clustersScanned: number;
  plansBuilt: number;
  applied: number;
  queued: number;
  /** Sample User 2026-06-17 — plans rejected by the quality gates BEFORE queueing
   *  (0-duplicate plans, "test" survivors, sprawling low-confidence clusters,
   *  100+ phone clusters, etc.). Surfaces on /autonomous-resolution + the
   *  twice-daily digest so the operator can see what the agent declined. */
  skipped: number;
  errors: number;
  /** Effective write permission AFTER the environment guardrail (dev = false even when enabled). */
  writesAllowed: boolean;
  items: ResolutionRunItem[];
}

function riskLevelFor(reasons: string[]): "low" | "medium" | "high" | "critical" {
  if (reasons.length === 0) return "low";
  const text = reasons.join(" ").toLowerCase();
  if (/pipeline|arr|active deal|cs overlap/.test(text)) return "critical";
  if (/confidence|conflict|no CRMProvider id|verification/.test(text)) return "high";
  return "medium";
}

/**
 * Run one full autonomous-resolution tick. Safe to call from cron, the
 * in-process fallback, or a manual admin endpoint. Never throws — failures are
 * captured per-cluster and in the summary.
 */
export async function runAutonomousResolution(
  opts: { now?: number; modeOverride?: ResolutionMode } = {},
): Promise<ResolutionRunSummary> {
  const startedAt = new Date().toISOString();
  const nowMs = opts.now ?? Date.now();
  const cfg = await resolveResolutionRunConfig();
  const mode = opts.modeOverride ?? cfg.mode;
  const policyCfg = getResolutionPolicyConfig();

  const summary: ResolutionRunSummary = {
    startedAt,
    finishedAt: startedAt,
    mode,
    enabled: cfg.enabled,
    clustersScanned: 0,
    plansBuilt: 0,
    applied: 0,
    queued: 0,
    skipped: 0,
    errors: 0,
    writesAllowed: false,
    items: [],
  };

  // Writes only happen in assisted/autonomous AND when the kill switch is on
  // AND we are in production (the dev environment shares prod's live CRMProvider creds).
  const writesAllowed = liveWritesPermitted(cfg, mode);
  summary.writesAllowed = writesAllowed;

  try {
    await initAIApprovalTable().catch(() => {});

    const clusters = await getAllClusters({ status: "active", limit: cfg.maxClusters });
    logger.info("[dup-resolution-runner] tick start", {
      mode,
      enabled: cfg.enabled,
      writesAllowed,
      clusters: clusters.length,
    });

    for (const cluster of clusters) {
      await processCluster({ cluster, nowMs, mode, writesAllowed, policyCfg, summary });
    }

    // Learning-curve snapshot every tick (best-effort).
    await snapshotGrades().catch(() => {});
  } catch (e) {
    summary.errors++;
    logger.error("[dup-resolution-runner] tick failed", {
      error: e instanceof Error ? e.message : String(e),
    });
  }

  await pingResolutionChatProvider(summary).catch(() => {});

  summary.finishedAt = new Date().toISOString();
  logger.info("[dup-resolution-runner] tick done", {
    scanned: summary.clustersScanned,
    plans: summary.plansBuilt,
    applied: summary.applied,
    queued: summary.queued,
    errors: summary.errors,
  });
  return summary;
}

/**
 * Re-do: re-run the resolution for ONE cluster now (Agent Activity log action).
 * Honours the same mode/kill-switch as the scheduled tick.
 */
export async function runResolutionForCluster(
  clusterId: number,
  opts: { now?: number; modeOverride?: ResolutionMode } = {},
): Promise<ResolutionRunSummary> {
  const startedAt = new Date().toISOString();
  const nowMs = opts.now ?? Date.now();
  const cfg = await resolveResolutionRunConfig();
  const mode = opts.modeOverride ?? cfg.mode;
  const policyCfg = getResolutionPolicyConfig();
  const writesAllowed = liveWritesPermitted(cfg, mode);

  const summary: ResolutionRunSummary = {
    startedAt,
    finishedAt: startedAt,
    mode,
    enabled: cfg.enabled,
    clustersScanned: 0,
    plansBuilt: 0,
    skipped: 0,
    applied: 0,
    queued: 0,
    errors: 0,
    writesAllowed,
    items: [],
  };
  try {
    await initAIApprovalTable().catch(() => {});
    const cluster = await getClusterById(clusterId);
    if (!cluster) {
      summary.errors++;
      summary.items.push({
        clusterId,
        module: "Accounts",
        verdict: "escalate",
        ruleOverride: null,
        reasons: ["cluster not found"],
        action: "error",
      });
    } else {
      await processCluster({ cluster, nowMs, mode, writesAllowed, policyCfg, summary });
    }
  } catch (e) {
    summary.errors++;
    logger.error("[dup-resolution-runner] run-cluster failed", {
      clusterId,
      error: e instanceof Error ? e.message : String(e),
    });
  }
  summary.finishedAt = new Date().toISOString();
  return summary;
}

/**
 * Undo the agent's last apply on a cluster: remove the Duplicate-Delete tags it
 * placed and reopen the cluster for review. Field gap-fills onto the survivor
 * are left in place — they only filled blanks (non-destructive). Reverses the
 * one consequential, irreversible-by-others signal (the admin delete-tag).
 */
export async function undoClusterResolution(
  clusterId: number,
  performedBy = AGENT_PERFORMED_BY,
): Promise<{ ok: boolean; untagged: number; module: string | null; message: string }> {
  try {
    const r = await pool.query(
      `SELECT plan_json, report_json
         FROM duplicate_resolution_feedback
        WHERE cluster_id = $1 AND event_type = 'applied'
        ORDER BY created_at DESC LIMIT 1`,
      [clusterId],
    );
    if (!r.rows.length) {
      return { ok: false, untagged: 0, module: null, message: "No applied action found for this cluster." };
    }
    const plan = r.rows[0].plan_json
      ? typeof r.rows[0].plan_json === "string"
        ? JSON.parse(r.rows[0].plan_json)
        : r.rows[0].plan_json
      : {};
    const report = r.rows[0].report_json
      ? typeof r.rows[0].report_json === "string"
        ? JSON.parse(r.rows[0].report_json)
        : r.rows[0].report_json
      : {};
    const module: string = plan.module || "Accounts";
    const taggedIds: string[] = (report.taggedRecordIds || plan.duplicateCRMProviderIds || []).filter(
      Boolean,
    );
    // Undo is ALSO a live CRMProvider mutation (it removes the Duplicate-Delete tag),
    // so it must obey the same environment guardrail as executeMergePlan — dev
    // shares prod's CRMProvider creds and must never touch the real org.
    if (taggedIds.length && !CRMProviderWritesAllowedInEnv()) {
      return {
        ok: false,
        untagged: 0,
        module,
        message:
          "Undo is blocked outside production (dev shares production's CRMProvider credentials). Undo from the deployed app, or set RESOLUTION_ALLOW_WRITES_OUTSIDE_PROD=true only for a dedicated non-prod CRMProvider org.",
      };
    }
    let untagged = 0;
    if (taggedIds.length) {
      await removeCRMProviderTags(module, taggedIds, ["Duplicate-Delete"]);
      untagged = taggedIds.length;
    }
    await updateClusterStatus(clusterId, "active").catch(() => {});
    await recordResolutionEvent({
      clusterId,
      eventType: "dry_run", // closest available type; performedBy marks it an UNDO
      plan,
      performedBy: `UNDO by ${performedBy}`,
    }).catch(() => {});
    logger.info("[dup-resolution-runner] undo complete", { clusterId, module, untagged });
    return {
      ok: true,
      untagged,
      module,
      message: `Removed the Duplicate-Delete tag from ${untagged} record(s) and reopened cluster #${clusterId}. Survivor gap-fills were kept (they only filled blanks).`,
    };
  } catch (e) {
    return {
      ok: false,
      untagged: 0,
      module: null,
      message: e instanceof Error ? e.message : String(e),
    };
  }
}

/** Process every module-present in one cluster. Shared by the full tick and
 *  the single-cluster Re-do path. Mutates `summary` in place. */
async function processCluster(ctx: {
  cluster: DuplicateCluster;
  nowMs: number;
  mode: ResolutionMode;
  writesAllowed: boolean;
  policyCfg: ReturnType<typeof getResolutionPolicyConfig>;
  summary: ResolutionRunSummary;
}): Promise<void> {
  const { cluster, nowMs, mode, writesAllowed, policyCfg, summary } = ctx;
  const clusterId = cluster.id;
  if (clusterId == null) return;
  summary.clustersScanned++;

  let records: DuplicateRecord[];
  try {
    records = await getRecordsByClusterId(clusterId);
  } catch (e) {
    summary.errors++;
    logger.error("[dup-resolution-runner] load-records failed", {
      clusterId,
      error: e instanceof Error ? e.message : String(e),
    });
    summary.items.push({
      clusterId,
      module: "Accounts",
      verdict: "escalate",
      ruleOverride: null,
      reasons: ["could not load cluster records"],
      action: "error",
      detail: e instanceof Error ? e.message : String(e),
    });
    return;
  }

  const byType = new Map<string, DuplicateRecord[]>();
  for (const r of records) {
    const arr = byType.get(r.record_type) || [];
    arr.push(r);
    byType.set(r.record_type, arr);
  }

  let mixed = { domains: [] as string[], phones: [] as string[] };
  try {
    const m = await getClusterMixedSignal(clusterId);
    mixed = { domains: m.domains, phones: m.phones };
  } catch {
    /* non-fatal */
  }

  for (const [recordType, moduleRecords] of byType.entries()) {
    const module = RECORD_TYPE_TO_MODULE[recordType];
    if (!module || moduleRecords.length < 2) continue;
    await processModule({
      cluster,
      clusterId,
      module,
      allRecords: records,
      moduleRecords,
      mixed,
      nowMs,
      mode,
      writesAllowed,
      policyCfg,
      summary,
    });
  }
}

async function processModule(ctx: {
  cluster: DuplicateCluster;
  clusterId: number;
  module: CrmModule;
  allRecords: DuplicateRecord[];
  moduleRecords: DuplicateRecord[];
  mixed: { domains: string[]; phones: string[] };
  nowMs: number;
  mode: ResolutionMode;
  writesAllowed: boolean;
  policyCfg: ReturnType<typeof getResolutionPolicyConfig>;
  summary: ResolutionRunSummary;
}): Promise<void> {
  const {
    cluster,
    clusterId,
    module,
    allRecords,
    moduleRecords,
    mixed,
    nowMs,
    mode,
    writesAllowed,
    policyCfg,
    summary,
  } = ctx;

  let plan: MergePlan;
  try {
    plan = buildMergePlan(module, clusterId, allRecords, {
      generatedBy: AGENT_PERFORMED_BY,
      generatedAt: new Date(nowMs).toISOString(),
    });
    summary.plansBuilt++;
  } catch (e) {
    summary.errors++;
    logger.error("[dup-resolution-runner] plan-build failed", {
      clusterId,
      module,
      error: e instanceof Error ? e.message : String(e),
    });
    summary.items.push({
      clusterId,
      module,
      verdict: "escalate",
      ruleOverride: null,
      reasons: ["plan build failed"],
      action: "error",
      detail: e instanceof Error ? e.message : String(e),
    });
    return;
  }

  let riskInput = buildResolutionRiskInput({
    module,
    cluster,
    moduleRecords,
    plan,
    mixed,
    nowMs,
  });
  const features = buildRuleFeatures(riskInput);

  // Rules consulted BEFORE the gate — they may flip the verdict ("don't re-ask").
  const ruleResult = await evaluateRules(module, features, clusterId).catch(() => ({
    override: null as "auto" | "escalate" | null,
    alwaysLink: false,
    ruleIds: [] as number[],
  }));

  // Evidence-protection check is a CRMProvider call, so run it ONLY for clusters that
  // would otherwise auto-apply (and aren't already rule-blocked). If any
  // to-be-tagged duplicate carries attachments, the gate escalates — we never
  // auto-merge away a record that might hold a signed contract/NDA. When it
  // fires, we name the evidence-holder and recommend keeping IT as the survivor
  // (escalate-with-recommendation — the operator makes the final call).
  let evidenceRecommendation: string | null = null;
  let firstPass = evaluateResolutionRisk(riskInput, policyCfg);
  if (ruleResult.override !== "escalate" && firstPass.verdict === "auto") {
    const dupAttach = await attachmentsOnDuplicates(module, plan.duplicateCRMProviderIds);
    if (dupAttach.length > 0) {
      riskInput = { ...riskInput, duplicatesWithAttachments: dupAttach.length };
      const nameOf = (Sample User: string) =>
        plan.records.find((r) => r.CRMProviderId === Sample User)?.name || Sample User;
      // Strongest evidence-holder = highest known count (unknown counts sort last).
      const strongest = [...dupAttach].sort(
        (a, b) => (b.count < 0 ? 0 : b.count) - (a.count < 0 ? 0 : a.count),
      )[0];
      const cntTxt = strongest.count < 0 ? "attachments (count unverified)" : `${strongest.count} attachment(s)`;
      evidenceRecommendation =
        `Evidence on a to-be-deleted record: "${nameOf(strongest.CRMProviderId)}" (${strongest.CRMProviderId}) holds ${cntTxt}. ` +
        `Recommend keeping THAT record as the survivor (or move its files first), then re-run. ` +
        (dupAttach.length > 1 ? `${dupAttach.length} duplicates carry files — attachments are split, review carefully.` : "");
    }
  }

  const gate: ResolutionRiskVerdict = evaluateResolutionRisk(riskInput, policyCfg);
  const verdict: "auto" | "escalate" = ruleResult.override ?? gate.verdict;
  const reasons =
    ruleResult.override === "auto"
      ? [`auto-approved by learned rule(s) #${ruleResult.ruleIds.join(", #")}`]
      : ruleResult.override === "escalate"
        ? [`blocked by learned rule(s) #${ruleResult.ruleIds.join(", #")}`, ...gate.reasons]
        : gate.reasons;
  if (evidenceRecommendation) reasons.push(evidenceRecommendation);

  // Apply the always-link rule hint to the plan if present and unset.
  if (ruleResult.alwaysLink && !plan.linkAccountCRMProviderId && plan.accountCandidates.length) {
    plan.linkAccountCRMProviderId = plan.accountCandidates[0].CRMProviderId;
  }

  const item: ResolutionRunItem = {
    clusterId,
    module,
    verdict,
    ruleOverride: ruleResult.override,
    reasons,
    action: "skipped",
  };

  // ─── Sample User 2026-06-17 — plan-quality gates ─────────────────────────────
  //
  // The bulk-reject sweep (June 17) cleared ~3,600 pending proposals that
  // were structurally bad: 0-duplicate plans queued anyway after the
  // Contacts strict-match rule correctly excluded everyone; survivors
  // literally named "test"; clusters spanning 192 distinct phones across
  // 3 corporate domains (different companies). The verdict gate caught
  // these as "escalate" (good — they didn't auto-apply) but the runner
  // still queued them, flooding the approval queue with junk.
  //
  // These gates make the resolver SILENT on these classes instead of
  // queueing for human review. Each gate is conservative and only
  // applies when the plan is plainly not actionable. Match leaves an
  // entry in summary.items so the gate firings are visible on the
  // /autonomous-resolution screen + the twice-daily digest.
  const skipReasons: string[] = [];
  const survivorName = (plan.masterName || "").trim().toLowerCase();
  const clusterRecordCount = Number(
    (cluster as any).total_records ?? moduleRecords.length,
  );
  const clusterConfidence = Number((cluster as any).confidence_score ?? 0);

  // (1) Nothing to do — no duplicates and no link target.
  if (plan.duplicateCRMProviderIds.length === 0 && !plan.linkAccountCRMProviderId) {
    skipReasons.push(
      "plan has 0 duplicates to tag and no Account_Name link target — nothing actionable",
    );
  }
  // (2) Garbage survivor name — "test", "demo", empty, 1-char, etc.
  // A survivor named "test" almost certainly means the cluster is built
  // around a stale test record and shouldn't drive a real merge.
  if (
    !survivorName ||
    survivorName.length < 2 ||
    /^(test|demo|temp|sample|na|n\/a|none|null|unknown|x|xx|xxx|xxxx|aaa|aaaa|untitled|new|new lead|new contact)$/i.test(
      survivorName,
    )
  ) {
    skipReasons.push(
      `survivor name "${plan.masterName}" looks like garbage — cluster needs human review, not auto-resolve`,
    );
  }
  // (3) Sprawling low-confidence cluster — engine grouped too loosely.
  // Confidence < 30% AND cluster > 10 records means the cluster engine
  // itself isn't sure these are duplicates; a merge proposal at that
  // signal-to-noise ratio creates more harm than it prevents.
  if (clusterConfidence < 30 && clusterRecordCount > 10) {
    skipReasons.push(
      `cluster confidence ${clusterConfidence}% is too low for a ${clusterRecordCount}-record cluster — needs cluster-engine re-segmentation, not resolution approval`,
    );
  }
  // (4) Wildly heterogeneous cluster — too many phones / domains for ONE
  // company. 192 phones at "Ministry of Health" means 192 distinct
  // employees grouped together; that's a cluster-engine fault, not a
  // duplicate-resolution task.
  if (mixed.phones.length > 50) {
    skipReasons.push(
      `${mixed.phones.length} distinct phone numbers in the cluster — likely distinct employees, not duplicate records`,
    );
  }
  if (mixed.domains.length > 5) {
    skipReasons.push(
      `${mixed.domains.length} distinct corporate domains — different companies grouped together; cluster engine needs re-segmentation`,
    );
  }
  if (skipReasons.length > 0) {
    item.action = "skipped";
    item.reasons = [
      ...item.reasons,
      ...skipReasons.map((r) => `quality-gate: ${r}`),
    ];
    item.detail = "Quality gate fired — plan not queued for approval";
    summary.items.push(item);
    summary.skipped++;
    return;
  }

  // AUTO + writes allowed → apply for real (on behalf of Sample User).
  if (verdict === "auto" && writesAllowed) {
    try {
      // Forensic snapshot BEFORE any write so Undo / audit can reconstruct
      // the pre-merge state.
      await captureClusterSnapshot(clusterId, AGENT_PERFORMED_BY, "pre_agent_apply").catch(
        () => null,
      );
      const report = await executeMergePlan(plan, {
        performedBy: AGENT_PERFORMED_BY,
        dryRun: false,
        closeCluster: !riskInput.isCrossModule,
      });
      item.action = report.errors.length ? "error" : "applied";
      item.detail = report.errors.length
        ? report.errors.map((e) => e.message).join("; ")
        : `tagged ${report.taggedRecordIds.length}, fields ${report.fieldsMigrated.length}`;
      if (report.errors.length) summary.errors++;
      else summary.applied++;
      await recordResolutionEvent({
        clusterId,
        eventType: "applied",
        plan,
        report,
        fieldsMigrated: report.fieldsMigrated.length,
        duplicatesTagged: report.taggedRecordIds.length,
        reparented:
          report.reparented.deals + report.reparented.contacts + report.reparented.notes,
        errors: report.errors.length,
        performedBy: AGENT_PERFORMED_BY,
      }).catch(() => {});
      // (Apply notifications are batched into the twice-daily digest.)
    } catch (e) {
      item.action = "error";
      item.detail = e instanceof Error ? e.message : String(e);
      summary.errors++;
      logger.error("[dup-resolution-runner] apply failed", {
        clusterId,
        module,
        error: item.detail,
      });
    }
    summary.items.push(item);
    return;
  }

  // Otherwise → dry-run for the record, then queue to the approval screen.
  try {
    // DON'T re-ask (Sample User 2026-06-20): if this exact cluster+module is already
    // PENDING in the queue, or the operator REJECTED it recently, skip it. This
    // stops the 6-hourly tick from re-flooding the queue with the same clusters
    // and makes a human rejection a durable "no" the agent honours — the
    // "AssistantPersona should learn from my decisions" behaviour.
    const priorAction = await findOpenOrRejectedResolutionAction(clusterId, module).catch(
      () => null,
    );
    if (priorAction) {
      item.action = "skipped";
      item.detail =
        priorAction.status === "pending"
          ? `already queued (${priorAction.action_code}) — not re-proposing`
          : `rejected earlier (${priorAction.action_code}) — honouring your decision, not re-proposing`;
      summary.items.push(item);
      return;
    }

    await executeMergePlan(plan, { performedBy: AGENT_PERFORMED_BY, dryRun: true }).catch(
      () => {},
    );
    await recordResolutionEvent({
      clusterId,
      eventType: "dry_run",
      plan,
      performedBy: AGENT_PERFORMED_BY,
    }).catch(() => {});

    await enqueuePendingAction({
      toolId: "duplicate-resolution",
      toolLabel: `Resolve duplicates — ${module} cluster #${clusterId}`,
      payload: {
        clusterId,
        module,
        plan,
        verdict,
        ruleOverride: ruleResult.override,
        reasons,
        recommendation:
          evidenceRecommendation
            ? evidenceRecommendation
            : verdict === "auto"
              ? "Safe to apply — agent would auto-apply once autonomy is enabled."
              : "Needs your call — escalated on the reasons listed.",
        features,
      },
      payloadPreview:
        `${module} cluster #${clusterId}: survivor "${plan.masterName}", ` +
        `${plan.duplicateCRMProviderIds.length} duplicate(s) to tag. ` +
        (reasons.length ? `Escalated: ${reasons.slice(0, 3).join("; ")}.` : "Safe-tier (shadow)."),
      riskLevel: riskLevelFor(reasons),
      complianceRefs: [
        "ISO 9001:2015 §8.5.1",
        "ISO 9001:2015 §7.5",
        ...(module === "Contacts" || module === "Leads" ? ["PDPL"] : []),
        "ISO 27001 A.8.3 (non-repudiation)",
      ],
      requestedByUserId: null,
      requestedByEmail: null,
      requestedByName: AGENT_PERFORMED_BY,
      threadId: null,
      ttlHours: 24 * 14,
    });
    item.action = mode === "shadow" ? "shadow_queued" : "queued";
    summary.queued++;
  } catch (e) {
    item.action = "error";
    item.detail = e instanceof Error ? e.message : String(e);
    summary.errors++;
    logger.error("[dup-resolution-runner] enqueue/dry-run failed", {
      clusterId,
      module,
      error: item.detail,
    });
  }
  summary.items.push(item);
}
