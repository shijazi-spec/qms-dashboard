import { createRedactedPool } from "./redactedPool";
import { logger } from "./logger";
import { normalizeSslMode } from "./normalizeDatabaseUrl";
// Arabic-aware name normalizer (planner only type-imports this file, so this
// runtime import creates no cycle).
import { normalizePersonName } from "./duplicateMergePlanner";
// Segment classification (JS mirror of buildSegmentPredicate) + the Cleaning
// Progress shaper — used by getDataCleaningProgress and the segmented
// burndown writer (captureDuplicateProgressSnapshot).
import { classifySegmentFromLayout } from "./duplicateRadarSegment";
import {
  shapeCleaningProgress,
  type ResolveRowRaw,
  type DataCleaningProgress,
} from "./dataCleaningProgress";
import { shapeDealCompliance, type DealComplianceSummary } from "./dealComplianceReport";
import type { CrmNameRow } from "./companyNameBatch";

// Normalize sslmode directly on the connection string (module-scope pool —
// see src/utils/normalizeDatabaseUrl.ts for why env-var ordering is unreliable
// in the production bundle). Idempotent.
//
// statement_timeout is a RUNAWAY BACKSTOP, not a latency budget. This pool is
// shared by the radar dashboards, AssistantPersona's tools AND the CRMProvider sync jobs, so the
// default is deliberately generous (15 min): no healthy individual statement
// comes close, but a query wedged behind a lock or a bad plan now dies with a
// clear Postgres error instead of pinning one of the pool's connections
// indefinitely. Tune with DUPLICATE_RADAR_STATEMENT_TIMEOUT_MS; set 0 to
// disable. Per-request latency is bounded in the callers (e.g. the Quality
// Reports aggregator's per-section budget), not here.
const STATEMENT_TIMEOUT_MS = (() => {
  const raw = process.env.DUPLICATE_RADAR_STATEMENT_TIMEOUT_MS;
  if (raw == null || raw.trim() === "") return 900000;
  const n = parseInt(raw, 10);
  return Number.isFinite(n) && n >= 0 ? n : 900000;
})();

// max:10 overrides createRedactedPool's conservative `max: 3` default — this is
// the platform's workhorse pool (bulk sync, cluster scans, batched doc/merge
// jobs run 3-5 concurrent), so it keeps the head-room it has always had while
// the ~35 low-traffic module pools shrink to relieve the provider's connection
// cap (see the connection-budget note in redactedPool.ts).
const pool = createRedactedPool({
  connectionString: normalizeSslMode(process.env.DATABASE_URL),
  max: 10,
  ...(STATEMENT_TIMEOUT_MS > 0 ? { statement_timeout: STATEMENT_TIMEOUT_MS } : {}),
});

export interface DuplicateCluster {
  id?: number;
  domain: string;
  company_name?: string;
  company_name_arabic?: string;
  company_name_normalized?: string;
  total_leads: number;
  total_deals: number;
  total_contacts: number;
  total_accounts: number;
  total_records: number;
  confidence_level: "high" | "medium" | "low";
  confidence_score: number;
  match_signals?: string[];
  first_record_date?: Date;
  latest_activity_date?: Date;
  owners_involved?: string[];
  estimated_pipeline_value?: number;
  status: "active" | "resolved" | "ignored";
  ai_recommendation?: string;
  resolved_by?: string;
  resolved_at?: Date;
  /** CS-pipeline-overlap verdict: block (active customer), review (within churn cool-off), warn (past cool-off, sales may re-engage), null (no overlap). */
  cs_overlap_verdict?: "block" | "review" | "warn" | null;
  /** Aggregated ARR exposure across the CS-pipeline deals in this cluster. */
  arr_exposure?: number;
  /** Strongest active CS phase observed in the cluster (onboarding > adoption > renewal > termination_recent > termination_old). */
  pipeline_lifecycle_state?:
    | "onboarding"
    | "adoption"
    | "renewal"
    | "termination_recent"
    | "termination_old"
    | null;
  /** Client sector derived from gov_type field or domain heuristic ("private" | "government"). */
  client_sector?: "private" | "government" | null;
  /** R3: post-merge CRMProvider verification outcome — 'verified' (records confirmed gone), 'failed' (records still in CRMProvider), or null (never verified). */
  verification_state?: "verified" | "failed" | "pending" | null;
  verification_at?: Date | null;
  verification_notes?: string | null;
  created_at?: Date;
  updated_at?: Date;
}

export interface DuplicateRecord {
  id?: number;
  cluster_id: number;
  record_type: "lead" | "deal" | "contact" | "account";
  CRMProvider_record_id?: string;
  record_name: string;
  company_name?: string;
  email?: string;
  domain?: string;
  phone?: string;
  phone_normalized?: string;
  mobile?: string;
  mobile_normalized?: string;
  owner_name?: string;
  owner_email?: string;
  status?: string;
  stage?: string;
  deal_value?: number;
  source?: string;
  created_date?: Date;
  modified_date?: Date;
  is_primary: boolean;
  ai_recommendation?: string;
  confidence_score: number;
  match_signals?: string[];
  is_mock_data: boolean;
  raw_data?: any;
  layout_name?: string;
  layout_id?: string;
  CRMProvider_module?: string;
  pipeline?: string;
  products?: string;
  contact_name?: string;
  account_name?: string;
  cr_number?: string;
  vat_number?: string;
  website?: string;
  country?: string;
  region?: string;
  industry?: string;
  no_of_employees?: number;
  title?: string;
  lead_type?: string;
  gov_type?: string;
  account_type?: string;
  created_at?: Date;
}

export interface CRMProviderSyncState {
  module: string;
  last_sync_at?: Date;
  total_synced: number;
  sync_status: "idle" | "syncing" | "completed" | "failed";
}

export interface DuplicateRecordTask {
  id?: number;
  CRMProvider_task_id: string;
  related_record_id?: string;
  cluster_id?: number;
  subject?: string;
  due_date?: Date;
  status?: string;
  owner_name?: string;
  description?: string;
  created_at?: Date;
}

export interface DuplicateFilters {
  modules?: string[];
  owners?: string[];
  layouts?: string[];
  pipelines?: string[];
  stages?: string[];
  domain?: string;
  start_date?: string;
  end_date?: string;
  /**
   * Quarter / year chip shared by every duplicate tab. Filters on the CRM's
   * dates (first_record_date), NOT on when our clustering saw the cluster —
   * see the DATE_BASIS note in buildClusterFilterClause for why that
   * distinction matters. `period_year` alone means the whole year;
   * `period_quarter` narrows it to Q1..Q4.
   */
  period_year?: number;
  period_quarter?: number;
  status?: string;
  confidence_level?: string;
  /**
   * Marketplace / Corporate segmentation. UI exposes this as a 3-way chip
   * + matching dropdown in Advanced Filters. Server maps it to layout_name:
   *   "marketplace" → layout CONTAINS 'marketplace' or 'partner account'
   *                    (e.g. "Doam Marketplace"), read from layout_name with a
   *                    raw_data Layout fallback
   *   "corporate"   → NOT marketplace (incl. NULL/empty = treat as corporate)
   *   "all" / undef → no constraint (current behavior)
   * Both segments stay actionable inside the radar — this is for comparison,
   * not for hiding records.
   */
  segment?: "all" | "marketplace" | "corporate" | "ExampleOrg" | "Example Organization";
  /**
   * AI-status chip: active (untouched) | tagged_pending | resolved | dismissed
   * | all. Absent from this interface until 2026-08-19, which is why
   * /filtered-clusters could not pass it and every chip returned the same
   * unfiltered list.
   */
  ai_status?: string;
}

/**
 * Returns the SQL predicate (no leading AND), the parameter values, and
 * whether the predicate references the `duplicate_records r` alias (so
 * callers know they need to add the record-table JOIN). `paramOffset` is
 * the next $N number to use — caller advances its own paramIdx by the
 * length of the returned params array.
 *
 * "marketplace" matches CRMProvider layouts the team treats as merchant /
 *   marketplace (currently "Marketplace" and "Partner Accounts" —
 *   matches the existing exclusion logic in cross-module / preflight).
 * "corporate" is the complement, defaulting NULL/empty to corporate so
 *   legacy records without an explicit layout aren't lost to the filter.
 */
/**
 * FAST SEGMENT PATH (opt-in via DUPLICATE_RADAR_FAST_SEGMENT=true).
 *
 * The classification below is per-row and expensive: LOWER + regexp_replace +
 * three leading-wildcard LIKEs on every row of duplicate_records, for a
 * predicate used by ~36 call sites across every radar tab. No index can help —
 * the ExampleOrg branch is a NEGATED leading-wildcard LIKE matching the majority
 * of the table, so a sequential scan is the correct plan and always will be.
 * The cost isn't lookup, it's recomputing the same regex per row.
 *
 * But `layout_name` only ever holds a handful of DISTINCT values. So we
 * classify those distinct values once (using classifySegmentFromLayout, the
 * exact JS mirror of the SQL below) and reduce the per-row test to an array
 * membership check against a short list.
 *
 * CORRECTNESS RULE — the cache is an optimization, never a source of truth.
 * The emitted predicate keeps the original expression as a live fallback for
 * any row whose layout is blank OR is not in the cached set. So a stale cache
 * (a layout added since the last refresh) makes those rows SLOWER, never
 * misclassified. That property is what makes this safe to run against numbers
 * that drive KPIs; verify it with scripts/checkSegmentPredicateParity.ts.
 */
const FAST_SEGMENT_ENABLED = process.env.DUPLICATE_RADAR_FAST_SEGMENT === "true";
const LAYOUT_CACHE_TTL_MS = 10 * 60 * 1000;

type LayoutSegmentCache = {
  at: number;
  all: string[];
  bySegment: Record<"marketplace" | "Example Organization" | "ExampleOrg", string[]>;
};
let layoutCache: LayoutSegmentCache | null = null;
let layoutCacheInFlight: Promise<LayoutSegmentCache> | null = null;

/** Reads the distinct layout values and classifies them. Cheap: served by idx_duplicate_records_layout. */
export async function refreshLayoutSegmentCache(): Promise<LayoutSegmentCache> {
  if (layoutCacheInFlight) return layoutCacheInFlight;
  layoutCacheInFlight = (async () => {
    const r = await pool.query(
      `SELECT DISTINCT layout_name FROM duplicate_records
        WHERE layout_name IS NOT NULL AND layout_name <> ''`,
    );
    const bySegment: LayoutSegmentCache["bySegment"] = {
      marketplace: [], Example Organization: [], ExampleOrg: [],
    };
    const all: string[] = [];
    for (const row of r.rows) {
      const name = String(row.layout_name);
      all.push(name);
      bySegment[classifySegmentFromLayout(name)].push(name);
    }
    layoutCache = { at: Date.now(), all, bySegment };
    return layoutCache;
  })().finally(() => { layoutCacheInFlight = null; });
  return layoutCacheInFlight;
}

function freshLayoutCache(): LayoutSegmentCache | null {
  if (!layoutCache) return null;
  if (Date.now() - layoutCache.at > LAYOUT_CACHE_TTL_MS) return null;
  return layoutCache;
}

export function buildSegmentPredicate(
  segment: DuplicateFilters["segment"],
  paramOffset: number,
): { condition: string | null; params: any[]; needsRecordJoin: boolean } {
  if (!segment || segment === "all") {
    return { condition: null, params: [], needsRecordJoin: false };
  }
  // Marketplace layouts are matched by SUBSTRING, not exact name (Sample User
  // 2026-07-15): the real CRMProvider layouts are "Doam Marketplace", "Marketplace",
  // "Partner Accounts", etc. — an exact `IN ('marketplace','partner accounts')`
  // let "Doam Marketplace" fall through into ExampleOrg. Match any layout that
  // CONTAINS "marketplace" (normalized) or "partneraccounts". Patterns compare
  // against NORM (below), which is already lowercased + alphanumeric-only.
  const markers = ["%marketplace%", "%partneraccounts%"];
  // Layout source (Sample User 2026-07-14): a Marketplace-layout deal was leaking into
  // the ExampleOrg segment because its `layout_name` COLUMN was blank — and blank
  // layouts default into ExampleOrg. Fall back to the synced raw_data Layout (CRMProvider
  // returns Layout as {id,name} under `Layout` and/or the system `$layout`; some
  // records only carry the plain string) so a record whose column wasn't
  // populated STILL segments by its true layout instead of defaulting to ExampleOrg.
  const LAYOUT =
    "LOWER(COALESCE(NULLIF(r.layout_name,''), r.raw_data#>>'{Layout,name}', r.raw_data#>>'{$layout,name}', r.raw_data->>'Layout', ''))";
  // Normalized layout (non-alphanumeric stripped) so "Example Organization" / "ExampleOrg One" /
  // "ExampleOrg-one" all match 'Example Organization' and "Doam Marketplace" matches '%marketplace%'.
  const NORM = `regexp_replace(${LAYOUT}, '[^a-z0-9]', '', 'g')`;
  const mktMatch = (offset: number) =>
    markers.map((_, i) => `${NORM} LIKE $${offset + i}`).join(" OR ");

  // The original per-row expression, parameterised by where its binds start so
  // the fast path can shift it after its own two array params.
  // Example Organization takes no binds; marketplace/ExampleOrg take the two markers.
  const buildExact = (offset: number): { condition: string; params: any[] } => {
    if (segment === "marketplace") {
      return { condition: `(${mktMatch(offset)})`, params: [...markers] };
    }
    if (segment === "Example Organization") {
      // Example Organization product — layout CONTAINS "Example Organization" (substring, so "Example Organization",
      // "ExampleOrg One", "Example Organization Corporate" all match). No bind params (literal).
      return { condition: `${NORM} LIKE '%Example Organization%'`, params: [] };
    }
    // "ExampleOrg" (renamed "corporate") + legacy "corporate" = NOT marketplace
    // AND NOT Example Organization. NULL/empty layout defaults here so legacy records
    // aren't lost.
    return {
      condition: `NOT (${mktMatch(offset)}) AND ${NORM} NOT LIKE '%Example Organization%'`,
      params: [...markers],
    };
  };

  const target: "marketplace" | "Example Organization" | "ExampleOrg" =
    segment === "marketplace" ? "marketplace"
      : segment === "Example Organization" ? "Example Organization"
        : "ExampleOrg";

  const cache = FAST_SEGMENT_ENABLED ? freshLayoutCache() : null;
  if (cache && cache.all.length > 0) {
    // Row is in this segment if its layout is a KNOWN layout of this segment,
    // OR its layout is blank/unknown and the original expression says so. The
    // second branch is what keeps a stale cache slow-but-correct rather than
    // wrong — never simplify it away.
    const exact = buildExact(paramOffset + 2);
    return {
      condition:
        `(r.layout_name = ANY($${paramOffset}::text[])` +
        ` OR ((r.layout_name IS NULL OR r.layout_name = ''` +
        ` OR NOT (r.layout_name = ANY($${paramOffset + 1}::text[])))` +
        ` AND (${exact.condition})))`,
      params: [cache.bySegment[target], cache.all, ...exact.params],
      needsRecordJoin: true,
    };
  }

  // Cold or stale cache: emit the original predicate (always correct) and warm
  // the cache in the background so the NEXT query gets the fast path. Never
  // awaited — this function is sync and called from 36 SQL-building sites.
  if (FAST_SEGMENT_ENABLED) {
    void refreshLayoutSegmentCache().catch((e) => {
      logger.warn("[DuplicateRadar] layout segment cache refresh failed", {
        error: e instanceof Error ? e.message : String(e),
      });
    });
  }
  const exact = buildExact(paramOffset);
  return { condition: exact.condition, params: exact.params, needsRecordJoin: true };
}

/**
 * OPEN-PIPELINE deal-stage predicate (Sample User 2026-07-29). Amount at risk =
 * OPEN pipeline only: a duplicate deal counts only if it is still live in the
 * sales pipeline — NOT a won customer (see WON_STAGES) and NOT any terminal /
 * closed stage (Closed Lost/Won, Dropped, Cancelled, Transferred to CS, Client
 * Activated). `alias` is the duplicate_records table alias.
 * Single source of truth so the exec headline, AssistantPersona's digest, the Top Clusters
 * panel and the View-all modal all agree.
 *
 * NOT excluded, deliberately, because they are ambiguous rather than clearly
 * won — flagged for Sample User 2026-08-23 and left as OPEN until confirmed:
 *   Partner Ready for Activation · Content in Process · Design in Process
 *     — marketplace production stages that may sit either side of signature.
 *   Old Data — dead rather than won; excluding it needs a different rationale
 *     (junk suppression), so it is not folded in here.
 */
/**
 * Stages that mean the deal is already WON — the customer signed or is live —
 * so the money is committed and no longer "open pipeline at risk".
 *
 * Extended 2026-08-23. The original list held only 'agreement signed' and
 * 'paid', with the regex below catching 'closed …', 'client activated' and
 * 'transferred to cs'. That left five post-win stages counting as open, the
 * largest by far being Partner Active — 181 live partners carrying SAR 450,984
 * were being reported as pipeline at risk. The rule was also self-contradictory:
 * it excluded 'client activated' but admitted 'partner active', and excluded
 * 'agreement signed' but admitted the bare 'signed'.
 *
 * Explicit names rather than regex on purpose: a pattern like /active/ would
 * also swallow legitimately open stages, and the exact vocabulary is known.
 */
const WON_STAGES = [
  "agreement signed",
  "paid",
  // Same family as 'agreement signed' — the win-rate KPI already counts this
  // as a win, so counting it as open pipeline double-booked the same deal.
  "signed",
  // Same family as 'client activated', which was already excluded.
  "partner active",
  "new client",
  // Post-activation onboarding, not pre-sale pipeline.
  "welcome communications",
  "registered 40 percent",
] as const;

/**
 * TERMINAL (dead) stages — the deal ended without becoming a customer, or was
 * handed off. Distinct from WON_STAGES: those are wins, these are closures.
 *
 * A Postgres regex rather than a name list because these arrive with many
 * suffixes in the wild ("Closed Lost", "Closed-Lost", "Dropped by client"),
 * unlike the won stages whose exact vocabulary is known and where a loose
 * pattern would wrongly swallow "Agreement Sent".
 *
 * Shared so openStagePredicate and the at-risk breakdown's bucket CASE cannot
 * drift apart — they held identical copies until 2026-08-23, which is how the
 * won-stage list ended up fixed in one place and stale in the other.
 */
const TERMINAL_STAGE_RE =
  "(closed|won|lost|drop|cancel|transferred to cs|client activated)";

/** SQL for "this record's stage", with the raw_data fallback. */
function stageSql(alias: string): string {
  return `LOWER(COALESCE(NULLIF(${alias}.stage,''), ${alias}.raw_data->>'Stage',''))`;
}

/** The won stages as a SQL literal list, for an IN (…) clause. */
function wonStagesSql(): string {
  return WON_STAGES.map((v) => `'${v}'`).join(",");
}

export function openStagePredicate(alias: string): string {
  const s = stageSql(alias);
  return `${s} NOT IN (${wonStagesSql()}) AND ${s} !~ '${TERMINAL_STAGE_RE}'`;
}

/**
 * The JS mirror of `buildSegmentPredicate`'s layout semantics, for filtering an
 * already-fetched array of records (e.g. the cluster preview modal) by segment
 * WITHOUT another query. Reads the record's layout from `layout_name` with the
 * same raw_data Layout fallback, normalizes it (lowercase, alphanumeric-only),
 * and classifies: contains "marketplace"/"partneraccounts" → marketplace;
 * contains "Example Organization" → Example Organization; else → ExampleOrg (the corporate default, incl.
 * blank layout). Keep in lockstep with buildSegmentPredicate.
 */
export function readRecordLayout(rec: any): string {
  const r = rec || {};
  const raw = (r.raw_data as any) || {};
  const col = r.layout_name != null ? String(r.layout_name).trim() : "";
  if (col) return col;
  if (raw.Layout && typeof raw.Layout === "object" && raw.Layout.name)
    return String(raw.Layout.name);
  if (raw.$layout && typeof raw.$layout === "object" && raw.$layout.name)
    return String(raw.$layout.name);
  if (typeof raw.Layout === "string") return raw.Layout;
  return "";
}
export function classifyLayoutSegment(
  layoutRaw: string | null | undefined,
): "marketplace" | "Example Organization" | "ExampleOrg" {
  const norm = String(layoutRaw ?? "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");
  if (norm.includes("marketplace") || norm.includes("partneraccounts"))
    return "marketplace";
  if (norm.includes("Example Organization")) return "Example Organization";
  return "ExampleOrg";
}
export function recordMatchesSegment(
  rec: any,
  segment: string | null | undefined,
): boolean {
  if (!segment || segment === "all") return true;
  const seg = classifyLayoutSegment(readRecordLayout(rec));
  // "corporate" is the legacy alias for "ExampleOrg".
  if (segment === "corporate") return seg === "ExampleOrg";
  return seg === segment;
}

export interface MergeAction {
  id?: number;
  cluster_id: number;
  primary_record_id: number;
  merged_record_ids: number[];
  /**
   * Five action types observed in the wild — keep this union in sync with
   * every callsite that writes to duplicate_merge_actions:
   *   "resolve"          — operator Mark Resolved OR successful merge Apply
   *                        (resolveCluster, executeMergePlan single-module path)
   *   "ignore"           — operator Mark Dismissed (false-positive)
   *   "module_resolved"  — partial-apply on a cross-module cluster: one module
   *                        merged, others still open (executeMergePlan
   *                        cross-module path, via recordPartialMergeAction)
   *   "split"            — bulk-split contacts cleanup (carved a cluster into
   *                        ≥2 strict sub-clusters)
   *   "merge"            — legacy; reserved for back-compat
   */
  action_type: "merge" | "resolve" | "ignore" | "module_resolved" | "split";
  performed_by?: string;
  notes?: string;
  created_at?: Date;
}

/** Enriched merge action: MergeAction + the cluster's domain / company name
 *  + the action_type's human-readable label. Powers the Logs tab UI + AssistantPersona's
 *  manualActionAuditTool. */
export interface MergeActionEnriched extends MergeAction {
  cluster_domain: string | null;
  cluster_company_name: string | null;
  cluster_status: string | null;
}

export interface OwnerAccountability {
  owner_name: string;
  owner_email: string;
  // Team / role badge sourced from SEED_USERS so coaching reports can group
  // owners by squad ("MP", "WO Sales", "CS", "MGMT", etc.). "Unassigned" when
  // the owner name doesn't match a known seed user.
  team: string;
  total_records: number;
  duplicate_records: number;
  duplicate_rate: number;
  clusters_involved: number;
  high_confidence_duplicates: number;
  estimated_waste_value: number;
  rag_status: "green" | "amber" | "red";
}

export interface DuplicateDetectionLog {
  id?: number;
  detection_type: "manual" | "scheduled" | "on_demand" | "interval-fallback";
  total_records_scanned: number;
  total_clusters_found: number;
  total_duplicates_detected: number;
  high_confidence_count: number;
  medium_confidence_count: number;
  low_confidence_count: number;
  estimated_pipeline_inflation?: number;
  detection_duration_ms?: number;
  triggered_by?: string;
  user_email?: string;
  status: "running" | "completed" | "failed";
  error_message?: string;
  detection_config?: any;
  created_at?: Date;
  completed_at?: Date;
}

export interface DuplicateExportLog {
  id?: number;
  export_type: "cluster" | "owner" | "time_period" | "all";
  filter_criteria?: any;
  total_records_exported: number;
  file_format: "excel" | "csv" | "xlsx";
  exported_by?: string;
  user_email?: string;
  created_at?: Date;
}

const PUBLIC_DOMAINS = [
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>.uk",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  // House / internal domains — ExampleOrg's OWN domains. Records that picked these
  // up (created via internal forms, or carrying the company email/website
  // instead of the client's) are NOT the same company. Without excluding them,
  // every such record collapses into one giant false "<REDACTED_HOST>" cluster.
  // Treated like a public domain → not a clustering signal. Add more house/ISP
  // domains via the DUPLICATE_EXCLUDED_DOMAINS env (comma-separated).
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  ...(process.env.DUPLICATE_EXCLUDED_DOMAINS || "")
    .split(",")
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean),
];

// Full list (no LIMIT 5) for "View All" modals on the dashboard.
// Defaults to active clusters only so resolved/ignored false-positives are excluded;
// pass includeInactive=true to see all clusters regardless of status.
export async function getAllClustersByInflation(
  opts: { limit?: number; offset?: number; includeInactive?: boolean } = {},
): Promise<any[]> {
  const limit = Math.max(1, Math.min(opts.limit ?? 500, 2000));
  const offset = Math.max(0, opts.offset ?? 0);
  // Aligned to the Amount-at-risk definition (Sample User 2026-07-29): value =
  // duplicate deal Amounts EXCLUDING Agreement Signed / Paid, recomputed live;
  // default excludes dismissed (status != 'active') and resolved clusters.
  const statusClause = opts.includeInactive
    ? ""
    : `AND c.status = 'active' AND ra.cluster_id IS NULL`;
  const r = await pool.query(
    `WITH resolved_act AS (
       SELECT DISTINCT cluster_id FROM duplicate_merge_actions
        WHERE action_type IN ('resolve','module_resolved')
     ),
     open_deals AS (
       SELECT rr.cluster_id, rr.deal_value,
              ROW_NUMBER() OVER (PARTITION BY rr.cluster_id
                ORDER BY rr.is_primary DESC, rr.deal_value DESC, rr.created_date ASC NULLS LAST, rr.id ASC) AS rn
         FROM duplicate_records rr
        WHERE rr.record_type = 'deal' AND rr.deal_value > 0
          AND (${openStagePredicate("rr")})
     ),
     at_risk AS (
       SELECT cluster_id, SUM(deal_value) AS at_risk_value
         FROM open_deals WHERE rn > 1 GROUP BY cluster_id
     )
     SELECT c.id, c.domain, c.company_name, c.company_name_arabic,
            ar.at_risk_value AS estimated_pipeline_value, c.total_records,
            c.total_leads, c.total_deals, c.total_contacts, c.total_accounts,
            c.confidence_score, c.confidence_level, c.status,
            c.cs_overlap_verdict, c.arr_exposure, c.pipeline_lifecycle_state, c.client_sector
       FROM duplicate_clusters c
       JOIN at_risk ar ON ar.cluster_id = c.id
       LEFT JOIN resolved_act ra ON ra.cluster_id = c.id
      WHERE ar.at_risk_value > 0
        AND c.total_deals > 1
        ${statusClause}
      ORDER BY ar.at_risk_value DESC, c.total_records DESC
      LIMIT $1 OFFSET $2`,
    [limit, offset],
  );
  return r.rows;
}

// All clusters that include a given match signal (e.g. exact_email, phone_match).
// Same active-by-default behavior as getAllClustersByInflation.
export async function getClustersBySignal(
  signal: string,
  opts: { limit?: number; offset?: number; includeInactive?: boolean } = {},
): Promise<any[]> {
  const limit = Math.max(1, Math.min(opts.limit ?? 500, 2000));
  const offset = Math.max(0, opts.offset ?? 0);
  const statusClause = opts.includeInactive ? "" : `AND status = 'active'`;
  const r = await pool.query(
    `SELECT id, domain, company_name, company_name_arabic,
            estimated_pipeline_value, total_records,
            total_leads, total_deals, total_contacts, total_accounts,
            confidence_score, confidence_level, status, match_signals,
            cs_overlap_verdict, arr_exposure, pipeline_lifecycle_state, client_sector
       FROM duplicate_clusters
      WHERE total_records > 1
        AND match_signals @> to_jsonb(ARRAY[$1::text])
        ${statusClause}
      ORDER BY confidence_score DESC, total_records DESC
      LIMIT $2 OFFSET $3`,
    [signal, limit, offset],
  );
  return r.rows;
}

// Free-text search across clusters by company name (EN/AR/normalized) or
// domain — powers the "show me everything on <X>" entity lookup so AssistantPersona can
// flag that a looked-up company also has open duplicate clusters. Active
// clusters with >1 record only; capped.
export async function searchClustersByText(
  query: string,
  limit = 10,
): Promise<any[]> {
  const q = (query || "").trim();
  if (!q) return [];
  const like = `%${q}%`;
  const cap = Math.max(1, Math.min(limit, 50));
  const r = await pool.query(
    `SELECT id, domain, company_name, company_name_arabic,
            estimated_pipeline_value, total_records,
            total_leads, total_deals, total_contacts, total_accounts,
            confidence_score, confidence_level, status,
            cs_overlap_verdict, pipeline_lifecycle_state, client_sector
       FROM duplicate_clusters
      WHERE total_records > 1
        AND status = 'active'
        AND (
          company_name ILIKE $1
          OR company_name_arabic ILIKE $1
          OR company_name_normalized ILIKE $1
          OR domain ILIKE $1
        )
      ORDER BY estimated_pipeline_value DESC NULLS LAST, total_records DESC
      LIMIT $2`,
    [like, cap],
  );
  return r.rows;
}

// ── Deal-Compliance document-scan persistence ─────────────────────────────
export interface DealDocComplianceRow {
  CRMProvider_deal_id: string;
  stage: string | null;
  compliant: boolean;
  present_docs: string[];
  missing_docs: string[];
  attachment_count: number;
  checked_at: string;
  checked_by: string | null;
}

/** Upsert the latest doc-compliance result for a deal (one row per deal). */
export async function upsertDealDocCompliance(rec: {
  CRMProviderDealId: string;
  stage?: string | null;
  compliant: boolean;
  presentDocs: string[];
  missingDocs: string[];
  attachmentCount: number;
  checkedBy?: string | null;
}): Promise<void> {
  await pool.query(
    `INSERT INTO deal_doc_compliance
       (CRMProvider_deal_id, stage, compliant, present_docs, missing_docs, attachment_count, checked_at, checked_by)
     VALUES ($1, $2, $3, $4::jsonb, $5::jsonb, $6, NOW(), $7)
     ON CONFLICT (CRMProvider_deal_id) DO UPDATE SET
       stage = EXCLUDED.stage,
       compliant = EXCLUDED.compliant,
       present_docs = EXCLUDED.present_docs,
       missing_docs = EXCLUDED.missing_docs,
       attachment_count = EXCLUDED.attachment_count,
       checked_at = NOW(),
       checked_by = EXCLUDED.checked_by`,
    [
      rec.CRMProviderDealId,
      rec.stage || null,
      !!rec.compliant,
      JSON.stringify(rec.presentDocs || []),
      JSON.stringify(rec.missingDocs || []),
      Number(rec.attachmentCount) || 0,
      rec.checkedBy || null,
    ],
  );
}

/** Fetch stored doc-compliance results. Optionally filtered to specific deal
 *  ids (the visible page); capped to keep payloads sane. */
export async function getDealDocCompliance(
  ids?: string[],
): Promise<DealDocComplianceRow[]> {
  if (ids && ids.length) {
    const r = await pool.query(
      `SELECT CRMProvider_deal_id, stage, compliant, present_docs, missing_docs,
              attachment_count, checked_at, checked_by
         FROM deal_doc_compliance
        WHERE CRMProvider_deal_id = ANY($1::text[])`,
      [ids],
    );
    return r.rows;
  }
  const r = await pool.query(
    `SELECT CRMProvider_deal_id, stage, compliant, present_docs, missing_docs,
            attachment_count, checked_at, checked_by
       FROM deal_doc_compliance
      ORDER BY checked_at DESC
      LIMIT 5000`,
  );
  return r.rows;
}

/** One checked deal, with the owner and money attached — the unit the Head of
 *  Sales acts on. Missing docs come from the stored check, not a live call. */
export interface DealComplianceReportRow {
  id: string;
  name: string;
  stage: string;
  owner: string;
  account: string | null;
  amount: number;
  created: string | null;
  compliant: boolean;
  missing_docs: string[];
  attachment_count: number;
  checked_at: string | null;
}

/**
 * Row-level document compliance for the report that goes to Sales.
 *
 * Joins the stored check to the deal mirror so every row carries an OWNER and
 * an AMOUNT: "632 deals are missing documents" is not actionable, "these are
 * yours and they are worth this much" is.
 *
 * Only deals that have actually been checked appear — a deal the background
 * sweep has not reached yet is not evidence of anything, and padding the
 * report with unknowns would understate compliance.
 */
export async function getDealComplianceReportRows(
  segment: DuplicateFilters["segment"],
): Promise<DealComplianceReportRow[]> {
  const seg = segment && segment !== "all" ? (segment === "corporate" ? "ExampleOrg" : segment) : "all";
  const p = buildSegmentPredicate(seg, 1);
  const segCond = p.condition ? " AND " + p.condition : "";
  const res = await pool.query(
    `SELECT d.CRMProvider_deal_id AS id,
            COALESCE(NULLIF(BTRIM(r.record_name), ''), d.CRMProvider_deal_id) AS name,
            COALESCE(NULLIF(BTRIM(d.stage), ''), NULLIF(BTRIM(r.stage), ''), '') AS stage,
            COALESCE(NULLIF(BTRIM(r.owner_name), ''), NULLIF(BTRIM(r.owner_email), ''), 'Unassigned') AS owner,
            COALESCE(
              NULLIF(BTRIM(r.raw_data->'Account_Name'->>'name'), ''),
              NULLIF(BTRIM(r.company_name), '')
            ) AS account,
            COALESCE(r.deal_value, 0)::float AS amount,
            r.created_date AS created,
            d.compliant AS compliant,
            d.missing_docs AS missing_docs,
            d.attachment_count AS attachment_count,
            d.checked_at AS checked_at
       FROM deal_doc_compliance d
       JOIN duplicate_records r ON r.CRMProvider_record_id = d.CRMProvider_deal_id
      WHERE r.record_type = 'deal'${segCond}
      ORDER BY d.compliant ASC, COALESCE(r.deal_value, 0) DESC`,
    [...p.params],
  );
  return (res.rows as any[]).map((x) => ({
    id: String(x.id),
    name: String(x.name || ""),
    stage: String(x.stage || ""),
    owner: String(x.owner || "Unassigned"),
    account: x.account || null,
    amount: Number(x.amount) || 0,
    created: x.created ? new Date(x.created).toISOString() : null,
    compliant: x.compliant === true,
    // pg parses jsonb into a JS array already; guard non-arrays.
    missing_docs: Array.isArray(x.missing_docs) ? x.missing_docs : [],
    attachment_count: Number(x.attachment_count) || 0,
    checked_at: x.checked_at ? new Date(x.checked_at).toISOString() : null,
  }));
}

// ── Weekly executive-brief snapshots (for week-over-week trend) ───────────
export interface ExecBriefSnapshot {
  total_clusters: number;
  resolved_count: number;
  active_count: number;
  exposure: number;
  dup_rate: number | null;
  metrics_json: any;
  created_at: string;
}

export async function recordExecBriefSnapshot(s: {
  totalClusters: number;
  resolvedCount: number;
  activeCount: number;
  exposure: number;
  dupRate: number | null;
  metricsJson?: any;
}): Promise<void> {
  await pool.query(
    `INSERT INTO exec_brief_snapshots
       (total_clusters, resolved_count, active_count, exposure, dup_rate, metrics_json)
     VALUES ($1, $2, $3, $4, $5, $6::jsonb)`,
    [
      s.totalClusters || 0,
      s.resolvedCount || 0,
      s.activeCount || 0,
      s.exposure || 0,
      s.dupRate == null ? null : s.dupRate,
      JSON.stringify(s.metricsJson || {}),
    ],
  );
}

/** Most recent snapshot (the prior week's), for computing the delta. */
export async function getPreviousExecBriefSnapshot(): Promise<ExecBriefSnapshot | null> {
  const r = await pool.query(
    `SELECT total_clusters, resolved_count, active_count, exposure, dup_rate, metrics_json, created_at
       FROM exec_brief_snapshots
      ORDER BY created_at DESC
      LIMIT 1`,
  );
  return r.rows[0] || null;
}

export function extractDomain(email: string): string | null {
  if (!email || typeof email !== "string") return null;
  const match = email
    .toLowerCase()
    .trim()
    .match(/@([^@]+)$/);
  if (!match) return null;
  let domain = match[1].replace(/^www\./, "").trim();
  if (PUBLIC_DOMAINS.includes(domain)) return null;
  return domain;
}

export function normalizeDomain(domain: string): string {
  if (!domain) return "";
  return domain
    .toLowerCase()
    .replace(/^www\./, "")
    .trim();
}

export function calculateSimilarity(str1: string, str2: string): number {
  if (!str1 || !str2) return 0;
  const s1 = str1.toLowerCase().trim();
  const s2 = str2.toLowerCase().trim();
  if (s1 === s2) return 100;

  const longer = s1.length > s2.length ? s1 : s2;

  if (longer.length === 0) return 100;

  const editDistance = levenshteinDistance(s1, s2);
  return Math.round((1 - editDistance / longer.length) * 100);
}

function levenshteinDistance(s1: string, s2: string): number {
  const m = s1.length;
  const n = s2.length;
  const dp: number[][] = Array(m + 1)
    .fill(null)
    .map(() => Array(n + 1).fill(0));

  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      if (s1[i - 1] === s2[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1];
      } else {
        dp[i][j] = Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]) + 1;
      }
    }
  }
  return dp[m][n];
}

export function getConfidenceLevel(score: number): "high" | "medium" | "low" {
  if (score >= 90) return "high";
  if (score >= 60) return "medium";
  return "low";
}

export function normalizePhone(phone: string): string {
  if (!phone) return "";
  return phone
    .replace(/[\s\-\(\)\+\.]/g, "")
    .replace(/^00/, "")
    .replace(/^966/, "")
    .slice(-9);
}

export interface MatchResult {
  score: number;
  signals: string[];
}

/**
 * Multi-signal duplicate match scoring.
 *
 * Weights are calibrated for B2B Saudi data (gov + private sector). In observed
 * real-world data (see `docs/duplicate-radar-cs-overlap.md`), ~100% of true
 * duplicates share the same domain while only ~12% share email — so domain
 * carries more weight than email here. PUBLIC_DOMAINS callers should still
 * suppress the domain signal when both records are personal-email accounts.
 *
 * Override profile by env if a different shape is needed:
 *   DUPLICATE_RADAR_SCORING_PROFILE=b2b   (default, current weights)
 *   DUPLICATE_RADAR_SCORING_PROFILE=email_first  (legacy: email=40, domain=25)
 */
export function calculateMultiSignalScore(
  record1: {
    email?: string;
    domain?: string;
    phone?: string;
    company_name?: string;
  },
  record2: {
    email?: string;
    domain?: string;
    phone?: string;
    company_name?: string;
  },
): MatchResult {
  const profile =
    process.env.DUPLICATE_RADAR_SCORING_PROFILE === "email_first"
      ? "email_first"
      : "b2b";
  const weights =
    profile === "email_first"
      ? { email: 40, domain: 25, phone: 30, companyExact: 20, companyFuzzy: 10 }
      : { email: 30, domain: 50, phone: 30, companyExact: 20, companyFuzzy: 10 };

  const signals: string[] = [];
  let score = 0;

  if (
    record1.email &&
    record2.email &&
    record1.email.toLowerCase() === record2.email.toLowerCase()
  ) {
    score += weights.email;
    signals.push("exact_email");
  }

  if (record1.domain && record2.domain && record1.domain === record2.domain) {
    score += weights.domain;
    signals.push("domain_match");
  }

  if (record1.phone && record2.phone) {
    const p1 = normalizePhone(record1.phone);
    const p2 = normalizePhone(record2.phone);
    if (p1 && p2 && p1.length >= 7 && p1 === p2) {
      score += weights.phone;
      signals.push("phone_match");
    }
  }

  if (record1.company_name && record2.company_name) {
    const similarity = calculateSimilarity(
      normalizeCompanyName(record1.company_name),
      normalizeCompanyName(record2.company_name),
    );
    if (similarity >= 90) {
      score += weights.companyExact;
      signals.push("company_exact");
    } else if (similarity >= 75) {
      score += weights.companyFuzzy;
      signals.push("company_fuzzy");
    }
  }

  return { score: Math.min(score, 100), signals };
}

// Memoization handle for initDuplicateRadarTables.
//
// 6 route handlers in duplicateRadarRoutes.ts call this at the top of
// every request (recalculate-stats, account-hints/scan, packet, kpis,
// preflight, the lifecycle endpoints…). The init body executes ~30
// CREATE TABLE / ALTER TABLE / CREATE INDEX statements plus an optional
// pg_trgm extension install. They're idempotent (IF NOT EXISTS) but on
// a cold HostingPlatform container the first run takes 5–15s, and 6 endpoints
// firing in parallel from /duplicates' refreshData all race for the
// same work. Same cold-start failure mode as initCallIntelligenceTables
// before its memoization landed (see that file for the playbook).
//
// Fix: run the schema body exactly once per process lifetime. Subsequent
// calls await the cached promise (cheap) and return as soon as the
// first call finishes. Cached promise is cleared on failure so a
// transient connection blip doesn't pin the cache forever.
let _ddrInitPromise: Promise<void> | null = null;
let _ddrInitDone = false;

export async function initDuplicateRadarTables(): Promise<void> {
  if (_ddrInitDone) return;
  if (_ddrInitPromise) return _ddrInitPromise;
  _ddrInitPromise = (async () => {
    const startedAt = Date.now();
    try {
      await _doInitDuplicateRadarTables();
      _ddrInitDone = true;
      const ms = Date.now() - startedAt;
      // Loud above 2s so an operator tailing logs can spot a legitimate
      // cold start vs a recurring slow path (which would mean the
      // memoization broke).
      if (ms > 2000) {
        logger.warn(
          `[duplicateRadarDatabase] initDuplicateRadarTables took ${ms}ms (cold start)`,
        );
      } else {
        logger.info(
          `[duplicateRadarDatabase] initDuplicateRadarTables completed in ${ms}ms`,
        );
      }
    } catch (err) {
      _ddrInitPromise = null;
      throw err;
    }
  })();
  return _ddrInitPromise;
}

async function _doInitDuplicateRadarTables(): Promise<void> {
  // Agentic-resolution learning store — created at BOOT (here) so it exists in
  // both dev and prod. If it were only created lazily on first use, the dev↔prod
  // schema diff at deploy time keeps proposing to DROP it from prod. DDL mirrors
  // ensureTable() in duplicateResolutionLearning.ts (which stays as a runtime
  // safety net). Keep the two in sync.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS duplicate_resolution_feedback (
      id SERIAL PRIMARY KEY,
      cluster_id INTEGER,
      event_type VARCHAR(32) NOT NULL,
      proposed_master_CRMProvider_id VARCHAR(100),
      chosen_master_CRMProvider_id VARCHAR(100),
      master_overridden BOOLEAN DEFAULT FALSE,
      fields_migrated INTEGER DEFAULT 0,
      duplicates_tagged INTEGER DEFAULT 0,
      reparented INTEGER DEFAULT 0,
      errors INTEGER DEFAULT 0,
      plan_json JSONB,
      report_json JSONB,
      performed_by VARCHAR(255),
      created_at TIMESTAMP DEFAULT NOW()
    );
  `);
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_dup_res_feedback_cluster ON duplicate_resolution_feedback(cluster_id);`,
  );
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_dup_res_feedback_created ON duplicate_resolution_feedback(created_at DESC);`,
  );

  // Autonomous-resolution learning RULES (mirrors ensureResolutionRulesTable in
  // duplicateResolutionRules.ts) — boot-created so dev & prod match.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS duplicate_resolution_rules (
      id SERIAL PRIMARY KEY,
      module VARCHAR(32) NOT NULL,
      case_signature JSONB NOT NULL,
      decision VARCHAR(32) NOT NULL,
      scope VARCHAR(16) NOT NULL DEFAULT 'pattern',
      cluster_id INTEGER,
      created_by VARCHAR(255),
      enabled BOOLEAN NOT NULL DEFAULT TRUE,
      usage_count INTEGER NOT NULL DEFAULT 0,
      created_at TIMESTAMP DEFAULT NOW(),
      last_used_at TIMESTAMP
    );
  `);
  await pool
    .query(
      `CREATE INDEX IF NOT EXISTS idx_dup_res_rules_module ON duplicate_resolution_rules(module) WHERE enabled = TRUE;`,
    )
    .catch(() => {});

  // Autonomous-resolution competence GRADE LOG (mirrors ensureGradeLogTable in
  // duplicateResolutionGrades.ts) — boot-created so dev & prod match.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS duplicate_resolution_grade_log (
      id SERIAL PRIMARY KEY,
      module VARCHAR(32) NOT NULL,
      grade INTEGER NOT NULL,
      grade_label VARCHAR(48),
      metrics_json JSONB,
      promoted BOOLEAN NOT NULL DEFAULT FALSE,
      note TEXT,
      created_at TIMESTAMP DEFAULT NOW()
    );
  `);
  await pool
    .query(
      `CREATE INDEX IF NOT EXISTS idx_dup_res_grade_log_module_time ON duplicate_resolution_grade_log(module, created_at DESC);`,
    )
    .catch(() => {});

  // In-platform autonomous-resolution mode/kill-switch override (single row).
  // Boot-created in BOTH dev & prod so HostingPlatform's deploy schema-diff doesn't
  // propose dropping a runtime-created table. See duplicateResolutionRunner.ts.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS autonomous_resolution_settings (
      id INTEGER PRIMARY KEY DEFAULT 1,
      enabled BOOLEAN,
      mode VARCHAR(16),
      updated_by VARCHAR(255),
      updated_at TIMESTAMP DEFAULT NOW(),
      CONSTRAINT autonomous_resolution_settings_singleton CHECK (id = 1)
    );
  `);

  // Deal-Compliance document-scan results (SOP 7.5.10 attachment checks).
  // One row per CRMProvider deal, latest scan only — shared across users/devices so
  // the missing-doc scope persists for re-checking and for sending to owners.
  // Boot-created in dev & prod so HostingPlatform's schema-diff won't propose dropping it.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS deal_doc_compliance (
      CRMProvider_deal_id VARCHAR(64) PRIMARY KEY,
      stage VARCHAR(64),
      compliant BOOLEAN NOT NULL DEFAULT FALSE,
      present_docs JSONB NOT NULL DEFAULT '[]'::jsonb,
      missing_docs JSONB NOT NULL DEFAULT '[]'::jsonb,
      attachment_count INTEGER NOT NULL DEFAULT 0,
      checked_at TIMESTAMP DEFAULT NOW(),
      checked_by VARCHAR(255)
    );
  `);

  // Scheduled-report send log — the idempotency guard for reports that must go
  // out exactly ONCE per period. The primary key IS the guard: the sender
  // inserts (report, period) before sending and treats a conflict as "already
  // sent". An in-memory stamp would re-send after a restart inside the send
  // window, which for a monthly email to the Head of Sales is worse than not
  // sending at all.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS scheduled_report_sends (
      report_key VARCHAR(64) NOT NULL,
      period VARCHAR(16) NOT NULL,
      sent_at TIMESTAMP DEFAULT NOW(),
      recipient_count INTEGER NOT NULL DEFAULT 0,
      detail JSONB,
      PRIMARY KEY (report_key, period)
    );
  `);

  // Weekly executive-brief snapshots — one row per weekly leadership digest, so
  // the next digest can report week-over-week trend (clusters cleared, exposure
  // change, duplicate-rate change). Boot-created in dev & prod.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS exec_brief_snapshots (
      id SERIAL PRIMARY KEY,
      total_clusters INTEGER NOT NULL DEFAULT 0,
      resolved_count INTEGER NOT NULL DEFAULT 0,
      active_count INTEGER NOT NULL DEFAULT 0,
      exposure NUMERIC NOT NULL DEFAULT 0,
      dup_rate INTEGER,
      metrics_json JSONB,
      created_at TIMESTAMP DEFAULT NOW()
    );
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS duplicate_clusters (
      id SERIAL PRIMARY KEY,
      domain VARCHAR(255) NOT NULL,
      company_name VARCHAR(500),
      company_name_arabic VARCHAR(500),
      company_name_normalized VARCHAR(500),
      total_leads INTEGER DEFAULT 0,
      total_deals INTEGER DEFAULT 0,
      total_contacts INTEGER DEFAULT 0,
      total_accounts INTEGER DEFAULT 0,
      total_records INTEGER DEFAULT 0,
      confidence_level VARCHAR(20) DEFAULT 'medium',
      confidence_score INTEGER DEFAULT 0,
      match_signals JSONB DEFAULT '[]',
      first_record_date TIMESTAMP,
      latest_activity_date TIMESTAMP,
      owners_involved JSONB DEFAULT '[]',
      estimated_pipeline_value DECIMAL(15,2) DEFAULT 0,
      status VARCHAR(50) DEFAULT 'active',
      ai_recommendation TEXT,
      resolved_by VARCHAR(255),
      resolved_at TIMESTAMP,
      cs_overlap_verdict VARCHAR(16),
      arr_exposure DECIMAL(15,2) DEFAULT 0,
      pipeline_lifecycle_state VARCHAR(32),
      client_sector VARCHAR(16),
      verification_state VARCHAR(16),
      verification_at TIMESTAMP,
      verification_notes TEXT,
      cross_module_handled_at TIMESTAMPTZ,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `);

  await pool.query(
    `ALTER TABLE duplicate_clusters ADD COLUMN IF NOT EXISTS total_contacts INTEGER DEFAULT 0`,
  );
  await pool.query(
    `ALTER TABLE duplicate_clusters ADD COLUMN IF NOT EXISTS total_accounts INTEGER DEFAULT 0`,
  );
  await pool.query(
    `ALTER TABLE duplicate_clusters ADD COLUMN IF NOT EXISTS match_signals JSONB DEFAULT '[]'`,
  );
  await pool.query(
    `ALTER TABLE duplicate_clusters ADD COLUMN IF NOT EXISTS resolved_by VARCHAR(255)`,
  );
  await pool.query(
    `ALTER TABLE duplicate_clusters ADD COLUMN IF NOT EXISTS resolved_at TIMESTAMP`,
  );
  await pool.query(
    `ALTER TABLE duplicate_clusters ADD COLUMN IF NOT EXISTS company_name_normalized VARCHAR(500)`,
  );

  // CS-pipeline overlap detection (sector-aware) — Phase 1
  await pool.query(
    `ALTER TABLE duplicate_clusters ADD COLUMN IF NOT EXISTS cs_overlap_verdict VARCHAR(16)`,
  );
  await pool.query(
    `ALTER TABLE duplicate_clusters ADD COLUMN IF NOT EXISTS arr_exposure DECIMAL(15,2) DEFAULT 0`,
  );
  await pool.query(
    `ALTER TABLE duplicate_clusters ADD COLUMN IF NOT EXISTS pipeline_lifecycle_state VARCHAR(32)`,
  );
  await pool.query(
    `ALTER TABLE duplicate_clusters ADD COLUMN IF NOT EXISTS client_sector VARCHAR(16)`,
  );
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_duplicate_clusters_cs_overlap ON duplicate_clusters(cs_overlap_verdict) WHERE cs_overlap_verdict IS NOT NULL`,
  );
  // Cross-Module "Handled" — module-scoped acknowledgement of a cross-module
  // overlap (e.g. Lead<->Account) that must NOT resolve the whole cluster
  // (same-module duplicates, e.g. 2 Leads, must stay visible elsewhere).
  // NULL = still open in the Cross-Module queue; set = handled (reversible).
  await pool.query(
    `ALTER TABLE duplicate_clusters ADD COLUMN IF NOT EXISTS cross_module_handled_at TIMESTAMPTZ`,
  );
  // R3 (quick-wins): post-merge verification state. When an operator clicks
  // "Mark Resolved + Verify" we check that the cluster's non-primary records
  // were actually deleted in CRMProvider and persist the outcome here so the
  // dashboard can surface a Verified / Failed badge.
  //   verification_state: NULL / 'verified' / 'failed' / 'pending'
  //   verification_at:    when we ran the check
  //   verification_notes: human-readable summary (X confirmed deleted, Y still present)
  await pool.query(
    `ALTER TABLE duplicate_clusters ADD COLUMN IF NOT EXISTS verification_state VARCHAR(16)`,
  );
  await pool.query(
    `ALTER TABLE duplicate_clusters ADD COLUMN IF NOT EXISTS verification_at TIMESTAMP`,
  );
  await pool.query(
    `ALTER TABLE duplicate_clusters ADD COLUMN IF NOT EXISTS verification_notes TEXT`,
  );
  // R10 (medium-term): pre-merge snapshots. Cloudingo's flagship feature is
  // "Undo Merge" — we can't actually undo a CRMProvider merge (CRMProvider deletes the
  // record), but we can freeze a JSON copy of the cluster + every record
  // (including raw_data) at the moment "Mark Resolved" is clicked. The
  // forensic trail lets owners audit what was about to be lost if a
  // verification later flags the merge as wrong, or settle a dispute weeks
  // later when memories fade. ON DELETE SET NULL so the snapshot survives
  // even if the cluster row is purged in a cleanup job.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS duplicate_cluster_snapshots (
      id              SERIAL PRIMARY KEY,
      cluster_id      INTEGER REFERENCES duplicate_clusters(id) ON DELETE SET NULL,
      snapshot_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      taken_by        VARCHAR(255),
      trigger         VARCHAR(64) NOT NULL,
      merge_action_id INTEGER,
      record_count    INTEGER NOT NULL DEFAULT 0,
      cluster_snapshot JSONB NOT NULL,
      records_snapshot JSONB NOT NULL,
      notes           TEXT
    )
  `);
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_dr_cluster_snapshots_cluster ON duplicate_cluster_snapshots(cluster_id) WHERE cluster_id IS NOT NULL`,
  );
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_dr_cluster_snapshots_at ON duplicate_cluster_snapshots(snapshot_at DESC)`,
  );

  await pool.query(`
    CREATE TABLE IF NOT EXISTS duplicate_records (
      id SERIAL PRIMARY KEY,
      cluster_id INTEGER REFERENCES duplicate_clusters(id) ON DELETE CASCADE,
      record_type VARCHAR(20) NOT NULL,
      CRMProvider_record_id VARCHAR(100),
      record_name VARCHAR(500),
      company_name VARCHAR(500),
      email VARCHAR(255),
      domain VARCHAR(255),
      phone VARCHAR(100),
      phone_normalized VARCHAR(50),
      owner_name VARCHAR(255),
      owner_email VARCHAR(255),
      status VARCHAR(100),
      stage VARCHAR(100),
      deal_value DECIMAL(15,2),
      source VARCHAR(255),
      created_date TIMESTAMP,
      modified_date TIMESTAMP,
      is_primary BOOLEAN DEFAULT FALSE,
      ai_recommendation TEXT,
      confidence_score INTEGER DEFAULT 0,
      match_signals JSONB DEFAULT '[]',
      layout_name VARCHAR(255),
      layout_id VARCHAR(100),
      CRMProvider_module VARCHAR(50),
      pipeline VARCHAR(255),
      products TEXT,
      mobile VARCHAR(100),
      mobile_normalized VARCHAR(50),
      contact_name VARCHAR(255),
      account_name VARCHAR(500),
      cr_number VARCHAR(100),
      vat_number VARCHAR(100),
      website VARCHAR(500),
      country VARCHAR(100),
      region VARCHAR(100),
      industry VARCHAR(255),
      no_of_employees INTEGER,
      title VARCHAR(255),
      lead_type VARCHAR(100),
      gov_type VARCHAR(100),
      account_type VARCHAR(100),
      is_mock_data BOOLEAN DEFAULT FALSE,
      raw_data JSONB,
      cleanup_class TEXT,
      last_verified_at TIMESTAMP,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `);

  await pool.query(
    `ALTER TABLE duplicate_records ADD COLUMN IF NOT EXISTS last_verified_at TIMESTAMP`,
  );
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_duplicate_records_verified ON duplicate_records(last_verified_at ASC NULLS FIRST)`,
  );
  await pool.query(
    `ALTER TABLE duplicate_records ADD COLUMN IF NOT EXISTS phone_normalized VARCHAR(50)`,
  );
  await pool.query(
    `ALTER TABLE duplicate_records ADD COLUMN IF NOT EXISTS match_signals JSONB DEFAULT '[]'`,
  );

  await pool.query(
    `ALTER TABLE duplicate_records ADD COLUMN IF NOT EXISTS layout_name VARCHAR(255)`,
  );
  await pool.query(
    `ALTER TABLE duplicate_records ADD COLUMN IF NOT EXISTS layout_id VARCHAR(100)`,
  );
  await pool.query(
    `ALTER TABLE duplicate_records ADD COLUMN IF NOT EXISTS CRMProvider_module VARCHAR(50)`,
  );
  await pool.query(
    `ALTER TABLE duplicate_records ADD COLUMN IF NOT EXISTS pipeline VARCHAR(255)`,
  );
  await pool.query(
    `ALTER TABLE duplicate_records ADD COLUMN IF NOT EXISTS products TEXT`,
  );
  await pool.query(
    `ALTER TABLE duplicate_records ADD COLUMN IF NOT EXISTS mobile VARCHAR(100)`,
  );
  await pool.query(
    `ALTER TABLE duplicate_records ADD COLUMN IF NOT EXISTS mobile_normalized VARCHAR(50)`,
  );
  await pool.query(
    `ALTER TABLE duplicate_records ADD COLUMN IF NOT EXISTS contact_name VARCHAR(255)`,
  );
  await pool.query(
    `ALTER TABLE duplicate_records ADD COLUMN IF NOT EXISTS account_name VARCHAR(500)`,
  );
  await pool.query(
    `ALTER TABLE duplicate_records ADD COLUMN IF NOT EXISTS cr_number VARCHAR(100)`,
  );
  await pool.query(
    `ALTER TABLE duplicate_records ADD COLUMN IF NOT EXISTS vat_number VARCHAR(100)`,
  );
  await pool.query(
    `ALTER TABLE duplicate_records ADD COLUMN IF NOT EXISTS website VARCHAR(500)`,
  );
  await pool.query(
    `ALTER TABLE duplicate_records ADD COLUMN IF NOT EXISTS country VARCHAR(100)`,
  );
  await pool.query(
    `ALTER TABLE duplicate_records ADD COLUMN IF NOT EXISTS region VARCHAR(100)`,
  );
  await pool.query(
    `ALTER TABLE duplicate_records ADD COLUMN IF NOT EXISTS industry VARCHAR(255)`,
  );
  await pool.query(
    `ALTER TABLE duplicate_records ADD COLUMN IF NOT EXISTS no_of_employees INTEGER`,
  );
  await pool.query(
    `ALTER TABLE duplicate_records ADD COLUMN IF NOT EXISTS title VARCHAR(255)`,
  );
  await pool.query(
    `ALTER TABLE duplicate_records ADD COLUMN IF NOT EXISTS lead_type VARCHAR(100)`,
  );
  await pool.query(
    `ALTER TABLE duplicate_records ADD COLUMN IF NOT EXISTS gov_type VARCHAR(100)`,
  );
  await pool.query(
    `ALTER TABLE duplicate_records ADD COLUMN IF NOT EXISTS account_type VARCHAR(100)`,
  );
  // Empty/Junk cleanup classification (Sample User 2026-07-01) — recomputed every
  // scan from the synced snapshot by classifyCleanupRecords(). Values:
  // 'empty' | 'test' | 'junk' | 'orphaned' | 'tagged' | NULL (real data).
  await pool.query(
    `ALTER TABLE duplicate_records ADD COLUMN IF NOT EXISTS cleanup_class TEXT`,
  );

  await pool.query(`
    CREATE TABLE IF NOT EXISTS CRMProvider_sync_state (
      module VARCHAR(50) PRIMARY KEY,
      last_sync_at TIMESTAMP,
      total_synced INTEGER DEFAULT 0,
      sync_status VARCHAR(50) DEFAULT 'idle',
      -- When the CURRENT run started. Distinct from last_sync_at, which is the
      -- incremental watermark and only moves on success; without this a run
      -- that died could not be aged and looked like one still working.
      sync_started_at TIMESTAMP
    )
  `);

  await pool.query(
    `ALTER TABLE CRMProvider_sync_state ADD COLUMN IF NOT EXISTS sync_started_at TIMESTAMP`,
  );

  await pool.query(`
    CREATE TABLE IF NOT EXISTS duplicate_record_tasks (
      id SERIAL PRIMARY KEY,
      CRMProvider_task_id VARCHAR(100) UNIQUE,
      related_record_id VARCHAR(100),
      cluster_id INTEGER REFERENCES duplicate_clusters(id) ON DELETE SET NULL,
      subject VARCHAR(500),
      due_date TIMESTAMP,
      status VARCHAR(100),
      owner_name VARCHAR(255),
      description TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS duplicate_merge_actions (
      id SERIAL PRIMARY KEY,
      cluster_id INTEGER REFERENCES duplicate_clusters(id) ON DELETE CASCADE,
      primary_record_id INTEGER REFERENCES duplicate_records(id),
      merged_record_ids JSONB DEFAULT '[]',
      action_type VARCHAR(20) NOT NULL DEFAULT 'resolve',
      performed_by VARCHAR(255),
      notes TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Durable archive of duplicate_merge_actions.
  //
  // duplicate_merge_actions.cluster_id is ON DELETE CASCADE, so the rebuild's
  // TRUNCATE ... CASCADE destroys every AI-Applied marker. backfillResolutionLedger
  // does NOT cover this: it records only the cluster's MASTER id as "resolved",
  // losing both the pending-vs-verified distinction and which duplicates were
  // actually tagged. Rebuilding without this archive silently converts ~44
  // clusters that are still awaiting a CRMProvider admin deletion into untouched ones,
  // while the ledger simultaneously credits them as resolved.
  //
  // Keyed by CRMProvider ids, never cluster ids, because the rebuild renumbers clusters.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS duplicate_merge_actions_archive (
      id SERIAL PRIMARY KEY,
      module VARCHAR(16) NOT NULL,
      master_CRMProvider_id VARCHAR(255) NOT NULL,
      merged_CRMProvider_ids JSONB DEFAULT '[]',
      action_type VARCHAR(20) NOT NULL,
      performed_by VARCHAR(255),
      notes TEXT,
      original_created_at TIMESTAMP,
      archived_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      restored_at TIMESTAMP NULL,
      UNIQUE (module, master_CRMProvider_id, action_type)
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS merge_jobs (
      id SERIAL PRIMARY KEY,
      cluster_id INTEGER NOT NULL,
      module VARCHAR(20) NOT NULL,
      status VARCHAR(20) NOT NULL DEFAULT 'queued',
      total INTEGER NOT NULL DEFAULT 0,
      processed INTEGER NOT NULL DEFAULT 0,
      tagged INTEGER NOT NULL DEFAULT 0,
      reparented INTEGER NOT NULL DEFAULT 0,
      errors INTEGER NOT NULL DEFAULT 0,
      error_message TEXT,
      master_CRMProvider_id VARCHAR(64),
      created_by VARCHAR(255),
      started_at TIMESTAMPTZ,
      last_progress_at TIMESTAMPTZ,
      finished_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      include_CRMProvider_ids TEXT,
      link_account_CRMProvider_id TEXT,
      force_merge BOOLEAN NOT NULL DEFAULT false
    )
  `);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_merge_jobs_cluster ON merge_jobs(cluster_id)`);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_merge_jobs_cluster_module_status ON merge_jobs(cluster_id, module, status)`);
  await pool.query(`ALTER TABLE merge_jobs ADD COLUMN IF NOT EXISTS include_CRMProvider_ids TEXT`);
  await pool.query(`ALTER TABLE merge_jobs ADD COLUMN IF NOT EXISTS link_account_CRMProvider_id TEXT`);
  await pool.query(`ALTER TABLE merge_jobs ADD COLUMN IF NOT EXISTS force_merge BOOLEAN NOT NULL DEFAULT false`);

  // Durable resolution ledger — keyed by STABLE CRMProvider identity (module +
  // master_CRMProvider_id), NOT by cluster_id. This table is intentionally NOT part of
  // truncateAllDuplicateData()'s TRUNCATE: "Rebuild Clusters" wipes
  // duplicate_clusters/duplicate_records (and cascades duplicate_merge_actions),
  // which previously collapsed the "solved" scoreboard back to 0 on every
  // rebuild/rescan. The ledger remembers that a survivor was resolved so the
  // breakdown can re-attribute "solved" to whatever cluster the survivor lands
  // in after the next scan. ON CONFLICT keeps it idempotent across re-applies.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS duplicate_resolution_ledger (
      id SERIAL PRIMARY KEY,
      module VARCHAR(20) NOT NULL,
      master_CRMProvider_id VARCHAR(100),
      duplicate_CRMProvider_ids JSONB NOT NULL DEFAULT '[]',
      action_type VARCHAR(20) NOT NULL DEFAULT 'resolve',
      performed_by VARCHAR(255),
      notes TEXT,
      resolved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `);
  await pool
    .query(
      `CREATE UNIQUE INDEX IF NOT EXISTS idx_dup_res_ledger_identity
         ON duplicate_resolution_ledger(module, master_CRMProvider_id)
         WHERE master_CRMProvider_id IS NOT NULL`,
    )
    .catch(() => {});
  await pool
    .query(
      `CREATE INDEX IF NOT EXISTS idx_dup_res_ledger_master
         ON duplicate_resolution_ledger(master_CRMProvider_id)`,
    )
    .catch(() => {});

  // One-time-safe backfill: seed the ledger from solved state that still exists
  // at boot so its "solved" credit survives the next rebuild. Idempotent via
  // ON CONFLICT DO NOTHING, safe on every boot. NOTE: cannot resurrect history
  // wiped by a prior rebuild (before this ledger existed).
  //
  // Attribution must be PER-MODULE-ACCURATE, or a partial cross-module apply
  // would inflate solved counts:
  //   A) WHOLE-cluster resolves (status='resolved' or a 'resolve' merge action)
  //      → credit EVERY module present, each keyed to a record OF THAT MODULE
  //      (its primary if any, else a representative — DISTINCT ON picks it).
  //   B) 'module_resolved' actions (ONE module merged inside a still-open
  //      cross-module cluster) → credit ONLY the module of that action's
  //      primary record, NOT every record_type in the cluster.
  await backfillResolutionLedger();

  await pool.query(`
    CREATE TABLE IF NOT EXISTS duplicate_detection_logs (
      id SERIAL PRIMARY KEY,
      detection_type VARCHAR(50) DEFAULT 'manual',
      total_records_scanned INTEGER DEFAULT 0,
      total_clusters_found INTEGER DEFAULT 0,
      total_duplicates_detected INTEGER DEFAULT 0,
      high_confidence_count INTEGER DEFAULT 0,
      medium_confidence_count INTEGER DEFAULT 0,
      low_confidence_count INTEGER DEFAULT 0,
      estimated_pipeline_inflation DECIMAL(15,2),
      detection_duration_ms INTEGER,
      triggered_by VARCHAR(255),
      user_email VARCHAR(255),
      status VARCHAR(50) DEFAULT 'running',
      error_message TEXT,
      detection_config JSONB,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      completed_at TIMESTAMP
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS duplicate_export_logs (
      id SERIAL PRIMARY KEY,
      export_type VARCHAR(50) DEFAULT 'all',
      filter_criteria JSONB,
      total_records_exported INTEGER DEFAULT 0,
      file_format VARCHAR(20) DEFAULT 'excel',
      exported_by VARCHAR(255),
      user_email VARCHAR(255),
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Daily progress snapshot — one row per module per day so the Duplicate Radar
  // can show a BURNDOWN per tab (Leads/Deals/Contacts/Accounts) over time, not
  // just a "right now" number. open = active clusters with that module; solved =
  // clusters no longer active (Sample User's chosen definition, 2026-06-17); total =
  // open + solved (the "from the beginning" denominator, which grows as new
  // duplicates are detected). merged = durable real-merge count from the
  // append-only ledger (survives Rebuild Clusters — the honest "data merged"
  // line). Upserted per (date, module): the last write of the day wins, so the
  // 6-hourly scan keeps today's row current while older days stay frozen as
  // history. See captureDuplicateProgressSnapshot / getDuplicateProgressSeries.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS duplicate_progress_daily (
      snapshot_date DATE NOT NULL,
      module VARCHAR(16) NOT NULL,
      segment VARCHAR(16) NOT NULL DEFAULT 'all',
      open_count INTEGER NOT NULL DEFAULT 0,
      solved_count INTEGER NOT NULL DEFAULT 0,
      total_count INTEGER NOT NULL DEFAULT 0,
      merged_count INTEGER NOT NULL DEFAULT 0,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (snapshot_date, module, segment)
    )
  `);

  // Segment burndown (2026-07-30): older deployments created this table before
  // the segment column existed. Add it + widen the PK so we can store one row
  // per (date, module, segment). Existing rows default to 'all' → no PK clash.
  // No DROP TABLE (HostingPlatform publish schema-sync trap). Idempotent.
  await pool.query(
    `ALTER TABLE duplicate_progress_daily
       ADD COLUMN IF NOT EXISTS segment VARCHAR(16) NOT NULL DEFAULT 'all'`,
  );
  await pool.query(
    `ALTER TABLE duplicate_progress_daily
       DROP CONSTRAINT IF EXISTS duplicate_progress_daily_pkey`,
  );
  await pool.query(
    `ALTER TABLE duplicate_progress_daily
       ADD PRIMARY KEY (snapshot_date, module, segment)`,
  );

  // Separation ledger (Sample User 2026-06-20) — durable "these CRMProvider records are NOT
  // duplicates of each other" decisions captured from Split / Dismiss. The
  // radar otherwise re-clusters by shared name / phone / domain on every sync,
  // which silently undoes an operator's split (the "I split it many times and
  // it came back" bug). findOrCreateClusterByCompany consults this and refuses
  // to re-fuse a record into a cluster holding a record it was separated from.
  // Pairs stored canonically (low,high) so the lookup is symmetric.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS duplicate_separation_ledger (
      id SERIAL PRIMARY KEY,
      CRMProvider_id_low VARCHAR(255) NOT NULL,
      CRMProvider_id_high VARCHAR(255) NOT NULL,
      reason VARCHAR(32) NOT NULL DEFAULT 'split',
      created_by VARCHAR(255),
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      UNIQUE (CRMProvider_id_low, CRMProvider_id_high)
    )
  `);
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_dup_sep_low ON duplicate_separation_ledger(CRMProvider_id_low)`,
  );
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_dup_sep_high ON duplicate_separation_ledger(CRMProvider_id_high)`,
  );

  // Empty/Orphaned cleanup: durable record of which records the operator has
  // already tagged Empty-Delete. The cleanup tab reads the LOCAL mirror, which
  // is stale until the next full sync — so without this a just-tagged record
  // reappears on Refresh ("why does it come back?"). The empty-records queries
  // exclude anything in this ledger, so a tagged record drops off immediately;
  // Untag removes it; a genuine CRMProvider deletion drops it from the mirror anyway.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS empty_delete_ledger (
      id SERIAL PRIMARY KEY,
      CRMProvider_record_id VARCHAR(255) NOT NULL,
      module VARCHAR(16) NOT NULL,
      tagged_by VARCHAR(255),
      status VARCHAR(16) NOT NULL DEFAULT 'pending_delete',
      deleted_at TIMESTAMP NULL,
      last_checked_at TIMESTAMP NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      UNIQUE (CRMProvider_record_id)
    )
  `);
  // Deletion-lifecycle columns (additive; reflected in the CREATE TABLE above so
  // schema-parity stays STRICT). status: 'pending_delete' until the CRMProvider admin
  // removes the record, then 'deleted' with deleted_at set; last_checked_at is
  // stamped by the reconcile pass that verifies existence in CRMProvider.
  await pool.query(
    `ALTER TABLE empty_delete_ledger ADD COLUMN IF NOT EXISTS status VARCHAR(16) NOT NULL DEFAULT 'pending_delete'`,
  );
  await pool.query(
    `ALTER TABLE empty_delete_ledger ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMP NULL`,
  );
  await pool.query(
    `ALTER TABLE empty_delete_ledger ADD COLUMN IF NOT EXISTS last_checked_at TIMESTAMP NULL`,
  );
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_empty_delete_ledger_rec ON empty_delete_ledger(CRMProvider_record_id)`,
  );
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_empty_delete_ledger_status ON empty_delete_ledger(status)`,
  );

  // Empty/Orphaned cleanup: durable "reviewed — keep, NOT empty" decisions. The
  // operator can Dismiss a flagged record that is actually legitimate (e.g. a
  // deal that has data); the empty-records queries exclude anything here so it
  // never reappears as cleanup work. Un-dismiss removes the row.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS empty_records_dismissed (
      id SERIAL PRIMARY KEY,
      CRMProvider_record_id VARCHAR(255) NOT NULL,
      module VARCHAR(16) NOT NULL,
      dismissed_by VARCHAR(255),
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      UNIQUE (CRMProvider_record_id)
    )
  `);
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_empty_records_dismissed_rec ON empty_records_dismissed(CRMProvider_record_id)`,
  );

  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_duplicate_clusters_domain ON duplicate_clusters(domain)`,
  );
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_duplicate_clusters_status ON duplicate_clusters(status)`,
  );
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_duplicate_records_cluster ON duplicate_records(cluster_id)`,
  );
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_duplicate_records_type ON duplicate_records(record_type)`,
  );

  // B6: Additional performance indexes
  await pool.query(
    `CREATE UNIQUE INDEX IF NOT EXISTS idx_duplicate_records_CRMProvider_id ON duplicate_records(CRMProvider_record_id) WHERE CRMProvider_record_id IS NOT NULL`,
  );
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_duplicate_records_email ON duplicate_records(LOWER(email)) WHERE email IS NOT NULL`,
  );
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_duplicate_records_phone_norm ON duplicate_records(phone_normalized) WHERE phone_normalized IS NOT NULL`,
  );
  // PERF (Sample User 2026-06-28): the per-contact cluster match in
  // findContactClusterByStrictMatch filters `LOWER(record_name) = $3` inside an
  // OR alongside email/phone. Email + phone are indexed above, but record_name
  // was NOT — and an OR where one arm is unindexed forces Postgres to SEQ-SCAN
  // all of duplicate_records. That query runs once PER fetched contact (≈59k on a
  // full pull), so the missing index turned the contact sync into hours of
  // O(N²) scanning that never finished (so the Contacts baseline never saved, so
  // every run re-pulled in full). This functional index lets the planner Bitmap-
  // OR all three identity arms. Mirrors idx_duplicate_records_email.
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_duplicate_records_name_lower ON duplicate_records(LOWER(record_name)) WHERE record_name IS NOT NULL`,
  );
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_duplicate_records_domain ON duplicate_records(domain) WHERE domain IS NOT NULL`,
  );

  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_duplicate_records_layout ON duplicate_records(layout_name) WHERE layout_name IS NOT NULL`,
  );
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_duplicate_records_CRMProvider_module ON duplicate_records(CRMProvider_module) WHERE CRMProvider_module IS NOT NULL`,
  );
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_duplicate_records_pipeline ON duplicate_records(pipeline) WHERE pipeline IS NOT NULL`,
  );
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_duplicate_records_owner ON duplicate_records(owner_name) WHERE owner_name IS NOT NULL`,
  );
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_duplicate_records_country ON duplicate_records(country) WHERE country IS NOT NULL`,
  );
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_duplicate_records_industry ON duplicate_records(industry) WHERE industry IS NOT NULL`,
  );
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_duplicate_records_modified ON duplicate_records(modified_date)`,
  );
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_duplicate_records_mobile_norm ON duplicate_records(mobile_normalized) WHERE mobile_normalized IS NOT NULL`,
  );
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_duplicate_records_cr ON duplicate_records(cr_number) WHERE cr_number IS NOT NULL`,
  );
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_duplicate_records_vat ON duplicate_records(vat_number) WHERE vat_number IS NOT NULL`,
  );
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_duplicate_record_tasks_record ON duplicate_record_tasks(related_record_id)`,
  );
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_duplicate_records_cleanup_class ON duplicate_records(cleanup_class)`,
  );

  // B4: pg_trgm for fuzzy matching
  try {
    await pool.query(`CREATE EXTENSION IF NOT EXISTS pg_trgm`);
    await pool.query(
      `CREATE INDEX IF NOT EXISTS idx_clusters_company_trgm ON duplicate_clusters USING GIN (company_name_normalized gin_trgm_ops)`,
    );
  } catch (e) {
    logger.info(
      "⚠️ [DuplicateRadar] pg_trgm not available, falling back to Levenshtein matching",
    );
  }
  // PERF (Sample User 2026-06-28): findOrCreateClusterByCompany does an EXACT-equality
  // lookup `WHERE company_name_normalized = $1` once per account/deal during the
  // sync. The GIN trigram index above only serves LIKE/similarity, NOT `=`, so
  // that exact match would seq-scan duplicate_clusters per record. This B-tree
  // index serves the equality lookup (prevents the account phase repeating the
  // contact-phase O(N²) stall).
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_clusters_company_name_eq ON duplicate_clusters(company_name_normalized) WHERE company_name_normalized IS NOT NULL`,
  );

  // Account inference hints — see src/utils/accountInference.ts. Stored
  // suggestions for sales: "this deal looks like it belongs to Account X
  // because the contact's email domain matches". Sales work the queue from
  // the Account Hints tab.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS account_inference_hints (
      id SERIAL PRIMARY KEY,
      deal_record_id INTEGER NOT NULL REFERENCES duplicate_records(id) ON DELETE CASCADE,
      suggested_account_record_id INTEGER REFERENCES duplicate_records(id) ON DELETE CASCADE,
      suggested_account_name TEXT,
      suggested_domain TEXT,
      evidence_contact_record_id INTEGER REFERENCES duplicate_records(id) ON DELETE SET NULL,
      evidence_contact_email TEXT,
      confidence INTEGER DEFAULT 0,
      status VARCHAR(16) DEFAULT 'pending',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      UNIQUE (deal_record_id, suggested_account_record_id)
    )
  `);
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_account_inference_status ON account_inference_hints(status)`,
  );
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_account_inference_confidence ON account_inference_hints(confidence DESC) WHERE status = 'pending'`,
  );

  // Record Hint — generalized cross-module link suggestions (Contact->Account,
  // Deal->Contact, etc). Mirrors account_inference_hints above but is
  // link-field agnostic (source_type + link_field describe what's being
  // suggested) so it can cover more than just deal->account.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS record_link_hints (
      id SERIAL PRIMARY KEY,
      source_record_id INT NOT NULL REFERENCES duplicate_records(id) ON DELETE CASCADE,
      source_type VARCHAR(20) NOT NULL,
      link_field VARCHAR(40) NOT NULL,
      suggested_target_record_id INT REFERENCES duplicate_records(id) ON DELETE SET NULL,
      suggested_target_CRMProvider_id VARCHAR(100),
      suggested_target_name TEXT,
      suggested_domain TEXT,
      evidence_record_id INT,
      evidence_detail TEXT,
      confidence INT NOT NULL DEFAULT 0,
      status VARCHAR(16) NOT NULL DEFAULT 'pending',
      created_at TIMESTAMPTZ DEFAULT NOW(),
      updated_at TIMESTAMPTZ DEFAULT NOW(),
      UNIQUE (source_record_id, link_field, suggested_target_record_id)
    )
  `);
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_record_link_hints_status ON record_link_hints (status)`,
  );
  await pool.query(
    `CREATE INDEX IF NOT EXISTS idx_record_link_hints_type ON record_link_hints (source_type, link_field)`,
  );

  // Record Hint §4 "Unaccounted deals — decide": the operator's ✗ "dismiss"
  // (Sample User 2026-07-14 — a stalled deal judged NOT a real issue). scanStaleDeals
  // excludes ids listed here so they stop resurfacing. No CRMProvider write — local
  // triage only.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS stale_deal_dismissals (
      deal_CRMProvider_id VARCHAR(100) PRIMARY KEY,
      dismissed_by TEXT,
      dismissed_at TIMESTAMPTZ DEFAULT NOW(),
      -- 'dismissed' = operator judged it not a real stale issue (false positive);
      -- 'resolved'  = operator already handled the deal MANUALLY in CRMProvider and wants
      -- it recorded as resolved, not dismissed (Sample User 2026-07-16). Both drop the
      -- deal off the Unaccounted list; the value is for audit/labelling.
      disposition TEXT NOT NULL DEFAULT 'dismissed'
    )
  `);
  // Schema-parity migration for tables that predate the disposition column.
  await pool.query(
    `ALTER TABLE stale_deal_dismissals ADD COLUMN IF NOT EXISTS disposition TEXT NOT NULL DEFAULT 'dismissed'`,
  );

  // R2 (per-owner Remediation Packet): cover-sheet text the operator
  // hands to a data-quality owner. Single-row key/value table — keeps the
  // dispute path + escalation contact editable without a code deploy and
  // without touching env vars. Seeded with sensible defaults if empty.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS duplicate_radar_packet_settings (
      setting_key   VARCHAR(64) PRIMARY KEY,
      setting_value TEXT NOT NULL,
      updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    )
  `);
  // Seed defaults — ON CONFLICT DO NOTHING so existing installs that
  // customised these values are not overwritten. To CHANGE a live value:
  //   UPDATE duplicate_radar_packet_settings
  //     SET setting_value='<new>'
  //     WHERE setting_key='<key>';
  await pool.query(
    `INSERT INTO duplicate_radar_packet_settings (setting_key, setting_value) VALUES
       ('escalation_contact_name',  'Sample User — Operations Quality'),
       ('escalation_contact_email', '<REDACTED_EMAIL>'),
       ('dispute_path',             'If a row should NOT be merged (e.g. intentional parallel deals for compliance reasons), flag it back to GRQ Quality with the Cluster ID and a one-line justification. Do not merge in CRMProvider until acknowledged.')
     ON CONFLICT (setting_key) DO NOTHING`,
  );
}

export interface PacketSettings {
  escalation_contact_name: string;
  escalation_contact_email: string;
  dispute_path: string;
}

export async function getPacketSettings(): Promise<PacketSettings> {
  const r = await pool.query(
    `SELECT setting_key, setting_value FROM duplicate_radar_packet_settings`,
  );
  const map: Record<string, string> = {};
  for (const row of r.rows) map[row.setting_key] = row.setting_value;
  return {
    escalation_contact_name:
      map.escalation_contact_name || "Sample User — Operations Quality",
    escalation_contact_email:
      map.escalation_contact_email || "<REDACTED_EMAIL>",
    dispute_path:
      map.dispute_path ||
      "If a row should NOT be merged, flag it back to GRQ Quality with the Cluster ID and a one-line justification. Do not merge in CRMProvider until acknowledged.",
  };
}

export async function createCluster(
  cluster: Omit<DuplicateCluster, "id" | "created_at" | "updated_at">,
): Promise<DuplicateCluster> {
  const companyNormalized = cluster.company_name
    ? normalizeCompanyName(cluster.company_name)
    : null;
  const result = await pool.query(
    `INSERT INTO duplicate_clusters 
     (domain, company_name, company_name_arabic, company_name_normalized, total_leads, total_deals, total_records, 
      confidence_level, confidence_score, first_record_date, latest_activity_date, 
      owners_involved, estimated_pipeline_value, status, ai_recommendation)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
     RETURNING *`,
    [
      cluster.domain,
      cluster.company_name,
      cluster.company_name_arabic,
      companyNormalized,
      cluster.total_leads,
      cluster.total_deals,
      cluster.total_records,
      cluster.confidence_level,
      cluster.confidence_score,
      cluster.first_record_date,
      cluster.latest_activity_date,
      JSON.stringify(cluster.owners_involved || []),
      cluster.estimated_pipeline_value || 0,
      cluster.status,
      cluster.ai_recommendation,
    ],
  );
  return result.rows[0];
}

// A1: Incremental upsert for records (replaces destructive clearAllDuplicateData approach)
export async function upsertRecord(
  record: Omit<DuplicateRecord, "id" | "created_at">,
): Promise<DuplicateRecord> {
  const phoneNorm = record.phone ? normalizePhone(record.phone) : null;
  const mobileNorm = record.mobile ? normalizePhone(record.mobile) : null;
  const result = await pool.query(
    `INSERT INTO duplicate_records 
     (cluster_id, record_type, CRMProvider_record_id, record_name, company_name, email, domain,
      phone, phone_normalized, mobile, mobile_normalized, owner_name, owner_email, status, stage, deal_value, source, created_date,
      modified_date, is_primary, ai_recommendation, confidence_score, is_mock_data, raw_data,
      layout_name, layout_id, CRMProvider_module, pipeline, products, contact_name, account_name,
      cr_number, vat_number, website, country, region, industry, no_of_employees, title,
      lead_type, gov_type, account_type)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24,
             $25, $26, $27, $28, $29, $30, $31, $32, $33, $34, $35, $36, $37, $38, $39, $40, $41, $42)
     ON CONFLICT (CRMProvider_record_id) WHERE CRMProvider_record_id IS NOT NULL DO UPDATE SET
       cluster_id = EXCLUDED.cluster_id,
       record_name = EXCLUDED.record_name,
       company_name = EXCLUDED.company_name,
       email = EXCLUDED.email,
       domain = EXCLUDED.domain,
       phone = EXCLUDED.phone,
       phone_normalized = EXCLUDED.phone_normalized,
       mobile = EXCLUDED.mobile,
       mobile_normalized = EXCLUDED.mobile_normalized,
       owner_name = EXCLUDED.owner_name,
       owner_email = EXCLUDED.owner_email,
       status = EXCLUDED.status,
       stage = EXCLUDED.stage,
       deal_value = EXCLUDED.deal_value,
       source = EXCLUDED.source,
       modified_date = EXCLUDED.modified_date,
       raw_data = EXCLUDED.raw_data,
       layout_name = EXCLUDED.layout_name,
       layout_id = EXCLUDED.layout_id,
       CRMProvider_module = EXCLUDED.CRMProvider_module,
       pipeline = EXCLUDED.pipeline,
       products = EXCLUDED.products,
       contact_name = EXCLUDED.contact_name,
       account_name = EXCLUDED.account_name,
       cr_number = EXCLUDED.cr_number,
       vat_number = EXCLUDED.vat_number,
       website = EXCLUDED.website,
       country = EXCLUDED.country,
       region = EXCLUDED.region,
       industry = EXCLUDED.industry,
       no_of_employees = EXCLUDED.no_of_employees,
       title = EXCLUDED.title,
       lead_type = EXCLUDED.lead_type,
       gov_type = EXCLUDED.gov_type,
       account_type = EXCLUDED.account_type
     RETURNING *`,
    [
      record.cluster_id,
      record.record_type,
      record.CRMProvider_record_id,
      record.record_name,
      record.company_name,
      record.email,
      record.domain,
      record.phone,
      phoneNorm,
      record.mobile,
      mobileNorm,
      record.owner_name,
      record.owner_email,
      record.status,
      record.stage,
      record.deal_value,
      record.source,
      record.created_date,
      record.modified_date,
      record.is_primary,
      record.ai_recommendation,
      record.confidence_score,
      record.is_mock_data,
      JSON.stringify(record.raw_data || {}),
      record.layout_name,
      record.layout_id,
      record.CRMProvider_module,
      record.pipeline,
      record.products,
      record.contact_name,
      record.account_name,
      record.cr_number,
      record.vat_number,
      record.website,
      record.country,
      record.region,
      record.industry,
      record.no_of_employees,
      record.title,
      record.lead_type,
      record.gov_type,
      record.account_type,
    ],
  );
  return result.rows[0];
}

// A7: phone_normalized included directly in INSERT
export async function addRecordToCluster(
  record: Omit<DuplicateRecord, "id" | "created_at">,
): Promise<DuplicateRecord> {
  const phoneNorm = record.phone ? normalizePhone(record.phone) : null;
  const result = await pool.query(
    `INSERT INTO duplicate_records 
     (cluster_id, record_type, CRMProvider_record_id, record_name, company_name, email, domain,
      phone, phone_normalized, owner_name, owner_email, status, stage, deal_value, source, created_date,
      modified_date, is_primary, ai_recommendation, confidence_score, is_mock_data, raw_data)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22)
     RETURNING *`,
    [
      record.cluster_id,
      record.record_type,
      record.CRMProvider_record_id,
      record.record_name,
      record.company_name,
      record.email,
      record.domain,
      record.phone,
      phoneNorm,
      record.owner_name,
      record.owner_email,
      record.status,
      record.stage,
      record.deal_value,
      record.source,
      record.created_date,
      record.modified_date,
      record.is_primary,
      record.ai_recommendation,
      record.confidence_score,
      record.is_mock_data,
      JSON.stringify(record.raw_data || {}),
    ],
  );
  return result.rows[0];
}

// Build the shared WHERE clause for cluster listing/counting. Centralised so
// the new `layouts` filter (and any future ones) stay in lock-step between
// `getAllClusters` and `getClusterCount`.
function buildClusterFilterClause(
  filters:
    | {
        status?: string;
        confidence_level?: string;
        start_date?: string;
        end_date?: string;
        hide_hierarchies?: boolean;
        layouts?: string[];
        /**
         * Per-owner drill: keep clusters that contain at least one
         * record owned by this email (case-insensitive). Wired into
         * the Owners tab on /duplicates so clicking an owner row
         * opens a modal listing the clusters they're carrying.
         */
        owner_email?: string;
        /** Marketplace / ExampleOrg / Example Organization product segment. */
        segment?: DuplicateFilters["segment"];
        /** Quarter / year chip — see the DATE_BASIS note below. */
        period_year?: number;
        period_quarter?: number;
      }
    | undefined,
  startIndex: number,
): { clause: string; params: any[]; nextIndex: number } {
  const params: any[] = [];
  let paramIndex = startIndex;
  let clause = "";

  // 2026-06-17 — DEFAULT excludes handled clusters so resolved (merged) and
  // ignored (dismissed) clusters never resurface in the clusters list or the
  // per-owner drill modal (which passes no status). Explicit 'all' opts back
  // in to every status; a specific status (active/resolved/ignored) filters
  // to exactly that one (the audit chips still work).
  if (filters?.status === "all") {
    /* explicit opt-in — no status filter */
  } else if (filters?.status) {
    clause += ` AND status = $${paramIndex++}`;
    params.push(filters.status);
  } else {
    clause += ` AND status NOT IN ('resolved', 'ignored')`;
  }
  if (filters?.confidence_level) {
    clause += ` AND confidence_level = $${paramIndex++}`;
    params.push(filters.confidence_level);
  }
  // DATE BASIS: first_record_date (when the earliest record in this cluster was
  // created IN THE CRM), not created_at (when OUR clustering process first saw
  // it). They are wildly different — a cluster observed live on 2026-08-24 had
  // first_record_date 2020-04-14 against created_at 2026-04-18, so a date filter
  // on created_at put a 2020 duplicate in Q2 2026. Worse, "Rebuild Clusters"
  // recreates these rows, so created_at is reset wholesale and every cluster
  // looks newly created. Filtering duplicates "by date" means the CRM's dates.
  // COALESCE keeps rows with no first_record_date reachable rather than
  // silently dropping them.
  const DATE_BASIS = "COALESCE(first_record_date, created_at)";
  if (filters?.start_date) {
    clause += ` AND ${DATE_BASIS} >= $${paramIndex++}`;
    params.push(filters.start_date);
  }
  if (filters?.end_date) {
    clause += ` AND ${DATE_BASIS} <= $${paramIndex++}`;
    params.push(filters.end_date + "T23:59:59Z");
  }
  // Quarter / year chip. Server-side derivation so every tab agrees on what
  // "Q3 2026" means, and a half-open [start, nextQuarterStart) interval so the
  // last day of the quarter is included and no date lands in two quarters —
  // same arithmetic as the Quality Reports timeframe selector.
  if (filters?.period_year) {
    const y = Number(filters.period_year);
    const q = filters.period_quarter ? Number(filters.period_quarter) : null;
    if (Number.isFinite(y) && y >= 2000 && y <= 2100) {
      const startMonth = q && q >= 1 && q <= 4 ? (q - 1) * 3 : 0;
      const endMonth = q && q >= 1 && q <= 4 ? q * 3 : 12;
      const start = new Date(Date.UTC(y, startMonth, 1)).toISOString();
      const end = new Date(Date.UTC(y, endMonth, 1)).toISOString();
      clause += ` AND ${DATE_BASIS} >= $${paramIndex++} AND ${DATE_BASIS} < $${paramIndex++}`;
      params.push(start, end);
    }
  }
  if (filters?.hide_hierarchies) {
    clause += ` AND GREATEST(COALESCE(total_leads,0), COALESCE(total_deals,0), COALESCE(total_contacts,0), COALESCE(total_accounts,0)) > 1`;
  }
  // Layout filter: keep clusters that have at least one record in any of the
  // selected CRMProvider layouts (Corporate Accounts, Standard, Marketplace, ...).
  if (filters?.layouts && filters.layouts.length > 0) {
    clause += ` AND EXISTS (
      SELECT 1 FROM duplicate_records dr
       WHERE dr.cluster_id = duplicate_clusters.id
         AND dr.layout_name = ANY($${paramIndex++}::text[])
    )`;
    params.push(filters.layouts);
  }
  // Owner filter: case-insensitive match against duplicate_records.owner_email.
  // A cluster qualifies when ANY of its records is owned by this person —
  // this matches how the Owners table aggregates total_records / dups
  // (it counts every record an owner is named on, regardless of who owns
  // the other records in the same cluster).
  if (filters?.owner_email && filters.owner_email.trim()) {
    clause += ` AND EXISTS (
      SELECT 1 FROM duplicate_records dr
       WHERE dr.cluster_id = duplicate_clusters.id
         AND LOWER(dr.owner_email) = LOWER($${paramIndex++})
    )`;
    params.push(filters.owner_email.trim());
  }
  // Segment chip (Marketplace / ExampleOrg / Example Organization) — Sample User 2026-07-13: keep
  // clusters that have at least one record in the chosen product layout. Mirrors
  // buildSegmentPredicate's layout semantics, inlined with the dr alias (all
  // literal, no bind params) so it composes with the EXISTS filters above.
  if (filters?.segment && filters.segment !== "all") {
    // Same layout source + substring marketplace match as buildSegmentPredicate
    // (Sample User 2026-07-15): fall back to raw_data Layout when the column is blank,
    // and treat any layout CONTAINING "marketplace" (e.g. "Doam Marketplace") as
    // marketplace — not just the exact 'marketplace' name.
    const LAYOUT =
      "LOWER(COALESCE(NULLIF(dr.layout_name,''), dr.raw_data#>>'{Layout,name}', dr.raw_data#>>'{$layout,name}', dr.raw_data->>'Layout', ''))";
    const NORM = `regexp_replace(${LAYOUT}, '[^a-z0-9]', '', 'g')`;
    const MKT = `(${NORM} LIKE '%marketplace%' OR ${NORM} LIKE '%partneraccounts%')`;
    let cond: string;
    if (filters.segment === "marketplace") {
      cond = MKT;
    } else if (filters.segment === "Example Organization") {
      cond = `${NORM} LIKE '%Example Organization%'`;
    } else {
      // ExampleOrg / corporate = NOT marketplace AND NOT Example Organization.
      cond = `NOT ${MKT} AND ${NORM} NOT LIKE '%Example Organization%'`;
    }
    clause += ` AND EXISTS (
      SELECT 1 FROM duplicate_records dr
       WHERE dr.cluster_id = duplicate_clusters.id
         AND ${cond}
    )`;
  }
  // Hide placeholder / junk-name clusters (Sample User 2026-07-14): لايوجد / "not
  // provided" / N/A / _placeholder etc. are CS name-quality noise, not real
  // duplicates — their home is the Empty/Junk tab. Filter on company_name
  // membership in the placeholder set + the quarantine domain. EMPTY names are
  // NOT hidden here (a real domain-keyed cluster can legitimately carry a blank
  // company name).
  clause += ` AND domain <> '${PLACEHOLDER_CLUSTER_DOMAIN}'
    AND LOWER(BTRIM(COALESCE(company_name,''))) <> ALL($${paramIndex++}::text[])`;
  params.push(PLACEHOLDER_COMPANY_NAMES_LOWER_ARR);
  return { clause, params, nextIndex: paramIndex };
}

// Whitelisted sort columns. Only allow values mapped here to be interpolated
// into the ORDER BY — guards against SQL injection from the query string.
const CLUSTER_SORT_COLUMNS: Record<string, string> = {
  records:    "total_records",
  similarity: "confidence_score",
  domain:     "domain",
  company:    "company_name",
  status:     "status",
  inflation:  "estimated_pipeline_value",
  updated:    "updated_at",
  // Sample User: newest duplicates first. latest_activity_date =
  // MAX(COALESCE(modified_date, created_date)) of the cluster's records,
  // so freshly created/touched dupes sort to the top of Domain Clusters.
  recent:     "latest_activity_date",
};

export async function getAllClusters(filters?: {
  status?: string;
  confidence_level?: string;
  limit?: number;
  offset?: number;
  start_date?: string;
  end_date?: string;
  hide_hierarchies?: boolean;
  layouts?: string[];
  owner_email?: string;
  sort?: string;
  dir?: string;
  segment?: DuplicateFilters["segment"];
}): Promise<Array<DuplicateCluster & { domain_count?: number }>> {
  const { clause, params, nextIndex } = buildClusterFilterClause(filters, 1);
  let paramIndex = nextIndex;
  // domain_count is a correlated subquery counting DISTINCT corporate-shaped
  // domains across the cluster's records. The frontend uses values >= 2 to
  // flag mixed clusters at the card level without an N+1 per-card fetch.
  // We approximate isCorporateDomain() in SQL by excluding empty values and
  // free-mail domains; the JS-side helper is authoritative for the modal,
  // this is just a cheap card-level hint.
  // domain_count is a correlated subquery that the frontend uses to flag
  // mixed-domain clusters at the card level (≥2 ⇒ mixed). We avoid a table
  // alias on the outer FROM because buildClusterFilterClause references
  // `duplicate_clusters.id` unqualified inside its EXISTS sub-clause for
  // the layouts filter.
  let query =
    `SELECT duplicate_clusters.*,
            (SELECT COUNT(DISTINCT LOWER(r.domain))
               FROM duplicate_records r
              WHERE r.cluster_id = duplicate_clusters.id
                AND r.domain IS NOT NULL
                AND r.domain <> ''
                AND LOWER(r.domain) NOT IN (
                  '<REDACTED_HOST>','<REDACTED_HOST>','<REDACTED_HOST>','<REDACTED_HOST>',
                  '<REDACTED_HOST>','<REDACTED_HOST>','<REDACTED_HOST>.uk','<REDACTED_HOST>',
                  '<REDACTED_HOST>','<REDACTED_HOST>','<REDACTED_HOST>','<REDACTED_HOST>','<REDACTED_HOST>','<REDACTED_HOST>',
                  '<REDACTED_HOST>','<REDACTED_HOST>','<REDACTED_HOST>','<REDACTED_HOST>',
                  '<REDACTED_HOST>','<REDACTED_HOST>','<REDACTED_HOST>','<REDACTED_HOST>','<REDACTED_HOST>'
                )
            ) AS domain_count,
            -- sibling_cluster_count: how many ACTIVE clusters share this exact
            -- domain (Sample User 2026-07-14 cross-link). >1 ⇒ this company was split
            -- into multiple cluster rows → show an "also split → Cluster Merge"
            -- badge on the card. Cheap: hits the domain btree index.
            (SELECT COUNT(*) FROM duplicate_clusters sc
              WHERE sc.domain = duplicate_clusters.domain
                AND sc.domain IS NOT NULL AND sc.domain <> ''
                AND sc.status = 'active'
            ) AS sibling_cluster_count
       FROM duplicate_clusters
      WHERE 1=1` + clause;

  // Exclude clusters where all remaining records are queued for deletion —
  // applies only to the active/open view (status='active' or default/undefined).
  // Resolved, ignored, and 'all' views are left exactly as they are.
  const isNonActiveView =
    filters?.status === "all" ||
    filters?.status === "resolved" ||
    filters?.status === "ignored";
  if (!isNonActiveView) {
    query += ` AND (SELECT COUNT(*) FROM duplicate_records dx WHERE dx.cluster_id = duplicate_clusters.id AND NOT ${queuedForDeletionSql("dx")}) >= 2`;
  }

  // Empty/Junk exclusion (Task 3): a cluster only belongs on this tab while
  // it still holds >=2 REAL records (cleanup_class IS NULL). Cleanup records
  // (empty/test/junk/orphaned/tagged) are classified post-scan by
  // classifyCleanupRecords() and are hidden here — their home is the
  // Empty/Junk tab, not Domain Clusters.
  query += ` AND (SELECT COUNT(*) FROM duplicate_records dc2 WHERE dc2.cluster_id = duplicate_clusters.id AND dc2.cleanup_class IS NULL) >= 2`;

  const sortKey = filters?.sort && CLUSTER_SORT_COLUMNS[filters.sort]
    ? CLUSTER_SORT_COLUMNS[filters.sort]
    : "total_records";
  const dir = filters?.dir === "asc" ? "ASC" : "DESC";
  // Stable secondary sort so equal primary values don't churn between pages.
  query += ` ORDER BY ${sortKey} ${dir} NULLS LAST, id ASC`;

  if (filters?.limit) {
    query += ` LIMIT $${paramIndex++}`;
    params.push(filters.limit);
  }
  if (filters?.offset !== undefined && filters?.offset !== null) {
    query += ` OFFSET $${paramIndex++}`;
    params.push(filters.offset);
  }

  const result = await pool.query(query, params);
  return result.rows;
}

export async function getClusterCount(filters?: {
  status?: string;
  confidence_level?: string;
  start_date?: string;
  end_date?: string;
  hide_hierarchies?: boolean;
  layouts?: string[];
  owner_email?: string;
  segment?: DuplicateFilters["segment"];
}): Promise<number> {
  const { clause, params } = buildClusterFilterClause(filters, 1);
  const query =
    "SELECT COUNT(*) as total FROM duplicate_clusters WHERE 1=1" + clause;
  const result = await pool.query(query, params);
  return parseInt(result.rows[0]?.total) || 0;
}

/**
 * Snapshot the current "solved" state (status='resolved' / 'resolve' &
 * 'module_resolved' merge actions) into the durable duplicate_resolution_ledger,
 * keyed by the survivor's stable CRMProvider id. Idempotent (ON CONFLICT DO NOTHING).
 *
 * MUST run at boot AND immediately before any Rebuild truncate — a Rebuild
 * CASCADE-deletes merge_actions and resets cluster status, so progress only
 * survives if it's been written to the ledger first. Skipping this is exactly
 * why the per-module "solved" counts collapsed to 0 after a rebuild.
 */
export async function backfillResolutionLedger(): Promise<void> {
  await pool
    .query(
      `INSERT INTO duplicate_resolution_ledger
         (module, master_CRMProvider_id, action_type, performed_by, notes, resolved_at)
       SELECT DISTINCT ON (dr.cluster_id, mod.module)
         mod.module,
         dr.CRMProvider_record_id,
         'resolve',
         dc.resolved_by,
         'backfilled from whole-cluster resolve',
         COALESCE(dc.resolved_at, NOW())
       FROM duplicate_clusters dc
       JOIN duplicate_records dr ON dr.cluster_id = dc.id
       JOIN LATERAL (
         SELECT CASE dr.record_type
                  WHEN 'lead' THEN 'Leads'
                  WHEN 'deal' THEN 'Deals'
                  WHEN 'contact' THEN 'Contacts'
                  WHEN 'account' THEN 'Accounts'
                END AS module
       ) mod ON true
       WHERE (
               dc.status = 'resolved'
               OR EXISTS (
                 SELECT 1 FROM duplicate_merge_actions ma
                  WHERE ma.cluster_id = dc.id AND ma.action_type = 'resolve'
               )
             )
         AND dr.record_type IN ('lead','deal','contact','account')
         AND dr.CRMProvider_record_id IS NOT NULL
       ORDER BY dr.cluster_id, mod.module, dr.is_primary DESC, dr.id ASC
       ON CONFLICT (module, master_CRMProvider_id) WHERE master_CRMProvider_id IS NOT NULL DO NOTHING`,
    )
    .catch((e) => {
      logger.warn("[DuplicateRadar] resolution-ledger resolve-backfill skipped (non-fatal)", {
        error: e instanceof Error ? e.message : String(e),
      });
    });
  await pool
    .query(
      `INSERT INTO duplicate_resolution_ledger
         (module, master_CRMProvider_id, action_type, performed_by, notes, resolved_at)
       SELECT DISTINCT ON (ma.cluster_id, mod.module)
         mod.module,
         pr.CRMProvider_record_id,
         'module_resolved',
         ma.performed_by,
         'backfilled from module_resolved action',
         COALESCE(ma.created_at, NOW())
       FROM duplicate_merge_actions ma
       JOIN duplicate_records pr ON pr.id = ma.primary_record_id
       JOIN duplicate_clusters dc ON dc.id = ma.cluster_id
       JOIN LATERAL (
         SELECT CASE pr.record_type
                  WHEN 'lead' THEN 'Leads'
                  WHEN 'deal' THEN 'Deals'
                  WHEN 'contact' THEN 'Contacts'
                  WHEN 'account' THEN 'Accounts'
                END AS module
       ) mod ON true
       WHERE ma.action_type = 'module_resolved'
         AND dc.status <> 'resolved'
         AND NOT EXISTS (
           SELECT 1 FROM duplicate_merge_actions r2
            WHERE r2.cluster_id = ma.cluster_id AND r2.action_type = 'resolve'
         )
         AND pr.record_type IN ('lead','deal','contact','account')
         AND pr.CRMProvider_record_id IS NOT NULL
       ORDER BY ma.cluster_id, mod.module, ma.created_at DESC
       ON CONFLICT (module, master_CRMProvider_id) WHERE master_CRMProvider_id IS NOT NULL DO NOTHING`,
    )
    .catch((e) => {
      logger.warn("[DuplicateRadar] resolution-ledger module-backfill skipped (non-fatal)", {
        error: e instanceof Error ? e.message : String(e),
      });
    });

  // THIRD source — the append-only apply log (duplicate_resolution_feedback).
  // Its cluster_id has NO foreign key, so it SURVIVES a Rebuild's TRUNCATE
  // CASCADE (unlike status + merge_actions). Seeding from it RECOVERS solved
  // progress that a prior rebuild wiped before this ledger captured it (the
  // "0 solved after rebuild" Sample User), keyed by the survivor's stable CRMProvider id.
  // Excludes applies that were later UNDONE (undo removes the tags + reopens).
  await pool
    .query(
      `INSERT INTO duplicate_resolution_ledger
         (module, master_CRMProvider_id, action_type, performed_by, notes, resolved_at)
       SELECT DISTINCT ON (mm.module, mm.master)
         mm.module,
         mm.master,
         -- APPLIED, not verified (Sample User 2026-07-06): an 'applied' feedback event
         -- means the duplicates were TAGGED, not confirmed deleted. Recover it as
         -- 'module_resolved' (AI-Applied/pending) so restoreLedgerResolvedClusterStatus
         -- does NOT auto-resolve it after a boot/Rebuild. Genuinely-verified clusters
         -- are recovered as 'resolve' by source-1 (status='resolved') above.
         'module_resolved',
         f.performed_by,
         'backfilled from apply feedback log (AI-Applied, pending verify)',
         COALESCE(f.created_at, NOW())
       FROM duplicate_resolution_feedback f
       JOIN LATERAL (
         SELECT f.plan_json->>'module' AS module,
                COALESCE(f.chosen_master_CRMProvider_id, f.proposed_master_CRMProvider_id) AS master
       ) mm ON true
       WHERE f.event_type = 'applied'
         AND COALESCE(f.performed_by, '') NOT ILIKE 'UNDO%'
         AND mm.module IN ('Leads','Deals','Contacts','Accounts')
         AND mm.master IS NOT NULL
         AND NOT EXISTS (
           SELECT 1 FROM duplicate_resolution_feedback u
            WHERE u.cluster_id = f.cluster_id
              AND COALESCE(u.performed_by, '') ILIKE 'UNDO%'
              AND u.created_at > f.created_at
         )
       ORDER BY mm.module, mm.master, f.created_at DESC
       ON CONFLICT (module, master_CRMProvider_id) WHERE master_CRMProvider_id IS NOT NULL DO NOTHING`,
    )
    .catch((e) => {
      logger.warn("[DuplicateRadar] resolution-ledger feedback-backfill skipped (non-fatal)", {
        error: e instanceof Error ? e.message : String(e),
      });
    });
}

// ── Daily progress snapshot (per-tab burndown) ────────────────────────────────

const PROGRESS_MODULES: Array<{ col: string; module: string }> = [
  { col: "total_leads", module: "Leads" },
  { col: "total_deals", module: "Deals" },
  { col: "total_contacts", module: "Contacts" },
  { col: "total_accounts", module: "Accounts" },
];

export interface DuplicateProgressRow {
  module: string;
  open: number; // active clusters with this module
  solved: number; // clusters no longer active (Sample User's definition)
  total: number; // open + solved (the "from the beginning" denominator)
  merged: number; // durable real-merge count across ALL 4 modules (ledger; survives rebuilds)
}

/**
 * Capture today's per-module progress and UPSERT one row per (date, module)
 * into duplicate_progress_daily. Idempotent within a day — the last write wins,
 * so the 6-hourly scan keeps today's row current while older days stay frozen
 * as history. Returns the snapshot it wrote. Best-effort: never throws (a
 * snapshot failure must not abort a scan).
 *
 * Definitions (locked with Sample User 2026-06-17; refined 2026-07-06):
 *   open   = clusters with status='active' that contain this module AND have NO
 *            apply action yet (truly untouched). An applied cluster now stays
 *            'active' in the AI-Applied queue until Verify-in-CRM resolves it, so
 *            it must NOT count as "open" — it's handled, awaiting deletion.
 *   solved = every other cluster containing this module (closed OR AI-Applied —
 *            merged, linked, marked-resolved, ignored, or tagged-pending-delete)
 *   total  = open + solved (all clusters that contain this module)
 *   merged = distinct durable real merges for this module from the ledger
 */
export async function captureDuplicateProgressSnapshot(): Promise<DuplicateProgressRow[]> {
  const out: DuplicateProgressRow[] = PROGRESS_MODULES.map((m) => ({
    module: m.module,
    open: 0,
    solved: 0,
    total: 0,
    merged: 0,
  }));
  try {
    // Per-segment merged counts (ALL ledger rows w/ a resolved survivor,
    // attributed by layout — matches the old un-segmented all-modules count).
    const resolveRows = await fetchResolveRowsWithSurvivorSegment(false);
    const mergedBySeg: Record<string, Record<string, number>> = {}; // segment -> module -> count
    const bump = (seg: string, mod: string) => {
      const b = (mergedBySeg[seg] ??= {});
      b[mod] = (b[mod] || 0) + 1;
    };
    for (const row of resolveRows) {
      bump("all", row.module); // matches old all-modules ledger count
      if (row.survivor_present) bump(classifySegmentFromLayout(row.layout), row.module);
    }

    // open/solved/total per segment via an EXISTS on duplicate_records layout.
    const SEG_LIST = ["all", "marketplace", "ExampleOrg", "Example Organization"] as const;
    for (const seg of SEG_LIST) {
      const p = buildSegmentPredicate(seg === "all" ? "all" : seg, 1);
      const exists = p.condition
        ? `AND EXISTS (SELECT 1 FROM duplicate_records r
                        WHERE r.cluster_id = dc.id AND ${p.condition})`
        : "";
      // `> 1`, not `> 0` — a cluster holding ONE record of this module is not a
      // duplicate of it. `> 0` counted every cross-module link as a duplicate
      // for each module present, which is why the ChatProvider digest reported totals
      // of 25,259 leads / 54,624 deals / 63,902 contacts against a real
      // duplicate universe of 10,327 clusters (measured 2026-08-20). Matches
      // getSummary, trueDuplicateClusters and the per-module tabs.
      const segSelects = PROGRESS_MODULES.map(
        (o) =>
          `COUNT(*) FILTER (WHERE dc.${o.col} > 1 ${exists})::int AS ${o.col}_t,
           COUNT(*) FILTER (WHERE dc.${o.col} > 1 ${exists} AND dc.status = 'active'
                            AND NOT EXISTS (SELECT 1 FROM duplicate_merge_actions ma
                              WHERE ma.cluster_id = dc.id
                                AND ma.action_type IN ('resolve','module_resolved','auto_merge_pending')))::int AS ${o.col}_o`,
      ).join(",\n");
      const sr = await pool.query(`SELECT ${segSelects} FROM duplicate_clusters dc`, p.params);
      const srow = sr.rows[0] || {};
      for (const [i, o] of PROGRESS_MODULES.entries()) {
        const total = Number(srow[`${o.col}_t`] || 0);
        const open = Number(srow[`${o.col}_o`] || 0);
        const solved = Math.max(0, total - open);
        const merged = mergedBySeg[seg]?.[o.module] || 0;
        // Keep populating out[] from the seg === "all" pass so the function's
        // return value (used by existing 1-segment callers) is unchanged.
        if (seg === "all") {
          out[i].total = total;
          out[i].open = open;
          out[i].solved = solved;
          out[i].merged = merged;
        }
        await pool.query(
          `INSERT INTO duplicate_progress_daily
             (snapshot_date, module, segment, open_count, solved_count, total_count, merged_count, created_at)
           VALUES (CURRENT_DATE, $1, $2, $3, $4, $5, $6, NOW())
           ON CONFLICT (snapshot_date, module, segment) DO UPDATE SET
             open_count = EXCLUDED.open_count, solved_count = EXCLUDED.solved_count,
             total_count = EXCLUDED.total_count, merged_count = EXCLUDED.merged_count, created_at = NOW()`,
          [o.module, seg, open, solved, total, merged],
        );
      }
    }
  } catch (e) {
    logger.warn("[DuplicateRadar] captureDuplicateProgressSnapshot skipped (non-fatal)", {
      error: e instanceof Error ? e.message : String(e),
    });
  }
  return out;
}

export interface DuplicateProgressSeriesPoint {
  date: string; // YYYY-MM-DD
  open: number;
  solved: number;
  total: number;
  merged: number;
}

/**
 * Read the per-module daily progress series for the last `days` days, plus the
 * latest snapshot per module and the day-over-day deltas. Powers the "Progress
 * by tab" panel + the digest line. If today has no row yet (e.g. first boot
 * before a scan), it captures one on the fly so the caller always sees current
 * numbers.
 */
export async function getDuplicateProgressSeries(
  days = 30,
  segment: string = "all",
): Promise<{
  byModule: Record<
    string,
    {
      latest: DuplicateProgressSeriesPoint | null;
      previous: DuplicateProgressSeriesPoint | null;
      series: DuplicateProgressSeriesPoint[];
    }
  >;
  generatedAt: string;
}> {
  const lookback = Math.max(1, Math.min(Math.floor(days) || 30, 365));
  const byModule: Record<string, any> = {};
  for (const m of PROGRESS_MODULES) {
    byModule[m.module] = { latest: null, previous: null, series: [] };
  }
  try {
    // Make sure today's row exists so "latest" is never stale.
    const todayCheck = await pool.query<{ n: string }>(
      `SELECT COUNT(*)::text AS n FROM duplicate_progress_daily
        WHERE snapshot_date = CURRENT_DATE AND segment = $1`,
      [segment],
    );
    if (Number(todayCheck.rows[0]?.n || 0) === 0) {
      await captureDuplicateProgressSnapshot();
    }

    const r = await pool.query(
      `SELECT to_char(snapshot_date, 'YYYY-MM-DD') AS date, module,
              open_count, solved_count, total_count, merged_count
         FROM duplicate_progress_daily
        WHERE snapshot_date >= CURRENT_DATE - ($1::int - 1) AND segment = $2
        ORDER BY module, snapshot_date ASC`,
      [lookback, segment],
    );
    for (const row of r.rows) {
      const bucket = byModule[row.module];
      if (!bucket) continue;
      const point: DuplicateProgressSeriesPoint = {
        date: row.date,
        open: Number(row.open_count) || 0,
        solved: Number(row.solved_count) || 0,
        total: Number(row.total_count) || 0,
        merged: Number(row.merged_count) || 0,
      };
      bucket.series.push(point);
    }
    for (const m of PROGRESS_MODULES) {
      const s = byModule[m.module].series as DuplicateProgressSeriesPoint[];
      byModule[m.module].latest = s.length ? s[s.length - 1] : null;
      byModule[m.module].previous = s.length > 1 ? s[s.length - 2] : null;
    }
  } catch (e) {
    logger.warn("[DuplicateRadar] getDuplicateProgressSeries failed (non-fatal)", {
      error: e instanceof Error ? e.message : String(e),
    });
  }
  return { byModule, generatedAt: new Date().toISOString() };
}

/**
 * Duplicate-merge ledger rows across ALL 4 modules (Leads, Deals, Contacts,
 * Accounts), each joined to its surviving record so we can attribute it to a
 * segment by layout. survivor_present distinguishes "blank layout on a real
 * record" (→ ExampleOrg) from "survivor gone" (→ unknown bucket). dup_count =
 * number of dups tagged/removed for that survivor.
 *
 * `resolveOnly` (default true) selects which ledger rows count:
 *   - true  → only VERIFIED merges (action_type='resolve'). This is the
 *             headline consumer (getDataCleaningProgress); its Cleaning
 *             Progress modules only cover Deals/Accounts, so Leads/Contacts
 *             rows returned here are simply dropped by shapeCleaningProgress's
 *             module guard — never miscounted into the unknown bucket.
 *   - false → every ledger row with a resolved survivor (master_CRMProvider_id IS
 *             NOT NULL), reproducing the original writer semantics used by
 *             captureDuplicateProgressSnapshot's per-tab "merged" burndown
 *             count (resolve + module_resolved + auto_merge_pending etc).
 */
export async function fetchResolveRowsWithSurvivorSegment(
  resolveOnly: boolean = true,
): Promise<ResolveRowRaw[]> {
  const whereClause = resolveOnly
    ? `l.action_type = 'resolve'`
    : `l.master_CRMProvider_id IS NOT NULL`;
  const r = await pool.query(
    `SELECT l.module AS module,
            (r.CRMProvider_record_id IS NOT NULL) AS survivor_present,
            COALESCE(NULLIF(r.layout_name,''), r.raw_data#>>'{Layout,name}',
                     r.raw_data#>>'{$layout,name}', r.raw_data->>'Layout') AS layout,
            COALESCE(jsonb_array_length(NULLIF(l.duplicate_CRMProvider_ids, '[]'::jsonb)), 0) AS dup_count
       FROM duplicate_resolution_ledger l
       LEFT JOIN duplicate_records r ON r.CRMProvider_record_id = l.master_CRMProvider_id
      WHERE ${whereClause}`,
  );
  return r.rows.map((x: any) => ({
    module: x.module,
    survivor_present: x.survivor_present === true,
    layout: x.layout ?? null,
    dup_count: Number(x.dup_count) || 0,
  }));
}

/** One source of truth for the Cleaning Progress tab, its export, and AssistantPersona. */
export async function getDataCleaningProgress(
  segment: DuplicateFilters["segment"],
): Promise<DataCleaningProgress> {
  const seg = segment && segment !== "all" ? segment : "all";
  // duplicate_progress_daily + classifySegmentFromLayout never produce
  // "corporate" (it's the legacy alias for "ExampleOrg") — normalize here so
  // shapeCleaningProgress's segment equality check and the daily-series
  // lookup both match rows actually stored under "ExampleOrg".
  const segN = seg === "corporate" ? "ExampleOrg" : seg;
  const sync = await pool.query(
    `SELECT to_char(MAX(last_sync_at), 'YYYY-MM-DD"T"HH24:MI:SS"Z"') AS last_sync_at FROM CRMProvider_sync_state`,
  );
  const resolveRows = await fetchResolveRowsWithSurvivorSegment();
  // No module filter. The tile above this figure says "all layouts", and the
  // old `module IN ('Deals','Accounts')` silently dropped every other module —
  // in this tenant ALL 253 confirmed deletions are module='Contacts', so the
  // tile read 0 next to a tagged list showing 253 deleted (verified
  // 2026-08-20). Deals/Accounts keep their own keys for the per-module cards;
  // shapeCleaningProgress sums the whole map for the headline.
  const empty = await pool.query(
    `SELECT module, COUNT(*)::text AS n FROM empty_delete_ledger
      WHERE status = 'deleted' GROUP BY module`,
  );
  const emptyMap: Record<string, number> = { Deals: 0, Accounts: 0 };
  for (const row of empty.rows) emptyMap[String(row.module)] = Number(row.n) || 0;

  const outstanding = { Deals: 0, Accounts: 0 } as Record<"Deals" | "Accounts", number>;
  for (const [mod, rtype] of [["Deals", "deal"], ["Accounts", "account"]] as const) {
    const p = buildSegmentPredicate(segN, 1);
    const segCond = p.condition ? " AND " + p.condition : "";
    const res = await pool.query(
      `SELECT COUNT(*)::text AS n
         FROM duplicate_records r
         JOIN duplicate_clusters dc ON dc.id = r.cluster_id
        WHERE r.record_type = $${p.params.length + 1}
          AND dc.status = 'active' AND dc.total_${rtype === "deal" ? "deals" : "accounts"} > 1
          AND r.is_primary = false${segCond}`,
      [...p.params, rtype],
    );
    outstanding[mod] = Number(res.rows[0]?.n) || 0;
  }

  const series = await getDuplicateProgressSeries(30, segN);
  const trendModule = "Deals"; // burndown headline module
  const bm = series.byModule[trendModule] || { series: [], latest: null };
  const trend = {
    days: 30, segment: segN, series: bm.series,
    first: bm.series[0] ?? null, latest: bm.latest ?? null,
  };

  return shapeCleaningProgress({
    segment: segN,
    generatedAt: new Date().toISOString(),
    lastSyncAt: sync.rows[0]?.last_sync_at ?? null,
    resolveRows, emptyDeleted: emptyMap, outstanding, trend,
  });
}

// Outstanding lead-duplicate count for a segment — mirrors the outstanding-count
// query in getDataCleaningProgress above, but for record_type='lead' (Deals/
// Accounts cleaning progress doesn't cover Leads, so the Quality Reports Hub's
// per-BU aggregator needs this standalone for SDR/Partnership function reports).
export async function getSegmentLeadDuplicateCount(
  segment: DuplicateFilters["segment"],
): Promise<{ segment: string; outstanding_leads: number }> {
  const seg = segment && segment !== "all" ? (segment === "corporate" ? "ExampleOrg" : segment) : "all";
  const p = buildSegmentPredicate(seg, 1);
  const segCond = p.condition ? " AND " + p.condition : "";
  const res = await pool.query(
    `SELECT COUNT(*)::text AS n
       FROM duplicate_records r
       JOIN duplicate_clusters dc ON dc.id = r.cluster_id
      WHERE r.record_type = 'lead' AND dc.status = 'active'
        AND dc.total_leads > 1 AND r.is_primary = false${segCond}`,
    [...p.params],
  );
  return { segment: seg, outstanding_leads: Number(res.rows[0]?.n) || 0 };
}

/** CRM company names + per-module counts + deal stages for the bulk name matcher.
 *  Names/counts/stages ONLY — never raw_data (large-payload lesson). */
export async function getCompanyBatchRows(
  segment: DuplicateFilters["segment"],
): Promise<CrmNameRow[]> {
  const seg = segment && segment !== "all" ? (segment === "corporate" ? "ExampleOrg" : segment) : "all";
  const p = buildSegmentPredicate(seg, 1);
  const segCond = p.condition ? " AND " + p.condition : "";
  const res = await pool.query(
    `SELECT COALESCE(NULLIF(r.company_name,''), NULLIF(r.account_name,''),
                     CASE WHEN r.record_type IN ('account','deal') THEN NULLIF(r.record_name,'') END) AS crm_name,
            r.record_type AS record_type,
            COUNT(*)::int AS n,
            ARRAY_AGG(DISTINCT r.stage) FILTER (
              WHERE r.record_type = 'deal' AND COALESCE(r.stage,'') <> ''
            ) AS stages
       FROM duplicate_records r
      WHERE COALESCE(NULLIF(r.company_name,''), NULLIF(r.account_name,''),
                     CASE WHEN r.record_type IN ('account','deal') THEN NULLIF(r.record_name,'') END) IS NOT NULL${segCond}
      GROUP BY 1, 2`,
    [...p.params],
  );
  return res.rows.map((x: any) => ({
    crm_name: String(x.crm_name || ""),
    record_type: String(x.record_type || ""),
    n: Number(x.n) || 0,
    stages: Array.isArray(x.stages) ? x.stages.filter(Boolean) : [],
  }));
}

// Outstanding account-duplicate count for a segment. Same shape as the lead
// counter above, for record_type='account'.
//
// Customer Success maps only to cs_lifecycle, which is a lifecycle report and
// carries no cleanup figure, so the CS Data cleanup tile read "not mapped"
// while SDR (leads) and Sales (deals) showed numbers. CS owns the customer
// ACCOUNT records, so that is what its cleanup burden is measured on
// (confirmed by Sample User 2026-08-20).
export async function getSegmentAccountDuplicateCount(
  segment: DuplicateFilters["segment"],
): Promise<{ segment: string; outstanding_accounts: number }> {
  const seg = segment && segment !== "all" ? (segment === "corporate" ? "ExampleOrg" : segment) : "all";
  const p = buildSegmentPredicate(seg, 1);
  const segCond = p.condition ? " AND " + p.condition : "";
  const res = await pool.query(
    `SELECT COUNT(*)::text AS n
       FROM duplicate_records r
       JOIN duplicate_clusters dc ON dc.id = r.cluster_id
      WHERE r.record_type = 'account' AND dc.status = 'active'
        AND dc.total_accounts > 1 AND r.is_primary = false${segCond}`,
    [...p.params],
  );
  return { segment: seg, outstanding_accounts: Number(res.rows[0]?.n) || 0 };
}

/**
 * How far along the pipeline an OPEN stage is, for deciding which of two
 * competing deals should carry the account forward.
 *
 * Stalled stages are deliberately ranked BELOW early-but-moving ones: an
 * On Hold deal has more pipeline history than a fresh Contacted, but keeping
 * it and closing the active one is the wrong way round. "Not Attend Meeting"
 * is a setback for the same reason.
 *
 * Unknown stages get a middling score rather than 0, so a stage this list has
 * never seen does not automatically lose to "New Deal".
 */
const OPEN_STAGE_RANK: Record<string, number> = {
  "agreement sent": 70,
  proposal: 60,
  meeting: 50,
  meetings: 50,
  "follow up": 40,
  contacted: 30,
  "in progress": 30,
  "new deal": 20,
  "not attend meeting": 15,
  "on hold": 10,
  hold: 10,
  unaccounted: 5,
  // "Old Data" is a parking label for records nobody is working, not a
  // pipeline position. Left to the default rank it scored 25 and beat a live
  // "New Deal" — the High Source row recommended KEEPing the dead record and
  // closing the real one (Sample User 2026-08-24). It must sit at the bottom.
  "old data": 1,
};
const DEFAULT_STAGE_RANK = 25;

function stageRank(stage: string): number {
  const s = (stage || "").trim().toLowerCase();
  return OPEN_STAGE_RANK[s] ?? DEFAULT_STAGE_RANK;
}

/**
 * Pick the deal that should stay open, and say why.
 *
 * Order of preference, each tie broken by the next:
 *   1. furthest along the pipeline (stageRank)
 *   2. most recent activity — a live conversation beats a dormant record
 *   3. has a value on it — a costed deal is the one being negotiated
 *   4. oldest created — the original, when nothing else separates them
 *
 * Returns the SAME array, annotated. Never reorders the caller's data and
 * never writes anything: Sales decides, this only argues a case.
 */
/**
 * Owner values that mean NOBODY is working this deal.
 *
 * "ExampleOrg" is the tenant's own placeholder owner on records that were
 * imported or never assigned — it is not a person. "Unassigned" is the
 * fallback this module substitutes when CRMProvider has neither an owner name nor an
 * owner email.
 */
const UNOWNED_OWNERS = new Set(["", "unassigned", "ExampleOrg", "ExampleOrg"]);

export function isUnownedDeal(owner: string | null | undefined): boolean {
  return UNOWNED_OWNERS.has(String(owner || "").trim().toLowerCase());
}

/**
 * Below this stage rank, having no owner disqualifies a deal from being the
 * keeper. At or above it (Proposal, Agreement Sent) the deal represents real,
 * live commercial progress and closing it would be destructive — the right fix
 * there is to assign an owner, not to close the deal, so it is left alone.
 */
const PROTECTED_UNOWNED_RANK = 60;

/** A deal nobody owns cannot carry the account forward — unless it is already
 *  at a closing stage. Lower sorts first, so 1 means "demoted". */
function ownershipDemotion(d: { stage: string; owner?: string }): number {
  if (!isUnownedDeal(d.owner)) return 0;
  return stageRank(d.stage) >= PROTECTED_UNOWNED_RANK ? 0 : 1;
}

function annotateKeepClose<
  T extends {
    stage: string;
    owner?: string;
    amount: number;
    created: string | null;
    last_activity: string | null;
  },
>(deals: T[]): Array<T & { suggestion: "keep" | "close"; suggestion_reason: string }> {
  const ms = (v: string | null) => (v ? new Date(v).getTime() || 0 : 0);
  const scored = deals.map((d, i) => ({
    i,
    // Ownership is checked FIRST, ahead of pipeline position (Sample User 2026-08-26).
    // A deal owned by nobody cannot carry the account forward — there is no one
    // to work it — so it must not win over a deal someone is actually holding,
    // even when its stage looks livelier. This is what stopped SBAHC and Royal
    // Commission recommending an ownerless "New Deal" over a rep's "On Hold".
    // Deals already at Proposal or beyond are exempt: closing live commercial
    // progress because of a blank field would be destructive, and the right fix
    // there is to assign an owner.
    demoted: ownershipDemotion(d),
    rank: stageRank(d.stage),
    activity: ms(d.last_activity),
    amount: Number(d.amount) || 0,
    created: ms(d.created) || Number.MAX_SAFE_INTEGER,
  }));
  const best = [...scored].sort(
    (a, b) =>
      a.demoted - b.demoted ||
      b.rank - a.rank ||
      b.activity - a.activity ||
      (b.amount > 0 ? 1 : 0) - (a.amount > 0 ? 1 : 0) ||
      a.created - b.created,
  )[0];
  return deals.map((d, i) => {
    const me = scored[i];
    if (i === best.i) {
      // When the keeper won because the alternative had no owner, say so
      // FIRST: otherwise the row shows a keeper at an apparently earlier stage
      // with no explanation, and the recommendation looks wrong.
      const beatAnUnowned = scored.some((s) => s.i !== best.i && s.demoted === 1);
      const bits = beatAnUnowned
        ? [`has a real owner (${d.owner || "assigned"})`]
        : [`furthest along (${d.stage || "unknown stage"})`];
      if (me.activity) bits.push("most recent activity");
      if (me.amount > 0) bits.push("has a value");
      return { ...d, suggestion: "keep" as const, suggestion_reason: bits.join(", ") };
    }
    const why =
      me.demoted === 1 && best.demoted === 0
        ? `nobody owns this deal (${d.owner || "unassigned"}) — assign it or close it`
        : me.rank < best.rank
          ? `behind ${deals[best.i].stage || "the kept deal"} in the pipeline`
          : me.activity < best.activity
            ? "less recent activity"
            : me.amount === 0 && best.amount > 0
              ? "no value recorded"
              : "duplicate of the kept deal";
    return { ...d, suggestion: "close" as const, suggestion_reason: why };
  });
}

export interface MultiActiveDealAccount {
  /** Domain the deals share, or null when they were grouped by company name. */
  domain: string | null;
  account_id: string | null;
  account_name: string;
  open_deals: number;
  distinct_owners: number;
  total_open_value: number;
  owners: string[];
  deals: Array<{
    id: string;
    name: string;
    stage: string;
    owner: string;
    amount: number;
    /** CRMProvider layout this deal sits on — every deal in a group shares it. */
    layout: string;
    created: string | null;
    last_activity: string | null;
    /**
     * RECOMMENDATION ONLY — nothing is written to CRMProvider. "keep" is the deal the
     * ranking says should carry the account forward; "close" is everything
     * else in the conflict. Sales decides.
     */
    suggestion: "keep" | "close";
    /** Why this deal was ranked where it was, in plain words. */
    suggestion_reason: string;
  }>;
}

/**
 * Accounts carrying MORE THAN ONE OPEN deal — the "one active deal per Account"
 * rule (Sample User 2026-08-24). Two open deals on the same customer means two sellers
 * can be working it, the client can be contacted twice, and the pipeline is
 * counted twice.
 *
 * "Open" is openStagePredicate — the SAME definition as Amount at risk and the
 * radar tabs, so won and terminal stages (Agreement Signed, Paid, Partner
 * Active, Closed *, …) never count. An account with one open deal and five
 * Closed Lost is CLEAN and must not appear.
 *
 * `distinct_owners > 1` is the aggravating case Sample User Sales: the
 * same account worked by two different people. Accounts where one owner holds
 * both open deals are still violations of the rule, but they are a
 * housekeeping problem rather than a collision, so the caller can separate them.
 *
 * Grouped by the CRMProvider Account id from raw_data, falling back to the account
 * name, so two deals pointing at the same account row group together even when
 * the deal names differ ("Example Organization" vs "Example Organization").
 */
/**
 * Short-lived result cache, keyed by layout.
 *
 * Viewing the tab and then downloading the Excel ran this query TWICE within
 * seconds, and a single run was enough to make the HostingPlatform instance fail its
 * healthcheck (2026-08-25). 90s is long enough to cover "look at the tab, then
 * export it" and short enough that a resolved conflict disappears on the next
 * refresh. Also collapses concurrent callers onto one in-flight query.
 */
const MULTI_ACTIVE_TTL_MS = 90_000;
const multiActiveCache = new Map<
  string,
  { at: number; rows: MultiActiveDealAccount[] }
>();
const multiActiveInFlight = new Map<string, Promise<MultiActiveDealAccount[]>>();

export async function getMultiActiveDealAccounts(
  segment: DuplicateFilters["segment"],
  opts?: { multiOwnerOnly?: boolean; limit?: number },
): Promise<MultiActiveDealAccount[]> {
  const cacheKey = `${!segment || segment === "corporate" ? "ExampleOrg" : segment}|${
    opts?.limit ?? "d"
  }`;
  const hit = multiActiveCache.get(cacheKey);
  if (hit && Date.now() - hit.at < MULTI_ACTIVE_TTL_MS) {
    // multiOwnerOnly is applied by the caller, so one cached set serves both.
    return opts?.multiOwnerOnly ? hit.rows.filter((r) => r.distinct_owners > 1) : hit.rows;
  }
  const flying = multiActiveInFlight.get(cacheKey);
  if (flying) {
    const rows = await flying;
    return opts?.multiOwnerOnly ? rows.filter((r) => r.distinct_owners > 1) : rows;
  }
  const run = queryMultiActiveDealAccounts(segment, opts?.limit)
    .then((rows) => {
      multiActiveCache.set(cacheKey, { at: Date.now(), rows });
      return rows;
    })
    .finally(() => {
      multiActiveInFlight.delete(cacheKey);
    });
  multiActiveInFlight.set(cacheKey, run);
  const rows = await run;
  return opts?.multiOwnerOnly ? rows.filter((r) => r.distinct_owners > 1) : rows;
}

async function queryMultiActiveDealAccounts(
  segment: DuplicateFilters["segment"],
  limitOpt?: number,
): Promise<MultiActiveDealAccount[]> {
  const opts = { multiOwnerOnly: false, limit: limitOpt };
  // The rule is scoped to ONE LAYOUT — ExampleOrg today (Sample User 2026-08-24).
  // Two open deals on the same company across DIFFERENT products (a ExampleOrg
  // deal and a Example Organization deal) are legitimately separate sales, not a collision,
  // so comparing across layouts would manufacture violations. An explicit
  // segment is honoured; "all" would compare across products and is therefore
  // NOT the default here, unlike the rest of the radar.
  const seg = !segment || segment === "corporate" ? "ExampleOrg" : segment;
  const p = buildSegmentPredicate(seg, 1);
  const segCond = p.condition ? " AND " + p.condition : "";
  const limit = Math.max(1, Math.min(opts?.limit ?? 500, 2000));
  const res = await pool.query(
    // TWO PASSES, deliberately (2026-08-25). The single-pass version built the
    // deal JSON for EVERY account in the layout and then threw away all but the
    // ~25 with more than one open deal. It took 5-6 seconds and repeatedly took
    // the HostingPlatform instance down — health returned 200 five times running, then
    // 500 immediately after one call. `keys` narrows to the conflicting
    // accounts on cheap columns first; json_agg then runs over tens of groups
    // instead of thousands. MATERIALIZED so `open_deals` is scanned once, not
    // once per reference.
    `WITH open_deals AS MATERIALIZED (
       SELECT r.CRMProvider_record_id AS id,
              COALESCE(NULLIF(BTRIM(r.record_name),''), r.CRMProvider_record_id) AS name,
              COALESCE(NULLIF(BTRIM(r.stage),''), r.raw_data->>'Stage', '') AS stage,
              COALESCE(NULLIF(BTRIM(r.owner_name),''), NULLIF(BTRIM(r.owner_email),''), 'Unassigned') AS owner,
              COALESCE(r.deal_value, 0) AS amount,
              r.created_date AS created,
              r.modified_date AS last_activity,
              COALESCE(NULLIF(BTRIM(r.layout_name), ''), '') AS layout,
              -- Deal records in this tenant carry no domain of their own. The
              -- Account's domain is fetched in a SECOND, small query keyed on
              -- the account ids this one returns, and merged in TypeScript —
              -- see below. A LEFT JOIN LATERAL here looked tidier and took the
              -- query from ~1s to 13s (measured 2026-08-25), because it runs
              -- once per open deal instead of once per surviving group.
              NULLIF(LOWER(BTRIM(r.domain)), '') AS domain,
              NULLIF(BTRIM(r.raw_data->'Account_Name'->>'id'), '') AS account_id,
              COALESCE(
                NULLIF(BTRIM(r.raw_data->'Account_Name'->>'name'), ''),
                NULLIF(BTRIM(r.company_name), '')
              ) AS account_name
         FROM duplicate_records r
        WHERE r.record_type = 'deal'
          AND (${openStagePredicate("r")})${segCond}
     ),
     keyed AS (
       -- Grouping key only — no aggregation yet, so this stays cheap.
       SELECT *,
              COALESCE(
                NULLIF(LOWER(BTRIM(domain)), ''),
                'acct:' || account_id,
                'name:' || LOWER(BTRIM(account_name))
              ) AS group_key
         FROM open_deals
        WHERE account_name IS NOT NULL AND account_name <> ''
     ),
     conflicting AS (
       -- PASS 1: which accounts are actually in conflict. Counting is far
       -- cheaper than building each account's deal JSON, and this discards
       -- ~99% of the layout before the expensive pass runs.
       SELECT group_key FROM keyed GROUP BY group_key HAVING COUNT(*) > 1
     ),
     grouped AS (
       -- PASS 2, over the survivors only.
       -- Grouping, in order of reliability (measured against live data
       -- 2026-08-24, after an earlier domain-only version missed 6 of the 13
       -- accounts Sample User by hand):
       --   1. DOMAIN when present. The same company can hold TWO Account
       --      records — an account duplicate — with one open deal on each;
       --      only domain merges those into one violation.
       --   2. ACCOUNT ID otherwise. Deal records carry NO domain in this
       --      tenant (null on every row sampled) but do carry
       --      raw_data->Account_Name->id on 14 of 15, and that is how CRMProvider
       --      itself groups them — it is the view Sample User at.
       --   3. Normalised company NAME as the last resort. It cannot lead:
       --      company_name varies per deal for one Account ("Example Organization", "stcbank",
       --      "الاتصالات السعودية", "Example Organization العناية بالموظفين"), so leading with
       --      it splits a single Account into several groups and hides the
       --      very collisions this is meant to surface.
       SELECT group_key,
              MIN(NULLIF(LOWER(BTRIM(domain)), '')) AS domain,
              MIN(account_id) AS account_id,
              MIN(account_name) AS account_name,
              COUNT(*)::int AS open_deals,
              COUNT(DISTINCT owner)::int AS distinct_owners,
              COALESCE(SUM(amount), 0)::float AS total_open_value,
              json_agg(json_build_object(
                'id', id, 'name', name, 'stage', stage,
                'owner', owner, 'amount', amount, 'layout', layout,
                'created', created, 'last_activity', last_activity
              ) ORDER BY created NULLS LAST) AS deals,
              json_agg(DISTINCT owner) AS owners
         FROM keyed
         JOIN conflicting USING (group_key)
        GROUP BY group_key
     )
     SELECT * FROM grouped
      ORDER BY distinct_owners DESC, open_deals DESC, total_open_value DESC
      LIMIT ${limit}`,
    [...p.params],
  );

  const raw: MultiActiveDealGroup[] = res.rows.map((r: any) => ({
    domain: r.domain || null,
    account_id: r.account_id || null,
    account_name: r.account_name,
    deals: Array.isArray(r.deals) ? r.deals : [],
  }));

  // Second query: the Account domains, for the handful of accounts that
  // survived grouping. Bounded by the number of CONFLICTS (tens), not by the
  // number of open deals (thousands) — which is what makes it cheap.
  const acctIds = Array.from(
    new Set(raw.map((g) => g.account_id).filter((x): x is string => !!x)),
  );
  const domains = new Map<string, string>();
  if (acctIds.length) {
    const dres = await pool.query(
      `SELECT CRMProvider_record_id AS id,
              NULLIF(
                regexp_replace(
                  regexp_replace(
                    LOWER(BTRIM(COALESCE(NULLIF(BTRIM(domain), ''), website, ''))),
                    '^https?://(www\\.)?', ''),
                  '[/?#].*$', ''),
                '') AS domain
         FROM duplicate_records
        WHERE record_type = 'account'
          AND CRMProvider_record_id = ANY($1::text[])`,
      [acctIds],
    );
    for (const row of dres.rows as any[]) {
      if (row.domain) domains.set(String(row.id), String(row.domain));
    }
  }
  for (const g of raw) {
    if (!g.domain && g.account_id) g.domain = domains.get(g.account_id) || null;
  }

  return finaliseMultiActiveDealGroups(raw, { multiOwnerOnly: !!opts?.multiOwnerOnly });
}

/** A conflict before domains are attached and same-domain groups are merged. */
export interface MultiActiveDealGroup {
  domain: string | null;
  account_id: string | null;
  account_name: string;
  deals: Array<{
    id: string;
    name: string;
    stage: string;
    owner: string;
    amount: number;
    layout: string;
    created: string | null;
    last_activity: string | null;
  }>;
}

/**
 * Merge groups that share a domain, then count, sort and annotate.
 *
 * PURE, so the merge rule is testable without a database.
 *
 * Why merge at all: one company can hold TWO Account records — an account
 * duplicate — and the deals on each should be judged together, not as two
 * separate conflicts.
 *
 * KNOWN LIMIT, stated rather than hidden: the SQL only returns Accounts that
 * ALREADY carry more than one open deal, so a company split across two Account
 * records with exactly ONE open deal on each is not surfaced. Catching that
 * would mean returning every single-deal Account (thousands of rows) to look
 * up its domain, and the query is already the slowest thing on this tab.
 * Those cases show up in Account Duplicates instead, which is where the
 * duplicate Account itself has to be fixed.
 *
 * Deal counting, owner counting and the keep/close call all happen AFTER the
 * merge — a recommendation only makes sense between deals that are actually
 * competing for the same customer.
 */
export function finaliseMultiActiveDealGroups(
  groups: MultiActiveDealGroup[],
  opts: { multiOwnerOnly: boolean },
): MultiActiveDealAccount[] {
  const merged = new Map<string, MultiActiveDealGroup>();
  for (const g of groups) {
    // Domain merges duplicate Accounts; without one, an Account stands alone.
    const key = g.domain || `acct:${g.account_id || g.account_name}`;
    const seen = merged.get(key);
    if (!seen) {
      merged.set(key, { ...g, deals: [...g.deals] });
      continue;
    }
    seen.deals.push(...g.deals);
    // Keep the longer name: "Gulf International Bank" reads better than the
    // "Gulf Intl Bank" duplicate it was merged with.
    if ((g.account_name || "").length > (seen.account_name || "").length) {
      seen.account_name = g.account_name;
    }
  }

  const out: MultiActiveDealAccount[] = [];
  for (const g of merged.values()) {
    // De-duplicate by deal id: two Account records can carry the same deal via
    // different paths, and counting it twice would invent a conflict.
    const byId = new Map<string, (typeof g.deals)[number]>();
    for (const d of g.deals) byId.set(String(d.id), d);
    const deals = [...byId.values()];
    if (deals.length < 2) continue;
    const owners = Array.from(new Set(deals.map((d) => d.owner).filter(Boolean)));
    if (opts.multiOwnerOnly && owners.length < 2) continue;
    out.push({
      domain: g.domain || null,
      account_id: g.account_id || null,
      account_name: g.account_name,
      open_deals: deals.length,
      distinct_owners: owners.length,
      total_open_value: deals.reduce((n, d) => n + (Number(d.amount) || 0), 0),
      owners,
      deals: annotateKeepClose(deals),
    });
  }
  // Same order the SQL used: the collisions Sales has to arbitrate first.
  return out.sort(
    (a, b) =>
      b.distinct_owners - a.distinct_owners ||
      b.open_deals - a.open_deals ||
      b.total_open_value - a.total_open_value,
  );
}

/** Deal doc-compliance rolled up to a segment (join to duplicate_records layout).
 *  Counts ONLY deals that have been doc-checked (rows in deal_doc_compliance). */
export async function getSegmentDealComplianceSummary(
  segment: DuplicateFilters["segment"],
): Promise<DealComplianceSummary> {
  const seg = segment && segment !== "all" ? (segment === "corporate" ? "ExampleOrg" : segment) : "all";
  const p = buildSegmentPredicate(seg, 1);
  const segCond = p.condition ? " AND " + p.condition : "";
  const res = await pool.query(
    `SELECT d.stage AS stage,
            d.compliant AS compliant,
            COALESCE(r.deal_value, 0) AS amount,
            COALESCE(NULLIF(r.owner_name,''), NULLIF(r.owner_email,''), 'Unassigned') AS owner,
            d.missing_docs AS missing_docs
       FROM deal_doc_compliance d
       JOIN duplicate_records r ON r.CRMProvider_record_id = d.CRMProvider_deal_id
      WHERE r.record_type = 'deal'${segCond}`,
    [...p.params],
  );
  const rows = res.rows.map((x: any) => ({
    stage: x.stage || "Unknown",
    compliant: x.compliant === true,
    amount: Number(x.amount) || 0,
    owner: x.owner || "Unassigned",
    // pg parses jsonb into a JS array already; guard non-arrays to [].
    missing_docs: Array.isArray(x.missing_docs) ? x.missing_docs : [],
  }));
  return shapeDealCompliance(seg, rows);
}

/** Outstanding duplicate DEALS in a segment — mirrors getSegmentLeadDuplicateCount. */
export async function getSegmentDealDuplicateCount(
  segment: DuplicateFilters["segment"],
): Promise<{ segment: string; outstanding_deals: number }> {
  const seg = segment && segment !== "all" ? (segment === "corporate" ? "ExampleOrg" : segment) : "all";
  const p = buildSegmentPredicate(seg, 1);
  const segCond = p.condition ? " AND " + p.condition : "";
  const res = await pool.query(
    `SELECT COUNT(*)::text AS n
       FROM duplicate_records r
       JOIN duplicate_clusters dc ON dc.id = r.cluster_id
      WHERE r.record_type = 'deal' AND dc.status = 'active'
        AND dc.total_deals > 1 AND r.is_primary = false${segCond}`,
    [...p.params],
  );
  return { segment: seg, outstanding_deals: Number(res.rows[0]?.n) || 0 };
}

// ── Bulk auto-merge: Contacts with EXACT email + phone match (Sample User 2026-06-20) ─
//
// Rule: when ≥2 contacts share the SAME email AND the SAME phone (both exact,
// after normalization), they're the same person — safe to bulk-merge. Keep the
// survivor (most complete → linked-Account → oldest), tag the rest
// "Duplicate-Delete" (migrate-then-tag; the admin deletes). Guards exclude
// placeholder emails / junk phones so a placeholder collision can't trigger it.

/**
 * CRMProvider ids of records already MERGED AWAY for a module (tagged Duplicate-Delete
 * but not yet deleted by the admin). Until the admin deletes them they still
 * sit in duplicate_records, so the bulk auto-merge matchers must EXCLUDE them —
 * otherwise the BATCHED apply re-derives + re-merges the same groups every batch
 * and never converges (re-hitting CRMProvider with redundant re-tags). Two sources,
 * unioned: the durable resolution ledger (agentic / account merges via
 * executeMergePlan) and pending merge actions (contact auto-merges record an
 * 'auto_merge_pending' action carrying the duplicates' DB ids). Best-effort —
 * a missing table just yields an empty set (no exclusion, no regression).
 */
async function getResolvedDuplicateCRMProviderIds(
  module: "Accounts" | "Contacts" | "Leads" | "Deals",
): Promise<Set<string>> {
  const out = new Set<string>();
  try {
    const led = await pool.query<{ duplicate_CRMProvider_ids: unknown }>(
      `SELECT duplicate_CRMProvider_ids FROM duplicate_resolution_ledger WHERE module = $1`,
      [module],
    );
    for (const r of led.rows) {
      const a = Array.isArray(r.duplicate_CRMProvider_ids) ? r.duplicate_CRMProvider_ids : [];
      for (const id of a) if (id != null) out.add(String(id));
    }
  } catch {
    /* ledger absent/empty */
  }
  try {
    const recordType =
      module === "Accounts"
        ? "account"
        : module === "Contacts"
          ? "contact"
          : module === "Leads"
            ? "lead"
            : "deal";
    const res = await pool.query<{ CRMProvider_record_id: string }>(
      `SELECT DISTINCT dr.CRMProvider_record_id
         FROM duplicate_merge_actions ma
         CROSS JOIN LATERAL jsonb_array_elements_text(ma.merged_record_ids) AS e(db_id)
         JOIN duplicate_records dr ON dr.id = e.db_id::int
        WHERE ma.action_type IN ('auto_merge_pending','resolve','module_resolved')
          AND dr.record_type = $1`,
      [recordType],
    );
    for (const r of res.rows) if (r.CRMProvider_record_id) out.add(String(r.CRMProvider_record_id));
  } catch {
    /* merge-actions table absent/empty */
  }
  return out;
}

/** One contact in a merge group, with its data-completeness score (drill-in). */
export interface ContactMergeMember {
  CRMProviderId: string;
  name: string;
  email: string | null;
  phone: string | null;
  /** Raw Phone / Mobile (original formatting) — used to preserve both numbers
   *  on merge and to recompute when the operator overrides the survivor. */
  phoneRaw?: string | null;
  mobileRaw?: string | null;
  account: string | null;
  owner: string | null;
  layout: string | null;
  createdMs: number | null;
  /** Populated tracked fields out of fieldsTotal (name, email, phone, account, title, owner). */
  fieldsPopulated: number;
  fieldsTotal: number;
  completionPct: number;
  /** True for the proposed survivor (kept on merge). Override-able by the operator. */
  isSurvivor: boolean;
}

/** Tracked fields for the contact completion % (drill-in display). */
const CONTACT_SCORE_FIELDS = 6; // name, email, phone, account, title, owner
function _contactCompletion(v: {
  name?: unknown;
  email?: unknown;
  phone?: unknown;
  account?: unknown;
  title?: unknown;
  owner?: unknown;
}): number {
  return [v.name, v.email, v.phone, v.account, v.title, v.owner].reduce<number>(
    (n, x) => n + (x != null && String(x).trim() !== "" ? 1 : 0),
    0,
  );
}

interface ExactContactGroup {
  /** Stable id = email|phone — carries a survivor override on apply. */
  key: string;
  email: string;
  phone: string;
  survivorCRMProviderId: string;
  duplicateCRMProviderIds: string[];
  /** Second number to preserve on the survivor (Mobile gap-fill) — both members
   *  share the same primary email+phone, so only a differing Mobile can be lost. */
  phoneUpdates: { Phone?: string; Mobile?: string };
  extraPhones: string[];
  /** Every contact in the group, scored — so the operator can verify / override. */
  members: ContactMergeMember[];
}

/** Find contact groups where email AND phone match exactly (guarded). */
async function getExactContactMatchGroups(): Promise<ExactContactGroup[]> {
  const res = await pool.query<{
    k_email: string;
    k_phone: string;
    CRMProvider_record_id: string;
    record_name: string | null;
    account_name: string | null;
    owner_name: string | null;
    title: string | null;
    layout_name: string | null;
    phone: string | null;
    mobile: string | null;
    has_account: boolean;
    completeness: number;
    created_ms: string | null;
  }>(
    `SELECT lower(trim(email)) AS k_email,
            phone_normalized    AS k_phone,
            CRMProvider_record_id, record_name, account_name, owner_name, title, layout_name,
            phone, mobile,
            (account_name IS NOT NULL AND btrim(account_name) <> '') AS has_account,
            ( (CASE WHEN account_name IS NOT NULL AND btrim(account_name)<>'' THEN 1 ELSE 0 END)
            + (CASE WHEN title       IS NOT NULL AND btrim(title)<>''        THEN 1 ELSE 0 END)
            + (CASE WHEN website     IS NOT NULL AND btrim(website)<>''      THEN 1 ELSE 0 END)
            + (CASE WHEN owner_name  IS NOT NULL AND btrim(owner_name)<>''   THEN 1 ELSE 0 END)
            + (CASE WHEN company_name IS NOT NULL AND btrim(company_name)<>'' THEN 1 ELSE 0 END)
            ) AS completeness,
            EXTRACT(EPOCH FROM COALESCE(created_date, modified_date))::bigint AS created_ms
       FROM duplicate_records
      WHERE record_type = 'contact'
        AND CRMProvider_record_id IS NOT NULL AND btrim(CRMProvider_record_id) <> ''
        AND email IS NOT NULL
        AND length(btrim(email)) > 4
        AND position('@' in email) > 1
        AND lower(email) NOT LIKE 'test@%'
        AND lower(email) NOT LIKE '%@test%'
        AND lower(email) NOT LIKE '%example.%'
        AND lower(btrim(email)) NOT IN ('n/a','na','none','null','-')
        AND phone_normalized IS NOT NULL
        AND length(phone_normalized) >= 7
        AND phone_normalized !~ '^(.)\\1+$'
        AND LOWER(COALESCE(layout_name, '')) NOT LIKE '%marketplace%'
        AND LOWER(COALESCE(layout_name, '')) NOT LIKE '%partner account%'`,
  );

  // Skip contacts already merged away (tagged Duplicate-Delete, pending admin
  // delete) so the batched apply converges instead of re-merging them forever.
  const resolvedContactIds = await getResolvedDuplicateCRMProviderIds("Contacts");
  const byKey = new Map<string, typeof res.rows>();
  for (const row of res.rows) {
    if (resolvedContactIds.has(row.CRMProvider_record_id)) continue;
    if (!row.k_email || !row.k_phone) continue;
    const key = `${row.k_email}|${row.k_phone}`;
    const arr = byKey.get(key) || [];
    arr.push(row);
    byKey.set(key, arr);
  }

  const groups: ExactContactGroup[] = [];
  for (const [key, rows] of byKey.entries()) {
    // Dedupe by CRMProvider id; need ≥2 DISTINCT records to be a real duplicate set.
    const seen = new Map<string, (typeof rows)[number]>();
    for (const r of rows) if (!seen.has(r.CRMProvider_record_id)) seen.set(r.CRMProvider_record_id, r);
    const members = [...seen.values()];
    if (members.length < 2) continue;
    // Survivor: most complete → linked-Account → oldest.
    members.sort((a, b) => {
      if (b.completeness !== a.completeness) return b.completeness - a.completeness;
      if (a.has_account !== b.has_account) return a.has_account ? -1 : 1;
      const am = Number(a.created_ms || Number.MAX_SAFE_INTEGER);
      const bm = Number(b.created_ms || Number.MAX_SAFE_INTEGER);
      return am - bm; // older first
    });
    const [survivor, ...dups] = members;
    const [email, phone] = key.split("|");
    const memberRows: ContactMergeMember[] = members.map((m) => {
      const pop = _contactCompletion({
        name: m.record_name,
        email: email,
        phone: phone,
        account: m.account_name,
        title: m.title,
        owner: m.owner_name,
      });
      return {
        CRMProviderId: m.CRMProvider_record_id,
        name: (m.record_name || "").trim(),
        email: email || null,
        phone: phone || null,
        phoneRaw: (m.phone || "").trim() || null,
        mobileRaw: (m.mobile || "").trim() || null,
        account: m.account_name,
        owner: m.owner_name,
        layout: m.layout_name,
        createdMs: m.created_ms != null ? Number(m.created_ms) : null,
        fieldsPopulated: pop,
        fieldsTotal: CONTACT_SCORE_FIELDS,
        completionPct: Math.round((pop / CONTACT_SCORE_FIELDS) * 100),
        isSurvivor: m.CRMProvider_record_id === survivor.CRMProvider_record_id,
      };
    });
    // Both members share the same primary email + phone (that's the match key),
    // so the only second number that can be lost is a duplicate's Mobile —
    // preserve it onto the survivor (gap-fill) exactly like the name+phone path.
    const dupNumbers = [...dups]
      .sort((a, b) => Number(b.created_ms || 0) - Number(a.created_ms || 0))
      .flatMap((d) => [String(d.phone || "").trim(), String(d.mobile || "").trim()])
      .filter(Boolean);
    const { updates: phoneUpdates, extra: extraPhones } = planMergedContactPhones({
      survivorPhone: survivor.phone,
      survivorMobile: survivor.mobile,
      otherNumbers: dupNumbers,
    });
    groups.push({
      key,
      email,
      phone,
      survivorCRMProviderId: survivor.CRMProvider_record_id,
      duplicateCRMProviderIds: dups.map((d) => d.CRMProvider_record_id),
      phoneUpdates,
      extraPhones,
      members: memberRows,
    });
  }
  return groups;
}

/** Preview only — count qualifying groups + how many records would be tagged. */
export async function previewExactContactMatches(): Promise<{
  qualifyingGroups: number;
  duplicatesToTag: number;
  numbersPreserved: number;
  sample: ExactContactGroup[];
}> {
  try {
    const groups = await getExactContactMatchGroups();
    return {
      qualifyingGroups: groups.length,
      duplicatesToTag: groups.reduce((n, g) => n + g.duplicateCRMProviderIds.length, 0),
      numbersPreserved: groups.filter(
        (g) => g.phoneUpdates.Phone || g.phoneUpdates.Mobile,
      ).length,
      // Up to 200 groups (with scored members) so the operator can drill into
      // and override the survivor of each before applying.
      sample: groups.slice(0, 200),
    };
  } catch (e) {
    logger.warn("[DuplicateRadar] previewExactContactMatches failed (non-fatal)", {
      error: e instanceof Error ? e.message : String(e),
    });
    return { qualifyingGroups: 0, duplicatesToTag: 0, numbersPreserved: 0, sample: [] };
  }
}

/**
 * Apply the bulk merge: tag the duplicate(s) in each exact-match group
 * Duplicate-Delete (keeping the survivor), batching the CRMProvider add_tags calls.
 * Records a ledger entry per survivor so the merge counts as "merged" in the
 * progress/breakdown views. Bounded by `limit` groups per run (re-runnable).
 */
export async function applyExactContactMatches(opts: {
  limit?: number;
  performedBy: string;
  /** Per-group survivor overrides { "email|phone": CRMProviderIdToKeep }. */
  overrides?: Record<string, string>;
  /** Per-group EXCLUDED contact ids — left untouched (not survivor, not tagged). */
  excludes?: Record<string, string[]>;
}): Promise<{ mergedGroups: number; taggedRecords: number; remaining: number; errors: number }> {
  const { addCRMProviderTags, updateCRMProviderRecord, CRMProviderWritesAllowedInEnv } = await import("./CRMProviderCRM");
  const { withTimeout } = await import("./promiseTimeout");
  if (!CRMProviderWritesAllowedInEnv()) {
    throw new Error("Live CRMProvider writes are disabled outside production.");
  }
  const limit = Math.max(1, Math.min(Math.floor(opts.limit || 300), 1000));
  const all = await getExactContactMatchGroups();
  const batch = all.slice(0, limit);
  let taggedRecords = 0;
  let mergedGroups = 0;
  let errors = 0;

  // Honor operator EXCLUDES (members left untouched) + override (else keep the
  // highest-completeness survivor); the duplicates are the other INCLUDED ones.
  const resolved = batch
    .map((g) => {
      const ex = new Set(opts.excludes?.[g.key] ?? []);
      const included = g.members.map((m) => m.CRMProviderId).filter((id) => !ex.has(id));
      if (included.length < 2) return null; // nothing to merge after exclusions
      const ov = opts.overrides?.[g.key];
      const chosen = ov && included.includes(ov)
        ? ov
        : included.includes(g.survivorCRMProviderId)
          ? g.survivorCRMProviderId
          : included[0]!;
      const dupIds = included.filter((id) => id !== chosen);
      return { g, chosen, dupIds };
    })
    .filter((r): r is { g: ExactContactGroup; chosen: string; dupIds: string[] } => r !== null);

  // MIGRATE-THEN-TAG: preserve a second number onto each survivor BEFORE tagging
  // its duplicates, so the admin can never delete the only record holding a
  // number. Recompute for the chosen survivor (it may be an override). A group
  // whose preservation write fails is DROPPED from this run (its dups are not
  // tagged) and stays re-runnable — never tag away an un-preserved number.
  const writeOk: typeof resolved = [];
  for (const r of resolved) {
    try {
      const chosenMember = r.g.members.find((m) => m.CRMProviderId === r.chosen);
      const dupMembers = r.g.members.filter((m) => r.dupIds.includes(m.CRMProviderId));
      const phoneUpd = planMergedContactPhones({
        survivorPhone: chosenMember?.phoneRaw ?? null,
        survivorMobile: chosenMember?.mobileRaw ?? null,
        otherNumbers: dupMembers
          .flatMap((m) => [(m.phoneRaw || "").trim(), (m.mobileRaw || "").trim()])
          .filter(Boolean),
      }).updates;
      if (phoneUpd.Phone || phoneUpd.Mobile) {
        await withTimeout(
          updateCRMProviderRecord("Contacts", r.chosen, phoneUpd as Record<string, unknown>),
          20_000,
          `field-migrate ${r.chosen}`,
        );
      }
      writeOk.push(r);
    } catch (e) {
      errors++;
      logger.warn("[DuplicateRadar] exact-merge survivor number preserve failed — group skipped", {
        error: e instanceof Error ? e.message : String(e),
      });
    }
  }
  resolved.length = 0;
  resolved.push(...writeOk);

  // Tag in chunks of 100 ids (CRMProvider add_tags multi-record limit). Track which
  // ids were ACTUALLY tagged so a failed chunk (e.g. CRMProvider rate-limited while a
  // sync is running) doesn't get marked AI-Applied · pending below — those
  // groups stay Untouched and re-runnable instead of stuck pending forever.
  const CHUNK = 100;
  const taggedOk = new Set<string>();
  const dupIds = resolved.flatMap((r) => r.dupIds);
  for (let i = 0; i < dupIds.length; i += CHUNK) {
    const chunk = dupIds.slice(i, i + CHUNK);
    try {
      await withTimeout(
        addCRMProviderTags("Contacts", chunk, ["Duplicate-Delete"]),
        20_000,
        `tag contacts ${i}`,
      );
      taggedRecords += chunk.length;
      for (const id of chunk) taggedOk.add(id);
    } catch (e) {
      errors++;
      logger.warn("[DuplicateRadar] bulk contact tag chunk failed", {
        error: e instanceof Error ? e.message : String(e),
      });
    }
  }

  // Mark each touched cluster AI-APPLIED · pending (Sample User 2026-06-21). We record
  // an 'auto_merge_pending' merge action — NOT a ledger 'resolve' — so the
  // cluster moves out of Untouched into "AI-Applied · pending CRMProvider admin delete"
  // but does NOT prematurely flip to Resolved. It becomes Resolved only once the
  // admin actually deletes the tagged duplicates in CRMProvider, which the next sync's
  // reconcileAutoMergedContactDeletions() detects (it then writes the durable
  // ledger entry, and restoreLedgerResolvedClusterStatus flips it to resolved).
  for (const { g, chosen, dupIds: groupDups } of resolved) {
    try {
      // Only mark groups whose duplicates were ACTUALLY tagged in CRMProvider.
      const taggedDupCRMProviderIds = groupDups.filter((id) => taggedOk.has(id));
      if (taggedDupCRMProviderIds.length === 0) continue; // tag failed → leave Untouched
      const idRes = await pool.query<{
        id: number;
        cluster_id: number | null;
        CRMProvider_record_id: string;
      }>(
        `SELECT id, cluster_id, CRMProvider_record_id
           FROM duplicate_records
          WHERE CRMProvider_record_id = ANY($1::text[])`,
        [[chosen, ...taggedDupCRMProviderIds]],
      );
      const rows = idRes.rows;
      const survivorRow = rows.find((r) => r.CRMProvider_record_id === chosen);
      const clusterId = survivorRow?.cluster_id ?? rows[0]?.cluster_id ?? null;
      const dupDbIds = rows
        .filter((r) => taggedDupCRMProviderIds.includes(r.CRMProvider_record_id))
        .map((r) => r.id);
      if (!clusterId || dupDbIds.length === 0) continue;
      await pool.query(
        `INSERT INTO duplicate_merge_actions
           (cluster_id, primary_record_id, merged_record_ids, action_type, performed_by, notes)
         VALUES ($1, $2, $3, 'auto_merge_pending', $4, $5)`,
        [
          clusterId,
          survivorRow?.id ?? null,
          JSON.stringify(dupDbIds),
          opts.performedBy,
          `Bulk auto-merge: exact email+phone. Tagged ${dupDbIds.length} Duplicate-Delete, pending CRMProvider admin delete.`,
        ],
      );
      mergedGroups++;
    } catch (e) {
      logger.warn("[DuplicateRadar] auto-merge mark-pending failed (non-fatal)", {
        error: e instanceof Error ? e.message : String(e),
      });
    }
  }

  return { mergedGroups, taggedRecords, remaining: Math.max(0, all.length - batch.length), errors };
}

// ── Bulk auto-merge: Contacts with SAME NAME + SAME PHONE (Sample User 2026-06-22) ──
//
// Broader than the exact email+phone rule: two contacts sharing the same
// (Arabic-normalized) name AND the same phone are the same person even when
// their emails differ or one is missing. On merge we keep BOTH emails — the
// survivor's primary Email plus the other in Secondary_Email — and when only
// ONE email exists across the pair it becomes the survivor's primary Email
// (the empty-email record is the same person). Migrate-then-tag; admin deletes.

/**
 * Decide the survivor's email fields for a same-name+phone contact merge.
 * Pure + exported for unit/simulation testing.
 *   • 0–1 distinct email total → that single email is the PRIMARY (no secondary).
 *   • ≥2 distinct emails → primary stays, the freshest OTHER email → Secondary_Email;
 *     any further alternates are returned in `extra` (CRMProvider has one secondary slot).
 */
export function planMergedContactEmails(input: {
  survivorEmail: string | null;
  otherEmails: string[]; // duplicate emails, freshest-first, original casing
}): { updates: { Email?: string; Secondary_Email?: string }; extra: string[] } {
  const trimOf = (e: string) => (e || "").trim();
  const keyOf = (e: string) => trimOf(e).toLowerCase();
  const updates: { Email?: string; Secondary_Email?: string } = {};
  const survivor = trimOf(input.survivorEmail || "");
  const seen = new Set<string>();
  const distinct: string[] = [];
  if (survivor) {
    seen.add(keyOf(survivor));
    distinct.push(survivor);
  }
  for (const raw of input.otherEmails || []) {
    const e = trimOf(raw);
    if (!e) continue;
    const k = keyOf(e);
    if (seen.has(k)) continue;
    seen.add(k);
    distinct.push(e);
  }
  if (distinct.length === 0) return { updates, extra: [] };
  if (!survivor) {
    // Survivor had no email → promote the freshest distinct email to PRIMARY.
    updates.Email = distinct[0]!;
    if (distinct.length >= 2) updates.Secondary_Email = distinct[1]!;
    return { updates, extra: distinct.slice(2) };
  }
  // Survivor keeps its primary; preserve the next distinct email as secondary.
  if (distinct.length >= 2) updates.Secondary_Email = distinct[1]!;
  return { updates, extra: distinct.slice(2) };
}

/**
 * Decide the survivor's phone fields for a same-name+phone contact merge.
 * Mirrors planMergedContactEmails but for CRMProvider's two phone slots (Phone +
 * Mobile). Saudi-normalised dedupe (drop +966 / leading 0, last 9 digits) so the
 * same number in different formats isn't double-stored. NEVER overwrites a number
 * the survivor already holds — only GAP-FILLS an empty slot — so a good number
 * can't be clobbered. A 3rd+ distinct number is returned in `extra` (CRMProvider keeps
 * only two). Pure + exported for unit/simulation testing.
 *   • survivor keeps its Phone (or, if it had none, the freshest distinct number
 *     becomes Phone);
 *   • the next distinct number fills Mobile only when the survivor's Mobile is empty.
 */
export function planMergedContactPhones(input: {
  survivorPhone: string | null;
  survivorMobile: string | null;
  otherNumbers: string[]; // duplicates' Phone+Mobile, freshest-first, original casing
}): { updates: { Phone?: string; Mobile?: string }; extra: string[] } {
  const trimOf = (s: string) => (s || "").trim();
  const normOf = (s: string) =>
    trimOf(s).replace(/\D/g, "").replace(/^966/, "").replace(/^0+/, "").slice(-9);
  const updates: { Phone?: string; Mobile?: string } = {};
  const sPhone = trimOf(input.survivorPhone || "");
  const sMobile = trimOf(input.survivorMobile || "");
  const seen = new Set<string>();
  const distinct: string[] = [];
  const add = (raw: string) => {
    const v = trimOf(raw);
    if (!v) return;
    const k = normOf(v);
    if (!k || seen.has(k)) return;
    seen.add(k);
    distinct.push(v);
  };
  add(sPhone);
  add(sMobile);
  for (const o of input.otherNumbers || []) add(o);
  if (distinct.length === 0) return { updates, extra: [] };
  // Survivor's primary number: keep its Phone; if it had none, promote freshest.
  const effPhone = sPhone || distinct[0]!;
  if (!sPhone) updates.Phone = effPhone;
  // Second slot → Mobile, GAP-FILL only (never overwrite a populated Mobile).
  if (!sMobile) {
    const second = distinct.find((v) => normOf(v) !== normOf(effPhone));
    if (second) updates.Mobile = second;
  }
  // Extras = distinct numbers beyond the two kept slots.
  const keptKeys = new Set<string>([normOf(effPhone)]);
  const effMobile = sMobile || updates.Mobile || "";
  if (effMobile) keptKeys.add(normOf(effMobile));
  const extra = distinct.filter((v) => !keptKeys.has(normOf(v)));
  return { updates, extra };
}

interface NamePhoneContactGroup {
  /** Stable id = normalizedName|phone — carries a survivor override on apply. */
  key: string;
  survivorCRMProviderId: string;
  duplicateCRMProviderIds: string[];
  emailUpdates: { Email?: string; Secondary_Email?: string };
  extraEmails: string[];
  phoneUpdates: { Phone?: string; Mobile?: string };
  extraPhones: string[];
  label: string;
  members: ContactMergeMember[];
}

/** Find contact groups sharing the same Arabic-normalized name + same phone. */
async function getNamePhoneContactGroups(): Promise<NamePhoneContactGroup[]> {
  const res = await pool.query<{
    CRMProvider_record_id: string;
    record_name: string;
    email: string | null;
    phone_normalized: string | null;
    mobile_normalized: string | null;
    phone: string | null;
    mobile: string | null;
    account_name: string | null;
    title: string | null;
    website: string | null;
    company_name: string | null;
    owner_name: string | null;
    layout_name: string | null;
    created_ms: string | null;
  }>(
    `SELECT CRMProvider_record_id, record_name, email,
            phone_normalized, mobile_normalized, phone, mobile,
            account_name, title, website, company_name, owner_name, layout_name,
            EXTRACT(EPOCH FROM COALESCE(created_date, modified_date))::bigint AS created_ms
       FROM duplicate_records
      WHERE record_type = 'contact'
        AND CRMProvider_record_id IS NOT NULL AND btrim(CRMProvider_record_id) <> ''
        AND record_name IS NOT NULL AND btrim(record_name) <> ''
        AND (
          (phone_normalized IS NOT NULL AND length(phone_normalized) >= 7)
          OR (mobile_normalized IS NOT NULL AND length(mobile_normalized) >= 7)
        )
        AND LOWER(COALESCE(layout_name, '')) NOT LIKE '%marketplace%'
        AND LOWER(COALESCE(layout_name, '')) NOT LIKE '%partner account%'`,
  );

  // Skip contacts already merged away (pending admin delete) so the batched
  // apply converges instead of re-merging the same name+phone groups forever.
  const resolvedContactIds = await getResolvedDuplicateCRMProviderIds("Contacts");
  const byKey = new Map<string, typeof res.rows>();
  for (const row of res.rows) {
    if (resolvedContactIds.has(row.CRMProvider_record_id)) continue;
    const nameKey = normalizePersonName(row.record_name);
    if (!nameKey) continue;
    // "Best phone" = the Phone field, else Mobile. (Cross-field Phone-vs-Mobile
    // matches between two records are not grouped in this v1 — same-field is the
    // overwhelmingly common case.)
    const phoneKey = (row.phone_normalized || row.mobile_normalized || "").trim();
    if (!phoneKey || phoneKey.length < 7) continue;
    const key = `${nameKey}|${phoneKey}`;
    const arr = byKey.get(key) || [];
    arr.push(row);
    byKey.set(key, arr);
  }

  const groups: NamePhoneContactGroup[] = [];
  for (const [key, rows] of byKey.entries()) {
    const seenIds = new Map<string, (typeof rows)[number]>();
    for (const r of rows) if (!seenIds.has(r.CRMProvider_record_id)) seenIds.set(r.CRMProvider_record_id, r);
    const members = [...seenIds.values()];
    if (members.length < 2) continue;
    const hasEmail = (r: (typeof rows)[number]) => (r.email && r.email.trim() ? 1 : 0);
    const completeness = (r: (typeof rows)[number]) =>
      (r.account_name && r.account_name.trim() ? 1 : 0) +
      (r.title && r.title.trim() ? 1 : 0) +
      (r.website && r.website.trim() ? 1 : 0) +
      (r.company_name && r.company_name.trim() ? 1 : 0);
    members.sort((a, b) => {
      // A record WITH an email must survive: CRMProvider dup-checks the PRIMARY Email,
      // so we never promote a still-existing duplicate's email to the survivor's
      // primary (that would be rejected). The survivor's email stays primary;
      // any different duplicate email goes to the un-dup-checked Secondary_Email.
      const ea = hasEmail(a),
        eb = hasEmail(b);
      if (eb !== ea) return eb - ea;
      const ca = completeness(a),
        cb = completeness(b);
      if (cb !== ca) return cb - ca;
      const am = Number(a.created_ms || Number.MAX_SAFE_INTEGER);
      const bm = Number(b.created_ms || Number.MAX_SAFE_INTEGER);
      return am - bm; // older survives on a tie
    });
    const [survivor, ...dups] = members;
    if (!survivor) continue;
    // Duplicate emails, freshest first, to drive the primary/secondary choice.
    const dupEmails = [...dups]
      .sort(
        (a, b) =>
          Number(b.created_ms || 0) - Number(a.created_ms || 0),
      )
      .map((d) => (d.email || "").trim())
      .filter(Boolean);
    const { updates, extra } = planMergedContactEmails({
      survivorEmail: survivor.email,
      otherEmails: dupEmails,
    });
    // Keep BOTH numbers — survivor's Phone stays; the freshest distinct dup
    // number gap-fills Mobile (same person, same name+phone group, so a second
    // number is a real alternate, not a different person).
    const dupNumbers = [...dups]
      .sort((a, b) => Number(b.created_ms || 0) - Number(a.created_ms || 0))
      .flatMap((d) => [String(d.phone || "").trim(), String(d.mobile || "").trim()])
      .filter(Boolean);
    const { updates: phoneUpdates, extra: extraPhones } = planMergedContactPhones({
      survivorPhone: survivor.phone,
      survivorMobile: survivor.mobile,
      otherNumbers: dupNumbers,
    });
    const phoneKey = key.split("|").slice(1).join("|");
    const memberRows: ContactMergeMember[] = members.map((m) => {
      const ph = (m.phone_normalized || m.mobile_normalized || "").trim() || phoneKey;
      const pop = _contactCompletion({
        name: m.record_name,
        email: m.email,
        phone: ph,
        account: m.account_name,
        title: m.title,
        owner: m.owner_name,
      });
      return {
        CRMProviderId: m.CRMProvider_record_id,
        name: (m.record_name || "").trim(),
        email: (m.email || "").trim() || null,
        phone: ph || null,
        phoneRaw: (m.phone || "").trim() || null,
        mobileRaw: (m.mobile || "").trim() || null,
        account: m.account_name,
        owner: m.owner_name,
        layout: m.layout_name,
        createdMs: m.created_ms != null ? Number(m.created_ms) : null,
        fieldsPopulated: pop,
        fieldsTotal: CONTACT_SCORE_FIELDS,
        completionPct: Math.round((pop / CONTACT_SCORE_FIELDS) * 100),
        isSurvivor: m.CRMProvider_record_id === survivor.CRMProvider_record_id,
      };
    });
    groups.push({
      key,
      survivorCRMProviderId: survivor.CRMProvider_record_id,
      duplicateCRMProviderIds: dups.map((d) => d.CRMProvider_record_id),
      emailUpdates: updates,
      extraEmails: extra,
      phoneUpdates,
      extraPhones,
      label: (survivor.record_name || "").trim(),
      members: memberRows,
    });
  }
  return groups;
}

/** Preview only — counts for the same-name+phone auto-merge. */
export async function previewNamePhoneContactMatches(): Promise<{
  qualifyingGroups: number;
  duplicatesToTag: number;
  emailsPreserved: number;
  numbersPreserved: number;
  sample: NamePhoneContactGroup[];
}> {
  try {
    const groups = await getNamePhoneContactGroups();
    return {
      qualifyingGroups: groups.length,
      duplicatesToTag: groups.reduce((n, g) => n + g.duplicateCRMProviderIds.length, 0),
      emailsPreserved: groups.filter(
        (g) => g.emailUpdates.Email || g.emailUpdates.Secondary_Email,
      ).length,
      numbersPreserved: groups.filter(
        (g) => g.phoneUpdates.Phone || g.phoneUpdates.Mobile,
      ).length,
      sample: groups.slice(0, 200),
    };
  } catch (e) {
    logger.warn("[DuplicateRadar] previewNamePhoneContactMatches failed (non-fatal)", {
      error: e instanceof Error ? e.message : String(e),
    });
    return { qualifyingGroups: 0, duplicatesToTag: 0, emailsPreserved: 0, numbersPreserved: 0, sample: [] };
  }
}

/**
 * Apply the same-name+phone auto-merge: write the email field(s) onto the
 * survivor (primary gap-fill and/or Secondary_Email), then tag the duplicates
 * Duplicate-Delete. Marks each touched cluster 'auto_merge_pending' (same
 * lifecycle as the exact email+phone merge). Bounded by `limit`, re-runnable.
 */
export async function applyNamePhoneContactMatches(opts: {
  limit?: number;
  performedBy: string;
  /** Per-group survivor overrides { "name|phone": CRMProviderIdToKeep }. */
  overrides?: Record<string, string>;
  /** Per-group EXCLUDED contact ids — left untouched (not survivor, not tagged). */
  excludes?: Record<string, string[]>;
}): Promise<{
  mergedGroups: number;
  taggedRecords: number;
  emailsWritten: number;
  remaining: number;
  errors: number;
}> {
  const { addCRMProviderTags, updateCRMProviderRecord, CRMProviderWritesAllowedInEnv } = await import("./CRMProviderCRM");
  const { withTimeout } = await import("./promiseTimeout");
  if (!CRMProviderWritesAllowedInEnv()) {
    throw new Error("Live CRMProvider writes are disabled outside production.");
  }
  const limit = Math.max(1, Math.min(Math.floor(opts.limit || 200), 1000));
  const all = await getNamePhoneContactGroups();
  const batch = all.slice(0, limit);
  let taggedRecords = 0;
  let mergedGroups = 0;
  let emailsWritten = 0;
  let errors = 0;

  for (const g of batch) {
    try {
      // Honor operator EXCLUDES + override. When the survivor or the member set
      // changes we recompute the duplicates AND the email plan from the chosen
      // survivor (a record WITH an email should survive — the email plan keeps
      // the survivor's email primary and routes a different dup email to
      // Secondary_Email). Excluded members are left completely untouched.
      const ex = new Set(opts.excludes?.[g.key] ?? []);
      const included = g.members.map((m) => m.CRMProviderId).filter((id) => !ex.has(id));
      if (included.length < 2) continue; // nothing to merge after exclusions
      const ov = opts.overrides?.[g.key];
      const chosen = ov && included.includes(ov)
        ? ov
        : included.includes(g.survivorCRMProviderId)
          ? g.survivorCRMProviderId
          : included[0]!;
      let dupCRMProviderIds = g.duplicateCRMProviderIds;
      let updates: {
        Email?: string;
        Secondary_Email?: string;
        Phone?: string;
        Mobile?: string;
      } = { ...g.emailUpdates, ...g.phoneUpdates };
      if (chosen !== g.survivorCRMProviderId || ex.size > 0) {
        dupCRMProviderIds = included.filter((id) => id !== chosen);
        const chosenMember = g.members.find((m) => m.CRMProviderId === chosen);
        const includedDups = g.members
          .filter((m) => included.includes(m.CRMProviderId) && m.CRMProviderId !== chosen)
          .sort((a, b) => Number(b.createdMs || 0) - Number(a.createdMs || 0));
        const emailUpd = planMergedContactEmails({
          survivorEmail: chosenMember?.email ?? null,
          otherEmails: includedDups.map((m) => (m.email || "").trim()).filter(Boolean),
        }).updates;
        const phoneUpd = planMergedContactPhones({
          survivorPhone: chosenMember?.phoneRaw ?? null,
          survivorMobile: chosenMember?.mobileRaw ?? null,
          otherNumbers: includedDups
            .flatMap((m) => [(m.phoneRaw || "").trim(), (m.mobileRaw || "").trim()])
            .filter(Boolean),
        }).updates;
        updates = { ...emailUpd, ...phoneUpd };
      }
      // 1) Preserve the email(s) AND number(s) on the survivor BEFORE tagging.
      if (updates.Email || updates.Secondary_Email || updates.Phone || updates.Mobile) {
        await withTimeout(
          updateCRMProviderRecord("Contacts", chosen, updates as Record<string, unknown>),
          20_000,
          `field-migrate ${chosen}`,
        );
        emailsWritten++;
      }
      // 2) Tag the duplicates Duplicate-Delete.
      const taggedOk = new Set<string>();
      for (let i = 0; i < dupCRMProviderIds.length; i += 100) {
        const chunk = dupCRMProviderIds.slice(i, i + 100);
        await withTimeout(
          addCRMProviderTags("Contacts", chunk, ["Duplicate-Delete"]),
          20_000,
          `tag ${chosen} ${i}`,
        );
        taggedRecords += chunk.length;
        for (const id of chunk) taggedOk.add(id);
      }
      // 3) Mark the cluster AI-Applied · pending (only for the tagged dups).
      const taggedDupCRMProviderIds = dupCRMProviderIds.filter((id) => taggedOk.has(id));
      if (taggedDupCRMProviderIds.length > 0) {
        const idRes = await pool.query<{ id: number; cluster_id: number | null; CRMProvider_record_id: string }>(
          `SELECT id, cluster_id, CRMProvider_record_id FROM duplicate_records WHERE CRMProvider_record_id = ANY($1::text[])`,
          [[chosen, ...taggedDupCRMProviderIds]],
        );
        const rows = idRes.rows;
        const survivorRow = rows.find((r) => r.CRMProvider_record_id === chosen);
        const clusterId = survivorRow?.cluster_id ?? rows[0]?.cluster_id ?? null;
        const dupDbIds = rows
          .filter((r) => taggedDupCRMProviderIds.includes(r.CRMProvider_record_id))
          .map((r) => r.id);
        if (clusterId && dupDbIds.length > 0) {
          await pool.query(
            `INSERT INTO duplicate_merge_actions
               (cluster_id, primary_record_id, merged_record_ids, action_type, performed_by, notes)
             VALUES ($1, $2, $3, 'auto_merge_pending', $4, $5)`,
            [
              clusterId,
              survivorRow?.id ?? null,
              JSON.stringify(dupDbIds),
              opts.performedBy,
              `Bulk auto-merge: same name + phone. Preserved email(s) on survivor; tagged ${dupDbIds.length} Duplicate-Delete, pending CRMProvider admin delete.`,
            ],
          );
          mergedGroups++;
        }
      }
    } catch (e) {
      errors++;
      logger.warn("[DuplicateRadar] name+phone auto-merge group failed (non-fatal)", {
        error: e instanceof Error ? e.message : String(e),
      });
    }
  }

  return {
    mergedGroups,
    taggedRecords,
    emailsWritten,
    remaining: Math.max(0, all.length - batch.length),
    errors,
  };
}

// ── Account auto-merge: same DOMAIN + same COMPANY NAME, within layout ───────
//
// Sample User 2026-06-22. Two accounts on the SAME layout that share the same domain
// AND the same (Arabic/English suffix-stripped) company name are the same
// company. Corporate accounts merge only with Corporate accounts; Partner
// (Marketplace) only with Partner — a Corporate and a Partner account for the
// same company are intentionally separate and are NEVER merged. CR/VAT are
// ignored (unreliable data). This is the read-only grouping + PREVIEW; the
// write/cascade (reparent contacts+deals, tag) is applied via the existing
// agentic Account executor once the preview is confirmed.

/** Layout names per scope (lowercased), tunable via env. */
export const ACCOUNT_SCOPE_LAYOUTS: Record<"corporate" | "partner", string[]> = {
  corporate: (process.env.ACCOUNT_CORPORATE_LAYOUTS || "Corporate Accounts")
    .split(",")
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean),
  partner: (process.env.ACCOUNT_PARTNER_LAYOUTS || "Marketplace")
    .split(",")
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean),
};

/** One account in a domain+name group, with its data-completeness score. */
export interface AccountDomainNameMember {
  CRMProviderId: string;
  name: string;
  domain: string | null;
  owner: string | null;
  website: string | null;
  cr: string | null;
  vat: string | null;
  country: string | null;
  industry: string | null;
  layout: string | null;
  createdMs: number | null;
  /** Number of Deals linked to this Account (Account_Name.id) — shown in place
   *  of the unreliable CR number; a bigger Deals book = a stronger survivor. */
  dealCount: number;
  /** Count of the tracked key fields that are populated, out of fieldsTotal. */
  fieldsPopulated: number;
  fieldsTotal: number;
  /** Completion % = fieldsPopulated / fieldsTotal, rounded. */
  completionPct: number;
  /** True for the proposed survivor (highest completion %, tie-break oldest). */
  isSurvivor: boolean;
}

export interface AccountDomainNameGroup {
  /** Stable id = domain|nameKey — used to carry a survivor override on apply. */
  key: string;
  domain: string;
  nameKey: string;
  /** Proposed survivor: the member with the highest completion %. Override-able. */
  survivorCRMProviderId: string;
  duplicateCRMProviderIds: string[];
  /** Distinct display names across the group (surfaces EN vs AR variants). */
  names: string[];
  label: string;
  /** Every account in the group, scored — so the operator can verify / override. */
  members: AccountDomainNameMember[];
}

/**
 * Group accounts on the given layouts by domain + normalized name (>=2).
 *
 * groupBy (Sample User 2026-06-23):
 *   'domain_name' (default) → key = domain|name  (strict; unchanged behaviour)
 *   'domain'                → key = domain only   ("same domain, any name" — the
 *      looser mode that catches EN/AR / spelling variants). A SHARED-DOMAIN
 *      GUARD skips any domain carrying more than `maxDistinctNames` distinct
 *      company names (likely a holding/agency/shared domain) — those are left
 *      for manual review.
 */
async function getAccountDomainNameGroups(
  layoutNames: string[],
  opts?: { groupBy?: "domain_name" | "domain"; maxDistinctNames?: number },
): Promise<AccountDomainNameGroup[]> {
  const groupBy = opts?.groupBy || "domain_name";
  const maxDistinctNames = opts?.maxDistinctNames ?? 6;
  if (!layoutNames.length) return [];
  const res = await pool.query<{
    CRMProvider_record_id: string;
    record_name: string | null;
    company_name: string | null;
    domain: string | null;
    owner_name: string | null;
    website: string | null;
    cr_number: string | null;
    vat_number: string | null;
    country: string | null;
    industry: string | null;
    layout_name: string | null;
    layout_norm: string | null;
    created_ms: string | null;
  }>(
    `SELECT CRMProvider_record_id, record_name, company_name, domain, owner_name, website,
            cr_number, vat_number, country, industry, layout_name,
            LOWER(COALESCE(layout_name, '')) AS layout_norm,
            EXTRACT(EPOCH FROM COALESCE(created_date, modified_date))::bigint AS created_ms
       FROM duplicate_records
      WHERE record_type = 'account'
        AND CRMProvider_record_id IS NOT NULL AND btrim(CRMProvider_record_id) <> ''
        AND domain IS NOT NULL AND btrim(domain) <> ''
        AND LOWER(COALESCE(layout_name, '')) = ANY($1::text[])`,
    [layoutNames],
  );

  // Deal count per Account (local DB — deals whose Account_Name.id points at the
  // account). Shown in the preview in place of the unreliable CR number; a bigger
  // Deals book is a stronger survivor signal. No CRMProvider call — counted from the
  // already-synced deal records.
  const dealCountByAccount = new Map<string, number>();
  const acctIds = res.rows.map((r) => r.CRMProvider_record_id).filter(Boolean);
  if (acctIds.length > 0) {
    const dcRes = await pool.query<{ account_id: string; n: string }>(
      `SELECT raw_data->'Account_Name'->>'id' AS account_id, COUNT(*) AS n
         FROM duplicate_records
        WHERE record_type = 'deal'
          AND raw_data->'Account_Name'->>'id' = ANY($1::text[])
        GROUP BY 1`,
      [acctIds],
    );
    for (const r of dcRes.rows) {
      if (r.account_id) dealCountByAccount.set(r.account_id, Number(r.n) || 0);
    }
  }

  // Exclude accounts already merged away (see getResolvedDuplicateCRMProviderIds):
  // tagged duplicates aren't deleted until the admin acts, so without this they
  // keep re-grouping and the BATCHED apply re-merges the same groups every batch
  // (never converges, re-hammering CRMProvider). Excluding them collapses a merged
  // group to a singleton, which drops out — so the work set shrinks each batch.
  const resolvedDupIds = await getResolvedDuplicateCRMProviderIds("Accounts");
  // Groups the operator DISMISSED ("not duplicates") — their accounts are
  // recorded as mutually separated, so the group must never reappear or merge.
  const sepPairs = await getSeparationPairKeySet();

  const byKey = new Map<string, typeof res.rows>();
  for (const row of res.rows) {
    if (resolvedDupIds.has(row.CRMProvider_record_id)) continue; // already merged away
    const dom = (row.domain || "").trim().toLowerCase();
    const nameKey = normalizeCompanyName(row.record_name || row.company_name || "");
    // Merge WITHIN the exact same layout only (Sample User 2026-06-23). The scope
    // allowlist can carry more than one layout (e.g. ACCOUNT_CORPORATE_LAYOUTS
    // = "Corporate,Partnership"); without this a Corporate account and a
    // Partnership/marketplace account that share a domain would fuse. Putting
    // the exact layout in the grouping key guarantees Corporate ↔ Corporate,
    // Marketplace ↔ Marketplace — never across.
    const layoutNorm = (row.layout_norm || "").trim();
    // Domain-only mode groups by domain alone (any name); strict mode needs both.
    if (!dom) continue;
    if (groupBy === "domain_name" && !nameKey) continue;
    const key =
      groupBy === "domain"
        ? `${dom}|@${layoutNorm}`
        : `${dom}|${nameKey}|@${layoutNorm}`;
    const arr = byKey.get(key) || [];
    arr.push(row);
    byKey.set(key, arr);
  }

  // Data completeness = how many of these key account fields are populated.
  // This is the transparent score the operator sees in the drill-in, and the
  // survivor is the member with the highest %. On apply we FORCE this survivor
  // (or the operator's override) as the merge master, so what's shown is
  // exactly what's kept — no divergence from a separate engine heuristic.
  const SCORED_FIELDS: Array<keyof (typeof res.rows)[number]> = [
    "record_name",
    "domain",
    "website",
    "owner_name",
    "cr_number",
    "vat_number",
    "country",
    "industry",
  ];
  const fieldsPopulated = (r: (typeof res.rows)[number]) =>
    SCORED_FIELDS.reduce(
      (n, f) => n + (r[f] != null && String(r[f]).trim() !== "" ? 1 : 0),
      0,
    );

  const groups: AccountDomainNameGroup[] = [];
  for (const [key, rows] of byKey.entries()) {
    const seen = new Map<string, (typeof rows)[number]>();
    for (const r of rows) if (!seen.has(r.CRMProvider_record_id)) seen.set(r.CRMProvider_record_id, r);
    const sorted = [...seen.values()];
    if (sorted.length < 2) continue;
    // Skip a DISMISSED group: if any member pair was recorded as separated
    // ("not duplicates"), drop the whole group so it never auto-merges.
    if (sepPairs.size > 0) {
      const ids = sorted.map((r) => r.CRMProvider_record_id);
      let separated = false;
      for (let a = 0; a < ids.length && !separated; a++) {
        for (let b = a + 1; b < ids.length; b++) {
          const lo = ids[a]! < ids[b]! ? ids[a]! : ids[b]!;
          const hi = ids[a]! < ids[b]! ? ids[b]! : ids[a]!;
          if (sepPairs.has(lo + "|" + hi)) {
            separated = true;
            break;
          }
        }
      }
      if (separated) continue;
    }
    // Survivor: highest completion % → oldest (canonical original).
    sorted.sort((a, b) => {
      const ca = fieldsPopulated(a),
        cb = fieldsPopulated(b);
      if (cb !== ca) return cb - ca;
      return (
        Number(a.created_ms || Number.MAX_SAFE_INTEGER) -
        Number(b.created_ms || Number.MAX_SAFE_INTEGER)
      );
    });
    const [survivor, ...dups] = sorted;
    if (!survivor) continue;
    const total = SCORED_FIELDS.length;
    const members: AccountDomainNameMember[] = sorted.map((m) => {
      const pop = fieldsPopulated(m);
      return {
        CRMProviderId: m.CRMProvider_record_id,
        name: (m.record_name || m.company_name || "").trim(),
        domain: m.domain,
        owner: m.owner_name,
        website: m.website,
        cr: m.cr_number,
        vat: m.vat_number,
        country: m.country,
        industry: m.industry,
        layout: m.layout_name,
        createdMs: m.created_ms != null ? Number(m.created_ms) : null,
        dealCount: dealCountByAccount.get(m.CRMProvider_record_id) ?? 0,
        fieldsPopulated: pop,
        fieldsTotal: total,
        completionPct: Math.round((pop / total) * 100),
        isSurvivor: m.CRMProvider_record_id === survivor.CRMProvider_record_id,
      };
    });
    const names = [
      ...new Set(
        sorted
          .map((m) => (m.record_name || m.company_name || "").trim())
          .filter(Boolean),
      ),
    ];
    // Shared-domain guard (domain-only mode): a domain carrying many DISTINCT
    // company names is probably a holding/agency/shared domain — skip it so it
    // isn't auto-merged; it stays for manual review.
    if (groupBy === "domain" && names.length > maxDistinctNames) continue;
    groups.push({
      key,
      domain: (sorted[0]!.domain || "").trim().toLowerCase(),
      nameKey: normalizeCompanyName(
        sorted[0]!.record_name || sorted[0]!.company_name || "",
      ),
      survivorCRMProviderId: survivor.CRMProvider_record_id,
      duplicateCRMProviderIds: dups.map((d) => d.CRMProvider_record_id),
      names,
      label: (survivor.record_name || survivor.company_name || "").trim(),
      members,
    });
  }
  return groups;
}

/** Read-only PREVIEW of the account auto-merge for both scopes. No writes. */
export async function previewAccountDomainNameMerge(): Promise<{
  corporate: { groups: number; accountsToTag: number; sample: AccountDomainNameGroup[] };
  partner: { groups: number; accountsToTag: number; sample: AccountDomainNameGroup[] };
}> {
  const build = async (layouts: string[]) => {
    const groups = await getAccountDomainNameGroups(layouts).catch(() => []);
    return {
      groups: groups.length,
      accountsToTag: groups.reduce((n, g) => n + g.duplicateCRMProviderIds.length, 0),
      // Return up to 200 so the operator can drill into and override the
      // survivor of every group before applying (was 15 — too few to verify).
      sample: groups.slice(0, 200),
    };
  };
  return {
    corporate: await build(ACCOUNT_SCOPE_LAYOUTS.corporate),
    partner: await build(ACCOUNT_SCOPE_LAYOUTS.partner),
  };
}

/**
 * Read-only PREVIEW of the LOOSER domain-only account auto-merge (Sample User
 * 2026-06-23): "same domain, any name", with the shared-domain guard. No writes.
 */
export async function previewAccountDomainOnlyMerge(): Promise<{
  corporate: { groups: number; accountsToTag: number; sample: AccountDomainNameGroup[] };
  partner: { groups: number; accountsToTag: number; sample: AccountDomainNameGroup[] };
}> {
  const build = async (layouts: string[]) => {
    const groups = await getAccountDomainNameGroups(layouts, { groupBy: "domain" }).catch(
      () => [],
    );
    return {
      groups: groups.length,
      accountsToTag: groups.reduce((n, g) => n + g.duplicateCRMProviderIds.length, 0),
      sample: groups.slice(0, 200),
    };
  };
  return {
    corporate: await build(ACCOUNT_SCOPE_LAYOUTS.corporate),
    partner: await build(ACCOUNT_SCOPE_LAYOUTS.partner),
  };
}

/**
 * Apply the account auto-merge for one scope. For each domain+name group it
 * reuses the PROVEN agentic merge engine (buildMergePlan + executeMergePlan):
 * survivor selection, EN/AR name preservation (into Description), re-parenting
 * the duplicates' contacts/deals onto the survivor, and tagging the rest
 * Duplicate-Delete — the platform never deletes. dryRun=true writes nothing
 * (still enumerates). Bounded by `limit`, re-runnable.
 */
export async function applyAccountDomainNameMerge(opts: {
  scope: "corporate" | "partner";
  dryRun: boolean;
  limit?: number;
  performedBy: string;
  /**
   * Per-group survivor overrides, keyed by AccountDomainNameGroup.key
   * (domain|nameKey) → the CRMProvider id to KEEP. When a group isn't listed we keep
   * the default survivor (highest completion %). An override pointing at a
   * record not in the group is ignored by the engine (it falls back safely).
   */
  overrides?: Record<string, string>;
  /**
   * Per-group EXCLUDED account ids, keyed by group key → CRMProvider ids to leave OUT
   * of the merge entirely (not survivor, not tagged — untouched). Lets the
   * operator drop a wrong member (e.g. a Partner account) from a 3+ group and
   * still merge the rest.
   */
  excludes?: Record<string, string[]>;
  /** 'domain_name' (strict, default) or 'domain' (looser same-domain-any-name). */
  groupBy?: "domain_name" | "domain";
}): Promise<{
  scope: string;
  groups: number;
  merged: number;
  accountsTagged: number;
  reparentedDeals: number;
  reparentedContacts: number;
  namesPreserved: number;
  remaining: number;
  errors: number;
}> {
  const layouts = ACCOUNT_SCOPE_LAYOUTS[opts.scope] || [];
  const all = await getAccountDomainNameGroups(layouts, { groupBy: opts.groupBy || "domain_name" });
  const limit = Math.max(1, Math.min(Math.floor(opts.limit || 100), 500));
  const batch = all.slice(0, limit);
  const { buildMergePlan } = await import("./duplicateMergePlanner");
  const { executeMergePlan, CRMProviderWritesAllowedInEnv } = await import("./duplicateMergeExecutor");
  if (!opts.dryRun && !CRMProviderWritesAllowedInEnv()) {
    throw new Error("Live CRMProvider writes are disabled outside production.");
  }
  let merged = 0,
    accountsTagged = 0,
    reparentedDeals = 0,
    reparentedContacts = 0,
    namesPreserved = 0,
    errors = 0;
  for (const g of batch) {
    try {
      // Drop operator-EXCLUDED members (e.g. a Partner account in a 3-group) so
      // only the chosen set merges; the excluded ones are left untouched.
      const excludedSet = new Set(opts.excludes?.[g.key] ?? []);
      const CRMProviderIds = [g.survivorCRMProviderId, ...g.duplicateCRMProviderIds].filter(
        (id) => !excludedSet.has(id),
      );
      if (CRMProviderIds.length < 2) continue; // nothing left to merge after exclusions
      const recRes = await pool.query(
        `SELECT * FROM duplicate_records WHERE record_type = 'account' AND CRMProvider_record_id = ANY($1::text[])`,
        [CRMProviderIds],
      );
      const recs = recRes.rows as DuplicateRecord[];
      if (recs.length < 2) continue;
      // Honor an operator override (else keep the highest-% survivor) — but only
      // among INCLUDED members. We FORCE it as the engine's master so the
      // applied survivor == the previewed one.
      const overrideId = opts.overrides?.[g.key];
      const chosenSurvivorId =
        overrideId && CRMProviderIds.includes(overrideId)
          ? overrideId
          : CRMProviderIds.includes(g.survivorCRMProviderId)
            ? g.survivorCRMProviderId
            : (g.members.find((m) => CRMProviderIds.includes(m.CRMProviderId))?.CRMProviderId ?? CRMProviderIds[0]!);
      const survivorRow =
        recs.find((r) => (r as any).CRMProvider_record_id === chosenSurvivorId) || recs[0];
      const clusterId = (survivorRow as any)?.cluster_id ?? (recs[0] as any)?.cluster_id;
      if (!clusterId) continue;
      const plan = buildMergePlan("Accounts", clusterId, recs, {
        masterCRMProviderId: chosenSurvivorId,
      });
      if (plan.fieldDecisions.some((d) => d.field === "Description" && d.action === "fill")) {
        namesPreserved++;
      }
      const report = await executeMergePlan(plan, {
        performedBy: opts.performedBy,
        dryRun: opts.dryRun,
        // Leave the cluster open — it may carry other modules; the next sync
        // resolves it once every module's duplicates are tagged/merged.
        closeCluster: false,
      });
      accountsTagged += plan.duplicateCRMProviderIds.length;
      reparentedDeals += report.reparented?.deals ?? 0;
      reparentedContacts += report.reparented?.contacts ?? 0;
      merged++;
    } catch (e) {
      errors++;
      logger.warn("[DuplicateRadar] account auto-merge group failed (non-fatal)", {
        error: e instanceof Error ? e.message : String(e),
      });
    }
  }
  return {
    scope: opts.scope,
    groups: batch.length,
    merged,
    accountsTagged,
    reparentedDeals,
    reparentedContacts,
    namesPreserved,
    remaining: Math.max(0, all.length - batch.length),
    errors,
  };
}

// ── Bulk link contacts → Account (Sample User 2026-06-23) ──────────────────────────
// The remaining contact clusters are "chained matches": colleagues at the same
// company who are NOT duplicates of each other (they don't pairwise share ≥2 of
// {email, phone, name}). The productive action is to LINK them to the company's
// Account (set Account_Name) so they roll up under one customer — not merge.
// This bulk job does that link cascade for every cluster that has contacts and
// exactly ONE account (an unambiguous link target) AND no genuine duplicates.

export interface ContactLinkCandidate {
  clusterId: number;
  accountCRMProviderId: string;
  accountName: string;
  contacts: number;
}

/** Active clusters with ≥1 contact and EXACTLY 1 account → unambiguous link. */
export async function getContactLinkCandidates(
  limit = 5000,
): Promise<ContactLinkCandidate[]> {
  const res = await pool.query<{
    cluster_id: number;
    contacts: string;
    account_CRMProvider_id: string | null;
    account_name: string | null;
  }>(
    `SELECT dr.cluster_id,
            COUNT(*) FILTER (WHERE dr.record_type = 'contact') AS contacts,
            (ARRAY_AGG(dr.CRMProvider_record_id) FILTER (WHERE dr.record_type = 'account'))[1] AS account_CRMProvider_id,
            (ARRAY_AGG(COALESCE(NULLIF(btrim(dr.record_name),''), dr.company_name))
               FILTER (WHERE dr.record_type = 'account'))[1] AS account_name
       FROM duplicate_records dr
       JOIN duplicate_clusters dc ON dc.id = dr.cluster_id
      WHERE dc.status = 'active'
        AND dr.cluster_id IS NOT NULL
      GROUP BY dr.cluster_id
     HAVING COUNT(*) FILTER (WHERE dr.record_type = 'contact') >= 1
        AND COUNT(DISTINCT dr.CRMProvider_record_id) FILTER (WHERE dr.record_type = 'account') = 1
        AND COUNT(*) FILTER (WHERE dr.record_type IN ('lead','deal')) = 0
      LIMIT $1`,
    [limit],
  );
  return res.rows
    .map((r) => ({
      clusterId: Number(r.cluster_id),
      accountCRMProviderId: (r.account_CRMProvider_id || "").trim(),
      accountName: (r.account_name || "").trim(),
      contacts: Number(r.contacts) || 0,
    }))
    .filter((c) => c.accountCRMProviderId && Number.isFinite(c.clusterId));
}

/** Read-only preview: how many clusters / contacts the bulk link would touch. */
export async function previewContactLinkToAccount(): Promise<{
  clusters: number;
  contacts: number;
  sample: ContactLinkCandidate[];
}> {
  try {
    const cands = await getContactLinkCandidates();
    return {
      clusters: cands.length,
      contacts: cands.reduce((n, c) => n + c.contacts, 0),
      sample: cands.slice(0, 200),
    };
  } catch (e) {
    logger.warn("[DuplicateRadar] previewContactLinkToAccount failed (non-fatal)", {
      error: e instanceof Error ? e.message : String(e),
    });
    return { clusters: 0, contacts: 0, sample: [] };
  }
}

/**
 * Apply the bulk link: for each candidate cluster, set every contact's
 * Account_Name to the cluster's sole account (the Account_Name cascade). Skips
 * any cluster that actually has genuine contact duplicates (those belong in the
 * merge flow, not a blind link). Reuses buildMergePlan/executeMergePlan — no
 * tagging happens in link-only mode. Bounded by `limit`, re-runnable.
 */
export async function applyContactLinkToAccount(opts: {
  dryRun: boolean;
  limit?: number;
  performedBy: string;
}): Promise<{
  clusters: number;
  linked: number;
  contactsLinked: number;
  <REDACTED_TOKEN>: number;
  remaining: number;
  errors: number;
  errorSample: string | null;
}> {
  const all = await getContactLinkCandidates();
  const limit = Math.max(1, Math.min(Math.floor(opts.limit || 50), 200));
  const batch = all.slice(0, limit);
  const { buildMergePlan } = await import("./duplicateMergePlanner");
  const { executeMergePlan, CRMProviderWritesAllowedInEnv } = await import("./duplicateMergeExecutor");
  if (!opts.dryRun && !CRMProviderWritesAllowedInEnv()) {
    throw new Error("Live CRMProvider writes are disabled outside production.");
  }
  let linked = 0,
    contactsLinked = 0,
    <REDACTED_TOKEN> = 0,
    errors = 0;
  let errorSample: string | null = null;
  for (const cand of batch) {
    try {
      const recs = await getRecordsByClusterId(cand.clusterId);
      const plan = buildMergePlan("Contacts", cand.clusterId, recs, {
        linkAccountCRMProviderId: cand.accountCRMProviderId,
      });
      // Only link clusters that are link-only — if there are genuine duplicates,
      // leave the cluster for the merge flow (don't blindly link + risk hiding a
      // real dup).
      if (plan.duplicateCRMProviderIds.length > 0) {
        <REDACTED_TOKEN>++;
        continue;
      }
      const report = await executeMergePlan(plan, {
        performedBy: opts.performedBy,
        dryRun: opts.dryRun,
        // Contacts-only cluster (no leads/deals) — once the colleagues are
        // linked to their Account the cluster's job is done, so resolve it.
        // This also makes the batched apply CONVERGE: a resolved cluster drops
        // out of getContactLinkCandidates (active only), so the work set shrinks.
        closeCluster: true,
      });
      contactsLinked += report.reparented?.contacts ?? 0;
      linked++;
    } catch (e) {
      errors++;
      const msg = e instanceof Error ? e.message : String(e);
      if (!errorSample) errorSample = msg;
      logger.warn("[DuplicateRadar] bulk contact link group failed (non-fatal)", {
        clusterId: cand.clusterId,
        accountCRMProviderId: cand.accountCRMProviderId,
        error: msg,
      });
    }
  }
  return {
    clusters: batch.length,
    linked,
    contactsLinked,
    <REDACTED_TOKEN>,
    remaining: Math.max(0, all.length - batch.length),
    errors,
    errorSample,
  };
}

/**
 * Resolve auto-merged contact clusters ONCE their tagged duplicates are
 * actually deleted in CRMProvider (Sample User 2026-06-21). The bulk auto-merge marks a
 * cluster 'auto_merge_pending' (→ shows as "AI-Applied · pending CRMProvider admin
 * delete"). This pass writes the durable resolution-ledger entry only after
 * deletion-detection has removed EVERY tagged duplicate — so the cluster stays
 * pending until the admin truly deletes, then restoreLedgerResolvedClusterStatus
 * (run right after this) flips it to 'resolved'. Idempotent + best-effort.
 *
 * Guards against a full rebuild that reassigned db ids: it only resolves when
 * the survivor row still exists, so stale ids can't false-resolve a cluster.
 */
export async function reconcileAutoMergedContactDeletions(): Promise<number> {
  try {
    const pend = await pool.query<{
      id: number;
      primary_record_id: number | null;
      merged_record_ids: any;
      performed_by: string | null;
    }>(
      `SELECT id, primary_record_id, merged_record_ids, performed_by
         FROM duplicate_merge_actions
        WHERE action_type = 'auto_merge_pending'`,
    );
    let resolved = 0;
    for (const a of pend.rows) {
      const dupIds: number[] = Array.isArray(a.merged_record_ids)
        ? a.merged_record_ids
        : (() => {
            try {
              return JSON.parse(a.merged_record_ids);
            } catch {
              return [];
            }
          })();
      if (!dupIds.length || !a.primary_record_id) continue;
      // Survivor must still exist (a full rebuild would have reassigned ids;
      // don't false-resolve on stale references).
      const surv = await pool.query<{ CRMProvider_record_id: string }>(
        `SELECT CRMProvider_record_id FROM duplicate_records WHERE id = $1`,
        [a.primary_record_id],
      );
      const survivorCRMProvider = surv.rows[0]?.CRMProvider_record_id;
      if (!survivorCRMProvider) continue;
      // Are ALL tagged duplicates gone (admin deleted them)?
      const still = await pool.query<{ n: number }>(
        `SELECT COUNT(*)::int AS n FROM duplicate_records WHERE id = ANY($1::int[])`,
        [dupIds],
      );
      if ((still.rows[0]?.n ?? 0) > 0) continue; // still pending — some dups remain
      // Deleted → record the true merge; the ledger-restore pass resolves it.
      await pool.query(
        `INSERT INTO duplicate_resolution_ledger
           (module, master_CRMProvider_id, duplicate_CRMProvider_ids, action_type, performed_by, notes, resolved_at)
         VALUES ('Contacts', $1, '[]'::jsonb, 'resolve', $2, 'bulk exact email+phone — admin deleted tagged dups', NOW())
         ON CONFLICT (module, master_CRMProvider_id) WHERE master_CRMProvider_id IS NOT NULL DO NOTHING`,
        [survivorCRMProvider, a.performed_by || "auto-merge"],
      );
      // Convert the pending marker to a normal resolve marker so it isn't
      // re-checked and reads correctly in the Manual Actions log.
      await pool.query(
        `UPDATE duplicate_merge_actions SET action_type = 'module_resolved' WHERE id = $1`,
        [a.id],
      );
      resolved++;
    }
    if (resolved > 0) {
      logger.info(
        `🔁 [DuplicateRadar] Auto-merge: ${resolved} cluster(s) had their tagged dups deleted in CRMProvider → resolving`,
      );
    }
    return resolved;
  } catch (e) {
    logger.warn(
      `[DuplicateRadar] reconcileAutoMergedContactDeletions skipped (non-fatal): ${e instanceof Error ? e.message : String(e)}`,
    );
    return 0;
  }
}

/**
 * Layer-2 of Sample User's "Mark Handled survives the 6h sync" fix (2026-06-16).
 *
 * Walk every status='active' cluster and flip it to status='resolved' when
 * EVERY module present in the cluster has a matching entry in
 * `duplicate_resolution_ledger` (keyed by the survivor's stable CRMProvider id +
 * module). Run this at the end of every scanCRMProviderCRMForDuplicates pass —
 * right after updateClusterStats — so the cluster that the sync just
 * created for a previously-handled overlap doesn't show back up in the
 * Open queue under a fresh cluster_id.
 *
 * Mechanics: array-set inclusion. `modules_present` is what record_types
 * the cluster has; `modules_ledger_resolved` is the subset of those
 * record_types whose CRMProvider id is in the ledger for the matching module.
 * Since modules_ledger_resolved ⊆ modules_present by construction, equal
 * cardinalities mean every present module is covered.
 *
 * Best-effort + idempotent: replays don't move anything (only `status =
 * 'active'` rows are candidates). resolved_by is stamped "ledger-restore"
 * so the audit trail distinguishes auto-resolved from manual.
 */
export async function restoreLedgerResolvedClusterStatus(): Promise<{
  candidates_examined: number;
  clusters_restored: number;
}> {
  try {
    const examineQ = await pool.query<{ count: string }>(
      `SELECT COUNT(*)::text AS count FROM duplicate_clusters WHERE status = 'active'`,
    );
    const examined = Number(examineQ.rows[0]?.count ?? 0);

    const r = await pool.query<{ id: number }>(
      `WITH cluster_modules AS (
         SELECT cluster_id,
                array_agg(DISTINCT record_type)
                  FILTER (WHERE record_type IS NOT NULL)                       AS present,
                array_agg(DISTINCT record_type)
                  FILTER (WHERE EXISTS (
                    SELECT 1 FROM duplicate_resolution_ledger lg
                    WHERE lg.master_CRMProvider_id = duplicate_records.CRMProvider_record_id
                      AND lg.module = CASE duplicate_records.record_type
                                        WHEN 'lead'    THEN 'Leads'
                                        WHEN 'deal'    THEN 'Deals'
                                        WHEN 'contact' THEN 'Contacts'
                                        WHEN 'account' THEN 'Accounts'
                                      END
                      -- VERIFIED only (Sample User 2026-07-06): 'resolve' means Verify-in-CRM
                      -- confirmed the Duplicate-Delete records are gone. 'module_resolved'
                      -- (an apply that hasn't been verified yet) must NOT auto-resolve — it
                      -- stays in the AI-Applied queue until Verify moves it to Resolved.
                      AND lg.action_type = 'resolve'
                  ))                                                            AS resolved_modules
           FROM duplicate_records
          WHERE CRMProvider_record_id IS NOT NULL
          GROUP BY cluster_id
       )
       UPDATE duplicate_clusters dc
          SET status      = 'resolved',
              resolved_by = COALESCE(dc.resolved_by, 'ledger-restore'),
              resolved_at = COALESCE(dc.resolved_at, NOW()),
              updated_at  = NOW()
         FROM cluster_modules cm
        WHERE dc.id = cm.cluster_id
          AND dc.status = 'active'
          AND COALESCE(array_length(cm.present, 1), 0) > 0
          AND COALESCE(array_length(cm.resolved_modules, 1), 0) =
              COALESCE(array_length(cm.present, 1), 0)
        RETURNING dc.id`,
    );
    const restored = r.rowCount ?? 0;
    if (restored > 0) {
      logger.info(
        `🔁 [DuplicateRadar] Ledger-restore: ${restored} cluster(s) flipped back to status='resolved' (of ${examined} active candidates)`,
      );
    }
    return { candidates_examined: examined, clusters_restored: restored };
  } catch (e) {
    logger.warn(
      "[DuplicateRadar] restoreLedgerResolvedClusterStatus skipped (non-fatal)",
      { error: e instanceof Error ? e.message : String(e) },
    );
    return { candidates_examined: 0, clusters_restored: 0 };
  }
}

// Hard reset for the "Rebuild Clusters" admin action.
// Wipes all clusters + records so the next scan starts from a clean slate.
/**
 * Snapshot every merge action to CRMProvider-id keys before a rebuild wipes them.
 *
 * Returns how many rows were archived so the caller can refuse to truncate if
 * the snapshot did not happen — losing the AI-Applied backlog is not something
 * to discover afterwards.
 */
export async function archiveMergeActions(): Promise<number> {
  const r = await pool.query(
    `INSERT INTO duplicate_merge_actions_archive
       (module, master_CRMProvider_id, merged_CRMProvider_ids, action_type, performed_by, notes, original_created_at)
     SELECT DISTINCT ON (ma.cluster_id, mod.module, ma.action_type)
       mod.module,
       pr.CRMProvider_record_id,
       COALESCE(
         (SELECT jsonb_agg(dr2.CRMProvider_record_id)
            FROM duplicate_records dr2
           WHERE dr2.cluster_id = ma.cluster_id
             AND dr2.CRMProvider_record_id IS NOT NULL
             AND dr2.id <> pr.id),
         '[]'::jsonb),
       ma.action_type, ma.performed_by, ma.notes, ma.created_at
     FROM duplicate_merge_actions ma
     JOIN duplicate_records pr
       ON pr.id = COALESCE(ma.primary_record_id,
            (SELECT dr3.id FROM duplicate_records dr3
              WHERE dr3.cluster_id = ma.cluster_id
              ORDER BY dr3.is_primary DESC, dr3.id ASC LIMIT 1))
     JOIN LATERAL (
       SELECT CASE pr.record_type
                WHEN 'lead' THEN 'Leads' WHEN 'deal' THEN 'Deals'
                WHEN 'contact' THEN 'Contacts' WHEN 'account' THEN 'Accounts'
              END AS module
     ) mod ON true
     WHERE pr.CRMProvider_record_id IS NOT NULL AND mod.module IS NOT NULL
     ORDER BY ma.cluster_id, mod.module, ma.action_type, ma.created_at DESC
     ON CONFLICT (module, master_CRMProvider_id, action_type) DO UPDATE SET
       merged_CRMProvider_ids = EXCLUDED.merged_CRMProvider_ids,
       archived_at = NOW(),
       restored_at = NULL`,
  );
  const n = r.rowCount || 0;
  logger.info(`🗄️ [DuplicateRadar] Archived ${n} merge action(s) before rebuild`);
  return n;
}

/**
 * Re-attach archived merge actions to the clusters a rescan rebuilt.
 *
 * Matches on the master's CRMProvider id, so a cluster that reformed around the same
 * surviving record gets its AI-Applied marker back. Records that no longer
 * exist in CRMProvider simply do not match — which is correct: if the admin really did
 * delete them, the cluster should not come back as pending.
 */
export async function restoreMergeActions(): Promise<number> {
  const r = await pool.query(
    `INSERT INTO duplicate_merge_actions
       (cluster_id, primary_record_id, merged_record_ids, action_type, performed_by, notes, created_at)
     SELECT dr.cluster_id, dr.id, a.merged_CRMProvider_ids, a.action_type, a.performed_by,
            COALESCE(a.notes, '') || ' [restored after rebuild]', a.original_created_at
       FROM duplicate_merge_actions_archive a
       JOIN duplicate_records dr
         ON dr.CRMProvider_record_id = a.master_CRMProvider_id
        AND dr.cluster_id IS NOT NULL
        AND CASE dr.record_type
              WHEN 'lead' THEN 'Leads' WHEN 'deal' THEN 'Deals'
              WHEN 'contact' THEN 'Contacts' WHEN 'account' THEN 'Accounts'
            END = a.module
      WHERE NOT EXISTS (
        SELECT 1 FROM duplicate_merge_actions ma
         WHERE ma.cluster_id = dr.cluster_id AND ma.action_type = a.action_type
      )`,
  );
  const n = r.rowCount || 0;
  await pool.query(
    `UPDATE duplicate_merge_actions_archive SET restored_at = NOW() WHERE restored_at IS NULL`,
  );
  logger.info(`♻️ [DuplicateRadar] Restored ${n} merge action(s) after rebuild`);
  return n;
}

export async function truncateAllDuplicateData(): Promise<void> {
  logger.info(
    "🧨 [DuplicateRadar] Truncating all duplicate data for rebuild...",
  );
  // CRITICAL: snapshot solved-state into the durable ledger BEFORE truncating.
  // The TRUNCATE ... CASCADE below deletes duplicate_merge_actions and resets
  // every cluster's status, so without this the per-module "solved" scoreboard
  // collapses to 0 on every rebuild (the bug Sample User). The ledger survives the
  // truncate and re-credits "solved" to whatever cluster each survivor lands in
  // after the rescan.
  await backfillResolutionLedger();
  // Snapshot the AI-Applied backlog to CRMProvider-id keys. NOT wrapped in a
  // try/catch: if this fails the truncate must not proceed, because the
  // markers it protects cannot be reconstructed afterwards.
  await archiveMergeActions();
  await pool.query(
    "TRUNCATE duplicate_records, duplicate_clusters RESTART IDENTITY CASCADE",
  );
  logger.info("✅ [DuplicateRadar] Duplicate tables truncated");
}

export async function getClusterById(
  id: number,
): Promise<DuplicateCluster | null> {
  const result = await pool.query(
    "SELECT * FROM duplicate_clusters WHERE id = $1",
    [id],
  );
  return result.rows[0] || null;
}

export async function getRecordsByClusterId(
  clusterId: number,
): Promise<DuplicateRecord[]> {
  const result = await pool.query(
    "SELECT * FROM duplicate_records WHERE cluster_id = $1 ORDER BY is_primary DESC, created_date ASC",
    [clusterId],
  );
  return result.rows;
}

/**
 * Inspect a cluster's records and report any "mixed signal" — distinct
 * corporate domains or distinct normalized phone numbers found inside.
 * Two unrelated companies that share a generic name fragment can end up
 * in the same cluster (e.g. "Al Suwaidi Industrial Services" + "APEX
 * Industrial Services"). Surfacing this lets the operator review &
 * split before any merge/link is performed in CRMProvider.
 *
 * `domain_groups` maps each domain to the record IDs holding that
 * domain so the UI can offer a one-click "Split by domain" action.
 */
export async function getClusterMixedSignal(clusterId: number): Promise<{
  domains: string[];
  phones: string[];
  domain_groups: Record<string, number[]>;
}> {
  const records = await getRecordsByClusterId(clusterId);
  const domainGroups: Record<string, number[]> = {};
  const phoneSet = new Set<string>();
  for (const r of records) {
    const d = (r.domain || "").toLowerCase().trim();
    if (d && isCorporateDomain(d)) {
      if (!domainGroups[d]) domainGroups[d] = [];
      if (typeof r.id === "number") domainGroups[d].push(r.id);
    }
    const p = normalizePhone(r.phone || "");
    if (p && p.length >= 7) phoneSet.add(p);
  }
  return {
    domains: Object.keys(domainGroups).sort(),
    phones: Array.from(phoneSet).sort(),
    domain_groups: domainGroups,
  };
}

/**
 * Move a set of records out of `sourceClusterId` and into a freshly
 * created cluster. Returns both cluster IDs so the caller can recompute
 * stats and refresh the UI. The source cluster is left in place even if
 * it ends up empty — `updateClusterStats` will drive its counters to
 * zero and the existing orphan-cleanup pass will collect it later.
 */
/**
 * Transactional core of the cluster-split flow. Performs ONLY the
 * destructive writes (insert new cluster row + move records across) using
 * the supplied client, so callers can wrap multiple plans in a single
 * BEGIN/COMMIT and roll back on any failure.
 *
 * Stats refresh (confidence_score etc.) is intentionally NOT performed
 * here — it is idempotent and is run by the caller AFTER commit. This
 * keeps the transaction window small and avoids the heavy multi-query
 * stats recompute participating in the locking scope.
 *
 * Exported so the split route can compose plans atomically.
 */
export async function splitRecordsIntoNewClusterInTx(
  client: { query: (sql: string, params?: any[]) => Promise<any> },
  sourceClusterId: number,
  recordIds: number[],
  newClusterSeed: {
    company_name: string;
    domain?: string | null;
  },
): Promise<{ source_cluster_id: number; new_cluster_id: number }> {
  if (!Array.isArray(recordIds) || recordIds.length === 0) {
    throw new Error("recordIds must be a non-empty array");
  }

  // Pre-flight: every record must currently belong to the source cluster.
  // This catches concurrent splits/moves and prevents creating a fresh
  // cluster pointing at records that already drifted away.
  const ownership = await client.query(
    `SELECT id FROM duplicate_records
      WHERE cluster_id = $1 AND id = ANY($2::int[])`,
    [sourceClusterId, recordIds],
  );
  if (ownership.rows.length !== recordIds.length) {
    throw new Error(
      `Split aborted — ${recordIds.length - ownership.rows.length} record(s) no longer belong to cluster ${sourceClusterId} (concurrent move?)`,
    );
  }

  const companyNormalized = normalizeCompanyName(newClusterSeed.company_name);
  const seedDomain =
    newClusterSeed.domain ||
    companyNormalized.replace(/\s+/g, "-") + ".cluster";

  const inserted = await client.query(
    `INSERT INTO duplicate_clusters
       (domain, company_name, company_name_arabic, company_name_normalized,
        total_leads, total_deals, total_records, confidence_level,
        confidence_score, owners_involved, estimated_pipeline_value, status)
     VALUES ($1, $2, NULL, $3, 0, 0, 0, 'low', 0, '[]'::jsonb, 0, 'active')
     RETURNING id`,
    [seedDomain, newClusterSeed.company_name, companyNormalized],
  );
  const newClusterId = inserted.rows[0].id as number;

  await client.query(
    `UPDATE duplicate_records
        SET cluster_id = $1,
            is_primary = false
      WHERE cluster_id = $2
        AND id = ANY($3::int[])`,
    [newClusterId, sourceClusterId, recordIds],
  );

  // Clear stale "primary" flag on the source if its old primary just
  // moved out — leaves the source consistent until updateClusterStats
  // (post-commit) re-derives a new primary.
  await client.query(
    `UPDATE duplicate_records
        SET is_primary = false
      WHERE cluster_id = $1
        AND is_primary = true
        AND NOT EXISTS (
          SELECT 1 FROM duplicate_records dr2
           WHERE dr2.cluster_id = $1 AND dr2.is_primary = true
        )`,
    [sourceClusterId],
  );

  return {
    source_cluster_id: sourceClusterId,
    new_cluster_id: newClusterId,
  };
}

/**
 * Convenience single-plan wrapper that opens its own short-lived
 * transaction. Kept for ad-hoc / scripted use; the duplicates route
 * uses the lower-level `splitRecordsIntoNewClusterInTx` to batch
 * multiple plans atomically.
 */
export async function splitRecordsIntoNewCluster(
  sourceClusterId: number,
  recordIds: number[],
  newClusterSeed: {
    company_name: string;
    domain?: string | null;
  },
): Promise<{ source_cluster_id: number; new_cluster_id: number }> {
  const client = await (pool as any).connect();
  let result: { source_cluster_id: number; new_cluster_id: number };
  try {
    await client.query("BEGIN");
    result = await splitRecordsIntoNewClusterInTx(
      client,
      sourceClusterId,
      recordIds,
      newClusterSeed,
    );
    await client.query("COMMIT");
  } catch (err) {
    try {
      await client.query("ROLLBACK");
    } catch {
      /* ignore rollback failure */
    }
    throw err;
  } finally {
    client.release();
  }
  // Stats refresh runs OUTSIDE the transaction — idempotent and
  // best-effort; failures here do not invalidate the split itself.
  try {
    await updateClusterStats(sourceClusterId);
    await updateClusterStats(result.new_cluster_id);
  } catch (e) {
    logger.warn("Post-split stats refresh failed (non-fatal)", e as any);
  }
  return result;
}

export async function getClusterSummary(): Promise<{
  totalClusters: number;
  totalDuplicateLeads: number;
  totalDuplicateDeals: number;
  highConfidence: number;
  mediumConfidence: number;
  lowConfidence: number;
  estimatedPipelineInflation: number;
  activeCount: number;
  resolvedCount: number;
}> {
  // A REAL duplicate cluster has ≥2 records OF THE SAME MODULE. A 1-record
  // "cluster" is a lone company, and a cluster holding one lead plus one
  // account is a CROSS-MODULE LINK — the same company seen in two places, not
  // a duplicate of either.
  //
  // The 2026-06-28 fix removed singletons but summed ACROSS modules
  // (total_leads + total_deals + total_contacts + total_accounts >= 2), so
  // every cross-module link still counted. Measured live 2026-08-23: this
  // reported 26,090 duplicate clusters where the dashboard and the module tabs
  // report 10,282 — a gap of 15,808 against 15,242 cross_module_link_candidate
  // signals. The executive brief therefore overstated the duplicate count
  // ~2.5x AND understated progress, because the inflated figure is also the
  // denominator of "% cleared" (7% shown against a 23% resolution rate).
  //
  // GREATEST(...) > 1 is the definition getSummary's trueDuplicateClusters,
  // the per-module tabs and getSegment*DuplicateCount all use. One definition.
  const MULTI = `GREATEST(COALESCE(dc.total_leads,0), COALESCE(dc.total_deals,0), COALESCE(dc.total_contacts,0), COALESCE(dc.total_accounts,0)) > 1`;
  const result = await pool.query(`
    WITH resolved_act AS (
      SELECT DISTINCT cluster_id FROM duplicate_merge_actions
       WHERE action_type IN ('resolve','module_resolved')
    )
    SELECT
      COUNT(*) as total_clusters,
      COALESCE(SUM(total_leads), 0) as total_leads,
      COALESCE(SUM(total_deals), 0) as total_deals,
      COUNT(*) FILTER (WHERE confidence_level = 'high') as high_confidence,
      COUNT(*) FILTER (WHERE confidence_level = 'medium') as medium_confidence,
      COUNT(*) FILTER (WHERE confidence_level = 'low') as low_confidence,
      -- Amount at risk (Sample User 2026-07-29): ACTIVE, non-resolved clusters only
      -- (dismiss/resolve drops the value out), AND excludes duplicate deals at
      -- Agreement Signed / Paid — those are WON customers, not pipeline at risk.
      -- Computed from duplicate_records (not the stored estimated_pipeline_value
      -- column) so the stage exclusion applies without a full rebuild.
      (SELECT COALESCE(SUM(t.deal_value), 0) FROM (
         SELECT r.deal_value,
                ROW_NUMBER() OVER (PARTITION BY r.cluster_id
                  ORDER BY r.is_primary DESC, r.deal_value DESC, r.created_date ASC NULLS LAST, r.id ASC) AS rn
           FROM duplicate_records r
           JOIN duplicate_clusters c2 ON c2.id = r.cluster_id
           LEFT JOIN resolved_act ra2 ON ra2.cluster_id = c2.id
          WHERE r.record_type = 'deal' AND r.deal_value > 0
            AND c2.status = 'active' AND ra2.cluster_id IS NULL
            AND c2.total_deals > 1
            AND (${openStagePredicate("r")})
       ) t WHERE t.rn > 1
      ) as pipeline_inflation,
      COUNT(*) FILTER (WHERE dc.status = 'active' AND ra.cluster_id IS NULL) as active_count,
      COUNT(*) FILTER (WHERE dc.status = 'resolved' OR ra.cluster_id IS NOT NULL) as resolved_count
    FROM duplicate_clusters dc
    LEFT JOIN resolved_act ra ON ra.cluster_id = dc.id
    WHERE ${MULTI}
  `);

  const row = result.rows[0];
  return {
    totalClusters: parseInt(row.total_clusters) || 0,
    totalDuplicateLeads: parseInt(row.total_leads) || 0,
    totalDuplicateDeals: parseInt(row.total_deals) || 0,
    highConfidence: parseInt(row.high_confidence) || 0,
    mediumConfidence: parseInt(row.medium_confidence) || 0,
    lowConfidence: parseInt(row.low_confidence) || 0,
    estimatedPipelineInflation: parseFloat(row.pipeline_inflation) || 0,
    activeCount: parseInt(row.active_count) || 0,
    resolvedCount: parseInt(row.resolved_count) || 0,
  };
}

/**
 * "Total cleanup actions across ALL tabs" for the Executive Summary (Sample User
 * 2026-06-30). The headline Resolution Rate only counts duplicate-cluster merges,
 * which made it look like barely anything was done when the team had also tagged
 * thousands of empty records and linked deals to accounts. This rolls up every
 * ACTION workstream so leadership sees the real total. Checks/monitoring tabs
 * (Deal Compliance, CS Lifecycle, Preflight) are NOT actions and are excluded.
 *
 * `total` is additive and NON-overlapping: duplicate resolved + dismissed +
 * Empty-Delete tagged + Account-Hints linked. `crossModuleHandled` is reported
 * separately (informational) — a cross-module overlap IS a duplicate cluster, so
 * its resolution is already inside `duplicatesResolved`; adding it would double-count.
 */
export async function getCleanupActionsSummary(): Promise<{
  duplicatesResolved: number;
  duplicatesDismissed: number;
  emptyDeleteTagged: number;
  accountHintsLinked: number;
  crossModuleHandled: number;
  total: number;
}> {
  // A real duplicate cluster has ≥2 records (mirror the headline gate).
  const MULTI = `(COALESCE(dc.total_leads,0)+COALESCE(dc.total_deals,0)+COALESCE(dc.total_contacts,0)+COALESCE(dc.total_accounts,0)) >= 2`;
  // ≥2 DISTINCT module types in the cluster = a cross-module overlap.
  const CROSS = `(( (dc.total_leads>0)::int + (dc.total_deals>0)::int + (dc.total_contacts>0)::int + (dc.total_accounts>0)::int ) >= 2)`;
  let duplicatesResolved = 0, duplicatesDismissed = 0, crossModuleHandled = 0;
  try {
    const r = await pool.query(`
      WITH resolved_act AS (
        SELECT DISTINCT cluster_id FROM duplicate_merge_actions
         WHERE action_type IN ('resolve','module_resolved')
      )
      SELECT
        COUNT(*) FILTER (WHERE (dc.status='resolved' OR ra.cluster_id IS NOT NULL)) AS resolved,
        COUNT(*) FILTER (WHERE dc.status='dismissed') AS dismissed,
        COUNT(*) FILTER (WHERE (dc.status='resolved' OR ra.cluster_id IS NOT NULL) AND ${CROSS}) AS cross_handled
      FROM duplicate_clusters dc
      LEFT JOIN resolved_act ra ON ra.cluster_id = dc.id
      WHERE ${MULTI}
    `);
    duplicatesResolved = parseInt(r.rows[0]?.resolved) || 0;
    duplicatesDismissed = parseInt(r.rows[0]?.dismissed) || 0;
    crossModuleHandled = parseInt(r.rows[0]?.cross_handled) || 0;
  } catch (e) {
    logger.warn("[getCleanupActionsSummary] duplicate counts failed (non-fatal)", e);
  }
  let emptyDeleteTagged = 0;
  try {
    const r = await pool.query(`SELECT COUNT(*)::int AS c FROM empty_delete_ledger`);
    emptyDeleteTagged = parseInt(r.rows[0]?.c) || 0;
  } catch (e) { /* table may not exist yet */ }
  let accountHintsLinked = 0;
  try {
    const r = await pool.query(`SELECT COUNT(*)::int AS c FROM account_inference_hints WHERE status='applied'`);
    accountHintsLinked = parseInt(r.rows[0]?.c) || 0;
  } catch (e) { /* table may not exist yet */ }
  const total = duplicatesResolved + duplicatesDismissed + emptyDeleteTagged + accountHintsLinked;
  return {
    duplicatesResolved,
    duplicatesDismissed,
    emptyDeleteTagged,
    accountHintsLinked,
    crossModuleHandled,
    total,
  };
}

// ─── Same-domain cluster duplicates (Sample User 2026-06-17) ────────────────
//
// Root cause: `duplicate_clusters.domain` is NOT covered by a UNIQUE
// constraint. Concurrent scans (or a deletion that happens between a
// SELECT and an INSERT in findOrCreateClusterByDomain) can both miss
// the existing row and BOTH insert one — producing two cluster rows
// with the EXACT same `domain` string. The operator finds the
// "duplicate-account-on-another-cluster" pattern when this happens.
//
// `findSameDomainClusterDuplicates()` finds every domain that has ≥2
// active clusters, groups the cluster rows together, and returns one
// row per group with enough detail for the operator to pick a master
// without opening every cluster modal.
//
// `mergeClustersIntoMaster()` is the structural counterpart: reparents
// every record from the source clusters to the target, captures a
// pre-merge snapshot per source (so the merge is undo-able), logs to
// duplicate_merge_actions, recomputes the target's stats, and deletes
// the now-empty source cluster rows. Idempotent within reason — a
// repeat call after success simply finds the source clusters empty and
// no-ops on them.

export interface SameDomainClusterGroup {
  domain: string;
  cluster_count: number;
  total_records: number;
  clusters: Array<{
    id: number;
    company_name: string | null;
    total_records: number;
    total_leads: number;
    total_deals: number;
    total_contacts: number;
    total_accounts: number;
    confidence_score: number;
    status: string;
    created_at: Date | null;
    has_account: boolean;
  }>;
}

/**
 * Find every domain that has ≥2 clusters with status='active' OR
 * status='resolved'. Sample User's view-time fix taught us to count
 * resolved clusters too — they still represent live CRMProvider records.
 * 'ignored' clusters (operator-dismissed false positives) are skipped
 * since merging them would resurrect a deliberate dismissal.
 *
 * Groups are sorted by total_records desc, then by domain asc, so the
 * biggest collisions surface first. Hard cap at 500 groups to keep
 * payloads bounded; the UI tells the operator when truncated.
 */
export async function findSameDomainClusterDuplicates(opts: {
  limit?: number;
  segment?: DuplicateFilters["segment"];
} = {}): Promise<{
  total_groups: number;
  truncated: boolean;
  groups: SameDomainClusterGroup[];
}> {
  const limit = Math.min(500, Math.max(1, opts.limit ?? 200));

  // Segment chip (Sample User 2026-07-15): only surface domains that have ≥1 cluster
  // holding a record on the chosen CRMProvider Layout — same predicate as every tab.
  // $1 = limit+1, so segment bind params start at $2.
  const cmParams: any[] = [limit + 1];
  let cmSegExists = "";
  const cmSeg = buildSegmentPredicate(opts.segment, 2);
  if (cmSeg.condition) {
    cmSegExists = `        AND EXISTS (
          SELECT 1 FROM duplicate_records r
           WHERE r.cluster_id = duplicate_clusters.id AND ${cmSeg.condition}
        )\n`;
    cmParams.push(...cmSeg.params);
  }

  // PASS 1 — pick the offending domains. Hits the existing
  // idx_duplicate_clusters_domain btree so it's cheap even on 20k rows.
  // Strip placeholder/quarantine buckets here so they never reach the
  // UI as "merge candidates" (they'd never be safe to merge anyway).
  const groupsQ = await pool.query<{
    domain: string;
    cluster_count: string;
    total_records: string;
  }>(
    `SELECT domain,
            COUNT(*)::text AS cluster_count,
            SUM(total_records)::text AS total_records
       FROM duplicate_clusters
      WHERE status = 'active'
        AND domain IS NOT NULL
        AND domain <> ''
        AND domain <> '${PLACEHOLDER_CLUSTER_DOMAIN}'
        AND NOT (total_deals = total_records AND total_records > 0)
        AND EXISTS (
          SELECT 1 FROM duplicate_records dr2
           WHERE dr2.cluster_id = duplicate_clusters.id AND dr2.cleanup_class IS NULL
        )
${cmSegExists}      GROUP BY domain
     HAVING COUNT(*) > 1
      ORDER BY SUM(total_records) DESC, domain ASC
      LIMIT $1`,
    cmParams,
  );

  const truncated = groupsQ.rows.length > limit;
  const domains = groupsQ.rows.slice(0, limit).map((r) => r.domain);
  if (domains.length === 0) {
    return { total_groups: 0, truncated: false, groups: [] };
  }

  // PASS 2 — fetch every cluster for those domains in one round-trip.
  const detailQ = await pool.query<{
    id: number;
    domain: string;
    company_name: string | null;
    total_records: number;
    total_leads: number;
    total_deals: number;
    total_contacts: number;
    total_accounts: number;
    confidence_score: number;
    status: string;
    created_at: Date | null;
  }>(
    `SELECT id, domain, company_name, total_records,
            total_leads, total_deals, total_contacts, total_accounts,
            confidence_score, status, created_at
       FROM duplicate_clusters
      WHERE domain = ANY($1::text[])
        AND status = 'active'
        AND NOT (total_deals = total_records AND total_records > 0)
        AND EXISTS (
          SELECT 1 FROM duplicate_records dr2
           WHERE dr2.cluster_id = duplicate_clusters.id AND dr2.cleanup_class IS NULL
        )
      ORDER BY domain ASC, total_records DESC, id ASC`,
    [domains],
  );

  const byDomain = new Map<string, SameDomainClusterGroup>();
  for (const head of groupsQ.rows.slice(0, limit)) {
    byDomain.set(head.domain, {
      domain: head.domain,
      cluster_count: Number(head.cluster_count),
      total_records: Number(head.total_records),
      clusters: [],
    });
  }
  for (const row of detailQ.rows) {
    const g = byDomain.get(row.domain);
    if (!g) continue;
    g.clusters.push({
      id: Number(row.id),
      company_name: row.company_name,
      total_records: Number(row.total_records),
      total_leads: Number(row.total_leads),
      total_deals: Number(row.total_deals),
      total_contacts: Number(row.total_contacts),
      total_accounts: Number(row.total_accounts),
      confidence_score: Number(row.confidence_score),
      status: row.status,
      created_at: row.created_at,
      has_account: Number(row.total_accounts) > 0,
    });
  }
  // Drop domain-groups whose clusters were INTENTIONALLY separated (Sample User
  // 2026-07-14). When an operator Split/Dismissed two clusters, their records
  // are logged in duplicate_separation_ledger as keep-apart pairs — re-suggesting
  // a merge is exactly the "already decided, don't resurface" false positive we
  // removed on Cross-Module. A group survives only if it still has at least ONE
  // pair of clusters that is NOT separated (a genuinely mergeable pair); a group
  // that collapses to a single mergeable cluster is dropped too.
  const allGroups = Array.from(byDomain.values());
  const allClusterIds = allGroups.flatMap((g) => g.clusters.map((c) => c.id));
  if (allClusterIds.length > 0) {
    try {
      const recQ = await pool.query<{
        cluster_id: number;
        CRMProvider_record_id: string;
      }>(
        `SELECT cluster_id, CRMProvider_record_id FROM duplicate_records
          WHERE cluster_id = ANY($1::int[])
            AND CRMProvider_record_id IS NOT NULL AND btrim(CRMProvider_record_id) <> ''`,
        [allClusterIds],
      );
      const clusterOfSample User = new Map<string, number>();
      for (const r of recQ.rows) {
        clusterOfSample User.set(String(r.CRMProvider_record_id), Number(r.cluster_id));
      }
      const sepQ = await pool.query<{
        CRMProvider_id_low: string;
        CRMProvider_id_high: string;
      }>(`SELECT CRMProvider_id_low, CRMProvider_id_high FROM duplicate_separation_ledger`);
      const separatedPairs = new Set<string>();
      for (const p of sepQ.rows) {
        const a = clusterOfSample User.get(String(p.CRMProvider_id_low));
        const b = clusterOfSample User.get(String(p.CRMProvider_id_high));
        if (a != null && b != null && a !== b) {
          separatedPairs.add(a < b ? `${a}|${b}` : `${b}|${a}`);
        }
      }
      if (separatedPairs.size > 0) {
        for (const g of allGroups) {
          const ids = g.clusters.map((c) => c.id);
          let hasMergeablePair = false;
          for (let i = 0; i < ids.length && !hasMergeablePair; i++) {
            for (let j = i + 1; j < ids.length; j++) {
              const key =
                ids[i] < ids[j] ? `${ids[i]}|${ids[j]}` : `${ids[j]}|${ids[i]}`;
              if (!separatedPairs.has(key)) {
                hasMergeablePair = true;
                break;
              }
            }
          }
          if (!hasMergeablePair) byDomain.delete(g.domain);
        }
      }
    } catch (e) {
      logger.warn(
        `[cluster-merge] separation-ledger filter skipped (non-fatal): ${e instanceof Error ? e.message : String(e)}`,
      );
    }
  }

  return {
    total_groups: byDomain.size,
    truncated,
    groups: Array.from(byDomain.values()),
  };
}

/**
 * Move every record from sourceClusterIds into targetClusterId,
 * snapshot each source pre-merge, log to duplicate_merge_actions, and
 * delete the now-empty source clusters. Transactional + idempotent.
 *
 * Safeguards:
 *   • target and source must all exist and be in status active/resolved
 *   • a source cannot equal the target
 *   • snapshots captured BEFORE the UPDATE so the merge is undo-able
 *   • final updateClusterStats run on the target so its rollups + owners
 *     reflect the merged record set.
 */
export async function mergeClustersIntoMaster(opts: {
  sourceClusterIds: number[];
  targetClusterId: number;
  performedBy: string;
  notes?: string;
}): Promise<{
  target_cluster_id: number;
  source_cluster_ids: number[];
  records_moved: number;
  source_clusters_deleted: number;
}> {
  const target = Number(opts.targetClusterId);
  const sources = Array.from(
    new Set(
      (opts.sourceClusterIds || [])
        .map((x) => Number(x))
        .filter((n) => Number.isFinite(n) && n > 0 && n !== target),
    ),
  );
  if (!Number.isFinite(target) || target <= 0) {
    throw new Error("mergeClustersIntoMaster: invalid targetClusterId");
  }
  if (sources.length === 0) {
    return {
      target_cluster_id: target,
      source_cluster_ids: [],
      records_moved: 0,
      source_clusters_deleted: 0,
    };
  }

  // Validate target exists + is mergeable
  const tgtQ = await pool.query(
    `SELECT id, status FROM duplicate_clusters WHERE id = $1`,
    [target],
  );
  if (tgtQ.rows.length === 0) {
    throw new Error(`mergeClustersIntoMaster: target cluster #${target} not found`);
  }
  if (!["active", "resolved"].includes(tgtQ.rows[0].status)) {
    throw new Error(
      `mergeClustersIntoMaster: target cluster #${target} is ${tgtQ.rows[0].status}, not active/resolved`,
    );
  }

  // Snapshot each source BEFORE the merge so undo is possible.
  for (const sid of sources) {
    await captureClusterSnapshot(sid, opts.performedBy, "pre_resolve", {
      notes: `Pre-merge snapshot — being merged into cluster #${target}.`,
    }).catch(() => { /* snapshot failure must not block the merge */ });
  }

  const client = await (pool as any).connect();
  let recordsMoved = 0;
  let deleted = 0;
  try {
    await client.query("BEGIN");

    // Move every record from each source to the target. Done one-by-one
    // so we can count rowCount per source for the audit log; sources
    // typically number ≤ a handful so this isn't a hot path.
    for (const sid of sources) {
      const moveQ = await client.query(
        `UPDATE duplicate_records
            SET cluster_id = $1, is_primary = false
          WHERE cluster_id = $2`,
        [target, sid],
      );
      recordsMoved += moveQ.rowCount ?? 0;
    }

    // Audit-log a single 'merge' row per source so the Manual Actions
    // tab + the Logs view show "who merged what into where".
    for (const sid of sources) {
      await client.query(
        `INSERT INTO duplicate_merge_actions
           (cluster_id, primary_record_id, merged_record_ids,
            action_type, performed_by, notes)
         VALUES ($1, NULL, '[]'::jsonb, $2, $3, $4)`,
        [
          sid,
          "cluster_merge",
          opts.performedBy,
          opts.notes ||
            `Merged source cluster #${sid} INTO master cluster #${target}.`,
        ],
      );
    }

    // Delete the now-empty source cluster rows.
    const delQ = await client.query(
      `DELETE FROM duplicate_clusters
        WHERE id = ANY($1::int[])
          AND NOT EXISTS (
            SELECT 1 FROM duplicate_records dr WHERE dr.cluster_id = duplicate_clusters.id
          )`,
      [sources],
    );
    deleted = delQ.rowCount ?? 0;

    await client.query("COMMIT");
  } catch (e) {
    try { await client.query("ROLLBACK"); } catch { /* ignore */ }
    throw e;
  } finally {
    client.release();
  }

  // Recompute the target's rollups + owners now that its record set has
  // grown. Best-effort: a stats failure must not roll back the merge.
  try {
    await updateClusterStats(target);
  } catch (e) {
    logger.warn("[DuplicateRadar] mergeClustersIntoMaster: updateClusterStats failed (non-fatal)", {
      error: e instanceof Error ? e.message : String(e),
    });
  }

  return {
    target_cluster_id: target,
    source_cluster_ids: sources,
    records_moved: recordsMoved,
    source_clusters_deleted: deleted,
  };
}

export async function getDuplicatesByOwner(): Promise<
  Array<{
    owner_name: string;
    owner_email: string;
    lead_count: number;
    deal_count: number;
    total_duplicates: number;
  }>
> {
  // 2026-06-17 — only count records whose cluster is still ACTIVE. Resolved
  // (merged) and ignored (dismissed) clusters are handled and must not keep
  // inflating an owner's outstanding-duplicate count on the Owner
  // Accountability tab.
  const result = await pool.query(`
    SELECT
      dr.owner_name,
      dr.owner_email,
      COUNT(*) FILTER (WHERE dr.record_type = 'lead') as lead_count,
      COUNT(*) FILTER (WHERE dr.record_type = 'deal') as deal_count,
      COUNT(*) as total_duplicates
    FROM duplicate_records dr
    JOIN duplicate_clusters dc ON dc.id = dr.cluster_id
    WHERE dr.owner_name IS NOT NULL
      AND dc.status = 'active'
    GROUP BY dr.owner_name, dr.owner_email
    ORDER BY total_duplicates DESC
  `);

  // Consolidate per OWNER_EMAIL_ALIASES so reps tagged on multiple mailboxes
  // (Rayan's three addresses, etc.) land in ONE row. Without this, AssistantPersona's
  // answers split a single rep into 3 — the dashboard already merges, but
  // every backend consumer needs the same treatment for parity.
  const { canonicaliseOwnerEmail } = await import("./ownerEmailAliases");
  const byCanonical = new Map<
    string,
    {
      owner_name: string;
      owner_email: string;
      lead_count: number;
      deal_count: number;
      total_duplicates: number;
    }
  >();
  for (const r of result.rows) {
    const rawEmail = String(r.owner_email || "");
    const canonical = canonicaliseOwnerEmail(rawEmail) || rawEmail.toLowerCase();
    const lead = parseInt(r.lead_count) || 0;
    const deal = parseInt(r.deal_count) || 0;
    const total = parseInt(r.total_duplicates) || 0;
    const existing = byCanonical.get(canonical);
    if (!existing) {
      byCanonical.set(canonical, {
        owner_name: r.owner_name,
        owner_email: canonical,
        lead_count: lead,
        deal_count: deal,
        total_duplicates: total,
      });
    } else {
      existing.lead_count += lead;
      existing.deal_count += deal;
      existing.total_duplicates += total;
    }
  }
  return Array.from(byCanonical.values()).sort(
    (a, b) => b.total_duplicates - a.total_duplicates,
  );
}

// CS Pipeline Overlap tab — active duplicate clusters that overlap a live CS
// customer, counted by verdict (block / review / warn). Powers AssistantPersona's
// cs-pipeline-overlap status answer.
export async function getCsOverlapVerdictCounts(): Promise<{
  block: number;
  review: number;
  warn: number;
  total: number;
}> {
  const r = await pool.query(
    `SELECT cs_overlap_verdict AS v, COUNT(*)::int AS n
       FROM duplicate_clusters
      WHERE cs_overlap_verdict IS NOT NULL
        AND status = 'active'
        AND total_records > 1
      GROUP BY cs_overlap_verdict`,
  );
  const out = { block: 0, review: 0, warn: 0, total: 0 };
  for (const row of r.rows) {
    const v = String(row.v || "").toLowerCase();
    if (v === "block") out.block = row.n;
    else if (v === "review") out.review = row.n;
    else if (v === "warn") out.warn = row.n;
    out.total += row.n;
  }
  return out;
}

export async function getDuplicatesBySource(): Promise<
  Array<{
    source: string;
    lead_count: number;
    deal_count: number;
    total: number;
  }>
> {
  // 2026-06-17 — "Duplicates by Source" was counting EVERY record (no cluster
  // join), so it showed ~90k for the whole CRM, not duplicates. And empty /
  // whitespace `source` values each became their own blank-labelled bar
  // because GROUP BY used the raw column while only NULL was coalesced.
  // Fixes: (a) count only records that belong to an ACTIVE duplicate cluster
  // (total_records > 1); (b) fold NULL/empty/whitespace into "Unknown" and
  // GROUP BY the same expression so there are no blank bars; (c) cap the long
  // tail into an "Other" bucket so the chart stays readable.
  const result = await pool.query(`
    SELECT
      COALESCE(NULLIF(TRIM(dr.source), ''), 'Unknown') AS source,
      COUNT(*) FILTER (WHERE dr.record_type = 'lead') AS lead_count,
      COUNT(*) FILTER (WHERE dr.record_type = 'deal') AS deal_count,
      COUNT(*) AS total
    FROM duplicate_records dr
    JOIN duplicate_clusters dc ON dr.cluster_id = dc.id
    WHERE dc.status = 'active' AND dc.total_records > 1
    GROUP BY COALESCE(NULLIF(TRIM(dr.source), ''), 'Unknown')
    ORDER BY total DESC
  `);
  const rows = result.rows.map((r) => ({
    source: r.source as string,
    lead_count: parseInt(r.lead_count) || 0,
    deal_count: parseInt(r.deal_count) || 0,
    total: parseInt(r.total) || 0,
  }));
  const TOP_N = 15;
  if (rows.length <= TOP_N) return rows;
  const top = rows.slice(0, TOP_N);
  const other = rows.slice(TOP_N).reduce(
    (acc, r) => ({
      source: "Other",
      lead_count: acc.lead_count + r.lead_count,
      deal_count: acc.deal_count + r.deal_count,
      total: acc.total + r.total,
    }),
    { source: "Other", lead_count: 0, deal_count: 0, total: 0 },
  );
  return [...top, other];
}

export async function updateClusterStatus(
  id: number,
  status: string,
): Promise<DuplicateCluster | null> {
  const result = await pool.query(
    "UPDATE duplicate_clusters SET status = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2 RETURNING *",
    [status, id],
  );
  return result.rows[0] || null;
}

export async function createDetectionLog(
  log: Omit<DuplicateDetectionLog, "id" | "created_at">,
): Promise<DuplicateDetectionLog> {
  const result = await pool.query(
    `INSERT INTO duplicate_detection_logs 
     (detection_type, total_records_scanned, total_clusters_found, total_duplicates_detected,
      high_confidence_count, medium_confidence_count, low_confidence_count,
      estimated_pipeline_inflation, detection_duration_ms, triggered_by, user_email, 
      status, error_message, detection_config, completed_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
     RETURNING *`,
    [
      log.detection_type,
      log.total_records_scanned,
      log.total_clusters_found,
      log.total_duplicates_detected,
      log.high_confidence_count,
      log.medium_confidence_count,
      log.low_confidence_count,
      log.estimated_pipeline_inflation,
      log.detection_duration_ms,
      log.triggered_by,
      log.user_email,
      log.status,
      log.error_message,
      JSON.stringify(log.detection_config || {}),
      log.completed_at,
    ],
  );
  return result.rows[0];
}

export async function updateDetectionLog(
  id: number,
  updates: Partial<DuplicateDetectionLog>,
): Promise<DuplicateDetectionLog | null> {
  const setClauses: string[] = [];
  const params: any[] = [];
  let paramIndex = 1;

  if (updates.status !== undefined) {
    setClauses.push(`status = $${paramIndex++}`);
    params.push(updates.status);
  }
  if (updates.total_clusters_found !== undefined) {
    setClauses.push(`total_clusters_found = $${paramIndex++}`);
    params.push(updates.total_clusters_found);
  }
  if (updates.total_duplicates_detected !== undefined) {
    setClauses.push(`total_duplicates_detected = $${paramIndex++}`);
    params.push(updates.total_duplicates_detected);
  }
  if (updates.completed_at !== undefined) {
    setClauses.push(`completed_at = $${paramIndex++}`);
    params.push(updates.completed_at);
  }
  if (updates.detection_duration_ms !== undefined) {
    setClauses.push(`detection_duration_ms = $${paramIndex++}`);
    params.push(updates.detection_duration_ms);
  }
  if (updates.error_message !== undefined) {
    setClauses.push(`error_message = $${paramIndex++}`);
    params.push(updates.error_message);
  }

  if (setClauses.length === 0) return null;

  params.push(id);
  const result = await pool.query(
    `UPDATE duplicate_detection_logs SET ${setClauses.join(", ")} WHERE id = $${paramIndex} RETURNING *`,
    params,
  );
  return result.rows[0] || null;
}

export async function getDetectionLogs(
  limit: number = 50,
): Promise<DuplicateDetectionLog[]> {
  const result = await pool.query(
    "SELECT * FROM duplicate_detection_logs ORDER BY created_at DESC LIMIT $1",
    [limit],
  );
  return result.rows;
}

export async function createExportLog(
  log: Omit<DuplicateExportLog, "id" | "created_at">,
): Promise<DuplicateExportLog> {
  const result = await pool.query(
    `INSERT INTO duplicate_export_logs 
     (export_type, filter_criteria, total_records_exported, file_format, exported_by, user_email)
     VALUES ($1, $2, $3, $4, $5, $6)
     RETURNING *`,
    [
      log.export_type,
      JSON.stringify(log.filter_criteria || {}),
      log.total_records_exported,
      log.file_format,
      log.exported_by,
      log.user_email,
    ],
  );
  return result.rows[0];
}

export async function clearMockData(): Promise<void> {
  await pool.query("DELETE FROM duplicate_records WHERE is_mock_data = true");
  await pool.query(`
    DELETE FROM duplicate_clusters 
    WHERE id NOT IN (SELECT DISTINCT cluster_id FROM duplicate_records WHERE cluster_id IS NOT NULL)
  `);
}

export async function getKPIMetrics(): Promise<{
  duplicateLeadRate: number;
  duplicateDealRate: number;
  domainsWithMultipleDeals: number;
  duplicateBySource: any[];
  duplicateByOwner: any[];
}> {
  const totalLeadsResult = await pool.query(`
    SELECT COUNT(*) as count FROM duplicate_records WHERE record_type = 'lead'
  `);
  const totalDealsResult = await pool.query(`
    SELECT COUNT(*) as count FROM duplicate_records WHERE record_type = 'deal'
  `);
  const duplicateLeadsResult = await pool.query(`
    SELECT COUNT(*) as count FROM duplicate_records dr
    JOIN duplicate_clusters dc ON dr.cluster_id = dc.id
    WHERE dr.record_type = 'lead' AND dc.total_leads > 1 AND dr.is_primary = false
      AND dc.status = 'active'
  `);
  const duplicateDealsResult = await pool.query(`
    SELECT COUNT(*) as count FROM duplicate_records dr
    JOIN duplicate_clusters dc ON dr.cluster_id = dc.id
    WHERE dr.record_type = 'deal' AND dc.total_deals > 1 AND dr.is_primary = false
      AND dc.status = 'active'
  `);
  const multiDealDomainsResult = await pool.query(`
    SELECT COUNT(*) as count FROM duplicate_clusters WHERE total_deals > 1 AND status = 'active'
  `);

  const totalLeads = parseInt(totalLeadsResult.rows[0].count) || 1;
  const totalDeals = parseInt(totalDealsResult.rows[0].count) || 1;
  const duplicateLeads = parseInt(duplicateLeadsResult.rows[0].count) || 0;
  const duplicateDeals = parseInt(duplicateDealsResult.rows[0].count) || 0;

  return {
    duplicateLeadRate: Math.round((duplicateLeads / totalLeads) * 100),
    duplicateDealRate: Math.round((duplicateDeals / totalDeals) * 100),
    domainsWithMultipleDeals:
      parseInt(multiDealDomainsResult.rows[0].count) || 0,
    duplicateBySource: await getDuplicatesBySource(),
    duplicateByOwner: await getDuplicatesByOwner(),
  };
}

export async function findOrCreateClusterByDomain(
  domain: string,
): Promise<DuplicateCluster> {
  const existing = await pool.query(
    "SELECT * FROM duplicate_clusters WHERE domain = $1",
    [domain],
  );

  if (existing.rows[0]) {
    return existing.rows[0];
  }

  return await createCluster({
    domain,
    total_leads: 0,
    total_deals: 0,
    total_contacts: 0,
    total_accounts: 0,
    total_records: 0,
    confidence_level: "medium",
    confidence_score: 75,
    status: "active",
  });
}

export async function updateClusterStats(clusterId: number): Promise<void> {
  const statsResult = await pool.query(
    `
    SELECT 
      COUNT(*) FILTER (WHERE record_type = 'lead') as lead_count,
      COUNT(*) FILTER (WHERE record_type = 'deal') as deal_count,
      COUNT(*) FILTER (WHERE record_type = 'contact') as contact_count,
      COUNT(*) FILTER (WHERE record_type = 'account') as account_count,
      COUNT(*) as total_count,
      COALESCE(SUM(deal_value), 0) as total_value,
      MIN(created_date) as first_date,
      MAX(COALESCE(modified_date, created_date)) as latest_date,
      ARRAY_AGG(DISTINCT owner_name) FILTER (WHERE owner_name IS NOT NULL) as owners
    FROM duplicate_records WHERE cluster_id = $1
  `,
    [clusterId],
  );

  const stats = statsResult.rows[0];
  const totalRecords = parseInt(stats.total_count) || 0;

  const records = await pool.query(
    "SELECT email, domain, phone, phone_normalized, company_name FROM duplicate_records WHERE cluster_id = $1 LIMIT 50",
    [clusterId],
  );

  let bestScore = 0;
  const allSignals = new Set<string>();
  const recs = records.rows;

  if (recs.length > 1) {
    for (let i = 0; i < Math.min(recs.length, 20); i++) {
      for (let j = i + 1; j < Math.min(recs.length, 20); j++) {
        const match = calculateMultiSignalScore(recs[i], recs[j]);
        if (match.score > bestScore) bestScore = match.score;
        match.signals.forEach((s) => allSignals.add(s));
      }
    }
  }

  // A cluster has 2+ records of the same type → classic same-module duplicate
  // (merge candidate). A cluster with multiple records but ≤1 per type is a
  // cross-module overlap (e.g. 1 Lead + 1 Account for the same company) — CRMProvider
  // does NOT support cross-module merges, so the action is CONVERT (lead →
  // contact under the existing account) or LINK (set Account_Name on the
  // deal/contact). Either way these are real cleanup work and must be surfaced
  // on the Cross-Module tab with a real confidence score, not buried at 0.
  // The Cross-Module Overlaps query (getCrossModuleOverlaps) already accepts
  // any cluster spanning 2+ record types regardless of score, so the only
  // thing the previous `confidenceScore = 0` did was sort these clusters to
  // the bottom and tag them as "legitimate_hierarchy" (a misleading label —
  // they need action, just not via merge).
  const leadCount = parseInt(stats.lead_count) || 0;
  const dealCount = parseInt(stats.deal_count) || 0;
  const contactCount = parseInt(stats.contact_count) || 0;
  const accountCount = parseInt(stats.account_count) || 0;
  const maxOfSameType = Math.max(
    leadCount,
    dealCount,
    contactCount,
    accountCount,
  );
  const isCrossModuleOnly = totalRecords > 1 && maxOfSameType <= 1;

  let confidenceScore: number;
  if (totalRecords <= 1) {
    confidenceScore = 0;
  } else if (bestScore > 0) {
    confidenceScore = bestScore;
  } else {
    confidenceScore = totalRecords > 3 ? 65 : 55;
  }
  if (isCrossModuleOnly) {
    // Tag for the Cross-Module tab + the cluster-detail modal verdict logic.
    // Keep the legacy signal too so any historic dashboard filter still works.
    allSignals.add("cross_module_link_candidate");
    allSignals.add("legitimate_hierarchy");
  }

  const inflationResult = await pool.query(
    `
    SELECT COALESCE(SUM(deal_value), 0) as inflation
    FROM duplicate_records
    WHERE cluster_id = $1 AND record_type = 'deal' AND is_primary = false AND deal_value > 0
      -- Only a genuine deal-duplicate cluster (2+ deals) inflates pipeline. A
      -- lone deal sharing a domain with an account is NOT a duplicate deal
      -- (Sample User 2026-07-29).
      AND (SELECT COUNT(*) FROM duplicate_records d2
             WHERE d2.cluster_id = $1 AND d2.record_type = 'deal') > 1
  `,
    [clusterId],
  );
  const pipelineInflation = parseFloat(inflationResult.rows[0]?.inflation) || 0;

  const primaryCheck = await pool.query(
    "SELECT COUNT(*) as cnt FROM duplicate_records WHERE cluster_id = $1 AND is_primary = true",
    [clusterId],
  );
  if (parseInt(primaryCheck.rows[0].cnt) === 0 && totalRecords > 0) {
    const earliest = await pool.query(
      "SELECT id FROM duplicate_records WHERE cluster_id = $1 ORDER BY created_date ASC NULLS LAST LIMIT 1",
      [clusterId],
    );
    if (earliest.rows[0]) {
      await pool.query(
        "UPDATE duplicate_records SET is_primary = true WHERE id = $1",
        [earliest.rows[0].id],
      );
    }
  }

  await pool.query(
    `
    UPDATE duplicate_clusters SET
      total_leads = $1,
      total_deals = $2,
      total_contacts = $3,
      total_accounts = $4,
      total_records = $5,
      estimated_pipeline_value = $6,
      first_record_date = $7,
      latest_activity_date = $8,
      owners_involved = $9,
      confidence_score = $10,
      confidence_level = $11,
      match_signals = $12,
      updated_at = CURRENT_TIMESTAMP
    WHERE id = $13
  `,
    [
      parseInt(stats.lead_count) || 0,
      parseInt(stats.deal_count) || 0,
      parseInt(stats.contact_count) || 0,
      parseInt(stats.account_count) || 0,
      totalRecords,
      pipelineInflation,
      stats.first_date,
      stats.latest_date,
      JSON.stringify(stats.owners || []),
      confidenceScore,
      confidenceScore === 0 ? "low" : getConfidenceLevel(confidenceScore),
      JSON.stringify(Array.from(allSignals)),
      clusterId,
    ],
  );
}

export interface DuplicateSearchParams {
  domain?: string;
  phone?: string;
  company_name?: string;
  contract_number?: string;
  email?: string;
  record_name?: string;
  owner_email?: string;
}

// A3: Fixed paramIndex bug for company_name
export async function searchDuplicates(params: DuplicateSearchParams): Promise<{
  records: DuplicateRecord[];
  clusters: DuplicateCluster[];
  total_records: number;
  search_params: DuplicateSearchParams;
}> {
  const conditions: string[] = [];
  const queryParams: any[] = [];
  let paramIndex = 1;

  if (params.domain?.trim()) {
    conditions.push(`LOWER(dr.domain) LIKE LOWER($${paramIndex++})`);
    queryParams.push(`%${params.domain.trim()}%`);
  }

  if (params.phone?.trim()) {
    conditions.push(
      `REGEXP_REPLACE(dr.phone, '[^0-9+]', '', 'g') LIKE $${paramIndex++}`,
    );
    queryParams.push(`%${params.phone.trim().replace(/[^0-9+]/g, "")}%`);
  }

  if (params.company_name?.trim()) {
    const pi = paramIndex++;
    conditions.push(
      `(LOWER(dr.company_name) LIKE LOWER($${pi}) OR LOWER(dc.company_name) LIKE LOWER($${pi}))`,
    );
    queryParams.push(`%${params.company_name.trim()}%`);
  }

  if (params.contract_number?.trim()) {
    conditions.push(`dr.CRMProvider_record_id LIKE $${paramIndex++}`);
    queryParams.push(`%${params.contract_number.trim()}%`);
  }

  if (params.email?.trim()) {
    conditions.push(`LOWER(dr.email) LIKE LOWER($${paramIndex++})`);
    queryParams.push(`%${params.email.trim()}%`);
  }

  if (params.record_name?.trim()) {
    conditions.push(`LOWER(dr.record_name) LIKE LOWER($${paramIndex++})`);
    queryParams.push(`%${params.record_name.trim()}%`);
  }

  if (params.owner_email?.trim()) {
    conditions.push(`LOWER(dr.owner_email) LIKE LOWER($${paramIndex++})`);
    queryParams.push(`%${params.owner_email.trim()}%`);
  }

  if (conditions.length === 0) {
    return {
      records: [],
      clusters: [],
      total_records: 0,
      search_params: params,
    };
  }

  const whereClause = conditions.join(" OR ");

  const recordsResult = await pool.query(
    `
    SELECT dr.*, dc.domain as cluster_domain, dc.confidence_level, dc.total_records as cluster_total
    FROM duplicate_records dr
    LEFT JOIN duplicate_clusters dc ON dr.cluster_id = dc.id
    WHERE ${whereClause}
    ORDER BY dr.confidence_score DESC, dr.created_at DESC
    LIMIT 200
  `,
    queryParams,
  );

  const clusterIds = [
    ...new Set(recordsResult.rows.map((r) => r.cluster_id).filter(Boolean)),
  ];

  let clustersData: DuplicateCluster[] = [];
  if (clusterIds.length > 0) {
    // 2026-06-17 — exclude already-handled clusters so dismissed
    // (status='ignored', e.g. an intentionally-separate Corporate vs
    // Marketplace account) and merged/resolved (status='resolved') clusters
    // never reappear in the Search "Related Clusters" cards. Only active,
    // still-actionable clusters surface here.
    const clustersResult = await pool.query(
      `
      SELECT * FROM duplicate_clusters
      WHERE id = ANY($1)
        AND status NOT IN ('ignored', 'resolved')
      ORDER BY total_records DESC
    `,
      [clusterIds],
    );
    clustersData = clustersResult.rows;
  }

  return {
    records: recordsResult.rows,
    clusters: clustersData,
    total_records: recordsResult.rows.length,
    search_params: params,
  };
}

// A1: Replaced destructive clear with incremental approach
//
// IMPORTANT: in incremental mode we deliberately do NOT call markStaleRecords()
// any more. The previous behaviour was unsafe: an incremental CRMProvider fetch only
// returns recently-modified records (or the most-recent N), so every untouched
// record would be marked stale and then purged by cleanupStaleRecords() —
// silently corrupting the radar over time. Records that were truly deleted in
// CRMProvider are now caught by the deletion-detection pass in the scan flow
// (fetchDeletedCRMProviderRecords + removeRecordsByCRMProviderIds).
export async function clearAllDuplicateData(): Promise<void> {
  const scanMode = process.env.DUPLICATE_SCAN_MODE || "incremental";
  if (scanMode === "full") {
    logger.info(
      "🗑️ [DuplicateRadar] FULL mode: Clearing all duplicate data for fresh CRMProvider import...",
    );
    await pool.query("DELETE FROM duplicate_records");
    await pool.query("DELETE FROM duplicate_clusters");
    logger.info("✅ [DuplicateRadar] All duplicate data cleared");
  } else {
    logger.info(
      "♻️ [DuplicateRadar] INCREMENTAL mode: relying on upserts + CRMProvider deletion detection (no stale-marking)",
    );
  }
}

// Purge records by their CRMProvider ID (used when CRMProvider reports them as deleted/merged).
// Returns the cluster IDs that lost records so the caller can re-score them.
export async function removeRecordsByCRMProviderIds(
  CRMProviderIds: string[],
  opts?: { module?: string },
): Promise<{ removedCount: number; affectedClusterIds: number[] }> {
  if (!CRMProviderIds || CRMProviderIds.length === 0) {
    return { removedCount: 0, affectedClusterIds: [] };
  }
  const params: any[] = [CRMProviderIds];
  let where = "CRMProvider_record_id = ANY($1::text[])";
  if (opts?.module) {
    params.push(opts.module);
    where += ` AND CRMProvider_module = $${params.length}`;
  }
  const affected = await pool.query(
    `SELECT DISTINCT cluster_id FROM duplicate_records WHERE ${where} AND cluster_id IS NOT NULL`,
    params,
  );
  const affectedClusterIds = affected.rows
    .map((r) => r.cluster_id)
    .filter((v): v is number => v != null);
  const del = await pool.query(
    `DELETE FROM duplicate_records WHERE ${where}`,
    params,
  );
  const removedCount = del.rowCount || 0;
  if (removedCount > 0) {
    logger.info(
      `🗑️ [DuplicateRadar] Removed ${removedCount} record(s) deleted/merged in CRMProvider` +
        (opts?.module ? ` (${opts.module})` : "") +
        ` — ${affectedClusterIds.length} cluster(s) affected`,
    );
  }
  return { removedCount, affectedClusterIds };
}

// A1: Mark records as stale before incremental scan
export async function markStaleRecords(): Promise<number> {
  const result = await pool.query(`
    UPDATE duplicate_records SET match_signals = match_signals || '["stale_pending"]'::jsonb
    WHERE is_mock_data = false AND NOT (match_signals @> '["stale_pending"]'::jsonb)
  `);
  logger.info(`📌 [DuplicateRadar] Marked ${result.rowCount} records as stale`);
  return result.rowCount || 0;
}

/**
 * Targeted version of markStaleRecords for a single CRMProvider record id. Used by
 * the agentic merge executor when CRMProvider responds 400 "the related id given
 * seems to be invalid" — that record is already gone from CRMProvider and our
 * local copy is a ghost; tagging stale_pending hands it to the existing
 * cleanupStaleRecords sweep so the next tick purges it. Returns true if a
 * row was actually flipped (false = no local match, or already stale).
 */
export async function markRecordStalePending(
  module: string,
  CRMProviderRecordId: string,
): Promise<boolean> {
  if (!CRMProviderRecordId) return false;
  const result = await pool.query(
    `UPDATE duplicate_records
        SET match_signals = match_signals || '["stale_pending"]'::jsonb
      WHERE CRMProvider_record_id = $1
        AND CRMProvider_module    = $2
        AND is_mock_data   = false
        AND NOT (match_signals @> '["stale_pending"]'::jsonb)`,
    [CRMProviderRecordId, module],
  );
  return (result.rowCount || 0) > 0;
}

/**
 * Mark specific duplicate_records rows (by primary-key id) stale_pending so the
 * cleanup sweep purges them. Used when a CRM re-check confirms a record was
 * deleted in CRMProvider (404) — e.g. the admin deleted a Duplicate-Delete duplicate,
 * so it should disappear from the (now-resolved) cluster, leaving the survivor.
 * Matches by id (not CRMProvider_module, which can be null on legacy rows).
 */
export async function markRecordsStalePendingByIds(
  ids: number[],
): Promise<number> {
  const clean = (ids || []).filter((n) => Number.isFinite(n));
  if (clean.length === 0) return 0;
  const result = await pool.query(
    `UPDATE duplicate_records
        SET match_signals = COALESCE(match_signals, '[]'::jsonb) || '["stale_pending"]'::jsonb
      WHERE id = ANY($1::int[])
        AND is_mock_data = false
        AND NOT (match_signals @> '["stale_pending"]'::jsonb)`,
    [clean],
  );
  return result.rowCount || 0;
}

/**
 * One-shot purge of singleton clusters — `duplicate_clusters` rows with
 * `status = 'active'` and `total_records ≤ 1`. These are residue from
 * the engine speculatively creating a cluster for every incoming record's
 * domain even when no second record ever joined; they're not duplicates,
 * they bloat the table (~78k extra rows in Sample User's env on 2026-06-15),
 * and they dilute COUNT() queries. Today's Executive Summary fix already
 * excludes them from every operator-facing number — this helper is the
 * underlying data hygiene pass.
 *
 * Safety rails:
 *  - `dryRun` defaults TRUE — caller must pass `false` explicitly to write.
 *  - Audit + a 20-row sample come back BEFORE the delete so the caller
 *    can sanity-check what's about to disappear.
 *  - Refuses if candidateCount > maxDelete (default 100,000). A
 *    sudden spike past that is almost certainly a bug, not a
 *    cleanup target.
 *  - duplicate_records rows whose cluster_id points at one of the
 *    targets get their cluster_id cleared FIRST (inside the same
 *    transaction) so a future incremental scan can re-cluster them
 *    cleanly. Without this they'd FK-orphan or be deleted by cascade,
 *    depending on the schema.
 *  - Everything runs inside BEGIN / COMMIT — partial failure rolls
 *    back the whole thing.
 *
 * Returns the full result so the caller can log + surface counts.
 */
export interface SingletonCleanupResult {
  dryRun: boolean;
  candidateCount: number;
  sampleRows: Array<{
    id: number;
    domain: string | null;
    company_name: string | null;
    total_records: number;
    created_at: string | null;
  }>;
  pointedAtByRecordsCount: number;
  refusedReason: "over-limit" | "no-candidates" | null;
  cleanedRecordCount: number;
  deletedClusterCount: number;
  durationMs: number;
}

export async function cleanupSingletonClusters(
  opts: { dryRun?: boolean; maxDelete?: number } = {},
): Promise<SingletonCleanupResult> {
  const t0 = Date.now();
  const dryRun = opts.dryRun !== false;
  const maxDelete = Math.max(1, opts.maxDelete ?? 100000);

  const countResult = await pool.query(
    `SELECT COUNT(*)::int AS n
       FROM duplicate_clusters
      WHERE status = 'active' AND total_records <= 1`,
  );
  const candidateCount = countResult.rows[0]?.n ?? 0;

  if (candidateCount === 0) {
    return {
      dryRun,
      candidateCount: 0,
      sampleRows: [],
      pointedAtByRecordsCount: 0,
      refusedReason: "no-candidates",
      cleanedRecordCount: 0,
      deletedClusterCount: 0,
      durationMs: Date.now() - t0,
    };
  }

  const sampleResult = await pool.query(
    `SELECT id, domain, company_name, total_records, created_at
       FROM duplicate_clusters
      WHERE status = 'active' AND total_records <= 1
      ORDER BY created_at DESC NULLS LAST
      LIMIT 20`,
  );
  const sampleRows = sampleResult.rows.map((r: any) => ({
    id: Number(r.id),
    domain: r.domain ?? null,
    company_name: r.company_name ?? null,
    total_records: Number(r.total_records) || 0,
    created_at: r.created_at ? new Date(r.created_at).toISOString() : null,
  }));

  const pointedResult = await pool.query(
    `SELECT COUNT(*)::int AS n
       FROM duplicate_records
      WHERE cluster_id IN (
        SELECT id FROM duplicate_clusters
         WHERE status = 'active' AND total_records <= 1
      )`,
  );
  const pointedAtByRecordsCount = pointedResult.rows[0]?.n ?? 0;

  if (candidateCount > maxDelete) {
    logger.warn(
      `🛑 [DuplicateRadar] cleanupSingletonClusters refused: ${candidateCount} candidates > maxDelete ${maxDelete}`,
    );
    return {
      dryRun,
      candidateCount,
      sampleRows,
      pointedAtByRecordsCount,
      refusedReason: "over-limit",
      cleanedRecordCount: 0,
      deletedClusterCount: 0,
      durationMs: Date.now() - t0,
    };
  }

  if (dryRun) {
    return {
      dryRun: true,
      candidateCount,
      sampleRows,
      pointedAtByRecordsCount,
      refusedReason: null,
      cleanedRecordCount: 0,
      deletedClusterCount: 0,
      durationMs: Date.now() - t0,
    };
  }

  const client = await pool.connect();
  let cleanedRecordCount = 0;
  let deletedClusterCount = 0;
  try {
    await client.query("BEGIN");
    const clearResult = await client.query(
      `UPDATE duplicate_records
          SET cluster_id = NULL
        WHERE cluster_id IN (
          SELECT id FROM duplicate_clusters
           WHERE status = 'active' AND total_records <= 1
        )`,
    );
    cleanedRecordCount = clearResult.rowCount || 0;
    const delResult = await client.query(
      `DELETE FROM duplicate_clusters
        WHERE status = 'active' AND total_records <= 1`,
    );
    deletedClusterCount = delResult.rowCount || 0;
    await client.query("COMMIT");
    logger.info(
      `🧹 [DuplicateRadar] cleanupSingletonClusters: deleted ${deletedClusterCount} clusters, cleared cluster_id on ${cleanedRecordCount} records`,
    );
  } catch (e) {
    await client.query("ROLLBACK").catch(() => {});
    throw e;
  } finally {
    client.release();
  }

  return {
    dryRun: false,
    candidateCount,
    sampleRows,
    pointedAtByRecordsCount,
    refusedReason: null,
    cleanedRecordCount,
    deletedClusterCount,
    durationMs: Date.now() - t0,
  };
}

// A1: Remove records that were stale and not refreshed
export async function cleanupStaleRecords(): Promise<number> {
  const result = await pool.query(`
    DELETE FROM duplicate_records 
    WHERE match_signals @> '["stale_pending"]'::jsonb AND is_mock_data = false
  `);
  logger.info(
    `🧹 [DuplicateRadar] Cleaned up ${result.rowCount} stale records`,
  );
  return result.rowCount || 0;
}

// A1: Remove orphan clusters with no records
export async function cleanupOrphanClusters(): Promise<number> {
  const result = await pool.query(`
    DELETE FROM duplicate_clusters 
    WHERE id NOT IN (SELECT DISTINCT cluster_id FROM duplicate_records WHERE cluster_id IS NOT NULL)
  `);
  logger.info(
    `🧹 [DuplicateRadar] Cleaned up ${result.rowCount} orphan clusters`,
  );
  return result.rowCount || 0;
}

export function normalizeCompanyName(name: string): string {
  if (!name) return "";
  let n = name
    .toLowerCase()
    .replace(/[^\w\s\u0600-\u06FF]/g, " ")
    .replace(/\s+/g, " ")
    .replace(
      /\b(llc|ltd|inc|corp|corporation|company|group|holdings?|holding|co|sa|ksa|uae|ae)\b/gi,
      " ",
    );

  const arabicBoilerplate = [
    "شركة",
    "الشركة",
    "مؤسسة",
    "المؤسسة",
    "مجموعة",
    "المجموعة",
    "محدودة",
    "المحدودة",
    "القابضة",
    "قابضة",
    "للتجارة",
    "التجارية",
    "التجاري",
    "للمقاولات",
    "المقاولات",
    "للاستثمار",
    "الاستثمارية",
    "للخدمات",
    "الخدمات",
    "العامة",
    "المتحدة",
    "ذ.م.م",
    "ذمم",
    "ش.م.م",
    "شمم",
    "ش.م.ك",
    "شمك",
  ];
  const boilerplateRe = new RegExp(
    "(^|\\s)(" +
      arabicBoilerplate.map((w) => w.replace(/\./g, "\\.")).join("|") +
      ")(?=\\s|$)",
    "g",
  );
  n = n.replace(boilerplateRe, " ");

  return n.replace(/\s+/g, " ").trim();
}

// Free-mail providers we never treat as a "corporate domain" for the
// purpose of the conflict guard below. Mirrors the list already used in
// `src/utils/CRMProviderCRM.ts`. Keep extending this if more providers appear.
const PUBLIC_EMAIL_DOMAINS = new Set<string>([
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>.uk",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
  "<REDACTED_HOST>",
]);

function isCorporateDomain(d: string | null | undefined): boolean {
  if (!d) return false;
  const norm = d.toLowerCase().trim();
  if (!norm) return false;
  return !PUBLIC_EMAIL_DOMAINS.has(norm);
}

// Placeholder / sentinel company names that CS users type into CRMProvider when the
// real company name is unknown. These should never form identity-bearing
// clusters — two unrelated records both named "N/A" are not duplicates of
// each other. Records with these names get routed to a single quarantine
// cluster so CS can fix the names at source rather than seeing the dashboard
// fan them out into bogus "duplicate" groups.
const PLACEHOLDER_COMPANY_NAMES = new Set<string>([
  // English
  "n/a", "na", "n.a", "n.a.",
  "unknown", "tbd", "tba", "pending",
  "test", "testing", "demo",
  "none", "null", "no name",
  "not provided", "not-provided", "notprovided",
  "not specified", "not available", "not applicable",
  "no company", "unknown company",
  "-", "--", "---", "0",
  // Arabic
  "لا يوجد", "لايوجد", "غير معروف", "غير محدد", "تجريبي",
  "لا شيء", "بدون اسم", "اختبار", "غير متوفر", "غير متاح",
  "لا يوجد حاليا", "لا يوجد حالياً", "غير موجود",
]);

// Lowercased array form for SQL `<> ALL(...)` filters (Domain Clusters hides
// placeholder-named clusters). Arabic is case-invariant, English entries are
// already lowercase, so LOWER(name) compares cleanly against this list.
const PLACEHOLDER_COMPANY_NAMES_LOWER_ARR: string[] = Array.from(
  PLACEHOLDER_COMPANY_NAMES,
).map((s) => s.toLowerCase());

const PLACEHOLDER_CLUSTER_DOMAIN = "_placeholder.cluster";

export function isPlaceholderName(
  name: string | null | undefined,
): boolean {
  if (!name) return true;
  const trimmed = name.trim();
  if (trimmed.length === 0) return true;
  const lower = trimmed.toLowerCase();
  if (PLACEHOLDER_COMPANY_NAMES.has(lower)) return true;
  if (PLACEHOLDER_COMPANY_NAMES.has(trimmed)) return true;
  return false;
}

/** The CRMProvider id of the (primary) Account record inside a matched cluster — used to
 * put a re-engagement Deal under the company we already have. Null if the cluster
 * has no account record. */
export async function getAccountCRMProviderIdByCluster(clusterId: number): Promise<string | null> {
  if (!Number.isFinite(clusterId)) return null;
  const r = await pool.query(
    `SELECT CRMProvider_record_id FROM duplicate_records
       WHERE cluster_id = $1 AND record_type = 'account'
         AND CRMProvider_record_id IS NOT NULL AND btrim(CRMProvider_record_id) <> ''
       ORDER BY is_primary DESC NULLS LAST, modified_date DESC NULLS LAST
       LIMIT 1`,
    [clusterId],
  );
  return r.rows[0]?.CRMProvider_record_id ? String(r.rows[0].CRMProvider_record_id) : null;
}

/** Resolve the CRMProvider id of an existing Account by domain (preferred) then by
 * exact normalized company name. Used by the Preflight Structured Push
 * "re-engage churned" action: churned clients are matched via the CS directory
 * (which sets no cluster_id in basic mode), so the existing Account must be
 * found the same way the match was — by domain / company name. Null if none. */
export async function getAccountCRMProviderIdByDomainOrName(
  domain: string | null | undefined,
  companyName: string | null | undefined,
): Promise<string | null> {
  const dom = String(domain || "").trim().toLowerCase();
  if (dom) {
    const r = await pool.query(
      `SELECT CRMProvider_record_id FROM duplicate_records
         WHERE record_type = 'account' AND LOWER(btrim(domain)) = $1
           AND CRMProvider_record_id IS NOT NULL AND btrim(CRMProvider_record_id) <> ''
         ORDER BY is_primary DESC NULLS LAST, modified_date DESC NULLS LAST
         LIMIT 1`,
      [dom],
    );
    if (r.rows[0]?.CRMProvider_record_id) return String(r.rows[0].CRMProvider_record_id);
  }
  const nm = String(companyName || "").trim().toLowerCase();
  if (nm && nm.length >= 3) {
    const r = await pool.query(
      `SELECT CRMProvider_record_id FROM duplicate_records
         WHERE record_type = 'account'
           AND LOWER(btrim(COALESCE(record_name, company_name, ''))) = $1
           AND CRMProvider_record_id IS NOT NULL AND btrim(CRMProvider_record_id) <> ''
         ORDER BY is_primary DESC NULLS LAST, modified_date DESC NULLS LAST
         LIMIT 1`,
      [nm],
    );
    if (r.rows[0]?.CRMProvider_record_id) return String(r.rows[0].CRMProvider_record_id);
  }
  return null;
}

/** Load the ENTIRE existing-account directory in ONE query, indexed by domain
 * and by normalized name, for bulk existing-account matching. The Preflight
 * push enriches ~900 rows at once; doing a per-row SQL lookup was ~900
 * sequential scans (it hung the UI). This loads once, then callers match in
 * memory. Best row per key wins (primary, then most-recently-modified). */
export async function getAccountDirectory(): Promise<{
  byDomain: Map<string, { CRMProviderId: string; name: string }>;
  byName: Map<string, { CRMProviderId: string; name: string }>;
  byId: Map<string, { CRMProviderId: string; name: string }>;
}> {
  const r = await pool.query(
    `SELECT CRMProvider_record_id,
            LOWER(btrim(domain)) AS dom,
            LOWER(btrim(COALESCE(record_name, company_name, ''))) AS nm,
            COALESCE(NULLIF(btrim(record_name), ''), NULLIF(btrim(company_name), ''), '') AS disp
       FROM duplicate_records
      WHERE record_type = 'account'
        AND CRMProvider_record_id IS NOT NULL AND btrim(CRMProvider_record_id) <> ''
      ORDER BY is_primary DESC NULLS LAST, modified_date DESC NULLS LAST`,
  );
  const byDomain = new Map<string, { CRMProviderId: string; name: string }>();
  const byName = new Map<string, { CRMProviderId: string; name: string }>();
  const byId = new Map<string, { CRMProviderId: string; name: string }>();
  for (const row of r.rows) {
    const ref = { CRMProviderId: String(row.CRMProvider_record_id), name: String(row.disp || "") };
    const dom = String(row.dom || "");
    const nm = String(row.nm || "");
    if (dom && !byDomain.has(dom)) byDomain.set(dom, ref);   // first = best (query is pre-ordered)
    if (nm && nm.length >= 3 && !byName.has(nm)) byName.set(nm, ref);
    if (!byId.has(ref.CRMProviderId)) byId.set(ref.CRMProviderId, ref);
  }
  return { byDomain, byName, byId };
}

/** Like getAccountCRMProviderIdByDomainOrName but returns the account's display NAME
 * alongside its CRMProvider id, so the Preflight push can show a human-readable
 * "links to <Account>" instead of a bare id. Same domain→name match order. */
export async function getAccountRefByDomainOrName(
  domain: string | null | undefined,
  companyName: string | null | undefined,
): Promise<{ CRMProviderId: string; name: string } | null> {
  const dom = String(domain || "").trim().toLowerCase();
  if (dom) {
    const r = await pool.query(
      `SELECT CRMProvider_record_id, COALESCE(NULLIF(btrim(record_name), ''), NULLIF(btrim(company_name), ''), '') AS name
         FROM duplicate_records
         WHERE record_type = 'account' AND LOWER(btrim(domain)) = $1
           AND CRMProvider_record_id IS NOT NULL AND btrim(CRMProvider_record_id) <> ''
         ORDER BY is_primary DESC NULLS LAST, modified_date DESC NULLS LAST
         LIMIT 1`,
      [dom],
    );
    if (r.rows[0]?.CRMProvider_record_id) return { CRMProviderId: String(r.rows[0].CRMProvider_record_id), name: String(r.rows[0].name || "") };
  }
  const nm = String(companyName || "").trim().toLowerCase();
  if (nm && nm.length >= 3) {
    const r = await pool.query(
      `SELECT CRMProvider_record_id, COALESCE(NULLIF(btrim(record_name), ''), NULLIF(btrim(company_name), ''), '') AS name
         FROM duplicate_records
         WHERE record_type = 'account'
           AND LOWER(btrim(COALESCE(record_name, company_name, ''))) = $1
           AND CRMProvider_record_id IS NOT NULL AND btrim(CRMProvider_record_id) <> ''
         ORDER BY is_primary DESC NULLS LAST, modified_date DESC NULLS LAST
         LIMIT 1`,
      [nm],
    );
    if (r.rows[0]?.CRMProvider_record_id) return { CRMProviderId: String(r.rows[0].CRMProvider_record_id), name: String(r.rows[0].name || "") };
  }
  return null;
}

/**
 * Returns true if `clusterId` already has at least one record whose
 * corporate domain differs from `candidateDomain`. Used as a guard so
 * that fuzzy / normalized-name matches do not fuse two unrelated
 * companies that happen to share a generic word ("Industrial Services",
 * "Trading", "Group" etc.).
 *
 * Public free-mail domains (gmail/yahoo/…) are ignored on both sides —
 * those cannot prove identity OR difference.
 */
async function clusterHasConflictingDomain(
  clusterId: number,
  candidateDomain: string,
): Promise<boolean> {
  if (!isCorporateDomain(candidateDomain)) return false;
  const candidate = candidateDomain.toLowerCase().trim();
  // Pull both the explicit domain column AND the email so we can derive
  // the corporate part of the email when Company_Domain is empty. Without
  // this, a cluster whose existing records have email-only identity
  // (CRMProvider Company_Domain blank) returns an empty conflict set and the
  // guard becomes a no-op.
  const res = await pool.query(
    `SELECT LOWER(domain) AS d, email
       FROM duplicate_records
      WHERE cluster_id = $1
        AND (
          (domain IS NOT NULL AND domain <> '')
          OR (email IS NOT NULL AND email <> '')
        )`,
    [clusterId],
  );
  const seen = new Set<string>();
  for (const row of res.rows) {
    const explicit = (row.d || "").trim();
    if (explicit && isCorporateDomain(explicit)) seen.add(explicit);
    const fromEmail = row.email ? extractDomain(row.email) : null;
    if (fromEmail && isCorporateDomain(fromEmail)) seen.add(fromEmail);
  }
  for (const d of seen) {
    if (d !== candidate) return true;
  }
  return false;
}

/**
 * One-shot cleanup: scan every existing Contacts cluster and retroactively
 * apply the ≥2-attribute strict rule. Contacts that fail the gate are split
 * into per-record stub clusters so the dashboard stops surfacing the
 * "7 SLB employees" false positives detected before the gate existed.
 *
 * Algorithm per cluster:
 *   1. Collect contact records (email, phone_normalized, lower record_name).
 *   2. Union-find: contacts A,B unite when they share ≥2 of the 3 keys.
 *   3. Whichever connected component is largest stays in the cluster.
 *   4. Every other component (and every singleton) gets split out via
 *      splitRecordsIntoNewClusterInTx — same code path as the manual
 *      split, so audit trail / primary-flag invariants are preserved.
 *
 * Returns per-cluster counts. dryRun=true returns the plan without writing.
 */
export async function bulkSplitContactClustersByStrictRule(opts: {
  dryRun?: boolean;
  performedBy: string;
  /** Hard cap on clusters processed in one call (default 500). */
  limit?: number;
}): Promise<{
  dryRun: boolean;
  clustersInspected: number;
  clustersSplit: number;
  recordsMoved: number;
  newClustersCreated: number;
  perCluster: Array<{
    cluster_id: number;
    contacts: number;
    components: number;
    largest_kept: number;
    split_out: number;
  }>;
}> {
  const dryRun = opts.dryRun !== false; // default safe: dry-run
  const limit = Math.max(1, Math.min(opts.limit || 500, 5000));

  // Source list: any cluster with ≥2 contacts. resolve()-d clusters are
  // skipped — historical merges already chose a survivor and we shouldn't
  // retroactively unpick that decision.
  const clusters = await pool.query(
    `SELECT dc.id, dc.company_name
       FROM duplicate_clusters dc
      WHERE dc.status = 'active'
        AND (
          SELECT COUNT(*) FROM duplicate_records dr
           WHERE dr.cluster_id = dc.id AND dr.record_type = 'contact'
        ) >= 2
      ORDER BY dc.id ASC
      LIMIT $1`,
    [limit],
  );

  const perCluster: Array<{
    cluster_id: number;
    contacts: number;
    components: number;
    largest_kept: number;
    split_out: number;
  }> = [];
  let clustersSplit = 0;
  let recordsMoved = 0;
  let newClustersCreated = 0;

  for (const cl of clusters.rows) {
    const recs = await pool.query(
      `SELECT id, email, phone_normalized, LOWER(record_name) AS lname, record_name
         FROM duplicate_records
        WHERE cluster_id = $1 AND record_type = 'contact'`,
      [cl.id],
    );
    const contacts = recs.rows;
    if (contacts.length < 2) continue;

    // Union-find — contacts A,B unite iff ≥2 of {email,phone,name} match.
    const parent = new Map<number, number>();
    const find = (x: number): number => {
      let r = x;
      while (parent.get(r) !== r) {
        const p = parent.get(r) as number;
        parent.set(r, parent.get(p) as number); // path compression
        r = parent.get(r) as number;
      }
      return r;
    };
    const union = (a: number, b: number) => {
      const ra = find(a),
        rb = find(b);
      if (ra !== rb) parent.set(ra, rb);
    };
    for (const c of contacts) parent.set(c.id, c.id);
    for (let i = 0; i < contacts.length; i++) {
      for (let j = i + 1; j < contacts.length; j++) {
        const a = contacts[i],
          b = contacts[j];
        let matches = 0;
        if (a.email && b.email && String(a.email).toLowerCase() === String(b.email).toLowerCase())
          matches++;
        if (a.phone_normalized && b.phone_normalized && a.phone_normalized === b.phone_normalized)
          matches++;
        if (a.lname && b.lname && a.lname === b.lname) matches++;
        if (matches >= 2) union(a.id, b.id);
      }
    }

    // Group by root → components
    const components = new Map<number, number[]>();
    for (const c of contacts) {
      const root = find(c.id);
      if (!components.has(root)) components.set(root, []);
      components.get(root)!.push(c.id);
    }
    const componentList = Array.from(components.values()).sort(
      (a, b) => b.length - a.length,
    );
    // If everything is one component, nothing to split — the cluster is
    // already consistent with the strict rule (everyone really IS a dup).
    if (componentList.length <= 1) {
      perCluster.push({
        cluster_id: cl.id,
        contacts: contacts.length,
        components: 1,
        largest_kept: contacts.length,
        split_out: 0,
      });
      continue;
    }

    // Largest component stays in cluster; rest get split. Use real names
    // for the new cluster seed so the audit trail is readable.
    const [, ...toSplit] = componentList;
    let splitCountForCluster = 0;
    for (const recordIds of toSplit) {
      const firstRow = contacts.find((r) => r.id === recordIds[0]);
      const seedName =
        firstRow?.record_name ||
        `Split from cluster ${cl.id} — ${recordIds.length} contact(s)`;
      if (!dryRun) {
        try {
          const split = await splitRecordsIntoNewCluster(cl.id, recordIds, {
            company_name: seedName,
          });
          // record audit-log via duplicate_merge_actions so the Logs tab
          // surfaces the cleanup — action_type='split' so it doesn't
          // count toward the "tagged for delete" set in getTaggedRecordDbIdsByCluster.
          await pool.query(
            `INSERT INTO duplicate_merge_actions
              (cluster_id, primary_record_id, merged_record_ids, action_type, performed_by, notes)
             VALUES ($1, $2, $3, $4, $5, $6)`,
            [
              split.new_cluster_id,
              recordIds[0],
              JSON.stringify(recordIds),
              "split",
              opts.performedBy,
              `Bulk-split: ≥2-attribute rule cleanup. Moved ${recordIds.length} contact(s) from cluster #${cl.id}.`,
            ],
          );
          recordsMoved += recordIds.length;
          newClustersCreated++;
          splitCountForCluster += recordIds.length;
        } catch (e) {
          // Skip clusters that fail (e.g. concurrent move) — keep going.
          logger.warn(
            `[bulk-split-contacts] cluster ${cl.id} split skipped: ${(e as Error).message}`,
          );
        }
      } else {
        // dry-run accounting
        recordsMoved += recordIds.length;
        newClustersCreated++;
        splitCountForCluster += recordIds.length;
      }
    }
    if (splitCountForCluster > 0) clustersSplit++;
    perCluster.push({
      cluster_id: cl.id,
      contacts: contacts.length,
      components: componentList.length,
      largest_kept: componentList[0].length,
      split_out: splitCountForCluster,
    });
  }

  return {
    dryRun,
    clustersInspected: clusters.rows.length,
    clustersSplit,
    recordsMoved,
    newClustersCreated,
    perCluster,
  };
}

/**
 * Strict-match path for Contact records: two contacts are duplicates of each
 * other ONLY when they share AT LEAST 2 of {email, normalized phone, lower
 * record_name}. Sharing only the parent company / domain is not enough —
 * seven different employees at "Schlumberger" are seven different people,
 * not seven duplicates. Returns the existing cluster on a strict match, or
 * `null` when no contact in any cluster meets the bar (the caller then
 * creates a fresh single-record cluster for this contact).
 *
 * Cheap by design — one indexed scan over duplicate_records filtered on
 * record_type='contact' + an OR over the three identity columns, then a
 * per-row tally in JS. Only candidates that have at least ONE matching
 * field come back, so the worst case is a few rows.
 */
export async function findContactClusterByStrictMatch(
  recordName: string | undefined,
  email: string | undefined,
  phone: string | undefined,
): Promise<DuplicateCluster | null> {
  const normalizedEmail = (email || "").trim().toLowerCase();
  const normalizedPhone = phone ? normalizePhone(phone) : "";
  // Compare on the trimmed lowercased full name. Two contacts sharing only
  // a last name ("Smith") would single-attribute match and still fall short
  // of the ≥2 gate, so this stays a strong-but-not-absolute signal.
  const normalizedName = (recordName || "").trim().toLowerCase();

  // Need at least one identity field to even bother with the lookup.
  if (!normalizedEmail && !normalizedPhone && !normalizedName) return null;

  const candidates = await pool.query(
    `SELECT cluster_id, email, phone_normalized, LOWER(record_name) AS lname
       FROM duplicate_records
      WHERE record_type = 'contact'
        AND (
          ($1 <> '' AND LOWER(email) = $1)
          OR ($2 <> '' AND phone_normalized = $2)
          OR ($3 <> '' AND LOWER(record_name) = $3)
        )
      LIMIT 200`,
    [normalizedEmail, normalizedPhone, normalizedName],
  );

  for (const row of candidates.rows) {
    let matches = 0;
    if (
      normalizedEmail &&
      row.email &&
      String(row.email).toLowerCase() === normalizedEmail
    )
      matches++;
    if (
      normalizedPhone &&
      row.phone_normalized &&
      row.phone_normalized === normalizedPhone
    )
      matches++;
    if (normalizedName && row.lname && row.lname === normalizedName) matches++;
    if (matches >= 2) {
      const cluster = await pool.query(
        "SELECT * FROM duplicate_clusters WHERE id = $1",
        [row.cluster_id],
      );
      if (cluster.rows[0]) return cluster.rows[0];
    }
  }
  return null;
}

// B4: Fuzzy match using pg_trgm similarity() with fallback
// ─── Separation ledger (Sample User 2026-06-20) ───────────────────────────────────
// Durable "not duplicates of each other" decisions from Split / Dismiss, so a
// later sync never re-fuses records the operator pulled apart.

function _sepPair(a: string, b: string): [string, string] {
  return a < b ? [a, b] : [b, a];
}

// Cache the set of CRMProvider ids that appear in ANY separation pair, so a full
// rebuild (50k+ records) does ONE lookup per sync instead of one per record:
// the vast majority of records aren't in the ledger, so we short-circuit
// getSeparatedCRMProviderIds() without a query. Invalidated on every write; TTL is a
// backstop. Refreshed lazily.
let _sepParticipants: Set<string> | null = null;
let _sepParticipantsAt = 0;
const SEP_PARTICIPANTS_TTL_MS = 60_000;

export async function getSeparationParticipants(): Promise<Set<string>> {
  const now = Date.now();
  if (_sepParticipants && now - _sepParticipantsAt < SEP_PARTICIPANTS_TTL_MS) {
    return _sepParticipants;
  }
  const r = await pool
    .query(
      `SELECT CRMProvider_id_low AS z FROM duplicate_separation_ledger
       UNION
       SELECT CRMProvider_id_high AS z FROM duplicate_separation_ledger`,
    )
    .catch(() => ({ rows: [] as any[] }));
  _sepParticipants = new Set((r.rows || []).map((x: any) => x.z).filter(Boolean));
  _sepParticipantsAt = now;
  return _sepParticipants;
}

/**
 * Record separations: every pair of CRMProvider ids that ended up in DIFFERENT groups
 * becomes a permanent "do not cluster together" entry. Pass each resulting
 * group as its own array (a Split passes [survivors, movedOut, ...]; a Dismiss
 * passes one singleton group per record so all pairs are separated). Idempotent.
 */
export async function recordSeparations(
  groups: string[][],
  reason: "split" | "dismiss",
  createdBy: string,
): Promise<number> {
  const clean = groups.map((g) =>
    (g || []).map((z) => (z || "").trim()).filter(Boolean),
  );
  const pairs: Array<[string, string]> = [];
  for (let i = 0; i < clean.length; i++) {
    for (let j = i + 1; j < clean.length; j++) {
      for (const a of clean[i]) {
        for (const b of clean[j]) {
          if (a !== b) pairs.push(_sepPair(a, b));
        }
      }
    }
  }
  if (pairs.length === 0) return 0;
  let written = 0;
  for (const [low, high] of pairs) {
    const r = await pool
      .query(
        `INSERT INTO duplicate_separation_ledger (CRMProvider_id_low, CRMProvider_id_high, reason, created_by)
         VALUES ($1, $2, $3, $4)
         ON CONFLICT (CRMProvider_id_low, CRMProvider_id_high) DO NOTHING`,
        [low, high, reason, createdBy],
      )
      .catch(() => ({ rowCount: 0 }));
    written += (r as any)?.rowCount || 0;
  }
  _sepParticipants = null; // invalidate the participant cache after a write
  return written;
}

/**
 * All separated pairs as a Set of "low|high" keys — so a grouping pass can
 * exclude a group the operator DISMISSED as "not duplicates" (its members were
 * recorded as mutually separated) in one in-memory lookup. Separation is rare,
 * so the set is small. Best-effort (missing table → empty set).
 */
export async function getSeparationPairKeySet(): Promise<Set<string>> {
  const out = new Set<string>();
  try {
    const r = await pool.query<{ CRMProvider_id_low: string; CRMProvider_id_high: string }>(
      `SELECT CRMProvider_id_low, CRMProvider_id_high FROM duplicate_separation_ledger`,
    );
    for (const row of r.rows) {
      if (row.CRMProvider_id_low && row.CRMProvider_id_high) {
        out.add(row.CRMProvider_id_low + "|" + row.CRMProvider_id_high);
      }
    }
  } catch {
    /* ledger absent/empty → nothing separated */
  }
  return out;
}

/** All CRMProvider ids this record has been separated from (empty for the 99% case). */
export async function getSeparatedCRMProviderIds(CRMProviderId?: string): Promise<string[]> {
  if (!CRMProviderId) return [];
  // Fast path: if this id isn't in any separation pair, skip the per-record
  // query entirely (the common case on a 50k-record sync).
  const participants = await getSeparationParticipants();
  if (!participants.has(CRMProviderId)) return [];
  const r = await pool
    .query(
      `SELECT CASE WHEN CRMProvider_id_low = $1 THEN CRMProvider_id_high ELSE CRMProvider_id_low END AS other
         FROM duplicate_separation_ledger
        WHERE CRMProvider_id_low = $1 OR CRMProvider_id_high = $1`,
      [CRMProviderId],
    )
    .catch(() => ({ rows: [] as any[] }));
  return (r.rows || []).map((x: any) => x.other).filter(Boolean);
}

async function clusterContainsAnyCRMProviderId(
  clusterId: number,
  CRMProviderIds: string[],
): Promise<boolean> {
  if (!CRMProviderIds.length) return false;
  const r = await pool
    .query(
      `SELECT 1 FROM duplicate_records
        WHERE cluster_id = $1 AND CRMProvider_record_id = ANY($2::text[]) LIMIT 1`,
      [clusterId, CRMProviderIds],
    )
    .catch(() => ({ rows: [] as any[] }));
  return (r.rows || []).length > 0;
}

export async function findOrCreateClusterByCompany(
  companyName: string,
  domain?: string,
  phone?: string,
  email?: string,
  // recordType + recordName are CONTACT-ONLY signals — when both are passed
  // and recordType === 'contact', the function delegates to the strict-match
  // path (≥2 of email/phone/name) instead of fusing on company / domain. For
  // every other module (Accounts / Leads / Deals) the legacy company-based
  // path is preserved verbatim — two records at the same company genuinely
  // are duplicates when the module is "Accounts".
  recordType?: "lead" | "deal" | "contact" | "account",
  recordName?: string,
  // The incoming record's CRMProvider id — when set, the separation ledger is honored
  // so a record the operator split/dismissed apart is never re-fused into a
  // cluster still holding a record it was separated from (Sample User 2026-06-20).
  CRMProviderRecordId?: string,
): Promise<DuplicateCluster> {
  // CONTACTS: bypass the company-name / domain branches and require ≥2
  // strict-match attributes (email / phone / name). Two contacts sharing
  // only "Schlumberger" are NOT duplicates — they're two different
  // employees. On no strict match, fall through to creating a fresh
  // single-record cluster (size 1 → invisible to the duplicates list).
  if (recordType === "contact") {
    const strict = await findContactClusterByStrictMatch(
      recordName,
      email,
      phone,
    );
    if (strict) return strict;
    // Build a per-contact stub cluster. Domain stays distinct so two stubs
    // never collide; the contact still gets a duplicate_records row so the
    // owner-accountability / coverage queries keep working.
    const stubDomain =
      `contact:${(email || phone || recordName || "anon").toLowerCase().replace(/\s+/g, "-")}.solo`;
    const existingStub = await pool.query(
      "SELECT * FROM duplicate_clusters WHERE domain = $1 LIMIT 1",
      [stubDomain],
    );
    if (existingStub.rows[0]) return existingStub.rows[0];
    return await createCluster({
      domain: stubDomain,
      company_name: recordName || companyName || "Single contact",
      total_leads: 0,
      total_deals: 0,
      total_contacts: 0,
      total_accounts: 0,
      total_records: 0,
      confidence_level: "low",
      confidence_score: 0,
      owners_involved: [],
      estimated_pipeline_value: 0,
      status: "active",
    });
  }

  const normalizedName = normalizeCompanyName(companyName);
  const normalizedPhone = phone ? normalizePhone(phone) : "";

  // Effective identity domain: prefer the explicit Company_Domain field, but
  // fall back to the corporate part of the email address. Without this fallback
  // a record whose CRMProvider Company_Domain is empty (but whose email is on a real
  // corporate domain) bypasses the conflict guard below and gets fused with
  // any same-named cluster — the root cause of mixed-cluster fan-outs on
  // generic Saudi/Arabic company names.
  const effectiveDomain = domain || (email ? extractDomain(email) : null);

  // Placeholder company names ("N/A", "لا يوجد", "TBD", …) are not identity
  // signals. Two records both named "N/A" are not duplicates of each other.
  // When we hit one, suppress the name-similarity branches entirely so the
  // record only fuses on real identity (domain / email / phone). If those
  // also fail, route the record to a single quarantine cluster instead of
  // creating one synthetic "n-a.cluster" per placeholder string.
  const placeholder = isPlaceholderName(companyName);

  // Durable separation guard. For records the operator split/dismissed apart,
  // skip any candidate cluster that still holds one of their separated records
  // and fall through to the next branch (ultimately a fresh cluster). Empty for
  // virtually every record → `notSeparatedFrom` is a no-op, zero added queries.
  const separatedIds = await getSeparatedCRMProviderIds(CRMProviderRecordId);
  // DIAGNOSTIC (Sample User 2026-06-26): when an operator reports a dismissed/split
  // cluster "coming back", this confirms whether the ledger guard is actually
  // firing for the re-synced record. Only logs for the rare separated record,
  // so it's quiet in normal operation. No behaviour change.
  if (separatedIds.length > 0) {
    logger.info(
      `[DuplicateRadar][sep-guard] record ${CRMProviderRecordId} (${recordType}, "${companyName}") is separated from ${separatedIds.length} id(s) — clusterer will refuse to re-fuse it`,
    );
  }
  const notSeparatedFrom = async (clu: any): Promise<boolean> =>
    separatedIds.length === 0
      ? true
      : !(await clusterContainsAnyCRMProviderId(clu.id, separatedIds));

  if (domain) {
    const existingByDomain = await pool.query(
      "SELECT * FROM duplicate_clusters WHERE domain = $1",
      [domain],
    );
    if (existingByDomain.rows[0] && (await notSeparatedFrom(existingByDomain.rows[0]))) {
      // Same domain on the cluster row itself → identity is proven, no
      // need to run the conflict guard.
      return existingByDomain.rows[0];
    }
  }

  if (email) {
    const existingByEmail = await pool.query(
      `SELECT dc.* FROM duplicate_clusters dc
       JOIN duplicate_records dr ON dr.cluster_id = dc.id
       WHERE LOWER(dr.email) = LOWER($1) LIMIT 1`,
      [email],
    );
    if (existingByEmail.rows[0] && (await notSeparatedFrom(existingByEmail.rows[0]))) {
      return existingByEmail.rows[0];
    }
  }

  if (normalizedPhone && normalizedPhone.length >= 7) {
    const existingByPhone = await pool.query(
      `SELECT dc.* FROM duplicate_clusters dc
       JOIN duplicate_records dr ON dr.cluster_id = dc.id
       WHERE dr.phone_normalized = $1 LIMIT 1`,
      [normalizedPhone],
    );
    if (existingByPhone.rows[0] && (await notSeparatedFrom(existingByPhone.rows[0]))) {
      return existingByPhone.rows[0];
    }
  }

  // Only use a substring ILIKE shortcut when the normalized name is distinctive
  // enough (>= 5 chars). Short fragments like "شركة" or "ltd" (after partial
  // strips) used to match unrelated rows.
  if (!placeholder && normalizedName && normalizedName.length >= 5) {
    const existingByCompany = await pool.query(
      `SELECT * FROM duplicate_clusters 
       WHERE company_name_normalized = $1`,
      [normalizedName],
    );
    if (existingByCompany.rows[0]) {
      const candidate = existingByCompany.rows[0];
      // Domain conflict guard — calibrated, not absolute. Two unrelated
      // companies sharing a SHORT generic normalized name (e.g. "industrial
      // services", "alkhalij", "saudi group") with different corporate
      // domains are a real false-positive risk and must stay separate.
      // But LONG name matches (≥10 chars normalized) on different corporate
      // domains are far more likely to be a real duplicate where one record
      // has a stale, secondary, or typo'd domain — fuse them and let the
      // reviewer split via the UI if it's actually wrong.
      const domainsConflict =
        !!effectiveDomain &&
        isCorporateDomain(effectiveDomain) &&
        (await clusterHasConflictingDomain(candidate.id, effectiveDomain));
      const nameIsGeneric = normalizedName.length < 10;
      if (domainsConflict && nameIsGeneric) {
        // fall through to fuzzy step / new-cluster creation below
      } else if (await notSeparatedFrom(candidate)) {
        return candidate;
      }
    }
  }

  // B4: Try pg_trgm similarity() first, fallback to limited Levenshtein.
  // Threshold raised to 0.6 — at 0.4, unrelated Arabic LLCs sharing only the
  // boilerplate "شركة ... المحدودة" were being clustered together.
  // Name-only fuse floor (Sample User 2026-07-13 "Shell + شركة العالمية fused —
  // no overlap"). When NO corporate domain corroborates the match, a mere
  // 0.6 trgm on boilerplate Arabic tokens (شركة / مؤسسة / المحدودة /
  // للخدمات / العالمية) fused genuinely different firms into one synthetic
  // cluster. Require a STRONG name match to fuse purely on the name; a
  // corporate domain still lets 0.6 through (the domain corroborates).
  // Env-tunable; 0.85 default. Only affects NEW clustering — existing
  // mixed clusters need a Rebuild (or per-cluster "Split by domain").
  const nameOnlyMinSim = parseFloat(
    process.env.DUPLICATE_RADAR_NAME_ONLY_MIN_SIM || "0.85",
  );
  const haveCorporateDomain = !!(
    effectiveDomain && isCorporateDomain(effectiveDomain)
  );
  if (!placeholder && normalizedName && normalizedName.length > 2) {
    try {
      // Pull the top few candidates so the domain guard can skip a bad
      // top hit (e.g. "alsuwaidi industrial services") and still pick a
      // legitimate sibling further down the list.
      // PERF (Sample User 2026-07-23 — "syncs stall for hours"): the `%` operator is
      // what makes this use the GIN trgm index (idx_clusters_company_trgm).
      // `similarity(col,$1) >= 0.6` ALONE is a FILTER — Postgres seq-scans EVERY
      // cluster computing similarity for EACH record, i.e. O(clusters × records)
      // — so a bulk upload (all-new records) or a rebuild took hours in the
      // per-record clusterer. `col % $1` pre-filters via the index; the `>= 0.6`
      // filter then keeps exactly the same rows.
      //
      // `%` uses the SESSION's pg_trgm.similarity_threshold, which other code
      // (preflight: set_limit 0.7 / 0.55) may have changed on a pooled
      // connection — a leftover 0.7 would make `%` MISS genuine 0.6–0.7 matches
      // and wrongly split clusters. So pin the threshold to 0.6 on the SAME
      // dedicated client that runs the query. Falls back (catch below) to the
      // Levenshtein scan if the client/trgm path errors.
      const _trgmClient = await pool.connect();
      let trgmResult: any;
      try {
        await _trgmClient.query(`SELECT set_limit(0.6)`);
        trgmResult = await _trgmClient.query(
          `SELECT *, similarity(company_name_normalized, $1) as sim
           FROM duplicate_clusters
           WHERE company_name_normalized IS NOT NULL AND company_name_normalized != ''
             AND company_name_normalized % $1
             AND similarity(company_name_normalized, $1) >= 0.6
           ORDER BY sim DESC LIMIT 5`,
          [normalizedName],
        );
      } finally {
        _trgmClient.release();
      }
      for (const candidate of trgmResult.rows) {
        if (!(candidate.sim >= 0.6)) continue;
        // Calibrated domain guard: skip the candidate only when both the
        // name-similarity is borderline (< 0.85) AND the domains conflict.
        // A very high trgm similarity (≥ 0.85) is strong enough evidence
        // to override the domain mismatch — typically a stale / secondary
        // / typo'd domain on one of the records.
        if (
          candidate.sim < 0.85 &&
          haveCorporateDomain &&
          (await clusterHasConflictingDomain(candidate.id, effectiveDomain))
        ) {
          continue; // try next-best candidate
        }
        // No corporate domain to corroborate → demand a strong name match.
        if (!haveCorporateDomain && candidate.sim < nameOnlyMinSim) {
          continue;
        }
        if (!(await notSeparatedFrom(candidate))) continue;
        return candidate;
      }
    } catch {
      const fallbackLimit = Math.max(
        1,
        Number.parseInt(
          process.env.DUPLICATE_RADAR_FALLBACK_SCAN_LIMIT ?? "2000",
          10,
        ) || 2000,
      );
      const recentClusters = await pool.query(
        "SELECT * FROM duplicate_clusters ORDER BY updated_at DESC LIMIT $1",
        [fallbackLimit],
      );
      for (const cluster of recentClusters.rows) {
        const clusterNormalized = normalizeCompanyName(
          cluster.company_name || "",
        );
        if (
          clusterNormalized &&
          normalizedName &&
          clusterNormalized.length > 2 &&
          normalizedName.length > 2
        ) {
          const similarity = calculateSimilarity(
            clusterNormalized,
            normalizedName,
          );
          if (similarity >= 85) {
            // Calibrated domain guard for the Levenshtein fallback path —
            // matches the trgm path: only skip when name similarity is in
            // the 85–94 borderline band AND domains conflict. ≥95
            // overrides the domain mismatch.
            if (
              similarity < 95 &&
              haveCorporateDomain &&
              (await clusterHasConflictingDomain(cluster.id, effectiveDomain))
            ) {
              continue;
            }
            // Mirror the trgm name-only floor (as a percentage): with no
            // corporate domain to corroborate, demand a strong name match.
            if (!haveCorporateDomain && similarity < nameOnlyMinSim * 100) {
              continue;
            }
            if (!(await notSeparatedFrom(cluster))) continue;
            return cluster;
          }
        }
      }
    }
  }

  // Placeholder-named record with no real identity → quarantine bucket.
  // Look up the existing quarantine cluster before creating a new one so
  // every subsequent placeholder record fuses there instead of fanning out.
  if (placeholder && !domain) {
    const existing = await pool.query(
      "SELECT * FROM duplicate_clusters WHERE domain = $1 LIMIT 1",
      [PLACEHOLDER_CLUSTER_DOMAIN],
    );
    if (existing.rows[0]) return existing.rows[0];
    return await createCluster({
      domain: PLACEHOLDER_CLUSTER_DOMAIN,
      company_name: "Example Organization",
      total_leads: 0,
      total_deals: 0,
      total_contacts: 0,
      total_accounts: 0,
      total_records: 0,
      confidence_level: "low",
      confidence_score: 0,
      status: "active",
    });
  }

  return await createCluster({
    domain: domain || normalizedName.replace(/\s+/g, "-") + ".cluster",
    company_name: companyName,
    total_leads: 0,
    total_deals: 0,
    total_contacts: 0,
    total_accounts: 0,
    total_records: 0,
    confidence_level: "low",
    confidence_score: 0,
    status: "active",
  });
}

export async function markPrimaryRecord(
  clusterId: number,
  recordId: number,
): Promise<boolean> {
  await pool.query(
    "UPDATE duplicate_records SET is_primary = false WHERE cluster_id = $1",
    [clusterId],
  );
  const result = await pool.query(
    "UPDATE duplicate_records SET is_primary = true WHERE id = $1 AND cluster_id = $2 RETURNING id",
    [recordId, clusterId],
  );
  return result.rows.length > 0;
}

/**
 * R10 — Freeze the current cluster + record state into duplicate_cluster_snapshots
 * so that future audit / dispute / forensic queries can see exactly what the
 * cluster looked like at the moment of an action.
 *
 * Best-effort by design: callers should wrap calls in try/catch but a thrown
 * snapshot error must NOT block the operator's primary action (resolve,
 * split, etc). Returns the new snapshot id on success or null on failure.
 *
 * Trigger labels currently in use:
 *   'pre_resolve' — before resolveCluster mutates status to resolved/ignored
 */
export async function captureClusterSnapshot(
  clusterId: number,
  takenBy: string,
  trigger: string,
  opts: { mergeActionId?: number | null; notes?: string | null } = {},
): Promise<number | null> {
  try {
    const clusterR = await pool.query(
      "SELECT * FROM duplicate_clusters WHERE id = $1",
      [clusterId],
    );
    if (clusterR.rows.length === 0) {
      logger.warn(
        `[duplicate-radar/snapshot] cluster ${clusterId} not found; skipping snapshot`,
      );
      return null;
    }
    const recordsR = await pool.query(
      "SELECT * FROM duplicate_records WHERE cluster_id = $1 ORDER BY is_primary DESC, id ASC",
      [clusterId],
    );
    const result = await pool.query<{ id: number }>(
      `INSERT INTO duplicate_cluster_snapshots
         (cluster_id, taken_by, trigger, merge_action_id,
          record_count, cluster_snapshot, records_snapshot, notes)
       VALUES ($1, $2, $3, $4, $5, $6::jsonb, $7::jsonb, $8)
       RETURNING id`,
      [
        clusterId,
        takenBy,
        trigger,
        opts.mergeActionId ?? null,
        recordsR.rows.length,
        JSON.stringify(clusterR.rows[0]),
        JSON.stringify(recordsR.rows),
        opts.notes ?? null,
      ],
    );
    return result.rows[0]?.id ?? null;
  } catch (err) {
    logger.warn(
      `[duplicate-radar/snapshot] failed to capture snapshot for cluster ${clusterId} (trigger=${trigger}): ${(err as Error).message}`,
    );
    return null;
  }
}

export interface ClusterSnapshotSummary {
  id: number;
  cluster_id: number | null;
  snapshot_at: Date;
  taken_by: string | null;
  trigger: string;
  merge_action_id: number | null;
  record_count: number;
  notes: string | null;
}

export interface ClusterSnapshotFull extends ClusterSnapshotSummary {
  cluster_snapshot: any;
  records_snapshot: any[];
}

export async function listClusterSnapshots(
  clusterId: number,
): Promise<ClusterSnapshotSummary[]> {
  const r = await pool.query<ClusterSnapshotSummary>(
    `SELECT id, cluster_id, snapshot_at, taken_by, trigger,
            merge_action_id, record_count, notes
       FROM duplicate_cluster_snapshots
      WHERE cluster_id = $1
      ORDER BY snapshot_at DESC`,
    [clusterId],
  );
  return r.rows;
}

export async function getClusterSnapshot(
  snapshotId: number,
): Promise<ClusterSnapshotFull | null> {
  const r = await pool.query(
    `SELECT id, cluster_id, snapshot_at, taken_by, trigger,
            merge_action_id, record_count, notes,
            cluster_snapshot, records_snapshot
       FROM duplicate_cluster_snapshots
      WHERE id = $1`,
    [snapshotId],
  );
  return (r.rows[0] as ClusterSnapshotFull) ?? null;
}

/**
 * Durable "solved" ledger write — keyed by STABLE CRMProvider identity (module +
 * survivor CRMProvider id), NOT by cluster_id. Survives a Rebuild Clusters wipe so the
 * per-module "solved" scoreboard does not collapse to 0 on every rescan.
 * Best-effort — never throws to the caller. No-op without a master CRMProvider id
 * (nothing stable to re-attribute after a rebuild).
 */
export async function recordResolutionLedgerEntry(params: {
  module: string;
  masterCRMProviderId: string | null | undefined;
  duplicateCRMProviderIds?: string[];
  actionType?: "resolve" | "module_resolved";
  performedBy?: string;
  notes?: string;
}): Promise<void> {
  const { module, masterCRMProviderId } = params;
  if (!module || !masterCRMProviderId) return;
  try {
    await pool.query(
      `INSERT INTO duplicate_resolution_ledger
         (module, master_CRMProvider_id, duplicate_CRMProvider_ids, action_type, performed_by, notes)
       VALUES ($1, $2, $3::jsonb, $4, $5, $6)
       ON CONFLICT (module, master_CRMProvider_id) WHERE master_CRMProvider_id IS NOT NULL
       DO UPDATE SET
         duplicate_CRMProvider_ids = EXCLUDED.duplicate_CRMProvider_ids,
         action_type = EXCLUDED.action_type,
         performed_by = EXCLUDED.performed_by,
         notes = EXCLUDED.notes,
         resolved_at = NOW()`,
      [
        module,
        masterCRMProviderId,
        JSON.stringify(params.duplicateCRMProviderIds || []),
        params.actionType || "resolve",
        params.performedBy || null,
        params.notes || null,
      ],
    );
  } catch (e) {
    logger.warn("[DuplicateRadar] resolution-ledger write failed (non-fatal)", {
      error: e instanceof Error ? e.message : String(e),
    });
  }
}

export async function resolveCluster(
  clusterId: number,
  action: "resolve" | "ignore",
  performedBy: string,
  primaryRecordId?: number,
  notes?: string,
): Promise<MergeAction | null> {
  // R10: freeze the cluster + records BEFORE any mutation, including the
  // markPrimaryRecord call below. If the operator changes the primary as
  // part of this resolve action, the forensic snapshot must reflect the
  // PRE-decision state ("here's what we had before they chose X as
  // primary") not the post-mutation state. Best-effort — a snapshot
  // failure must not block the operator's primary action.
  await captureClusterSnapshot(clusterId, performedBy, "pre_resolve", {
    notes:
      action === "resolve"
        ? "Pre-resolve snapshot taken when operator clicked Mark Resolved"
        : "Pre-ignore snapshot taken when operator clicked Ignore",
  });

  if (primaryRecordId) {
    await markPrimaryRecord(clusterId, primaryRecordId);
  }

  const nonPrimary = await pool.query(
    "SELECT id FROM duplicate_records WHERE cluster_id = $1 AND is_primary = false",
    [clusterId],
  );
  const mergedIds = nonPrimary.rows.map((r) => r.id);

  const result = await pool.query(
    `
    INSERT INTO duplicate_merge_actions (cluster_id, primary_record_id, merged_record_ids, action_type, performed_by, notes)
    VALUES ($1, $2, $3, $4, $5, $6) RETURNING *
  `,
    [
      clusterId,
      primaryRecordId || null,
      JSON.stringify(mergedIds),
      action,
      performedBy,
      notes || null,
    ],
  );

  const newStatus = action === "resolve" ? "resolved" : "ignored";
  // Clear the cached cs_overlap_verdict here too: it's only re-populated by the
  // next CS-overlap scan, and a resolved/ignored cluster must stop counting
  // toward CS-overlap totals/ARR immediately, not just be hidden by the list
  // query's `status = 'active'` filter. This UPDATE is reached only via the
  // resolve/ignore path (bulkResolve's "reopen" branch calls updateClusterStatus
  // instead), so reopen→active never runs through here and never gets nulled.
  await pool.query(
    "UPDATE duplicate_clusters SET status = $1, resolved_by = $2, resolved_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP, cs_overlap_verdict = NULL WHERE id = $3",
    [newStatus, performedBy, clusterId],
  );

  // Dismiss = "these are NOT duplicates of each other." Record every record in
  // the cluster as mutually separated so a future sync can't re-fuse them and
  // resurrect the dismissed cluster (Sample User 2026-06-20). Each record is its own
  // group → recordSeparations() separates all pairs.
  if (action === "ignore") {
    try {
      const zr = await pool.query(
        `SELECT CRMProvider_record_id FROM duplicate_records
          WHERE cluster_id = $1 AND CRMProvider_record_id IS NOT NULL`,
        [clusterId],
      );
      const groups = zr.rows.map((r) => [r.CRMProvider_record_id as string]);
      if (groups.length >= 2) {
        const n = await recordSeparations(groups, "dismiss", performedBy);
        logger.info(
          `[DuplicateRadar] Dismiss cluster ${clusterId}: recorded ${n} separation pair(s) so it won't re-cluster`,
        );
      }
    } catch (e) {
      logger.warn(
        `[DuplicateRadar] dismiss separation-ledger write skipped (non-fatal): ${e instanceof Error ? e.message : String(e)}`,
      );
    }
  }

  // Durable ledger write so this "Mark Resolved" survives a future Rebuild
  // Clusters wipe. Only 'resolve' counts as solved ('ignore' is a dismissal).
  // We key EACH present module to a record OF THAT MODULE (its primary if any,
  // else a representative) so the survivor's stable CRMProvider id re-attributes to
  // whatever cluster it lands in after a rescan. Best-effort.
  if (action === "resolve") {
    try {
      const recs = await pool.query(
        `SELECT id, record_type, CRMProvider_record_id, is_primary
           FROM duplicate_records WHERE cluster_id = $1`,
        [clusterId],
      );
      const rtToModule: Record<string, string> = {
        lead: "Leads",
        deal: "Deals",
        contact: "Contacts",
        account: "Accounts",
      };
      const modules = new Set<string>();
      for (const r of recs.rows) {
        const m = rtToModule[r.record_type as string];
        if (m) modules.add(m);
      }
      for (const m of modules) {
        const modRecs = recs.rows.filter(
          (r) => rtToModule[r.record_type as string] === m && r.CRMProvider_record_id,
        );
        if (modRecs.length === 0) continue;
        const modMaster =
          modRecs.find((r) => primaryRecordId && r.id === primaryRecordId) ||
          modRecs.find((r) => r.is_primary) ||
          modRecs[0];
        const modMasterCRMProvider = modMaster.CRMProvider_record_id as string;
        const dupCRMProviderIds = modRecs
          .filter((r) => r.CRMProvider_record_id && r.CRMProvider_record_id !== modMasterCRMProvider)
          .map((r) => r.CRMProvider_record_id as string);
        await recordResolutionLedgerEntry({
          module: m,
          masterCRMProviderId: modMasterCRMProvider,
          duplicateCRMProviderIds: dupCRMProviderIds,
          actionType: "resolve",
          performedBy,
          notes: notes || "Mark Resolved",
        });
      }
    } catch (e) {
      logger.warn(
        "[DuplicateRadar] ledger write on resolveCluster failed (non-fatal)",
        { error: e instanceof Error ? e.message : String(e) },
      );
    }
  }

  return result.rows[0] || null;
}

export async function bulkResolve(
  clusterIds: number[],
  action: "resolve" | "ignore" | "reopen",
  performedBy: string,
): Promise<number> {
  let count = 0;
  for (const id of clusterIds) {
    if (action === "reopen") {
      // Re-open = set the cluster back to 'active' (recover a mistaken dismiss /
      // resolve). No CRMProvider changes — same as the per-cluster Re-open.
      await updateClusterStatus(id, "active");
    } else {
      await resolveCluster(id, action, performedBy);
    }
    count++;
  }
  return count;
}

/**
 * R3 — Post-merge verification.
 *
 * After an operator marks a cluster resolved (asserting they merged the
 * duplicates in CRMProvider), check whether CRMProvider actually has the non-primary
 * records gone. We do per-record `searchCRMProviderRecords(module, id:equals:RID)`
 * lookups — returning 0 rows means the record no longer exists in CRMProvider
 * (it was merged, deleted, or moved).
 *
 * Returns a structured result. The caller decides what to do with it
 * (write back verification_state, flip status, notify operator).
 *
 * Why per-record search and not the /deleted feed: the deleted feed has
 * an indeterminate lag (CRMProvider documents "up to a few minutes") so it's
 * unreliable in the seconds immediately after a merge. A search-by-id
 * returns 204/empty within the same request as the operator's action.
 *
 * Concurrency: at most 4 records are checked in parallel to stay polite
 * with CRMProvider's rate limiter. Most clusters have 2–5 records so we don't
 * fan out further.
 */
export interface ClusterVerificationResult {
  verified: boolean;
  confirmed_deleted: number;
  still_present: number;
  errors: number;
  notes: string;
  per_record: Array<{
    record_id: number;
    CRMProvider_record_id: string | null;
    module: string;
    status: "deleted" | "still_present" | "error" | "skipped";
    detail?: string;
  }>;
}

export async function verifyClusterMergedInCRMProvider(
  clusterId: number,
): Promise<ClusterVerificationResult> {
  const { searchCRMProviderRecords } = await import("./CRMProviderCRM");

  const rowsR = await pool.query<{
    id: number;
    CRMProvider_record_id: string | null;
    CRMProvider_module: string | null;
    record_type: string | null;
    is_primary: boolean;
  }>(
    `SELECT id, CRMProvider_record_id, CRMProvider_module, record_type, is_primary
       FROM duplicate_records
      WHERE cluster_id = $1`,
    [clusterId],
  );

  // Only the non-primary records are expected to be gone in CRMProvider.
  const nonPrimary = rowsR.rows.filter((r) => !r.is_primary);

  if (nonPrimary.length === 0) {
    return {
      verified: true,
      confirmed_deleted: 0,
      still_present: 0,
      errors: 0,
      notes:
        "No non-primary records in this cluster; nothing to verify against CRMProvider.",
      per_record: [],
    };
  }

  // Map record_type → CRMProvider module name. Records carry CRMProvider_module directly
  // when ingested via the scanner; fall back to type-based mapping for
  // older rows that don't have it.
  const moduleFor = (
    r: (typeof nonPrimary)[number],
  ): string | null => {
    if (r.CRMProvider_module && r.CRMProvider_module.trim()) return r.CRMProvider_module.trim();
    const t = (r.record_type ?? "").trim().toLowerCase();
    if (t === "lead") return "Leads";
    if (t === "deal") return "Deals";
    if (t === "contact") return "Contacts";
    if (t === "account") return "Accounts";
    return null;
  };

  const concurrency = 4;
  const perRecord: ClusterVerificationResult["per_record"] = [];

  // Run lookups in batches to bound CRMProvider API pressure.
  for (let i = 0; i < nonPrimary.length; i += concurrency) {
    const batch = nonPrimary.slice(i, i + concurrency);
    const results = await Promise.all(
      batch.map(async (r) => {
        if (!r.CRMProvider_record_id) {
          return {
            record_id: r.id,
            CRMProvider_record_id: null,
            module: r.record_type ?? "unknown",
            status: "skipped" as const,
            detail: "Record has no CRMProvider_record_id (synthetic / pre-sync row)",
          };
        }
        const mod = moduleFor(r);
        if (!mod) {
          return {
            record_id: r.id,
            CRMProvider_record_id: r.CRMProvider_record_id,
            module: r.record_type ?? "unknown",
            status: "skipped" as const,
            detail: `Unknown CRMProvider module for record_type=${r.record_type}`,
          };
        }
        try {
          const found = await searchCRMProviderRecords(
            mod,
            `(id:equals:${r.CRMProvider_record_id})`,
          );
          if (!found || found.length === 0) {
            return {
              record_id: r.id,
              CRMProvider_record_id: r.CRMProvider_record_id,
              module: mod,
              status: "deleted" as const,
            };
          }
          return {
            record_id: r.id,
            CRMProvider_record_id: r.CRMProvider_record_id,
            module: mod,
            status: "still_present" as const,
            detail: `CRMProvider still has this ${mod.slice(0, -1)} record`,
          };
        } catch (err: any) {
          return {
            record_id: r.id,
            CRMProvider_record_id: r.CRMProvider_record_id,
            module: mod,
            status: "error" as const,
            detail: String(err?.message ?? err),
          };
        }
      }),
    );
    perRecord.push(...results);
  }

  const confirmed = perRecord.filter((p) => p.status === "deleted").length;
  const stillPresent = perRecord.filter(
    (p) => p.status === "still_present",
  ).length;
  const errors = perRecord.filter((p) => p.status === "error").length;
  const skipped = perRecord.filter((p) => p.status === "skipped").length;

  // "Verified" = every non-primary record we could check is gone, AND no
  // errors. Skipped records (no CRMProvider id) don't fail verification but they
  // do mean we couldn't fully confirm.
  const verified = stillPresent === 0 && errors === 0;
  const noteParts: string[] = [];
  if (confirmed > 0) noteParts.push(`${confirmed} confirmed deleted in CRMProvider`);
  if (stillPresent > 0)
    noteParts.push(`${stillPresent} still present in CRMProvider`);
  if (errors > 0) noteParts.push(`${errors} lookup error(s)`);
  if (skipped > 0) noteParts.push(`${skipped} skipped (no CRMProvider id)`);
  const notes =
    noteParts.length > 0 ? noteParts.join("; ") : "No records to verify.";

  const newState = verified ? "verified" : "failed";
  await pool.query(
    `UPDATE duplicate_clusters
        SET verification_state = $1,
            verification_at    = CURRENT_TIMESTAMP,
            verification_notes = $2,
            updated_at         = CURRENT_TIMESTAMP
      WHERE id = $3`,
    [newState, notes, clusterId],
  );

  return {
    verified,
    confirmed_deleted: confirmed,
    still_present: stillPresent,
    errors,
    notes,
    per_record: perRecord,
  };
}

export async function getMergeHistory(
  clusterId?: number,
  limit: number = 50,
): Promise<MergeAction[]> {
  let query = "SELECT * FROM duplicate_merge_actions";
  const params: any[] = [];
  if (clusterId) {
    query += " WHERE cluster_id = $1";
    params.push(clusterId);
  }
  query += " ORDER BY created_at DESC LIMIT $" + (params.length + 1);
  params.push(limit);
  const result = await pool.query(query, params);
  return result.rows;
}

/**
 * Enriched merge-history reader — joins duplicate_clusters to surface domain
 * + company_name + status alongside each action row. Powers the Logs tab UI
 * (a new "Manual Actions" sub-section) and AssistantPersona's manualActionAuditTool so
 * neither has to make a second hop per row.
 *
 * Filters:
 *   - clusterId      : single cluster
 *   - actionTypes    : narrow to one or more of resolve / ignore /
 *                      module_resolved / split / merge
 *   - performedByLike: substring match on the performed_by field
 *                      (e.g. "GRQ Assistant" to find agent actions, or an
 *                       operator's email)
 * Sorted by created_at DESC, capped at 500.
 */
export async function getMergeHistoryEnriched(opts: {
  clusterId?: number;
  actionTypes?: Array<MergeAction["action_type"]>;
  performedByLike?: string;
  limit?: number;
} = {}): Promise<MergeActionEnriched[]> {
  const lim = Math.max(1, Math.min(opts.limit ?? 100, 500));
  const where: string[] = [];
  const params: any[] = [];
  if (typeof opts.clusterId === "number") {
    params.push(opts.clusterId);
    where.push(`ma.cluster_id = $${params.length}`);
  }
  if (opts.actionTypes && opts.actionTypes.length > 0) {
    params.push(opts.actionTypes);
    where.push(`ma.action_type = ANY($${params.length}::text[])`);
  }
  if (opts.performedByLike && opts.performedByLike.trim()) {
    params.push(`%${opts.performedByLike.trim()}%`);
    where.push(`ma.performed_by ILIKE $${params.length}`);
  }
  const whereClause = where.length ? `WHERE ${where.join(" AND ")}` : "";
  params.push(lim);
  const limitParam = `$${params.length}`;
  const result = await pool.query(
    `SELECT ma.id, ma.cluster_id, ma.primary_record_id, ma.merged_record_ids,
            ma.action_type, ma.performed_by, ma.notes, ma.created_at,
            dc.domain        AS cluster_domain,
            dc.company_name  AS cluster_company_name,
            dc.status        AS cluster_status
       FROM duplicate_merge_actions ma
       LEFT JOIN duplicate_clusters dc ON dc.id = ma.cluster_id
       ${whereClause}
      ORDER BY ma.created_at DESC
      LIMIT ${limitParam}`,
    params,
  );
  return result.rows as MergeActionEnriched[];
}

/**
 * Append a merge_action row WITHOUT closing the cluster. Used for cross-module
 * clusters when a single-module Apply (e.g. Accounts) finishes — the merged
 * Accounts are tagged Duplicate-Delete in CRMProvider but the cluster stays open so
 * the operator can still resolve its Contacts/Deals/Leads. Without this log
 * row there is no record of which Accounts were already merged, so the next
 * Contact merge plan would surface the deleted SLB / Slb duplicates as link
 * targets in LINK SURVIVOR TO ACCOUNT.
 */
export async function recordPartialMergeAction(
  clusterId: number,
  primaryRecordId: number | null,
  mergedRecordIds: number[],
  performedBy: string,
  notes?: string,
): Promise<MergeAction | null> {
  const result = await pool.query(
    `INSERT INTO duplicate_merge_actions
       (cluster_id, primary_record_id, merged_record_ids, action_type, performed_by, notes)
     VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
    [
      clusterId,
      primaryRecordId,
      JSON.stringify(mergedRecordIds || []),
      "module_resolved",
      performedBy,
      notes || null,
    ],
  );
  return result.rows[0] || null;
}

/**
 * Union of merged_record_ids (db ids) across every merge_action recorded on
 * the cluster — closing 'resolve' actions PLUS partial 'module_resolved'
 * actions. The merge planner uses this to drop already-tagged Accounts from
 * LINK SURVIVOR TO ACCOUNT in subsequent module Apply runs.
 */
export async function getTaggedRecordDbIdsByCluster(
  clusterId: number,
): Promise<number[]> {
  const result = await pool.query(
    `SELECT merged_record_ids FROM duplicate_merge_actions
       WHERE cluster_id = $1
         AND action_type IN ('resolve', 'module_resolved', 'auto_merge_pending')`,
    [clusterId],
  );
  const out = new Set<number>();
  for (const row of result.rows) {
    const raw = row.merged_record_ids;
    // JSONB column — node-postgres parses to JS, but accept stringified as a
    // belt-and-braces guard against schema drift / migration scripts.
    let arr: unknown = raw;
    if (typeof raw === "string") {
      try {
        arr = JSON.parse(raw);
      } catch {
        arr = [];
      }
    }
    if (Array.isArray(arr)) {
      for (const v of arr) {
        const n = typeof v === "number" ? v : parseInt(String(v), 10);
        if (Number.isFinite(n)) out.add(n);
      }
    }
  }
  return Array.from(out);
}

// C3: Enhanced owner accountability with RAG status against 2% KPI target.
// dc.status = 'active' is REQUIRED for parity with the packet route — without
// it, owners whose only clusters are archived/dismissed appear in the table
// with a Packet link but get an empty Action Items sheet (Cover still shows
// the stale duplicate counts). See pre-publish review MAJOR-1.
export async function getOwnerAccountability(): Promise<OwnerAccountability[]> {
  const result = await pool.query(`
    SELECT
      dr.owner_name,
      dr.owner_email,
      COUNT(*) as total_records,
      COUNT(*) FILTER (WHERE dc.total_records > 1 AND dr.is_primary = false) as duplicate_records,
      COUNT(DISTINCT dr.cluster_id) FILTER (WHERE dc.total_records > 1) as clusters_involved,
      COUNT(*) FILTER (WHERE dc.total_records > 1 AND dc.confidence_level = 'high' AND dr.is_primary = false) as high_confidence_duplicates,
      COALESCE(SUM(dr.deal_value) FILTER (WHERE dc.total_records > 1 AND dr.is_primary = false AND dr.record_type = 'deal'), 0) as estimated_waste_value
    FROM duplicate_records dr
    JOIN duplicate_clusters dc ON dr.cluster_id = dc.id
    WHERE dr.owner_name IS NOT NULL
      AND dr.owner_name != 'Unknown'
      AND dc.status = 'active'
    GROUP BY dr.owner_name, dr.owner_email
    HAVING COUNT(*) FILTER (WHERE dc.total_records > 1 AND dr.is_primary = false) > 0
    ORDER BY duplicate_records DESC
  `);

  // Resolve owner → team via the SEED_USERS roster so the UI can render a
  // role badge without an extra round-trip. Lazy-imported to avoid pulling
  // the static seed list into modules that don't touch the owner scorecard.
  const { findSeedUser } = await import("../data/seedUsers");
  const { canonicaliseOwnerEmail } = await import("./ownerEmailAliases");

  // Aggregate by CANONICAL email so a single rep tagged on multiple
  // mailboxes (e.g. Rayan's three addresses) lands in ONE row, not three.
  // The map preserves insertion order so the SQL's ORDER BY (highest dup
  // count first) survives the consolidation.
  type Accum = {
    owner_name: string;
    owner_email: string;
    alias_emails: Set<string>;
    total_records: number;
    duplicate_records: number;
    clusters_involved: number;
    high_confidence_duplicates: number;
    estimated_waste_value: number;
  };
  const byCanonical = new Map<string, Accum>();
  for (const r of result.rows) {
    const rawEmail = String(r.owner_email || "");
    const canonical = canonicaliseOwnerEmail(rawEmail) || rawEmail.toLowerCase();
    const totalRecs = parseInt(r.total_records) || 0;
    const dupRecs = parseInt(r.duplicate_records) || 0;
    const clusters = parseInt(r.clusters_involved) || 0;
    const highConf = parseInt(r.high_confidence_duplicates) || 0;
    const waste = parseFloat(r.estimated_waste_value) || 0;
    const existing = byCanonical.get(canonical);
    if (!existing) {
      byCanonical.set(canonical, {
        owner_name: r.owner_name,
        owner_email: canonical,
        alias_emails: new Set(rawEmail ? [rawEmail.toLowerCase()] : []),
        total_records: totalRecs,
        duplicate_records: dupRecs,
        clusters_involved: clusters,
        high_confidence_duplicates: highConf,
        estimated_waste_value: waste,
      });
    } else {
      existing.total_records += totalRecs;
      existing.duplicate_records += dupRecs;
      existing.clusters_involved += clusters;
      existing.high_confidence_duplicates += highConf;
      existing.estimated_waste_value += waste;
      if (rawEmail) existing.alias_emails.add(rawEmail.toLowerCase());
    }
  }

  return Array.from(byCanonical.values()).map((a) => {
    const dupRate =
      a.total_records > 0
        ? Math.round((a.duplicate_records / a.total_records) * 1000) / 10
        : 0;
    // RAG bands (SDR-KPI-09): ≤2% green · 2–5% amber · >5% red. Matches
    // the dashboard's post-merge re-derive — single source of truth.
    let ragStatus: "green" | "amber" | "red" = "green";
    if (dupRate > 5) ragStatus = "red";
    else if (dupRate > 2) ragStatus = "amber";

    const seed = findSeedUser(a.owner_name);
    const team = (seed && seed.team) || "Unassigned";

    return {
      owner_name: a.owner_name,
      owner_email: a.owner_email,
      team,
      total_records: a.total_records,
      duplicate_records: a.duplicate_records,
      duplicate_rate: dupRate,
      clusters_involved: a.clusters_involved,
      high_confidence_duplicates: a.high_confidence_duplicates,
      estimated_waste_value: a.estimated_waste_value,
      rag_status: ragStatus,
    };
  });
}

export async function checkForDuplicates(params: {
  email?: string;
  phone?: string;
  company_name?: string;
}): Promise<{
  is_duplicate: boolean;
  confidence: number;
  signals: string[];
  matching_clusters: DuplicateCluster[];
  matching_records: DuplicateRecord[];
}> {
  const domain = params.email ? extractDomain(params.email) : null;
  const normalizedPhone = params.phone ? normalizePhone(params.phone) : "";
  const conditions: string[] = [];
  const queryParams: any[] = [];
  let idx = 1;

  if (params.email) {
    conditions.push(`LOWER(dr.email) = LOWER($${idx++})`);
    queryParams.push(params.email);
  }
  if (domain) {
    conditions.push(`dr.domain = $${idx++}`);
    queryParams.push(domain);
  }
  if (normalizedPhone && normalizedPhone.length >= 7) {
    conditions.push(`dr.phone_normalized = $${idx++}`);
    queryParams.push(normalizedPhone);
  }
  if (params.company_name) {
    conditions.push(`LOWER(dr.company_name) ILIKE LOWER($${idx++})`);
    queryParams.push(`%${params.company_name}%`);
  }

  if (conditions.length === 0) {
    return {
      is_duplicate: false,
      confidence: 0,
      signals: [],
      matching_clusters: [],
      matching_records: [],
    };
  }

  const result = await pool.query(
    `
    SELECT dr.*, dc.confidence_level, dc.confidence_score as cluster_confidence, dc.total_records as cluster_total
    FROM duplicate_records dr
    JOIN duplicate_clusters dc ON dr.cluster_id = dc.id
    WHERE dc.status = 'active' AND (${conditions.join(" OR ")})
    ORDER BY dr.confidence_score DESC
    LIMIT 20
  `,
    queryParams,
  );

  if (result.rows.length === 0) {
    return {
      is_duplicate: false,
      confidence: 0,
      signals: [],
      matching_clusters: [],
      matching_records: [],
    };
  }

  const matchSignals: string[] = [];
  let bestScore = 0;
  for (const row of result.rows) {
    const match = calculateMultiSignalScore(
      {
        email: params.email,
        domain: domain || undefined,
        phone: params.phone,
        company_name: params.company_name,
      },
      {
        email: row.email,
        domain: row.domain,
        phone: row.phone,
        company_name: row.company_name,
      },
    );
    if (match.score > bestScore) bestScore = match.score;
    match.signals.forEach((s) => {
      if (!matchSignals.includes(s)) matchSignals.push(s);
    });
  }

  const clusterIds = [...new Set(result.rows.map((r) => r.cluster_id))];
  const clustersResult = await pool.query(
    "SELECT * FROM duplicate_clusters WHERE id = ANY($1)",
    [clusterIds],
  );

  return {
    is_duplicate: bestScore >= 50,
    confidence: bestScore,
    signals: matchSignals,
    matching_clusters: clustersResult.rows,
    matching_records: result.rows,
  };
}

// A2: Fixed low_confidence count — only clusters with total_records > 1, added singletonCount
/**
 * R4 — Duplicate creation-rate trend.
 *
 * Industry-standard leading indicator: count NEW DUPLICATE records created
 * per bucket (week or day) — "are bad-data inputs still flowing into CRMProvider
 * at the same rate, or is prevention work moving the needle?" Stakeholders
 * care about the slope, not the absolute count.
 *
 * Definition of "new duplicate":
 *   - A record (lead / deal / contact / account) whose created_date falls
 *     in the bucket AND whose cluster has total_records > 1 (so the record
 *     is actually a duplicate, not a singleton).
 *   - Both primary AND non-primary records count — both are "new records
 *     that ended up in a duplicate cluster", which is the input rate we
 *     want to track regardless of which one survives the merge.
 *
 * Also returns the per-bucket TOTAL record creation count so the UI can
 * render a duplicate-rate ratio (new_duplicates / new_records) — the
 * percentage that is the headline number for prevention effectiveness.
 *
 * Bucket size: 'week' (default) uses DATE_TRUNC('week', …) which Postgres
 * anchors on Monday. 'day' uses DATE_TRUNC('day', …). Anything else falls
 * back to 'week' silently.
 *
 * `weeks` caps the window. Default 12 weeks. Clamped to [1, 52] to keep
 * the query bounded.
 */
export interface DuplicateCreationTrendBucket {
  bucket_start: string; // ISO date 'YYYY-MM-DD'
  new_records: number;
  new_duplicates: number;
  duplicate_rate_pct: number; // 0-100, rounded to 1 decimal
}

/**
 * AMOUNT-AT-RISK OPEN vs CLOSED breakdown (Sample User 2026-07-29). The Amount at
 * risk = SUM of the CRMProvider `Amount` of every DUPLICATE (non-primary) deal in an
 * ACTIVE cluster. This splits that total by deal STAGE: "closed" = terminal /
 * customer states (Paid, Agreement Signed, Closed Won/Lost, Dropped, Cancelled,
 * Transferred to CS, Client Activated) — a duplicate of an already-concluded
 * deal, i.e. data debt but not open pipeline; "open" = everything still in the
 * active sales pipeline (real inflation that could still book twice). Only
 * ACTIVE, non-resolved clusters count — dismissed / resolved drop out, matching
 * the headline figure. Read-only.
 */
export async function getInflationOpenClosedBreakdown(
  segment?: DuplicateFilters["segment"],
): Promise<{
  total_sar: number; // everything (for reference)
  at_risk_sar: number; // headline: EXCLUDES Agreement Signed + Paid
  open_sar: number;
  closed_sar: number; // terminal but NOT signed/paid
  excluded_signed_paid_sar: number; // Agreement Signed + Paid (won customers)
  open_deals: number;
  closed_deals: number;
  excluded_deals: number;
  by_stage: Array<{
    stage: string;
    bucket: "open" | "closed" | "excluded";
    sar: number;
    deals: number;
  }>;
}> {
  const seg = buildSegmentPredicate(segment, 1);
  const segCond = seg.condition ? ` AND ${seg.condition}` : "";
  const stageExpr = stageSql("r");
  // Sample User 2026-07-29: WON customers → EXCLUDED from Amount at risk. Other
  // terminal stages (closed lost/won/dropped/cancelled/…) = "closed";
  // everything else = "open" pipeline. Amount at risk = open + closed.
  //
  // Reads WON_STAGES rather than its own copy of the list (2026-08-23). This
  // expression previously hardcoded IN ('agreement signed','paid'), so when
  // openStagePredicate learned about partner active / signed / new client /
  // welcome communications / registered 40 percent, the HEADLINE dropped but
  // this drill-down still filed those 180+ deals under "open" — the panel
  // contradicting its own headline, which is exactly the failure the earlier
  // by_stage-vs-headline confusion was about. One list, both places.
  const bucketExpr = `CASE
      WHEN ${stageExpr} IN (${wonStagesSql()}) THEN 'excluded'
      WHEN ${stageExpr} ~ '${TERMINAL_STAGE_RE}' THEN 'closed'
      ELSE 'open' END`;
  const rows = (
    await pool.query(
      `WITH resolved_act AS (
         SELECT DISTINCT cluster_id FROM duplicate_merge_actions
          WHERE action_type IN ('resolve','module_resolved')
       )
       SELECT COALESCE(NULLIF(${stageExpr}, ''), '(no stage)') AS stage,
              ${bucketExpr} AS bucket,
              COUNT(*)::int AS deals,
              COALESCE(SUM(r.deal_value), 0)::float AS sar
         FROM duplicate_records r
         JOIN duplicate_clusters c ON c.id = r.cluster_id
         LEFT JOIN resolved_act ra ON ra.cluster_id = c.id
        WHERE r.record_type = 'deal' AND r.is_primary = false AND r.deal_value > 0
          AND c.status = 'active' AND ra.cluster_id IS NULL
          AND c.total_deals > 1${segCond}
        GROUP BY 1, 2
        ORDER BY sar DESC`,
      seg.params,
    )
  ).rows as any[];
  let open_sar = 0,
    closed_sar = 0,
    excluded_signed_paid_sar = 0,
    open_deals = 0,
    closed_deals = 0,
    excluded_deals = 0;
  const by_stage = rows.map((x) => {
    const sar = Number(x.sar) || 0;
    const deals = Number(x.deals) || 0;
    if (x.bucket === "excluded") {
      excluded_signed_paid_sar += sar;
      excluded_deals += deals;
    } else if (x.bucket === "closed") {
      closed_sar += sar;
      closed_deals += deals;
    } else {
      open_sar += sar;
      open_deals += deals;
    }
    return {
      stage: String(x.stage),
      bucket: x.bucket as "open" | "closed" | "excluded",
      sar,
      deals,
    };
  });
  // Survivor exclusion for the OPEN bucket (the headline): keep ONE survivor
  // open deal per cluster and sum the rest, so a genuine 2-deal cluster where
  // the ACCOUNT is primary doesn't count both deals (Sample User 2026-07-29). The
  // by_stage / closed / excluded figures above stay full-sum (informational).
  const openAdj = (
    await pool.query(
      `WITH resolved_act AS (
         SELECT DISTINCT cluster_id FROM duplicate_merge_actions
          WHERE action_type IN ('resolve','module_resolved')
       ),
       open_deals AS (
         SELECT r.deal_value,
                ROW_NUMBER() OVER (PARTITION BY r.cluster_id
                  ORDER BY r.is_primary DESC, r.deal_value DESC, r.created_date ASC NULLS LAST, r.id ASC) AS rn
           FROM duplicate_records r
           JOIN duplicate_clusters c ON c.id = r.cluster_id
           LEFT JOIN resolved_act ra ON ra.cluster_id = c.id
          WHERE r.record_type = 'deal' AND r.deal_value > 0
            AND c.status = 'active' AND ra.cluster_id IS NULL AND c.total_deals > 1
            AND (${openStagePredicate("r")})${segCond}
       )
       SELECT COALESCE(SUM(deal_value),0)::float AS sar, COUNT(*)::int AS deals
         FROM open_deals WHERE rn > 1`,
      seg.params,
    )
  ).rows[0];
  open_sar = Number(openAdj?.sar) || 0;
  open_deals = Number(openAdj?.deals) || 0;
  return {
    total_sar: open_sar + closed_sar + excluded_signed_paid_sar,
    at_risk_sar: open_sar + closed_sar,
    open_sar,
    closed_sar,
    excluded_signed_paid_sar,
    open_deals,
    closed_deals,
    excluded_deals,
    by_stage,
  };
}

/**
 * CLIENTHUB ↔ CRMProvider RECONCILE BY CRM ID (Sample User 2026-08-03). Given the CRMProvider
 * record IDs ClientHub stores (its "CRM ID" column), classify each against the
 * CRMProvider mirror so a ClientHub-vs-QMS count gap can be attributed exactly:
 *   corporate_deal   — a Deal on a ExampleOrg layout WITH a CS Phase set → this is
 *                      what the CS-Lifecycle census counts.
 *   non_corporate    — a Deal but on a Marketplace / Example Organization layout → the census
 *                      (ExampleOrg-scoped) excludes it.
 *   not_a_deal       — the id resolves to an Account/Contact/Lead, not a Deal →
 *                      the deal-based census can't count it.
 *   blank_phase      — a ExampleOrg Deal but its CS Phase field is empty → the
 *                      is_cs_deal gate drops it.
 *   not_in_mirror    — the id isn't in the synced CRMProvider mirror at all.
 * Read-only.
 */
interface ReconcilePhaseBucket {
  file_total: number; // file rows ClientHub tags with THIS phase
  in_qms_same_phase: number; // …that QMS also counts as this phase (exact overlap)
  in_qms_other_phase: number; // …that QMS counts, but under a DIFFERENT phase
  non_corporate: number;
  not_a_deal: number;
  blank_phase: number;
  not_in_mirror: number;
}
export async function reconcileCrmIds(
  crmIds: string[],
  /** Optional map of CRM ID → the phase ClientHub tags it with (from the file's
   *  Stage column), so the reconcile can compare per-phase, not just overall. */
  clientHubPhaseById?: Record<string, string>,
): Promise<{
  total: number;
  summary: {
    corporate_deal: number;
    non_corporate: number;
    not_a_deal: number;
    blank_phase: number;
    not_in_mirror: number;
  };
  by_phase_corporate: Record<string, number>;
  /** Per ClientHub phase (lowercased), the overlap with QMS using the FILE's own
   *  IDs. Empty when no phase map was supplied. */
  clienthub_phases: Record<string, ReconcilePhaseBucket>;
  rows: Array<{
    crm_id: string;
    verdict: string;
    record_type: string | null;
    segment: string | null;
    phase: string | null;
    stage: string | null;
    clienthub_phase: string | null;
  }>;
}> {
  const ids = Array.from(
    new Set((crmIds || []).map((x) => String(x).trim()).filter(Boolean)),
  );
  const summary = {
    corporate_deal: 0,
    non_corporate: 0,
    not_a_deal: 0,
    blank_phase: 0,
    not_in_mirror: 0,
  };
  const by_phase_corporate: Record<string, number> = {};
  const clienthub_phases: Record<string, ReconcilePhaseBucket> = {};
  const phaseMap = clientHubPhaseById || {};
  const hasPhaseMap = Object.keys(phaseMap).length > 0;
  const chBucket = (id: string): ReconcilePhaseBucket | null => {
    if (!hasPhaseMap) return null;
    const key = String(phaseMap[id] || "").trim().toLowerCase() || "(blank)";
    let b = clienthub_phases[key];
    if (!b) {
      b = {
        file_total: 0,
        in_qms_same_phase: 0,
        in_qms_other_phase: 0,
        non_corporate: 0,
        not_a_deal: 0,
        blank_phase: 0,
        not_in_mirror: 0,
      };
      clienthub_phases[key] = b;
    }
    return b;
  };
  if (!ids.length)
    return { total: 0, summary, by_phase_corporate, clienthub_phases, rows: [] };
  const dbRows = (
    await pool.query(
      `SELECT r.CRMProvider_record_id AS crm_id, r.record_type,
              COALESCE(NULLIF(r.layout_name,''), r.raw_data#>>'{Layout,name}', r.raw_data#>>'{$layout,name}', r.raw_data->>'Layout','') AS layout,
              COALESCE(NULLIF(r.raw_data->>'Phase',''), NULLIF(r.raw_data->>'CS_Phase',''), NULLIF(r.raw_data->>'Customer_Phase','')) AS phase,
              COALESCE(NULLIF(r.stage,''), r.raw_data->>'Stage','') AS stage
         FROM duplicate_records r
        WHERE r.CRMProvider_record_id = ANY($1::text[])`,
      [ids],
    )
  ).rows as any[];
  // Prefer a Deal row if the same id somehow appears under multiple types.
  const byId = new Map<string, any>();
  for (const x of dbRows) {
    const k = String(x.crm_id);
    const prev = byId.get(k);
    if (!prev || (prev.record_type !== "deal" && x.record_type === "deal")) {
      byId.set(k, x);
    }
  }
  const rows = ids.map((id) => {
    const b = chBucket(id);
    if (b) b.file_total++;
    const chPhase = String(phaseMap[id] || "").trim().toLowerCase() || null;
    const rec = byId.get(id);
    if (!rec) {
      summary.not_in_mirror++;
      if (b) b.not_in_mirror++;
      return { crm_id: id, verdict: "not_in_mirror", record_type: null, segment: null, phase: null, stage: null, clienthub_phase: chPhase };
    }
    const rt = String(rec.record_type || "");
    if (rt !== "deal") {
      summary.not_a_deal++;
      if (b) b.not_a_deal++;
      return { crm_id: id, verdict: "not_a_deal", record_type: rt, segment: null, phase: null, stage: null, clienthub_phase: chPhase };
    }
    const segment = classifyLayoutSegment(String(rec.layout || ""));
    const phase = (rec.phase || "").toString().trim() || null;
    const stage = (rec.stage || "").toString().trim() || null;
    if (segment !== "ExampleOrg") {
      summary.non_corporate++;
      if (b) b.non_corporate++;
      return { crm_id: id, verdict: "non_corporate", record_type: rt, segment, phase, stage, clienthub_phase: chPhase };
    }
    if (!phase) {
      summary.blank_phase++;
      if (b) b.blank_phase++;
      return { crm_id: id, verdict: "blank_phase", record_type: rt, segment, phase, stage, clienthub_phase: chPhase };
    }
    summary.corporate_deal++;
    const pk = phase.toLowerCase();
    by_phase_corporate[pk] = (by_phase_corporate[pk] || 0) + 1;
    if (b) {
      if (chPhase && pk === chPhase) b.in_qms_same_phase++;
      else b.in_qms_other_phase++;
    }
    return { crm_id: id, verdict: "corporate_deal", record_type: rt, segment, phase, stage, clienthub_phase: chPhase };
  });
  return { total: ids.length, summary, by_phase_corporate, clienthub_phases, rows };
}

/**
 * LIVE "lost data" check (Sample User 2026-08-04). For ClientHub CRM IDs the reconcile
 * flagged as not_in_mirror, ask CRMProvider DIRECTLY (GET by id) across the likely
 * modules. Three outcomes per id:
 *   - in_CRMProvider : found live in some module → just a local sync gap, not lost.
 *   - lost    : every module returned 404/empty → genuinely gone from the CRM
 *               (deleted / never existed) — the "lost data" the CS team wants.
 *   - error   : a lookup errored (rate-limit/auth) and none confirmed found →
 *               could NOT verify, so we do NOT call it lost.
 * Read-only (GETs), bounded, small concurrency.
 */
export async function verifyCrmIdsInCRMProvider(
  crmIds: string[],
  opts?: { max?: number },
): Promise<{
  total: number;
  in_CRMProvider: number;
  lost: number;
  errored: number;
  rows: Array<{ crm_id: string; verdict: "in_CRMProvider" | "lost" | "error"; module: string | null }>;
}> {
  const ids = Array.from(
    new Set((crmIds || []).map((x) => String(x).trim()).filter(Boolean)),
  ).slice(0, Math.max(1, Math.min(opts?.max ?? 500, 2000)));
  const rows: Array<{
    crm_id: string;
    verdict: "in_CRMProvider" | "lost" | "error";
    module: string | null;
  }> = [];
  let in_CRMProvider = 0;
  let lost = 0;
  let errored = 0;
  if (!ids.length) return { total: 0, in_CRMProvider, lost, errored, rows };
  const { fetchCRMProviderRecordById } = await import("./CRMProviderCRM");
  const modules = ["Deals", "Accounts", "Contacts", "Leads"];
  let idx = 0;
  const worker = async () => {
    while (idx < ids.length) {
      const id = ids[idx++]!;
      let found = false;
      let mod: string | null = null;
      let hadError = false;
      for (const m of modules) {
        try {
          const rec = await fetchCRMProviderRecordById(m, id);
          if (rec) {
            found = true;
            mod = m;
            break;
          }
        } catch {
          hadError = true; // a real API error, NOT a 404 (those return null)
        }
      }
      if (found) {
        in_CRMProvider++;
        rows.push({ crm_id: id, verdict: "in_CRMProvider", module: mod });
      } else if (hadError) {
        errored++;
        rows.push({ crm_id: id, verdict: "error", module: null });
      } else {
        lost++;
        rows.push({ crm_id: id, verdict: "lost", module: null });
      }
    }
  };
  const CONC = 5;
  await Promise.all(Array.from({ length: Math.min(CONC, ids.length) }, worker));
  return { total: ids.length, in_CRMProvider, lost, errored, rows };
}

/**
 * OWNER OFFBOARDING (Sample User 2026-07-30). For a (usually resigned) deal owner,
 * list their OPEN-pipeline deals grouped by Stage so the operator can review
 * and bulk-close / re-stage them in CRMProvider. "Open pipeline" = openStagePredicate
 * (NOT Agreement Signed / Paid and NOT any closed/terminal stage). Read-only.
 * Owner is matched EXACTLY on owner_name (a destructive follow-up write acts on
 * these ids, so we do not fuzzy-match and risk touching another rep's deals).
 */
export async function getOwnerOpenDeals(ownerName: string): Promise<{
  owner: string;
  total: number;
  total_value: number;
  by_stage: Array<{
    stage: string;
    count: number;
    value: number;
    deals: Array<{
      id: string;
      name: string;
      domain: string | null;
      value: number;
      modified: string | null;
    }>;
  }>;
}> {
  const owner = String(ownerName || "").trim();
  if (!owner) return { owner: "", total: 0, total_value: 0, by_stage: [] };
  const rows = (
    await pool.query(
      `SELECT r.CRMProvider_record_id AS id,
              COALESCE(NULLIF(r.account_name,''), NULLIF(r.company_name,''), '(unnamed deal)') AS name,
              LOWER(r.domain) AS domain,
              COALESCE(r.deal_value, 0)::float AS value,
              COALESCE(NULLIF(r.stage,''), NULLIF(r.raw_data->>'Stage',''), '(no stage)') AS stage,
              r.raw_data->>'Modified_Time' AS modified
         FROM duplicate_records r
        WHERE r.record_type = 'deal'
          AND r.owner_name = $1
          AND r.CRMProvider_record_id IS NOT NULL AND r.CRMProvider_record_id <> ''
          AND (${openStagePredicate("r")})
        ORDER BY value DESC`,
      [owner],
    )
  ).rows as any[];
  const byStage = new Map<string, any>();
  let total_value = 0;
  for (const d of rows) {
    const stage = String(d.stage || "(no stage)");
    const value = Number(d.value) || 0;
    total_value += value;
    let g = byStage.get(stage);
    if (!g) {
      g = { stage, count: 0, value: 0, deals: [] };
      byStage.set(stage, g);
    }
    g.count++;
    g.value += value;
    g.deals.push({
      id: String(d.id),
      name: String(d.name),
      domain: d.domain || null,
      value,
      modified: d.modified || null,
    });
  }
  return {
    owner,
    total: rows.length,
    total_value,
    by_stage: Array.from(byStage.values()).sort((a, b) => b.value - a.value),
  };
}

/**
 * OWNER OFFBOARDING — the destructive bulk write (Sample User 2026-07-30). Re-checks
 * each id against the mirror (must still be OWNED BY `owner` and OPEN-pipeline)
 * so we never act on stale selections, then bulk-updates CRMProvider: action
 * 'close_lost' → Stage 'Closed Lost' + the Lost-Reason field (env
 * DUPLICATE_RADAR_FIELD_LOST_REASON, default Reason_For_Loss); action 'move' →
 * Stage = targetStage. Returns per-deal outcomes + a skipped list.
 */
export async function bulkUpdateOwnerDeals(input: {
  owner: string;
  dealIds: string[];
  action: "close_lost" | "move";
  targetStage?: string;
  lostReason?: string;
}): Promise<{
  attempted: number;
  updated: number;
  failed: number;
  skipped: string[];
  outcomes: Array<{ id: string; status: string; message?: string }>;
}> {
  const owner = String(input.owner || "").trim();
  const ids = Array.from(
    new Set((input.dealIds || []).map((x) => String(x).trim()).filter(Boolean)),
  );
  if (!owner || !ids.length) {
    return { attempted: 0, updated: 0, failed: 0, skipped: [], outcomes: [] };
  }
  // Re-validate against the mirror: still this owner AND still open-pipeline.
  const valid = (
    await pool.query(
      `SELECT r.CRMProvider_record_id AS id
         FROM duplicate_records r
        WHERE r.record_type = 'deal'
          AND r.owner_name = $1
          AND r.CRMProvider_record_id = ANY($2::text[])
          AND (${openStagePredicate("r")})`,
      [owner, ids],
    )
  ).rows.map((x: any) => String(x.id));
  const validSet = new Set(valid);
  const skipped = ids.filter((id) => !validSet.has(id));
  if (!valid.length) {
    return { attempted: 0, updated: 0, failed: 0, skipped, outcomes: [] };
  }
  const { updateCRMProviderRecordsBulk } = await import("./CRMProviderCRM");
  let records: Array<Record<string, any>>;
  if (input.action === "move") {
    const stage = String(input.targetStage || "").trim();
    if (!stage) throw new Error("targetStage required for action 'move'");
    records = valid.map((id) => ({ id, Stage: stage }));
  } else {
    const lostField = (
      process.env.DUPLICATE_RADAR_FIELD_LOST_REASON || "Reason_For_Loss"
    ).trim();
    const reason = String(input.lostReason || "Old Data");
    records = valid.map((id) => ({
      id,
      Stage: "Closed Lost",
      [lostField]: reason,
    }));
  }
  const outcomes = await updateCRMProviderRecordsBulk("Deals", records);
  const updated = outcomes.filter((o) => o.status === "success").length;
  return {
    attempted: valid.length,
    updated,
    failed: valid.length - updated,
    skipped,
    outcomes: outcomes.map((o, i) => ({
      id: String(records[i]?.id ?? ""),
      status: o.status,
      message: o.message,
    })),
  };
}

/**
 * DUPLICATE SPIKE ROOT-CAUSE (Sample User 2026-07-23). The Creation-Trend chart shows
 * WHEN duplicates are rising, but not WHY. This attributes the rise: it counts
 * NEW duplicate records (created in-window AND part of a real duplicate cluster —
 * the same definition the trend uses) in the RECENT window vs the immediately
 * PRIOR window of equal length, broken down three ways — by Lead SOURCE, by
 * OWNER, and by MODULE — and sorts each by the biggest INCREASE. The top of each
 * list is the pain area: the channel / person / record-type that is leaking the
 * most new duplicates into CRMProvider. Read-only.
 */
export interface SpikeBreakdownRow {
  label: string;
  recent: number;
  prior: number;
  delta: number;
}
export async function getDuplicateSpikeBreakdown(opts: {
  weeks?: number;
  segment?: DuplicateFilters["segment"];
  top?: number;
} = {}): Promise<{
  window_weeks: number;
  recent_total: number;
  prior_total: number;
  delta_total: number;
  by_source: SpikeBreakdownRow[];
  by_owner: SpikeBreakdownRow[];
  by_module: SpikeBreakdownRow[];
  provenance: {
    created_in_window: number;
    created_before_window: number;
    exposure_new_sar: number;
    exposure_old_sar: number;
    first_synced_in_window: number;
    back_detected: number;
    last_synced: string | null;
    synced_view_unreliable: boolean;
  };
}> {
  const weeks = Math.min(26, Math.max(1, Math.floor(Number(opts.weeks ?? 3) || 3)));
  const top = Math.min(50, Math.max(3, Math.floor(Number(opts.top ?? 12) || 12)));

  const params: any[] = [];
  const seg = buildSegmentPredicate(opts.segment, 1);
  let segCond = "";
  if (seg.condition) {
    // buildSegmentPredicate emits an `r.` alias; dr IS that record alias here.
    segCond = ` AND ${seg.condition.replace(/\br\./g, "dr.")}`;
    params.push(...seg.params);
  }

  // recent = [now - weeks, now]; prior = [now - 2*weeks, now - weeks].
  // A record counts once, bucketed by which window its created_date falls in.
  const runDim = async (dimSql: string): Promise<SpikeBreakdownRow[]> => {
    const q = await pool.query<{ label: string; recent: string; prior: string }>(
      `SELECT ${dimSql} AS label,
              COUNT(*) FILTER (WHERE dr.created_date >= NOW() - INTERVAL '${weeks} weeks')::int AS recent,
              COUNT(*) FILTER (WHERE dr.created_date >= NOW() - INTERVAL '${weeks * 2} weeks'
                                 AND dr.created_date <  NOW() - INTERVAL '${weeks} weeks')::int AS prior
         FROM duplicate_records dr
         JOIN duplicate_clusters dc ON dr.cluster_id = dc.id
        WHERE dc.total_records > 1
          AND dr.created_date >= NOW() - INTERVAL '${weeks * 2} weeks'
          AND dr.created_date <= NOW()${segCond}
        GROUP BY ${dimSql}`,
      params,
    );
    return q.rows
      .map((r) => {
        const recent = parseInt(r.recent) || 0;
        const prior = parseInt(r.prior) || 0;
        return { label: r.label, recent, prior, delta: recent - prior };
      })
      .filter((r) => r.recent > 0 || r.prior > 0)
      .sort((a, b) => b.delta - a.delta || b.recent - a.recent)
      .slice(0, top);
  };

  const [by_source, by_owner, by_module] = await Promise.all([
    runDim("COALESCE(NULLIF(TRIM(dr.source), ''), 'Unknown')"),
    runDim("COALESCE(NULLIF(TRIM(dr.owner_name), ''), 'Unassigned')"),
    runDim("INITCAP(dr.record_type)"),
  ]);

  const sum = (rows: SpikeBreakdownRow[], k: "recent" | "prior") =>
    rows.reduce((a, r) => a + r[k], 0);
  // Module totals cover every record exactly once, so use them for the headline.
  const recent_total = sum(by_module, "recent");
  const prior_total = sum(by_module, "prior");

  // PROVENANCE — new-in-CRMProvider vs pre-existing (Sample User 2026-07-23). Answers "did
  // inflation rise from a real NEW leak, or from re-detecting OLD records?".
  //   · created_date  = when the record was born in CRMProvider (100% reliable).
  //   · created_at    = when OUR mirror first inserted it (SYNCED date). Caveat:
  //                     a FULL rebuild re-inserts every row, resetting created_at,
  //                     so when a rebuild falls inside the window these read high.
  // Computed over the CURRENT live duplicate exposure (active clusters,
  // total_records > 1) so it explains the snapshot the SAR/inflation card shows.
  const provQ = await pool.query<{
    created_in_window: string;
    created_before_window: string;
    exposure_new_sar: string;
    exposure_old_sar: string;
    first_synced_in_window: string;
    back_detected: string;
    last_synced: string | null;
  }>(
    `SELECT
       COUNT(*) FILTER (WHERE dr.created_date >= NOW() - INTERVAL '${weeks} weeks')::int AS created_in_window,
       COUNT(*) FILTER (WHERE dr.created_date <  NOW() - INTERVAL '${weeks} weeks' OR dr.created_date IS NULL)::int AS created_before_window,
       COALESCE(SUM(COALESCE(dr.deal_value,0)) FILTER (WHERE dr.record_type = 'deal' AND dr.created_date >= NOW() - INTERVAL '${weeks} weeks'), 0)::float AS exposure_new_sar,
       COALESCE(SUM(COALESCE(dr.deal_value,0)) FILTER (WHERE dr.record_type = 'deal' AND (dr.created_date <  NOW() - INTERVAL '${weeks} weeks' OR dr.created_date IS NULL)), 0)::float AS exposure_old_sar,
       COUNT(*) FILTER (WHERE dr.created_at >= NOW() - INTERVAL '${weeks} weeks')::int AS first_synced_in_window,
       COUNT(*) FILTER (WHERE dr.created_at >= NOW() - INTERVAL '${weeks} weeks' AND (dr.created_date < NOW() - INTERVAL '${weeks} weeks' OR dr.created_date IS NULL))::int AS back_detected,
       TO_CHAR(MAX(dr.created_at), 'YYYY-MM-DD') AS last_synced
       FROM duplicate_records dr
       JOIN duplicate_clusters dc ON dr.cluster_id = dc.id
      WHERE dc.status = 'active' AND dc.total_records > 1${segCond}`,
    params,
  );
  const pr = provQ.rows[0];
  // Was a mirror rebuild likely inside the window? If the OLDEST created_at is
  // itself inside the window, every row was re-inserted recently → the synced
  // view is unreliable. Cheap proxy: min(created_at) within the window.
  const rebuildQ = await pool.query<{ min_synced: string | null }>(
    `SELECT TO_CHAR(MIN(dr.created_at), 'YYYY-MM-DD') AS min_synced
       FROM duplicate_records dr
       JOIN duplicate_clusters dc ON dr.cluster_id = dc.id
      WHERE dc.status = 'active' AND dc.total_records > 1${segCond}`,
    params,
  );
  const minSynced = rebuildQ.rows[0]?.min_synced || null;
  const rebuildInWindow =
    !!minSynced &&
    Date.parse(minSynced) >= Date.now() - weeks * 7 * 86400000;

  return {
    window_weeks: weeks,
    recent_total,
    prior_total,
    delta_total: recent_total - prior_total,
    by_source,
    by_owner,
    by_module,
    provenance: {
      created_in_window: parseInt(pr?.created_in_window || "0") || 0,
      created_before_window: parseInt(pr?.created_before_window || "0") || 0,
      exposure_new_sar: Number(pr?.exposure_new_sar || 0) || 0,
      exposure_old_sar: Number(pr?.exposure_old_sar || 0) || 0,
      first_synced_in_window: parseInt(pr?.first_synced_in_window || "0") || 0,
      back_detected: parseInt(pr?.back_detected || "0") || 0,
      last_synced: pr?.last_synced || null,
      synced_view_unreliable: rebuildInWindow,
    },
  };
}

export async function getDuplicateCreationTrend(opts: {
  weeks?: number;
  granularity?: "week" | "day";
} = {}): Promise<{
  granularity: "week" | "day";
  window_weeks: number;
  buckets: DuplicateCreationTrendBucket[];
}> {
  const weeks = Math.min(
    52,
    Math.max(1, Math.floor(Number(opts.weeks ?? 12) || 12)),
  );
  const granularity: "week" | "day" =
    opts.granularity === "day" ? "day" : "week";
  const trunc = granularity === "day" ? "day" : "week";

  // Single query with FILTER for the duplicate subset. DATE_TRUNC handles
  // the bucketing in Postgres so the result set is tiny (≤ 52 rows).
  const sql = `
    SELECT
      TO_CHAR(DATE_TRUNC('${trunc}', dr.created_date)::date, 'YYYY-MM-DD') AS bucket_start,
      COUNT(*)::int AS new_records,
      COUNT(*) FILTER (WHERE dc.total_records > 1)::int AS new_duplicates
    FROM duplicate_records dr
    JOIN duplicate_clusters dc ON dr.cluster_id = dc.id
    WHERE dr.created_date >= NOW() - INTERVAL '${weeks} weeks'
      AND dr.created_date <= NOW()
    GROUP BY DATE_TRUNC('${trunc}', dr.created_date)
    ORDER BY bucket_start ASC
  `;
  const r = await pool.query<{
    bucket_start: string;
    new_records: number;
    new_duplicates: number;
  }>(sql);

  const buckets: DuplicateCreationTrendBucket[] = r.rows.map((row) => {
    const total = Number(row.new_records ?? 0);
    const dup = Number(row.new_duplicates ?? 0);
    const ratePct =
      total > 0 ? Math.round((dup / total) * 1000) / 10 : 0;
    return {
      bucket_start: row.bucket_start,
      new_records: total,
      new_duplicates: dup,
      duplicate_rate_pct: ratePct,
    };
  });

  return { granularity, window_weeks: weeks, buckets };
}

export async function getEnhancedSummary(): Promise<{
  totalClusters: number;
  trueDuplicateClusters: number;
  singletonCount: number;
  totalRecords: number;
  totalDuplicateLeads: number;
  totalDuplicateDeals: number;
  totalDuplicateContacts: number;
  totalDuplicateAccounts: number;
  highConfidence: number;
  mediumConfidence: number;
  lowConfidence: number;
  estimatedPipelineInflation: number;
  activeCount: number;
  resolvedCount: number;
  ignoredCount: number;
  resolutionRate: number;
  topSignals: Record<string, number>;
  duplicateLeadRate: number;
  duplicateDealRate: number;
  /** Whole-system duplicate rate — actionable duplicate records across ALL
   *  modules (Leads + Deals + Contacts + Accounts) over the total record
   *  count across all modules. The Executive Summary gauge uses this so the
   *  headline reflects every module's duplication, not just Leads. */
  duplicateOverallRate: number;
  topClustersByInflation: any[];
  lastScanInfo: any;
  /** ISO timestamp of the most recent successful sync across all modules
   *  (incremental OR full) — sourced from CRMProvider_sync_state. Drives the
   *  "Last sync" line on the Executive Summary card. Distinct from
   *  lastScanInfo, which is the most recent FULL rebuild only. */
  lastSyncAt: string | null;
}> {
  const result = await pool.query(`
    WITH resolved_act AS (
      SELECT DISTINCT cluster_id FROM duplicate_merge_actions
       WHERE action_type IN ('resolve','module_resolved')
    )
    SELECT
      COUNT(*) as total_clusters,
      COUNT(*) FILTER (WHERE GREATEST(COALESCE(total_leads,0), COALESCE(total_deals,0), COALESCE(total_contacts,0), COALESCE(total_accounts,0)) > 1) as true_dup_clusters,
      COUNT(*) FILTER (WHERE total_records <= 1) as singleton_count,
      COALESCE(SUM(total_records), 0) as total_records,
      COALESCE(SUM(total_leads) FILTER (WHERE total_leads > 1), 0) as dup_leads,
      COALESCE(SUM(total_deals) FILTER (WHERE total_deals > 1), 0) as dup_deals,
      COALESCE(SUM(total_contacts) FILTER (WHERE total_contacts > 1), 0) as dup_contacts,
      COALESCE(SUM(total_accounts) FILTER (WHERE total_accounts > 1), 0) as dup_accounts,
      COUNT(*) FILTER (WHERE confidence_level = 'high' AND GREATEST(COALESCE(total_leads,0), COALESCE(total_deals,0), COALESCE(total_contacts,0), COALESCE(total_accounts,0)) > 1) as high_confidence,
      COUNT(*) FILTER (WHERE confidence_level = 'medium' AND GREATEST(COALESCE(total_leads,0), COALESCE(total_deals,0), COALESCE(total_contacts,0), COALESCE(total_accounts,0)) > 1) as medium_confidence,
      COUNT(*) FILTER (WHERE confidence_level = 'low' AND GREATEST(COALESCE(total_leads,0), COALESCE(total_deals,0), COALESCE(total_contacts,0), COALESCE(total_accounts,0)) > 1) as low_confidence,
      -- Amount at risk (Sample User 2026-07-29): ACTIVE, non-resolved clusters only
      -- (dismiss sets status='ignored', resolve joins resolved_act — both drop
      -- out), AND excludes duplicate deals at Agreement Signed / Paid (won
      -- customers). Computed live from duplicate_records so the stage exclusion
      -- and dismiss both apply immediately, with no full rebuild.
      (SELECT COALESCE(SUM(t.deal_value), 0) FROM (
         SELECT r.deal_value,
                ROW_NUMBER() OVER (PARTITION BY r.cluster_id
                  ORDER BY r.is_primary DESC, r.deal_value DESC, r.created_date ASC NULLS LAST, r.id ASC) AS rn
           FROM duplicate_records r
           JOIN duplicate_clusters c2 ON c2.id = r.cluster_id
           LEFT JOIN resolved_act ra2 ON ra2.cluster_id = c2.id
          WHERE r.record_type = 'deal' AND r.deal_value > 0
            AND c2.status = 'active' AND ra2.cluster_id IS NULL
            AND c2.total_deals > 1
            AND (${openStagePredicate("r")})
       ) t WHERE t.rn > 1
      ) as pipeline_inflation,
      COUNT(*) FILTER (WHERE GREATEST(dc.total_leads, dc.total_deals, dc.total_contacts, dc.total_accounts) > 1
                        AND dc.status = 'active' AND ra.cluster_id IS NULL) as active_count,
      COUNT(*) FILTER (WHERE GREATEST(dc.total_leads, dc.total_deals, dc.total_contacts, dc.total_accounts) > 1
                        AND (dc.status = 'resolved' OR ra.cluster_id IS NOT NULL)) as resolved_count,
      COUNT(*) FILTER (WHERE GREATEST(dc.total_leads, dc.total_deals, dc.total_contacts, dc.total_accounts) > 1
                        AND dc.status = 'ignored' AND ra.cluster_id IS NULL) as ignored_count
    FROM duplicate_clusters dc
    LEFT JOIN resolved_act ra ON ra.cluster_id = dc.id
  `);

  const row = result.rows[0];
  const totalLeads = await pool.query(
    "SELECT COUNT(*) as cnt FROM duplicate_records WHERE record_type = 'lead'",
  );
  const totalDeals = await pool.query(
    "SELECT COUNT(*) as cnt FROM duplicate_records WHERE record_type = 'deal'",
  );
  const totalContacts = await pool.query(
    "SELECT COUNT(*) as cnt FROM duplicate_records WHERE record_type = 'contact'",
  );
  const totalAccounts = await pool.query(
    "SELECT COUNT(*) as cnt FROM duplicate_records WHERE record_type = 'account'",
  );
  const tLeads = parseInt(totalLeads.rows[0]?.cnt) || 1;
  const tDeals = parseInt(totalDeals.rows[0]?.cnt) || 1;
  const tContacts = parseInt(totalContacts.rows[0]?.cnt) || 1;
  const tAccounts = parseInt(totalAccounts.rows[0]?.cnt) || 1;

  // ACTIONABLE-only counts: records that should be merged/deleted to
  // deduplicate, i.e. dup-cluster members that are NOT the survivor.
  // The old "dup_leads" (SUM(total_leads) FILTER total_leads>1) counted
  // EVERY record in a dup cluster including the primary, which inflated
  // the rate from the actionable 43% to a misleading 58% and didn't
  // match the 2% target framing (the target is about records that need
  // action). Same applies to deals/contacts/accounts.
  const actionableResult = await pool.query(`
    SELECT
      COUNT(*) FILTER (WHERE dr.record_type = 'lead'    AND dc.total_leads    > 1 AND dr.is_primary = false AND dc.status = 'active') AS act_leads,
      COUNT(*) FILTER (WHERE dr.record_type = 'deal'    AND dc.total_deals    > 1 AND dr.is_primary = false AND dc.status = 'active') AS act_deals,
      COUNT(*) FILTER (WHERE dr.record_type = 'contact' AND dc.total_contacts > 1 AND dr.is_primary = false AND dc.status = 'active') AS act_contacts,
      COUNT(*) FILTER (WHERE dr.record_type = 'account' AND dc.total_accounts > 1 AND dr.is_primary = false AND dc.status = 'active') AS act_accounts
    FROM duplicate_records dr
    JOIN duplicate_clusters dc ON dr.cluster_id = dc.id
  `);
  const dupLeads = parseInt(actionableResult.rows[0]?.act_leads) || 0;
  const dupDeals = parseInt(actionableResult.rows[0]?.act_deals) || 0;
  const dupContacts = parseInt(actionableResult.rows[0]?.act_contacts) || 0;
  const dupAccounts = parseInt(actionableResult.rows[0]?.act_accounts) || 0;

  const signalResult = await pool.query(`
    SELECT match_signals FROM duplicate_clusters
    WHERE total_records > 1 AND match_signals IS NOT NULL AND status = 'active'
  `);
  const topSignals: Record<string, number> = {};
  for (const r of signalResult.rows) {
    const signals = Array.isArray(r.match_signals) ? r.match_signals : [];
    for (const s of signals) {
      if (s !== "stale_pending") topSignals[s] = (topSignals[s] || 0) + 1;
    }
  }

  // D4: Top 5 clusters by pipeline inflation (active only — excludes resolved/ignored false positives)
  // Top clusters ranked by AMOUNT AT RISK (Sample User 2026-07-29) — recomputed live
  // from duplicate_records EXCLUDING Agreement Signed / Paid duplicate deals,
  // active + non-resolved clusters only, so this panel matches the headline.
  // Aliased back to estimated_pipeline_value so the frontend needs no change.
  const topClustersResult = await pool.query(`
    WITH resolved_act AS (
      SELECT DISTINCT cluster_id FROM duplicate_merge_actions
       WHERE action_type IN ('resolve','module_resolved')
    ),
    open_deals AS (
      SELECT r.cluster_id, r.deal_value,
             ROW_NUMBER() OVER (PARTITION BY r.cluster_id
               ORDER BY r.is_primary DESC, r.deal_value DESC, r.created_date ASC NULLS LAST, r.id ASC) AS rn
        FROM duplicate_records r
       WHERE r.record_type = 'deal' AND r.deal_value > 0
         AND (${openStagePredicate("r")})
    ),
    at_risk AS (
      SELECT cluster_id, SUM(deal_value) AS at_risk_value
        FROM open_deals WHERE rn > 1 GROUP BY cluster_id
    )
    SELECT c.id, c.domain, c.company_name,
           ar.at_risk_value AS estimated_pipeline_value,
           c.total_records, c.confidence_score
      FROM duplicate_clusters c
      JOIN at_risk ar ON ar.cluster_id = c.id
      LEFT JOIN resolved_act ra ON ra.cluster_id = c.id
     WHERE c.status = 'active' AND ra.cluster_id IS NULL
       AND ar.at_risk_value > 0 AND c.total_deals > 1
     ORDER BY ar.at_risk_value DESC
     LIMIT 5
  `);

  // D4: Last scan info — most recent FULL rebuild (every row in
  //     duplicate_detection_logs corresponds to a complete corpus scan).
  const lastScanResult = await pool.query(`
    SELECT completed_at, detection_duration_ms, total_records_scanned, total_clusters_found, total_duplicates_detected
    FROM duplicate_detection_logs WHERE status = 'completed'
    ORDER BY completed_at DESC LIMIT 1
  `);

  // Most recent sync of ANY kind (incremental Sync Now / scheduled cron /
  // full rebuild) — taken from the per-module CRMProvider_sync_state. This is
  // what the operator-facing "Last sync" line reflects. The incremental
  // syncs that landed via the inngest path between full rebuilds DO
  // update CRMProvider_sync_state but not duplicate_detection_logs, which is
  // why the legacy Last-Scan card looked frozen on the last full
  // rebuild date. The query is a no-op if the table is empty.
  const lastSyncResult = await pool.query(`
    SELECT MAX(last_sync_at) AS last_sync_at FROM CRMProvider_sync_state
  `);
  const lastSyncAt: string | null = lastSyncResult.rows[0]?.last_sync_at
    ? new Date(lastSyncResult.rows[0].last_sync_at).toISOString()
    : null;

  const totalClusters = parseInt(row.total_clusters) || 0;
  const resolvedCount = parseInt(row.resolved_count) || 0;
  const ignoredCount = parseInt(row.ignored_count) || 0;
  const trueDuplicateClusters = parseInt(row.true_dup_clusters) || 0;
  // Denominator is the universe of duplicate clusters we ever cared about:
  // open dup clusters + ones we've already resolved or ignored. Using
  // totalClusters here (which includes ~77k singletons) silently diluted
  // the rate to 0% even after hundreds of clusters were closed — singletons
  // are not duplicates and never were.
  //
  // true_dup_clusters counts EVERY cluster with GREATEST(total_*) > 1 and
  // applies no status filter, so it ALREADY contains the resolved and ignored
  // ones. Adding them again double-counted every closed cluster and understated
  // the rate. Measured live 2026-08-20: active 7,934 + resolved 1,704 +
  // ignored 689 = 10,327, exactly true_dup_clusters — so the old denominator
  // was 12,720 instead of 10,327 and the tile read 19% instead of 23%.
  const resolutionDenominator = trueDuplicateClusters;
  const resolutionRate =
    resolutionDenominator > 0
      ? Math.round(
          ((resolvedCount + ignoredCount) / resolutionDenominator) * 100,
        )
      : 0;

  return {
    totalClusters,
    trueDuplicateClusters,
    singletonCount: parseInt(row.singleton_count) || 0,
    totalRecords: parseInt(row.total_records) || 0,
    totalDuplicateLeads: dupLeads,
    totalDuplicateDeals: dupDeals,
    totalDuplicateContacts: dupContacts,
    totalDuplicateAccounts: dupAccounts,
    highConfidence: parseInt(row.high_confidence) || 0,
    mediumConfidence: parseInt(row.medium_confidence) || 0,
    lowConfidence: parseInt(row.low_confidence) || 0,
    estimatedPipelineInflation: parseFloat(row.pipeline_inflation) || 0,
    activeCount: parseInt(row.active_count) || 0,
    resolvedCount,
    ignoredCount,
    resolutionRate,
    topSignals,
    duplicateLeadRate: Math.round((dupLeads / tLeads) * 100),
    duplicateDealRate: Math.round((dupDeals / tDeals) * 100),
    duplicateOverallRate: Math.round(
      ((dupLeads + dupDeals + dupContacts + dupAccounts) /
        Math.max(1, tLeads + tDeals + tContacts + tAccounts)) *
        100,
    ),
    topClustersByInflation: topClustersResult.rows,
    lastScanInfo: lastScanResult.rows[0] || null,
    lastSyncAt,
  };
}

export async function getLastScanDate(): Promise<Date | null> {
  const result = await pool.query(
    "SELECT completed_at FROM duplicate_detection_logs WHERE status = 'completed' ORDER BY completed_at DESC LIMIT 1",
  );
  return result.rows[0]?.completed_at || null;
}

/**
 * Lightweight per-tab snapshot for the Executive Summary "at-a-glance"
 * scorecard. Fans out across every Duplicate Radar tab in parallel and
 * returns ONLY the headline figures (no row arrays) so the response
 * stays fast and small.
 *
 * Each tab returns its own `verdict` field — green / amber / red /
 * neutral — so the UI can colour the tile without re-deriving the
 * logic. The verdict thresholds match the same rules each tab uses
 * internally.
 *
 * Errors in any single tab are swallowed and returned as
 * `error: <message>` on that tab's slot so a slow CRMProvider dependency or
 * missing optional table never bricks the whole exec view.
 */
export interface RadarTabSnapshot {
  verdict: "green" | "amber" | "red" | "neutral";
  headline: string;
  metrics: Record<string, number | string>;
  error?: string;
}
export interface DuplicateRadarOverview {
  generatedAt: string;
  tabs: {
    leadDuplicates: RadarTabSnapshot;
    dealDuplicates: RadarTabSnapshot;
    contactDuplicates: RadarTabSnapshot;
    accountDuplicates: RadarTabSnapshot;
    crossModule: RadarTabSnapshot;
    csOverlap: RadarTabSnapshot;
    csLifecycle: RadarTabSnapshot;
    dealsLifecycle: RadarTabSnapshot;
    dealCompliance: RadarTabSnapshot;
    accountHints: RadarTabSnapshot;
    ownerAccountability: RadarTabSnapshot;
    logs: RadarTabSnapshot;
  };
}

async function _safeSnapshot(
  loader: () => Promise<RadarTabSnapshot>,
): Promise<RadarTabSnapshot> {
  try {
    return await loader();
  } catch (e: any) {
    return {
      verdict: "neutral",
      headline: "Snapshot unavailable",
      metrics: {},
      error: e?.message || String(e),
    };
  }
}

export async function getDuplicateRadarOverview(): Promise<DuplicateRadarOverview> {
  const generatedAt = new Date().toISOString();

  // 2026-06-17 — per-module duplicate snapshot for the at-a-glance grid so the
  // Executive Summary covers the 4 core duplicate tabs too (Lead / Deal /
  // Contact / Account Duplicates), not just the supporting tabs. `field` is a
  // fixed column name (never user input) so the interpolation is safe.
  const _moduleDupSnapshot = (
    field: "total_leads" | "total_deals" | "total_contacts" | "total_accounts",
    noun: string,
  ) =>
    _safeSnapshot(async () => {
      // Same lifecycle as the tabs: a cluster is "handled/resolved" when its
      // status is 'resolved' OR it carries a resolve/module_resolved action;
      // "open" = active and NOT resolved. The resolved-action set is computed
      // once (CTE) and hash-joined, so this stays cheap.
      const r = await pool.query(
        `WITH resolved_act AS (
           SELECT DISTINCT cluster_id FROM duplicate_merge_actions
            WHERE action_type IN ('resolve','module_resolved')
         )
         SELECT
           COUNT(*) FILTER (WHERE dc.status = 'active' AND ra.cluster_id IS NULL AND ${field} > 1)::int AS open_clusters,
           COUNT(*) FILTER (WHERE (dc.status = 'resolved' OR ra.cluster_id IS NOT NULL) AND ${field} > 1)::int AS handled,
           COALESCE(SUM(${field}) FILTER (WHERE dc.status = 'active' AND ra.cluster_id IS NULL AND ${field} > 1), 0)::int AS dup_records
         FROM duplicate_clusters dc
         LEFT JOIN resolved_act ra ON ra.cluster_id = dc.id`,
      );
      const row = r.rows[0] || {};
      const open = Number(row.open_clusters || 0);
      const handled = Number(row.handled || 0);
      const records = Number(row.dup_records || 0);
      const verdict: RadarTabSnapshot["verdict"] =
        open === 0 ? "green" : open > 50 ? "red" : "amber";
      return {
        verdict,
        headline:
          open.toLocaleString() +
          " duplicate cluster(s) · " +
          records.toLocaleString() +
          " " +
          noun,
        metrics: { openClusters: open, handled, dupRecords: records },
      };
    });

  const [
    leadDuplicates,
    dealDuplicates,
    contactDuplicates,
    accountDuplicates,
    crossModule,
    csOverlap,
    csLifecycle,
    dealsLifecycle,
    dealCompliance,
    accountHints,
    ownerAccountability,
    logs,
  ] = await Promise.all([
    _moduleDupSnapshot("total_leads", "lead records"),
    _moduleDupSnapshot("total_deals", "deal records"),
    _moduleDupSnapshot("total_contacts", "contact records"),
    _moduleDupSnapshot("total_accounts", "account records"),
    _safeSnapshot(async () => {
      // Cross-module overlaps are NOT a separate column — they're clusters
      // whose total_<kind> > 0 for ≥2 record types. Lifecycle uses the
      // cluster's existing `status` column. Matches the shape of
      // getCrossModuleOverlaps().
      const crossModuleFilter = `(
        (CASE WHEN total_leads    > 0 THEN 1 ELSE 0 END +
         CASE WHEN total_contacts > 0 THEN 1 ELSE 0 END +
         CASE WHEN total_accounts > 0 THEN 1 ELSE 0 END +
         CASE WHEN total_deals    > 0 THEN 1 ELSE 0 END) >= 2
      )`;
      // Same lifecycle as the tabs (resolve/module_resolved action = handled).
      const r = await pool.query(
        `WITH resolved_act AS (
           SELECT DISTINCT cluster_id FROM duplicate_merge_actions
            WHERE action_type IN ('resolve','module_resolved')
         )
         SELECT
           COUNT(*) FILTER (WHERE dc.status = 'active' AND ra.cluster_id IS NULL)::int   AS open_count,
           COUNT(*) FILTER (WHERE dc.status = 'resolved' OR ra.cluster_id IS NOT NULL)::int AS handled_count,
           COUNT(*) FILTER (WHERE dc.status = 'ignored' AND ra.cluster_id IS NULL)::int  AS dismissed_count,
           COALESCE(SUM(estimated_pipeline_value)
             FILTER (WHERE dc.status = 'active' AND ra.cluster_id IS NULL), 0)::float    AS arr_sar
         FROM duplicate_clusters dc
         LEFT JOIN resolved_act ra ON ra.cluster_id = dc.id
         WHERE ${crossModuleFilter}`,
      );
      const row = r.rows[0] || {};
      const open = Number(row.open_count || 0);
      const handled = Number(row.handled_count || 0);
      const dismissed = Number(row.dismissed_count || 0);
      const arr = Math.round(Number(row.arr_sar || 0));
      const verdict: RadarTabSnapshot["verdict"] =
        open === 0 ? "green" : open > 50 ? "red" : "amber";
      return {
        verdict,
        headline: open + " open overlap(s), SAR " + arr.toLocaleString() + " exposure",
        metrics: { open, handled, dismissed, arrExposureSar: arr },
      };
    }),

    _safeSnapshot(async () => {
      const v = await getCsOverlapVerdictCounts();
      const verdict: RadarTabSnapshot["verdict"] =
        v.block > 0 ? "red" : v.review > 0 || v.warn > 0 ? "amber" : "green";
      return {
        verdict,
        headline:
          v.block + " block / " + v.review + " review / " + v.warn + " warn",
        metrics: { block: v.block, review: v.review, warn: v.warn, total: v.total },
      };
    }),

    _safeSnapshot(async () => {
      const r = await scanCsLifecycleViolations({ limit: 50000 });
      const s = r.summary;
      const critical = s.by_severity.critical || 0;
      const warning = s.by_severity.warning || 0;
      const inRenewal = s.by_phase?.renewal || 0;
      const verdict: RadarTabSnapshot["verdict"] =
        critical > 0 ? "red" : warning > 0 ? "amber" : "green";
      return {
        verdict,
        headline:
          critical +
          " critical / " +
          warning +
          " warning · " +
          s.total_cs_deals +
          " CS deals",
        metrics: {
          critical,
          warning,
          info: s.by_severity.info || 0,
          totalCsDeals: s.total_cs_deals,
          inRenewal,
        },
      };
    }),

    _safeSnapshot(async () => {
      const { scanDealStageAgingViolations } = await import(
        "./duplicateRadarDatabase"
      );
      const r = await scanDealStageAgingViolations({ limit: 50000 });
      const s = r.summary;
      const critical = s.by_severity.critical || 0;
      const warning = s.by_severity.warning || 0;
      const verdict: RadarTabSnapshot["verdict"] =
        critical > 0 ? "red" : warning > 0 ? "amber" : "green";
      return {
        verdict,
        headline:
          critical +
          " critical / " +
          warning +
          " warning · " +
          s.total_tracked_deals +
          " Sales-stage deals",
        metrics: {
          critical,
          warning,
          totalTrackedDeals: s.total_tracked_deals,
        },
      };
    }),

    _safeSnapshot(async () => {
      // deal_doc_compliance schema: compliant BOOLEAN (not result->>compliant).
      const r = await pool.query(
        `SELECT
           COUNT(*)::int                                AS checked,
           COUNT(*) FILTER (WHERE compliant = true)::int AS compliant
         FROM deal_doc_compliance`,
      );
      const row = r.rows[0] || {};
      const checked = Number(row.checked || 0);
      const compliant = Number(row.compliant || 0);
      const missing = checked - compliant;
      const verdict: RadarTabSnapshot["verdict"] =
        checked === 0
          ? "neutral"
          : missing === 0
            ? "green"
            : missing > checked / 2
              ? "red"
              : "amber";
      return {
        verdict,
        headline:
          checked > 0
            ? compliant + " / " + checked + " deals fully documented"
            : "No documents checked yet",
        metrics: { checked, compliant, missing },
      };
    }),

    _safeSnapshot(async () => {
      const r = await pool.query(
        `SELECT
           COUNT(*) FILTER (WHERE status = 'pending')::int                                                    AS pending,
           COUNT(*) FILTER (WHERE status = 'pending' AND confidence >= 70)::int                               AS ready,
           COUNT(*) FILTER (WHERE status = 'applied')::int                                                    AS applied,
           COUNT(*) FILTER (WHERE status = 'dismissed')::int                                                  AS dismissed
         FROM account_inference_hints`,
      );
      const row = r.rows[0] || {};
      const pending = Number(row.pending || 0);
      const ready = Number(row.ready || 0);
      const applied = Number(row.applied || 0);
      const dismissed = Number(row.dismissed || 0);
      const verdict: RadarTabSnapshot["verdict"] =
        pending === 0
          ? "green"
          : ready > 0
            ? "amber"
            : pending > 100
              ? "red"
              : "amber";
      return {
        verdict,
        headline:
          pending +
          " pending (" +
          ready +
          " AI-ready ≥70%) · " +
          applied +
          " applied · " +
          dismissed +
          " dismissed",
        metrics: { pending, ready, applied, dismissed },
      };
    }),

    _safeSnapshot(async () => {
      const owners = await getOwnerAccountability();
      const inRed = owners.filter((o) => o.rag_status === "red").length;
      const inAmber = owners.filter((o) => o.rag_status === "amber").length;
      const worst = owners[0];
      const verdict: RadarTabSnapshot["verdict"] =
        inRed > 0 ? "red" : inAmber > 0 ? "amber" : "green";
      return {
        verdict,
        headline:
          inRed +
          " red / " +
          inAmber +
          " amber" +
          (worst ? " · worst: " + (worst.owner_name || worst.owner_email || "—") : ""),
        metrics: {
          redCount: inRed,
          amberCount: inAmber,
          totalOwners: owners.length,
          worstOwner: worst
            ? worst.owner_name || worst.owner_email || ""
            : "",
          worstRatePct: worst ? Math.round(worst.duplicate_rate) : 0,
        },
      };
    }),

    _safeSnapshot(async () => {
      // Both tables use created_at (not performed_at) for the timestamp.
      const since24h = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
      const r = await pool.query(
        `SELECT
           (SELECT COUNT(*)::int FROM duplicate_resolution_feedback WHERE created_at >= $1) AS agent_24h,
           (SELECT COUNT(*)::int FROM duplicate_merge_actions       WHERE created_at >= $1) AS manual_24h`,
        [since24h],
      );
      const agent = Number(r.rows[0]?.agent_24h || 0);
      const manual = Number(r.rows[0]?.manual_24h || 0);
      const verdict: RadarTabSnapshot["verdict"] =
        agent + manual === 0 ? "neutral" : "green";
      return {
        verdict,
        headline:
          agent +
          " agent event(s) · " +
          manual +
          " operator action(s) in 24h",
        metrics: { agentEvents24h: agent, manualActions24h: manual },
      };
    }),
  ]);

  return {
    generatedAt,
    tabs: {
      leadDuplicates,
      dealDuplicates,
      contactDuplicates,
      accountDuplicates,
      crossModule,
      csOverlap,
      csLifecycle,
      dealsLifecycle,
      dealCompliance,
      accountHints,
      ownerAccountability,
      logs,
    },
  };
}

/**
 * SQL predicate (static, no params) — TRUE when the record at `alias` is QUEUED
 * FOR DELETION: tagged Empty-Delete (via the in-platform ledger OR the synced
 * CRMProvider Tag) or Duplicate-Delete (synced CRMProvider Tag). Such records must not appear
 * in the Untouched view of ANY Duplicate Radar tab, nor be compared against
 * other records — they're on their way out, awaiting the CRM admin's deletion
 * (Sample User 2026-06-26). They DO stay visible in the "AI-Applied · pending CRMProvider
 * admin delete" bucket, so the exclusion is applied only to the active/Untouched
 * view by the caller. COALESCE(...,false) so a record with a null/absent Tag is
 * treated as NOT queued (it must still count as a real record).
 */
function queuedForDeletionSql(alias: string): string {
  return `COALESCE(
    ${alias}.CRMProvider_record_id IN (SELECT CRMProvider_record_id FROM empty_delete_ledger)
    OR ${alias}.raw_data->'Tag' @> '[{"name":"Empty-Delete"}]'::jsonb
    OR ${alias}.raw_data->'Tag' @> '[{"name":"Duplicate-Delete"}]'::jsonb
  , false)`;
}

// Whitelisted sort columns for the per-type record tabs (Leads/Deals/
// Contacts/Accounts). Mirrors CLUSTER_SORT_COLUMNS above — only values
// mapped here may be interpolated into the ORDER BY, which guards against
// SQL injection from the query string. Keys are the UI sort keys the
// frontend sends.
//
// IMPORTANT: this view paginates by CLUSTER (see the "Paginate by CLUSTER"
// comment below) — the cluster-page query selects only `dc.id` and has no
// `dr` alias in its outer scope, so a per-record column (name/email/owner/
// created/modified) can't be referenced directly in that query's ORDER BY.
// Instead each entry is a full, self-contained correlated-subquery
// expression (referencing dc.id and the outer $1 = recordType param) that
// picks one representative value per cluster — MIN() so the result is
// deterministic regardless of row order, and so NULLs (no matching value)
// naturally sort last via NULLS LAST below. `confidence` is the one
// cluster-level field (dc.confidence_score) and needs no subquery — it's
// also the existing default sort.
const RECORD_SORT_COLUMNS: Record<string, string> = {
  name: `(SELECT MIN(dr_s.record_name) FROM duplicate_records dr_s WHERE dr_s.cluster_id = dc.id AND dr_s.record_type = $1)`,
  email: `(SELECT MIN(dr_s.email) FROM duplicate_records dr_s WHERE dr_s.cluster_id = dc.id AND dr_s.record_type = $1)`,
  owner: `(SELECT MIN(dr_s.owner_name) FROM duplicate_records dr_s WHERE dr_s.cluster_id = dc.id AND dr_s.record_type = $1)`,
  created: `(SELECT MIN(dr_s.created_date) FROM duplicate_records dr_s WHERE dr_s.cluster_id = dc.id AND dr_s.record_type = $1)`,
  modified: `(SELECT MIN(dr_s.modified_date) FROM duplicate_records dr_s WHERE dr_s.cluster_id = dc.id AND dr_s.record_type = $1)`,
  confidence: "dc.confidence_score",
};

// B5: JOIN-based queries eliminating N+1 pattern
export async function getDuplicateRecordsByType(
  recordType: string,
  options?: {
    limit?: number;
    offset?: number;
    start_date?: string;
    end_date?: string;
    owners?: string[];
    layouts?: string[];
    pipelines?: string[];
    stages?: string[];
    confidence_level?: string;
    domain?: string;
    ai_status?: string;
    segment?: "all" | "marketplace" | "corporate" | "ExampleOrg" | "Example Organization";
    sort?: string;
    dir?: string;
  },
): Promise<{ groups: any[]; total: number }> {
  const countField =
    recordType === "lead"
      ? "total_leads"
      : recordType === "deal"
        ? "total_deals"
        : recordType === "contact"
          ? "total_contacts"
          : "total_accounts";

  // Date AND advanced-filter clauses constraining which records (and
  // therefore which clusters) are in scope. Placeholders start at $2 so the
  // fragment can be reused inside the EXISTS sub-queries below ($1 =
  // recordType). dc is the correlated outer cluster alias in those
  // sub-queries, so cluster-level predicates (confidence_level) are valid here.
  let dateFilter = "";
  const dateParams: any[] = [];
  if (options?.start_date) {
    dateFilter += ` AND dr.created_date >= $${dateParams.length + 2}`;
    dateParams.push(options.start_date);
  }
  if (options?.end_date) {
    dateFilter += ` AND dr.created_date <= $${dateParams.length + 2}`;
    dateParams.push(options.end_date + "T23:59:59Z");
  }
  if (options?.owners && options.owners.length > 0) {
    dateFilter += ` AND dr.owner_name = ANY($${dateParams.length + 2}::text[])`;
    dateParams.push(options.owners);
  }
  if (options?.layouts && options.layouts.length > 0) {
    dateFilter += ` AND dr.layout_name = ANY($${dateParams.length + 2}::text[])`;
    dateParams.push(options.layouts);
  }
  if (options?.pipelines && options.pipelines.length > 0) {
    dateFilter += ` AND dr.pipeline = ANY($${dateParams.length + 2}::text[])`;
    dateParams.push(options.pipelines);
  }
  if (options?.stages && options.stages.length > 0) {
    dateFilter += ` AND dr.stage = ANY($${dateParams.length + 2}::text[])`;
    dateParams.push(options.stages);
  }
  if (options?.confidence_level) {
    dateFilter += ` AND dc.confidence_level = $${dateParams.length + 2}`;
    dateParams.push(options.confidence_level);
  }
  if (options?.domain) {
    dateFilter += ` AND dr.domain ILIKE $${dateParams.length + 2}`;
    dateParams.push(`%${options.domain}%`);
  }
  // Corporate/Marketplace segment chip (Bug #2 fix). buildSegmentPredicate
  // emits its condition against a `r.` alias — dr IS that duplicate_records
  // alias here (the EXISTS sub-query that dateFilter is appended to is
  // `SELECT 1 FROM duplicate_records dr WHERE dr.cluster_id = dc.id ...`),
  // so swap the `r.` the helper returns for `dr.` to match this function's
  // actual alias before appending. Offset = dateParams.length + 2, same
  // running-offset convention as every other clause above ($1=recordType).
  const segmentClause = buildSegmentPredicate(
    options?.segment,
    dateParams.length + 2,
  );
  if (segmentClause.condition) {
    dateFilter += ` AND ${segmentClause.condition.replace(/\br\./g, "dr.")}`;
    dateParams.push(...segmentClause.params);
  }

  const limit = options?.limit || 50;
  const offset = options?.offset || 0;

  // AI-status filter — visualises the "this cluster was already AI-applied
  // and is now waiting for the CRMProvider admin to physically delete the tagged
  // duplicates" state. Default 'active' keeps the legacy view (untouched
  // active clusters). 'tagged_pending' = active cluster that has at least
  // one merge_action against it. 'resolved' = cluster status='resolved'.
  // 'all' = no filter.
  const aiStatus = ((options as any)?.ai_status as string) || "active";
  // The four AI-status tabs are MUTUALLY EXCLUSIVE — every cluster lands in
  // exactly one, by lifecycle precedence (Sample User 2026-06-24):
  //   Resolved > AI-Applied(pending) > Dismissed > Untouched
  // CRITICAL DISTINCTION: an `auto_merge_pending` action means the AI tagged the
  // duplicates and is WAITING for the CRMProvider admin to delete them (→ AI-Applied).
  // A `resolve` / `module_resolved` action means the cluster was ALREADY resolved
  // / merged (→ Resolved). The old filter lumped all three as "AI-Applied", so
  // past-resolved clusters whose status hadn't flipped to 'resolved' (records
  // reappeared on a later sync) showed in AI-Applied instead of Resolved — the
  // "124 in AI-Applied but only 7 truly pending" bug.
  const HAS_PENDING =
    "EXISTS (SELECT 1 FROM duplicate_merge_actions ma WHERE ma.cluster_id = dc.id AND ma.action_type = 'auto_merge_pending')";
  const HAS_RESOLVED_ACTION =
    "EXISTS (SELECT 1 FROM duplicate_merge_actions ma WHERE ma.cluster_id = dc.id AND ma.action_type IN ('resolve','module_resolved'))";
  let statusFilter = "AND dc.status = 'active'";
  let mergeActionFilter = "";
  if (aiStatus === "tagged_pending") {
    // AI-APPLIED · pending CRMProvider admin delete (Sample User 2026-07-06): an apply ran —
    // records were TAGGED Duplicate-Delete — but the cluster is NOT yet Resolved
    // (the admin hasn't deleted the tagged records AND Verify-in-CRM / a sync
    // hasn't confirmed they're gone). This is the "waiting for deletion" queue.
    // Includes cross-module PARTIAL applies (module_resolved) and auto-merge
    // pends. "Applied" ≠ "Resolved" until verified.
    statusFilter = "AND dc.status NOT IN ('resolved','ignored')";
    mergeActionFilter = ` AND (${HAS_PENDING} OR ${HAS_RESOLVED_ACTION})`;
  } else if (aiStatus === "resolved") {
    // Resolved = the cluster STATUS is actually flipped to 'resolved' — Verify-in-
    // CRM confirmed the Duplicate-Delete records are gone, or the sync reconciled
    // every module. NOT merely "Apply was clicked" (that stays AI-Applied above).
    statusFilter = "AND dc.status = 'resolved'";
  } else if (aiStatus === "dismissed") {
    // Dismissed = operator false-positive (status 'ignored') with NO AI action.
    statusFilter = "AND dc.status = 'ignored'";
    mergeActionFilter = ` AND NOT ${HAS_PENDING} AND NOT ${HAS_RESOLVED_ACTION}`;
  } else if (aiStatus === "all") {
    statusFilter = "";
  } else if (aiStatus === "active") {
    // Untouched = active, nothing done by AI or operator.
    statusFilter = "AND dc.status = 'active'";
    mergeActionFilter = ` AND NOT ${HAS_PENDING} AND NOT ${HAS_RESOLVED_ACTION}`;
  }

  // GENUINE-DUPLICATE gate for DEALS (Sample User 2026-06-21). Deal clusters are
  // grouped by COMPANY, so a company with two DIFFERENT deals (e.g. "Renewal
  // 2025" and "New Project") becomes a cluster with 2 deals — counted as a
  // "duplicate group" even though the deals aren't duplicates. The Deal tab's
  // renderer then drops them (it only shows deals sharing name+account or a
  // duplicate CRM id), leaving the page empty while the footer claimed
  // thousands of groups. Mirror the renderer here so the count + pages reflect
  // ONLY clusters that hold a real deal duplicate. Accounts don't need this —
  // every account-cluster is a genuine duplicate. _normName = lower + trim +
  // collapse whitespace.
  let genuineDupFilter = "";
  if (recordType === "deal") {
    genuineDupFilter = `
      AND (
        EXISTS (
          SELECT 1 FROM duplicate_records dd
           WHERE dd.cluster_id = dc.id AND dd.record_type = 'deal'
             AND dd.record_name IS NOT NULL AND btrim(dd.record_name) <> ''
             AND COALESCE(dd.raw_data->'Account_Name'->>'id', dd.raw_data->>'account_id', '') <> ''
           GROUP BY lower(regexp_replace(btrim(dd.record_name), '\\s+', ' ', 'g')),
                    COALESCE(dd.raw_data->'Account_Name'->>'id', dd.raw_data->>'account_id', '')
          HAVING COUNT(*) >= 2
        )
        OR EXISTS (
          SELECT 1 FROM duplicate_records de
           WHERE de.cluster_id = dc.id AND de.record_type = 'deal'
             AND de.CRMProvider_record_id IS NOT NULL AND btrim(de.CRMProvider_record_id) <> ''
           GROUP BY de.CRMProvider_record_id
          HAVING COUNT(*) >= 2
        )
      )`;
  } else if (recordType === "contact") {
    // GENUINE-DUPLICATE gate for CONTACTS (Sample User 2026-06-22). A cluster only
    // counts as a contact-duplicate when >=2 of its contacts DIRECTLY share an
    // identity signal — same email, OR same phone, OR same name. Contacts that
    // are merely colleagues at the same company (sharing only the account/
    // domain) form no such pair, so a "chained match" cluster held together
    // only by the domain drops off the list — it's a link-to-account job, not a
    // duplicate. A direct single-signal pair still shows (it MAY be a dup).
    genuineDupFilter = `
      AND (
        EXISTS (
          SELECT 1 FROM duplicate_records ce
           WHERE ce.cluster_id = dc.id AND ce.record_type = 'contact'
             AND ce.email IS NOT NULL AND btrim(ce.email) <> ''
           GROUP BY lower(btrim(ce.email))
          HAVING COUNT(*) >= 2
        )
        OR EXISTS (
          SELECT 1 FROM duplicate_records cp
           WHERE cp.cluster_id = dc.id AND cp.record_type = 'contact'
             AND cp.phone_normalized IS NOT NULL AND length(cp.phone_normalized) >= 7
           GROUP BY cp.phone_normalized
          HAVING COUNT(*) >= 2
        )
        OR EXISTS (
          SELECT 1 FROM duplicate_records cn
           WHERE cn.cluster_id = dc.id AND cn.record_type = 'contact'
             AND cn.record_name IS NOT NULL AND btrim(cn.record_name) <> ''
           -- Arabic-aware to match the frontend _normName: fold ة→ه, ى→ي,
           -- آأإ→ا and drop tatweel (ـ) before collapsing whitespace.
           GROUP BY lower(regexp_replace(
                      translate(btrim(cn.record_name), 'ةىأإآـ', 'هيااا'),
                      '\\s+', ' ', 'g'))
          HAVING COUNT(*) >= 2
        )
      )`;
  } else if (recordType === "lead") {
    // GENUINE-DUPLICATE gate for LEADS (Sample User 2026-07-22). The Leads tab was the
    // ONE record tab with no server-side filter: it counted every cluster holding
    // >=2 leads — including COLLEAGUES who share only their company's domain — so
    // the footer read "5,158 duplicate groups / 258 pages" while the client, which
    // re-groups leads by a DIRECT identity signal (name / email / phone / CRMProvider id,
    // matching renderLeadRows' union-find), rendered just 1 real duplicate on the
    // page. (Contacts already had this gate; Accounts don't need one — their
    // renderer keeps a per-cluster fallback bucket so fuzzy-name clusters never
    // drop.) A cluster now counts as a lead-duplicate only when >=2 of its leads
    // DIRECTLY share email, OR phone, OR mobile, OR a normalised name, OR the same
    // CRMProvider record id (a repeated id = an indexer/sync twin, still worth surfacing).
    genuineDupFilter = `
      AND (
        EXISTS (
          SELECT 1 FROM duplicate_records le
           WHERE le.cluster_id = dc.id AND le.record_type = 'lead'
             AND le.email IS NOT NULL AND btrim(le.email) <> ''
           GROUP BY lower(btrim(le.email))
          HAVING COUNT(*) >= 2
        )
        OR EXISTS (
          SELECT 1 FROM duplicate_records lp
           WHERE lp.cluster_id = dc.id AND lp.record_type = 'lead'
             AND lp.phone_normalized IS NOT NULL AND length(lp.phone_normalized) >= 7
           GROUP BY lp.phone_normalized
          HAVING COUNT(*) >= 2
        )
        OR EXISTS (
          SELECT 1 FROM duplicate_records lmob
           WHERE lmob.cluster_id = dc.id AND lmob.record_type = 'lead'
             AND lmob.mobile_normalized IS NOT NULL AND length(lmob.mobile_normalized) >= 7
           GROUP BY lmob.mobile_normalized
          HAVING COUNT(*) >= 2
        )
        OR EXISTS (
          SELECT 1 FROM duplicate_records ln
           WHERE ln.cluster_id = dc.id AND ln.record_type = 'lead'
             AND ln.record_name IS NOT NULL AND btrim(ln.record_name) <> ''
           -- Arabic-aware, matching the frontend _normName (ة→ه, ى→ي, آأإ→ا,
           -- drop tatweel) — same expression as the contacts gate above.
           GROUP BY lower(regexp_replace(
                      translate(btrim(ln.record_name), 'ةىأإآـ', 'هيااا'),
                      '\\s+', ' ', 'g'))
          HAVING COUNT(*) >= 2
        )
        OR EXISTS (
          SELECT 1 FROM duplicate_records li
           WHERE li.cluster_id = dc.id AND li.record_type = 'lead'
             AND li.CRMProvider_record_id IS NOT NULL AND btrim(li.CRMProvider_record_id) <> ''
           GROUP BY li.CRMProvider_record_id
          HAVING COUNT(*) >= 2
        )
      )`;
  }

  // ── Paginate by CLUSTER, not by record. ────────────────────────────────
  //
  // This view groups records into duplicate clusters, so the unit of
  // pagination must be the cluster. The previous implementation applied
  // LIMIT/OFFSET to individual `duplicate_records` rows while computing the
  // page count from the DISTINCT cluster total. Because every duplicate
  // cluster holds >=2 records, there were always more record-pages than the
  // reported cluster-page count, so the low-confidence tail of clusters was
  // unreachable and any cluster whose records straddled a page boundary was
  // split into partial groups. We instead select the page of cluster ids
  // first, then fetch ALL in-scope records for exactly those clusters.
  // A record queued for deletion (Empty-Delete or Duplicate-Delete) must NOT
  // keep showing as duplicate work, nor be compared against other records — it's
  // on its way out (Sample User 2026-06-26). Require >=2 NON-queued records of the type
  // for the cluster to still count as a duplicate, so a pair where one side is
  // already tagged for deletion drops off. Applied to the UNTOUCHED (active) view
  // ONLY — the pending-verify bucket must keep these records visible until the
  // CRM admin confirms the deletion. Effective the instant the operator tags
  // (ledger) and after sync (CRMProvider Tag).
  const hideQueued = aiStatus === "active";
  const stillTwoUntagged = hideQueued
    ? `
      AND (
        SELECT COUNT(*) FROM duplicate_records dx
         WHERE dx.cluster_id = dc.id AND dx.record_type = $1
           AND NOT ${queuedForDeletionSql("dx")}
      ) >= 2`
    : "";

  // Sort: only a whitelisted key may be interpolated (RECORD_SORT_COLUMNS),
  // and dir is validated to exactly ASC/DESC — never a raw user string.
  // Falls back to the original default (confidence DESC) when sort is
  // absent/unrecognized, so existing behavior is unchanged unless a sort is
  // explicitly selected. dc.id ASC is a stable tiebreaker so pagination
  // stays deterministic across pages even when many clusters share a value.
  const recordSortKey =
    options?.sort && RECORD_SORT_COLUMNS[options.sort]
      ? RECORD_SORT_COLUMNS[options.sort]
      : null;
  const recordSortDir = options?.dir === "asc" ? "ASC" : "DESC";
  // DEFAULT = MOST-RECENTLY-CREATED cluster first (Sample User 2026-07-06): surface the
  // newest duplications at the top so fresh dupes are caught first, then older
  // data. Ordered by the cluster's NEWEST record's created_date DESC. An explicit
  // column sort still overrides. dc.id ASC = stable pagination tiebreaker.
  const clusterOrderBy = recordSortKey
    ? `ORDER BY ${recordSortKey} ${recordSortDir} NULLS LAST, dc.id ASC`
    : `ORDER BY (SELECT MAX(dr_d.created_date) FROM duplicate_records dr_d WHERE dr_d.cluster_id = dc.id AND dr_d.record_type = $1) DESC NULLS LAST, dc.id ASC`;

  const clusterPage = await pool.query(
    `
    SELECT dc.id
    FROM duplicate_clusters dc
    WHERE dc.${countField} > 1 ${statusFilter}${mergeActionFilter}
      AND EXISTS (
        SELECT 1 FROM duplicate_records dr
        WHERE dr.cluster_id = dc.id AND dr.record_type = $1 AND dr.cleanup_class IS NULL${dateFilter}
      )${genuineDupFilter}${stillTwoUntagged}
    ${clusterOrderBy}
    LIMIT $${dateParams.length + 2} OFFSET $${dateParams.length + 3}
  `,
    [recordType, ...dateParams, limit, offset],
  );

  const clusterIds = clusterPage.rows.map((r) => r.id);

  const countResult = await pool.query(
    `
    SELECT COUNT(*) as total
    FROM duplicate_clusters dc
    WHERE dc.${countField} > 1 ${statusFilter}${mergeActionFilter}
      AND EXISTS (
        SELECT 1 FROM duplicate_records dr
        WHERE dr.cluster_id = dc.id AND dr.record_type = $1 AND dr.cleanup_class IS NULL${dateFilter}
      )${genuineDupFilter}${stillTwoUntagged}
  `,
    [recordType, ...dateParams],
  );

  if (clusterIds.length === 0) {
    return { groups: [], total: parseInt(countResult.rows[0]?.total) || 0 };
  }

  // Records filter re-anchored to $3 ($1=recordType, $2=clusterIds). Mirrors
  // the cluster-scoping fragment above so only records matching the active
  // advanced filters are returned within each in-scope cluster. dc is JOINed
  // in the records query, so confidence_level is valid here too.
  let recDateFilter = "";
  const recDateParams: any[] = [];
  if (options?.start_date) {
    recDateFilter += ` AND dr.created_date >= $${recDateParams.length + 3}`;
    recDateParams.push(options.start_date);
  }
  if (options?.end_date) {
    recDateFilter += ` AND dr.created_date <= $${recDateParams.length + 3}`;
    recDateParams.push(options.end_date + "T23:59:59Z");
  }
  if (options?.owners && options.owners.length > 0) {
    recDateFilter += ` AND dr.owner_name = ANY($${recDateParams.length + 3}::text[])`;
    recDateParams.push(options.owners);
  }
  if (options?.layouts && options.layouts.length > 0) {
    recDateFilter += ` AND dr.layout_name = ANY($${recDateParams.length + 3}::text[])`;
    recDateParams.push(options.layouts);
  }
  if (options?.pipelines && options.pipelines.length > 0) {
    recDateFilter += ` AND dr.pipeline = ANY($${recDateParams.length + 3}::text[])`;
    recDateParams.push(options.pipelines);
  }
  if (options?.stages && options.stages.length > 0) {
    recDateFilter += ` AND dr.stage = ANY($${recDateParams.length + 3}::text[])`;
    recDateParams.push(options.stages);
  }
  if (options?.confidence_level) {
    recDateFilter += ` AND dc.confidence_level = $${recDateParams.length + 3}`;
    recDateParams.push(options.confidence_level);
  }
  if (options?.domain) {
    recDateFilter += ` AND dr.domain ILIKE $${recDateParams.length + 3}`;
    recDateParams.push(`%${options.domain}%`);
  }
  // Mirror the same segment constraint on the records-fetch query so the
  // rows returned for the in-scope clusters are themselves segment-scoped
  // (the clusterIds list above already excludes out-of-segment clusters,
  // but a mixed cluster could otherwise still surface off-segment rows).
  // $1=recordType, $2=clusterIds, so offset starts at recDateParams.length+3.
  const recSegmentClause = buildSegmentPredicate(
    options?.segment,
    recDateParams.length + 3,
  );
  if (recSegmentClause.condition) {
    recDateFilter += ` AND ${recSegmentClause.condition.replace(/\br\./g, "dr.")}`;
    recDateParams.push(...recSegmentClause.params);
  }

  const result = await pool.query(
    `
    SELECT dr.*, dc.domain as cluster_domain, dc.company_name as cluster_company,
           dc.confidence_level, dc.confidence_score as cluster_confidence,
           dc.total_records as cluster_total, dc.estimated_pipeline_value,
           dc.id as cluster_id_ref
    FROM duplicate_records dr
    JOIN duplicate_clusters dc ON dr.cluster_id = dc.id
    WHERE dr.record_type = $1 AND dr.cluster_id = ANY($2::int[]) AND dr.cleanup_class IS NULL${recDateFilter}
      ${hideQueued ? `AND NOT ${queuedForDeletionSql("dr")}` : ""}
    ORDER BY dc.confidence_score DESC, dc.id ASC, dr.is_primary DESC, dr.created_date ASC
  `,
    [recordType, clusterIds, ...recDateParams],
  );

  const grouped: Record<number, any> = {};
  for (const row of result.rows) {
    const cid = row.cluster_id;
    if (!grouped[cid]) {
      grouped[cid] = {
        cluster: {
          id: cid,
          domain: row.cluster_domain,
          company_name: row.cluster_company,
          confidence_level: row.confidence_level,
          confidence_score: row.cluster_confidence,
          total_records: row.cluster_total,
          estimated_pipeline_value: row.estimated_pipeline_value,
        },
        [recordType + "s"]: [],
        duplicate_count: 0,
      };
    }
    grouped[cid][recordType + "s"].push(row);
    grouped[cid].duplicate_count++;
  }

  // Sidecar — per-cluster AI-status. Powers the new "🤖 Already AI-applied,
  // pending CRMProvider admin delete" badge on each cluster header so the operator
  // can tell apart untouched / tagged / fully-resolved clusters without
  // opening each one. One query per page (≤ ~50 clusters), aggregated by id.
  if (clusterIds.length > 0) {
    const statusRows = await pool.query(
      `SELECT dc.id, dc.status,
              COALESCE(ma.action_count, 0)        AS merge_action_count,
              COALESCE(ma.tagged_records, 0)      AS tagged_records,
              COALESCE(ma.has_pending, false)     AS has_pending,
              COALESCE(ma.has_resolved, false)    AS has_resolved,
              ma.last_merge_at
         FROM duplicate_clusters dc
         LEFT JOIN (
           SELECT cluster_id,
                  COUNT(*) AS action_count,
                  BOOL_OR(action_type = 'auto_merge_pending')               AS has_pending,
                  BOOL_OR(action_type IN ('resolve','module_resolved'))     AS has_resolved,
                  SUM(jsonb_array_length(merged_record_ids))                AS tagged_records,
                  MAX(created_at) AS last_merge_at
             FROM duplicate_merge_actions
            WHERE action_type IN ('resolve','module_resolved','auto_merge_pending')
            GROUP BY cluster_id
         ) ma ON ma.cluster_id = dc.id
        WHERE dc.id = ANY($1::int[])`,
      [clusterIds],
    );
    const byId = new Map<number, any>();
    for (const r of statusRows.rows) {
      byId.set(r.id, r);
    }
    for (const cid of clusterIds) {
      const meta = byId.get(cid);
      if (!meta || !grouped[cid]) continue;
      const taggedCount = Number(meta.tagged_records || 0);
      const actionCount = Number(meta.merge_action_count || 0);
      // SAME lifecycle as the tab filter (getDuplicateRecordsByType), Sample User
      // 2026-07-06: RESOLVED only when the cluster STATUS is actually flipped to
      // 'resolved' (Verify-in-CRM / sync-reconciled). Any apply action
      // (auto_merge_pending OR resolve/module_resolved) with the status not yet
      // resolved = AI-Applied · pending CRMProvider delete. Keeps the per-row badge in
      // sync with its tab so "Applied" never masquerades as "Resolved".
      const aiState =
        meta.status === "resolved"
          ? "resolved"
          : (meta.has_pending || meta.has_resolved)
            ? "tagged_pending_delete"
            : "untouched";
      grouped[cid].cluster.ai_state = aiState;
      grouped[cid].cluster.merge_action_count = actionCount;
      grouped[cid].cluster.tagged_records = taggedCount;
      grouped[cid].cluster.last_merge_at = meta.last_merge_at || null;
      grouped[cid].cluster.cluster_status = meta.status;
    }
  }

  return {
    groups: Object.values(grouped),
    total: parseInt(countResult.rows[0]?.total) || 0,
  };
}

// B5: JOIN-based export eliminating N+1
export async function getExportRecords(filters?: {
  owner?: string;
  start_date?: string;
  end_date?: string;
  status?: string;
}): Promise<any[]> {
  let whereClause = "WHERE 1=1";
  const params: any[] = [];
  let pi = 1;

  if (filters?.status) {
    whereClause += ` AND dc.status = $${pi++}`;
    params.push(filters.status);
  } else {
    whereClause += ` AND dc.status = 'active'`;
  }
  if (filters?.owner) {
    whereClause += ` AND (dr.owner_name = $${pi++} OR dr.owner_email = $${pi - 1})`;
    params.push(filters.owner);
  }
  if (filters?.start_date) {
    whereClause += ` AND dr.created_date >= $${pi++}`;
    params.push(filters.start_date);
  }
  if (filters?.end_date) {
    whereClause += ` AND dr.created_date <= $${pi++}`;
    params.push(filters.end_date + "T23:59:59Z");
  }

  const result = await pool.query(
    `
    SELECT dr.*, dc.domain as cluster_domain, dc.confidence_level as cluster_confidence
    FROM duplicate_records dr
    JOIN duplicate_clusters dc ON dr.cluster_id = dc.id
    ${whereClause}
    ORDER BY dc.total_records DESC, dr.cluster_id, dr.is_primary DESC
  `,
    params,
  );

  return result.rows;
}

// C5: Auto-resolution engine
export async function autoResolveClusters(): Promise<{
  singletonsIgnored: number;
  highConfidenceResolved: number;
  totalProcessed: number;
}> {
  let singletonsIgnored = 0;
  let highConfidenceResolved = 0;

  // Only auto-clean SINGLETONS (clusters left with <=1 record after deletions
  // — they are not duplicates anymore, so ignoring them is safe cleanup).
  const singletons = await pool.query(`
    SELECT id FROM duplicate_clusters WHERE total_records <= 1 AND status = 'active'
  `);
  for (const row of singletons.rows) {
    await pool.query(
      "UPDATE duplicate_clusters SET status = 'ignored', resolved_by = 'auto-resolve', resolved_at = CURRENT_TIMESTAMP WHERE id = $1",
      [row.id],
    );
    singletonsIgnored++;
  }

  // REMOVED (2026-06-12): the old high-confidence auto-resolve marked any
  // cluster with confidence_score >= 95% as 'resolved' — but high confidence
  // that two records are duplicates is NOT the same as them having been MERGED
  // in CRMProvider. This silently marked real, un-merged duplicates "Resolved",
  // locking operators out of merging them ("already resolved" guard). A cluster
  // must only become 'resolved' from an actual Apply/merge or an explicit
  // operator "Mark Resolved" after merging in CRMProvider. highConfidenceResolved
  // stays 0 to preserve the return shape for callers.

  return {
    singletonsIgnored,
    highConfidenceResolved,
    totalProcessed: singletonsIgnored + highConfidenceResolved,
  };
}

// C7: Smart AI recommendations considering completeness, deals, recency
// CRMProvider-correct recommendation engine.
//
// CRMProvider does NOT support cross-module merges (you cannot merge a Contact into an
// Account). The right action depends on the relationship between the record
// types in the cluster, not just on which one looks "best":
//
//   • same module as primary  → MERGE (native CRMProvider merge inside the module)
//   • Contact/Deal under an Account primary → LINK (set Account_Name field)
//   • Deal under a Contact primary          → LINK (set Contact_Name field)
//   • Lead when a real Account/Contact/Deal already exists → CLOSE/convert
//   • anything else (e.g. Deal vs Contact with no Account) → REVIEW manually
//
// Primary selection priority is by record type first
// (Account > Contact > Deal > Lead > Task), with quality-score breaking ties.
export type DuplicateActionType =
  | "keep"
  | "merge"
  | "link"
  | "close"
  | "review";

export interface SmartRecommendation {
  record_id: number;
  record_name: string;
  is_primary: boolean;
  recommendation: string;
  action_type: DuplicateActionType;
  confidence: number;
  reasons: string[];
}

const RECORD_TYPE_PRIORITY: Record<string, number> = {
  account: 5,
  contact: 4,
  deal: 3,
  lead: 2,
  task: 1,
};

export function generateSmartRecommendations(
  records: DuplicateRecord[],
): SmartRecommendation[] {
  if (records.length === 0) return [];

  const scored = records.map((r) => {
    let score = 0;
    const reasons: string[] = [];

    const fields = [
      r.email,
      r.phone,
      r.company_name,
      r.owner_name,
      r.source,
    ].filter(Boolean);
    const completeness = Math.round((fields.length / 5) * 100);
    score += completeness;
    if (completeness >= 80) reasons.push("High data completeness");

    if (r.record_type === "deal" && r.deal_value && r.deal_value > 0) {
      score += 30;
      reasons.push("Has active deal value");
    }

    if (r.modified_date) {
      const daysSinceModified =
        (Date.now() - new Date(r.modified_date).getTime()) /
        (1000 * 60 * 60 * 24);
      if (daysSinceModified < 30) {
        score += 20;
        reasons.push("Recently modified");
      } else if (daysSinceModified < 90) {
        score += 10;
        reasons.push("Modified in last 90 days");
      }
    }

    if (r.created_date) {
      const ageInDays =
        (Date.now() - new Date(r.created_date).getTime()) /
        (1000 * 60 * 60 * 24);
      if (ageInDays > 180) {
        score += 5;
        reasons.push("Established record (6mo+)");
      }
    }

    if (
      r.stage &&
      ["Closed Won", "Negotiation", "Proposal"].includes(r.stage)
    ) {
      score += 15;
      reasons.push(`Active deal stage: ${r.stage}`);
    }

    return { record: r, score, reasons };
  });

  // Pick primary by CRMProvider-module priority first, then by quality score.
  // Account beats Contact beats Deal beats Lead beats Task.
  scored.sort((a, b) => {
    const pa = RECORD_TYPE_PRIORITY[a.record.record_type] || 0;
    const pb = RECORD_TYPE_PRIORITY[b.record.record_type] || 0;
    if (pa !== pb) return pb - pa;
    return b.score - a.score;
  });

  const primary = scored[0].record;
  const primaryType = primary.record_type;
  const primaryScore = scored[0].score;
  const hasAccount = scored.some((s) => s.record.record_type === "account");
  const hasContact = scored.some((s) => s.record.record_type === "contact");
  const hasDeal = scored.some((s) => s.record.record_type === "deal");

  return scored.map((item, index) => {
    if (index === 0) {
      return {
        record_id: item.record.id!,
        record_name: item.record.record_name,
        is_primary: true,
        recommendation: `KEEP as primary ${primaryType} (best CRMProvider-priority + quality score)`,
        action_type: "keep" as const,
        confidence: 95,
        reasons: item.reasons,
      };
    }

    const t = item.record.record_type;
    let action: DuplicateActionType;
    let recommendation: string;

    if (t === primaryType) {
      action = "merge";
      recommendation = `MERGE into primary ${primaryType} (native CRMProvider merge — same module)`;
    } else if (
      primaryType === "account" &&
      ((t as string) === "contact" ||
        (t as string) === "deal" ||
        (t as string) === "task")
    ) {
      action = "link";
      const field =
        (t as string) === "contact" || (t as string) === "deal"
          ? "Account_Name"
          : "What_Id";
      recommendation = `LINK to primary account by setting ${field} on this ${t} (cross-module — do NOT merge)`;
    } else if (
      primaryType === "contact" &&
      ((t as string) === "deal" || (t as string) === "task")
    ) {
      action = "link";
      const field = t === "deal" ? "Contact_Name" : "Who_Id";
      recommendation = `LINK to primary contact by setting ${field} on this ${t} (cross-module — do NOT merge)`;
    } else if (t === "lead" && (hasAccount || hasContact || hasDeal)) {
      action = "close";
      recommendation =
        "CLOSE — a converted Account/Contact/Deal already exists for this company";
    } else {
      action = "review";
      recommendation = `REVIEW manually — cross-module pairing (${primaryType} ↔ ${t}) has no automatic CRMProvider action`;
    }

    return {
      record_id: item.record.id!,
      record_name: item.record.record_name,
      is_primary: false,
      recommendation,
      action_type: action,
      confidence: Math.min(95, 60 + Math.max(0, primaryScore - item.score)),
      reasons: item.reasons,
    };
  });
}

// Convenience: derive cluster-level metadata from a set of records, used by
// the cluster API responses so the UI can render cross-module banners and
// pick the right Resolve button label.
export function getClusterRecordTypeMeta(records: DuplicateRecord[]): {
  primary_type: string | null;
  is_cross_module: boolean;
  record_types: string[];
} {
  if (!records || records.length === 0) {
    return { primary_type: null, is_cross_module: false, record_types: [] };
  }
  const types = Array.from(
    new Set(records.map((r) => r.record_type).filter(Boolean)),
  );
  const sorted = [...records].sort(
    (a, b) =>
      (RECORD_TYPE_PRIORITY[b.record_type] || 0) -
      (RECORD_TYPE_PRIORITY[a.record_type] || 0),
  );
  return {
    primary_type: sorted[0].record_type,
    is_cross_module: types.length > 1,
    record_types: types,
  };
}

/**
 * R6 — Classify a cross-module cluster by which pair of record types
 * co-exist. Pure helper, exported for vitest.
 *
 * Industry context: a Lead at `<REDACTED_HOST>` representing the same person /
 * company as a Contact under the existing Example Organization Account is the most common
 * cross-module duplicate. The fix is NOT "merge" (CRMProvider doesn't support
 * cross-module merges) — it's CONVERT (the Lead becomes the Contact) or
 * LINK (set Account_Name on the deal/contact). The generateSmartRecommendations
 * helper already emits the right per-record action; this classifier groups
 * clusters by pairing type so the Cross-Module tab can filter / KPI them.
 *
 * Returns one of:
 *   lead_contact   — Lead + Contact (most common — convert lead to contact)
 *   lead_account   — Lead + Account (close the lead, link to account)
 *   lead_deal      — Lead + Deal (close the lead, deal is canonical)
 *   contact_account — Contact + Account (link Contact's Account_Name)
 *   contact_deal   — Contact + Deal (link Deal's Contact_Name)
 *   deal_account   — Deal + Account (link Deal's Account_Name)
 *   mixed          — 3 or more distinct record types (compound case)
 *   null           — same-module / not actually cross-module
 *
 * Two-module pairings use an explicit canonical ordering (Lead first, then
 * Contact, then Deal, then Account) so the same pair always maps to the
 * same key. Lead-first ordering follows operational priority: Leads are
 * net-new pipeline that need disposition, so a "Lead + something" pair is
 * always read as "what do we do with the Lead?".
 */
// ─── Cross-module lifecycle helpers ──────────────────────────────────────
//
// Sample User's refined rules (2026-06-16):
//   • Lead has no "link to Account/Contact" field in CRMProvider — the only
//     action on a Lead in a cross-module cluster is CLOSE, and that's
//     already handled by the Leads Duplicates tab. So Lead↔Contact and
//     Lead↔Account add NOISE to this tab and must be hidden.
//   • Lead↔Deal IS surfaced — only when BOTH sides are still live
//     (active Lead + active Deal = wasted prospecting effort).
//   • "Existing client" = a Paid / Agreement Signed style Deal (those
//     are CS-owned). A Contact alone is NOT customer evidence.
//   • Contact↔Account, Deal↔Account, Contact↔Deal are the real LINK
//     queue — these CAN be wired up in CRMProvider via Account_Name /
//     Contact_Name and that's the actionable work on this tab.
//
// Stage / status string sets are lowercased + frozen at module load so
// the membership check is allocation-free in the hot path. Kept in sync
// with sdrCallLinking.JUNK_LEAD_STATUSES and dealComplianceCheck stages.

const INACTIVE_LEAD_STATUSES_LOWER: ReadonlySet<string> = new Set([
  "junk lead",
  "bogus lead",
  "lost lead",
  "not qualified",
  "disqualified",
  "converted",
]);

const INACTIVE_DEAL_STAGES_LOWER: ReadonlySet<string> = new Set([
  "closed lost",
  "lost",
  "dropped",
  "cancelled",
  "canceled",
]);

const CLIENT_DEAL_STAGES_LOWER: ReadonlySet<string> = new Set([
  "paid",
  "agreement signed",
  "closed won",
  "agreement sent",
  "awaiting po",
  "client activated",
  "transferred to cs",
]);

/** A Lead is "active" when its Lead_Status is not in the disqualified /
 *  closed / converted set. Empty / null status counts as active (raw
 *  records from CRMProvider occasionally lack the field). */
export function isActiveLead(leadStatus: string | null | undefined): boolean {
  const v = String(leadStatus ?? "").trim().toLowerCase();
  if (!v) return true;
  return !INACTIVE_LEAD_STATUSES_LOWER.has(v);
}

/** A Deal is "active" when its Stage is not Closed Lost / Lost / Dropped /
 *  Cancelled. Empty / null stage counts as active. */
export function isActiveDeal(stage: string | null | undefined): boolean {
  const v = String(stage ?? "").trim().toLowerCase();
  if (!v) return true;
  return !INACTIVE_DEAL_STAGES_LOWER.has(v);
}

/** A "client deal" is one whose Stage indicates we already have this
 *  customer (Paid / Agreement Signed / Closed Won / Agreement Sent /
 *  etc.). Such clusters are CS-owned — Sales should not pursue. */
export function isClientDeal(stage: string | null | undefined): boolean {
  const v = String(stage ?? "").trim().toLowerCase();
  if (!v) return false;
  return CLIENT_DEAL_STAGES_LOWER.has(v);
}

export type CrossModulePairing =
  | "lead_contact"
  | "lead_account"
  | "lead_deal"
  | "contact_account"
  | "contact_deal"
  | "deal_account"
  | "mixed";

// Explicit lookup: hasLead × hasContact × hasAccount × hasDeal → key.
// Keeps the type union in lock-step with what the classifier returns.
const CROSS_MODULE_PAIRING_LOOKUP: Record<string, CrossModulePairing> = {
  "lead+contact": "lead_contact",
  "lead+account": "lead_account",
  "lead+deal": "lead_deal",
  "contact+account": "contact_account",
  "contact+deal": "contact_deal",
  "deal+account": "deal_account",
};

export function classifyCrossModulePairing(input: {
  total_leads: number;
  total_contacts: number;
  total_accounts: number;
  total_deals: number;
}): CrossModulePairing | null {
  const present: string[] = [];
  if ((input.total_leads ?? 0) > 0) present.push("lead");
  if ((input.total_contacts ?? 0) > 0) present.push("contact");
  if ((input.total_deals ?? 0) > 0) present.push("deal");
  if ((input.total_accounts ?? 0) > 0) present.push("account");
  if (present.length <= 1) return null;
  if (present.length >= 3) return "mixed";
  // Exactly two — the priority push order above (lead, contact, deal,
  // account) guarantees they're already in canonical order when joined.
  const key = present.join("+");
  return CROSS_MODULE_PAIRING_LOOKUP[key] ?? "mixed";
}

export interface CrossModuleClusterRow {
  id: number;
  domain: string | null;
  company_name: string | null;
  confidence_score: number;
  confidence_level: "high" | "medium" | "low";
  total_records: number;
  total_leads: number;
  total_contacts: number;
  total_accounts: number;
  total_deals: number;
  pairing: CrossModulePairing | null;
  estimated_pipeline_value: number;
  status: string;
  cross_module_handled_at?: Date | null;
  created_at: Date | null;
  updated_at: Date | null;
  // Per-record dimensions aggregated from duplicate_records so the dashboard's
  // Advanced Filters (Owner / Module / Stage / Layout / Pipeline) can match a
  // cross-module CLUSTER by what its member records hold. Owner/Stage/etc. live
  // on records, not the cluster, so without these the filters silently no-op.
  modules_present?: string[]; // e.g. ["lead","deal"]
  owners?: string[];
  owner_name?: string; // owners joined — the substring matcher reads this
  stages?: string[]; // Deal stages present in the cluster
  layouts?: string[];
  pipelines?: string[];
  // Refined-rule lifecycle flags (Sample User 2026-06-16). Derived from the
  // member records' Lead_Status / Stage so the tab can reason in business
  // terms (active vs. dead Lead, active vs. dead Deal, existing client).
  has_active_lead?: boolean;
  has_active_deal?: boolean;
  has_client_deal?: boolean;
  // True when ALL modules present in the cluster have a matching entry in
  // duplicate_resolution_ledger — i.e. the operator already clicked Mark
  // Handled on this overlap on a prior cluster row, and the next 6h sync
  // re-clustered the records into a new row that lost the status flag.
  // The tab treats these as "effectively resolved" and hides them from
  // the Open queue even though duplicate_clusters.status='active'.
  ledger_resolved?: boolean;
}

export interface CrossModuleOverlapsResponse {
  total: number;
  by_pairing: Record<string, number>;
  // Action-oriented counts that power the headline tiles. A single cluster
  // can fall into multiple buckets (a 3+ modules cluster might be both a
  // Lead↔ActiveDeal AND a Deal↔Account link gap) — this is intentional:
  // each tile asks a different operator question.
  by_action: {
    lead_vs_active_deal: number;
    contact_account_link: number;
    deal_account_link: number;
    contact_deal_link: number;
    three_plus_modules: number;
    existing_client_cs_owned: number;
  };
  arr_exposure_total: number;
  clusters: CrossModuleClusterRow[];
}

/**
 * R6 — Fetch active clusters that span 2+ record types ("cross-module
 * overlaps") with per-pairing counts.
 *
 * Definition: at least two of total_leads/contacts/accounts/deals are > 0.
 * Filtering: status='active' so resolved/ignored clusters drop off the
 * triage queue. Optional `pairing` filter applies a post-query JS filter
 * (the SQL aggregates produce all pairings; trimming after is cheap given
 * the result set is bounded by `limit`).
 *
 * Returns the FULL set of active cross-module clusters by default (the previous
 * 200 cap silently hid real overlaps). The dashboard paginates client-side, so
 * returning everything is fine. `limit` defaults to "all" and is clamped to a
 * 100,000 safety ceiling to guard against a pathological payload.
 */
export async function getCrossModuleOverlaps(opts: {
  limit?: number;
  pairing?: CrossModulePairing | null;
  /** Which lifecycle status to return: 'active' (default, the open queue),
   *  'resolved' (whole cluster resolved), 'ignored' (dismissed), 'handled'
   *  (module-scoped: cross_module_handled_at IS NOT NULL, cluster itself
   *  still 'active' — see markCrossModuleHandled), or 'all'. */
  status?: "active" | "resolved" | "ignored" | "handled" | "all";
  /** Marketplace / ExampleOrg / Example Organization segment chip. Filters clusters by the
   *  layouts present on their member records (c.layouts). undefined/'all' = no
   *  filter. Mirrors buildSegmentPredicate's layout semantics. */
  segment?: DuplicateFilters["segment"];
} = {}): Promise<CrossModuleOverlapsResponse> {
  const CROSS_MODULE_MAX = 100000;
  const limit = Math.min(
    CROSS_MODULE_MAX,
    Math.max(1, Math.floor(opts.limit ?? CROSS_MODULE_MAX) || CROSS_MODULE_MAX),
  );
  const statusOpt = opts.status ?? "active";
  // Parameterised status clause; 'all' drops the filter entirely.
  // 'handled' is NOT a cluster.status value — it's the module-scoped
  // cross_module_handled_at column on an otherwise-'active' cluster, so it
  // filters on status='active' (same base population as the open queue)
  // and flips the handled-column condition below.
  const statusClause =
    statusOpt === "all"
      ? "TRUE"
      : statusOpt === "handled"
        ? "duplicate_clusters.status = 'active'"
        : statusOpt === "resolved"
          // Merged view (Sample User 2026-07-04): the operator sees NO difference
          // between "handled" and "resolved" on this tab, so "Resolved" returns
          // BOTH — whole-cluster resolved OR cross-module marked-done (handled).
          ? "(duplicate_clusters.status = 'resolved' OR (duplicate_clusters.status = 'active' AND duplicate_clusters.cross_module_handled_at IS NOT NULL))"
          : "duplicate_clusters.status = $2";
  const params: any[] =
    statusOpt === "all" || statusOpt === "handled" || statusOpt === "resolved"
      ? [limit]
      : [limit, statusOpt];
  const r = await pool.query<CrossModuleClusterRow>(
    `
    SELECT
      id, domain, company_name,
      confidence_score, confidence_level,
      total_records,
      total_leads, total_contacts, total_accounts, total_deals,
      COALESCE(estimated_pipeline_value, 0)::numeric AS estimated_pipeline_value,
      status, cross_module_handled_at, created_at, updated_at
    FROM duplicate_clusters
    WHERE ${statusClause}
      AND (
        ${statusOpt === "handled"
          ? "duplicate_clusters.cross_module_handled_at IS NOT NULL"
          : statusOpt === "active"
            ? "duplicate_clusters.cross_module_handled_at IS NULL"
            : "TRUE"}
      )
      AND (
        ${statusOpt === "active"
          ? `(CASE WHEN EXISTS (SELECT 1 FROM duplicate_records dr WHERE dr.cluster_id = duplicate_clusters.id AND dr.record_type = 'lead'    AND dr.cleanup_class IS NULL AND NOT ${queuedForDeletionSql("dr")}) THEN 1 ELSE 0 END +
         CASE WHEN EXISTS (SELECT 1 FROM duplicate_records dr WHERE dr.cluster_id = duplicate_clusters.id AND dr.record_type = 'contact' AND dr.cleanup_class IS NULL AND NOT ${queuedForDeletionSql("dr")}) THEN 1 ELSE 0 END +
         CASE WHEN EXISTS (SELECT 1 FROM duplicate_records dr WHERE dr.cluster_id = duplicate_clusters.id AND dr.record_type = 'account' AND dr.cleanup_class IS NULL AND NOT ${queuedForDeletionSql("dr")}) THEN 1 ELSE 0 END +
         CASE WHEN EXISTS (SELECT 1 FROM duplicate_records dr WHERE dr.cluster_id = duplicate_clusters.id AND dr.record_type = 'deal'    AND dr.cleanup_class IS NULL AND NOT ${queuedForDeletionSql("dr")}) THEN 1 ELSE 0 END`
          : `(CASE WHEN total_leads > 0 THEN 1 ELSE 0 END +
         CASE WHEN total_contacts > 0 THEN 1 ELSE 0 END +
         CASE WHEN total_accounts > 0 THEN 1 ELSE 0 END +
         CASE WHEN total_deals > 0 THEN 1 ELSE 0 END`}
        ) >= 2
      )
    ORDER BY total_records DESC, confidence_score DESC
    LIMIT $1
    `,
    params,
  );

  const all = r.rows.map((row) => ({
    ...row,
    estimated_pipeline_value: Number(row.estimated_pipeline_value ?? 0),
    pairing: classifyCrossModulePairing({
      total_leads: Number(row.total_leads ?? 0),
      total_contacts: Number(row.total_contacts ?? 0),
      total_accounts: Number(row.total_accounts ?? 0),
      total_deals: Number(row.total_deals ?? 0),
    }),
  }));

  // Drop placeholder / quarantine buckets — these are NOT real cross-module
  // overlaps. `_placeholder.cluster` is the single quarantine bucket for blank /
  // placeholder company names, and any cluster whose company name is itself a
  // placeholder (N/A, "Not Provided", …) is CS name-quality noise, not one
  // company to CONVERT/LINK. They'd otherwise inflate Total open + ARR with
  // thousands of unrelated records. Genuine no-domain clusters (a real company
  // that simply has no domain, e.g. "جباس") are KEPT.
  const realOverlaps = all.filter(
    (c) =>
      c.domain !== PLACEHOLDER_CLUSTER_DOMAIN &&
      !isPlaceholderName(c.company_name),
  );

  // Aggregate the per-record dimensions (owner / module / deal-stage / layout /
  // pipeline) onto each cluster so the dashboard's Advanced Filters can match a
  // cross-module cluster by what its member records hold. One grouped query over
  // the already-bounded cluster set — owner_name is a column; stage/layout/
  // pipeline are read out of raw_data (Layout arrives as { name }). Best-effort:
  // any failure just leaves the dimensions empty (filters skip them, no crash).
  //
  // Also derives the refined-rule lifecycle flags inline:
  //   • has_active_lead / has_active_deal / has_client_deal — drive the
  //     Lead↔ActiveDeal filter + the "Existing client → CS" badge.
  //   • modules_ledger_resolved — which of the cluster's modules already
  //     have a matching `duplicate_resolution_ledger` entry. When every
  //     module-present has a ledger match, the cluster is "effectively
  //     resolved" (the operator clicked Mark Handled on a prior incarnation
  //     of this cluster before the 6h sync re-clustered) and must drop
  //     out of the Open queue.
  if (realOverlaps.length > 0) {
    try {
      const ids = realOverlaps.map((c) => c.id);
      const agg = await pool.query(
        `SELECT cluster_id,
                COUNT(*) FILTER (WHERE record_type = 'lead')    AS real_leads,
                COUNT(*) FILTER (WHERE record_type = 'contact') AS real_contacts,
                COUNT(*) FILTER (WHERE record_type = 'account') AS real_accounts,
                COUNT(*) FILTER (WHERE record_type = 'deal')    AS real_deals,
                array_agg(DISTINCT record_type)
                  FILTER (WHERE record_type IS NOT NULL)                       AS modules_present,
                array_agg(DISTINCT owner_name)
                  FILTER (WHERE owner_name IS NOT NULL AND owner_name <> '')   AS owners,
                array_agg(DISTINCT (raw_data->>'Stage'))
                  FILTER (WHERE record_type = 'deal'
                          AND COALESCE(raw_data->>'Stage','') <> '')           AS stages,
                array_agg(DISTINCT COALESCE(raw_data#>>'{Layout,name}', raw_data->>'Layout'))
                  FILTER (WHERE COALESCE(raw_data#>>'{Layout,name}', raw_data->>'Layout','') <> '') AS layouts,
                array_agg(DISTINCT (raw_data->>'Pipeline'))
                  FILTER (WHERE COALESCE(raw_data->>'Pipeline','') <> '')      AS pipelines,
                array_agg(DISTINCT LOWER(COALESCE(raw_data->>'Lead_Status','')))
                  FILTER (WHERE record_type = 'lead')                          AS lead_statuses,
                array_agg(DISTINCT LOWER(COALESCE(raw_data->>'Stage','')))
                  FILTER (WHERE record_type = 'deal')                          AS deal_stages_lower,
                array_agg(DISTINCT record_type)
                  FILTER (WHERE EXISTS (
                    SELECT 1 FROM duplicate_resolution_ledger lg
                    WHERE lg.master_CRMProvider_id = duplicate_records.CRMProvider_record_id
                      AND lg.module = CASE duplicate_records.record_type
                                        WHEN 'lead'    THEN 'Leads'
                                        WHEN 'deal'    THEN 'Deals'
                                        WHEN 'contact' THEN 'Contacts'
                                        WHEN 'account' THEN 'Accounts'
                                      END
                      AND lg.action_type IN ('resolve','module_resolved')
                  ))                                                            AS modules_ledger_resolved
           FROM duplicate_records
          WHERE cluster_id = ANY($1::int[]) AND cleanup_class IS NULL
          GROUP BY cluster_id`,
        [ids],
      );
      const byId = new Map<number, any>();
      for (const row of agg.rows) byId.set(Number(row.cluster_id), row);
      for (const c of realOverlaps as any[]) {
        const a = byId.get(c.id);
        if (!a) continue;
        // Overwrite the denormalized duplicate_clusters totals with REAL
        // (cleanup_class IS NULL) per-type counts so isActionable/byAction/
        // matchesPairingChip below judge the cluster's cross-module status
        // on genuine records only, not cleanup (empty/test/junk/tagged) ones.
        c.total_leads = Number(a.real_leads ?? 0);
        c.total_contacts = Number(a.real_contacts ?? 0);
        c.total_accounts = Number(a.real_accounts ?? 0);
        c.total_deals = Number(a.real_deals ?? 0);
        c.modules_present = a.modules_present ?? [];
        c.owners = a.owners ?? [];
        c.owner_name = (a.owners ?? []).join(", ");
        c.stages = a.stages ?? [];
        c.layouts = a.layouts ?? [];
        c.pipelines = a.pipelines ?? [];

        // Lifecycle flags (string sets already lowercased by the SQL).
        const leadStatuses: string[] = a.lead_statuses ?? [];
        const dealStagesLower: string[] = a.deal_stages_lower ?? [];
        c.has_active_lead =
          (Number(c.total_leads) || 0) > 0 &&
          (leadStatuses.length === 0
            ? true // no statuses captured → assume active (raw_data gap)
            : leadStatuses.some((s) => isActiveLead(s)));
        c.has_active_deal =
          (Number(c.total_deals) || 0) > 0 &&
          (dealStagesLower.length === 0
            ? true
            : dealStagesLower.some((s) => isActiveDeal(s)));
        c.has_client_deal =
          (Number(c.total_deals) || 0) > 0 &&
          dealStagesLower.some((s) => isClientDeal(s));

        // Ledger-resolved heuristic: every module present in the cluster
        // has a matching ledger entry. Empty cluster (no modules) doesn't
        // qualify (nothing to be resolved AGAINST).
        const modulesPresent: string[] = c.modules_present ?? [];
        const modulesLedgerResolved: string[] = a.modules_ledger_resolved ?? [];
        c.ledger_resolved =
          modulesPresent.length > 0 &&
          modulesLedgerResolved.length > 0 &&
          modulesPresent.every((m: string) =>
            modulesLedgerResolved.includes(m),
          );
      }
    } catch (e) {
      logger.warn(
        "[DuplicateRadar] cross-module dimension aggregation failed (filters will skip those dims)",
        { error: e instanceof Error ? e.message : String(e) },
      );
    }
  }

  // ─── Refined-rule filter (Sample User 2026-06-16) ───────────────────────────
  //
  // Hide clusters whose ONLY cross-module relationship is Lead↔Contact or
  // Lead↔Account — those have no CRMProvider action available on this tab (a
  // Lead can't be linked to anything), and CLOSE-the-Lead is the job of
  // the Leads Duplicates tab anyway. Keep the cluster if ANY of these
  // actionable conditions are true:
  //   • Active Lead alongside an active Deal (wasted prospecting).
  //   • Contact + Account (potential Account_Name link gap).
  //   • Deal + Account (potential Account_Name link gap).
  //   • Contact + Deal (potential Contact_Name link gap).
  //
  // Also drop "effectively resolved" clusters from the Open queue (status
  // 'active' callers only) — these are clusters where the survivor records
  // are all in the resolution ledger, meaning a prior Mark Handled click
  // is being re-displayed because the 6h sync re-clustered.
  // Live-conflict-only rule (Sample User 2026-07-13 "this cluster has no overlap").
  // The old rule flipped a cluster to actionable on bare CO-PRESENCE of
  // contact+account / deal+account / contact+deal — but a Contact and its
  // Account (or a Deal under its Account) for ONE company is the NORMAL CRM
  // hierarchy, not an overlap, and those 2-module LINK gaps moved to the Record
  // Hint tab anyway. It also ignored lifecycle, so a Closed Lost deal + a Not
  // Qualified lead (both DEAD) still counted. Result: legit account hierarchies
  // sprinkled with dead records showed as "3+ modules compound cases".
  //
  // A cross-module cluster is now actionable ONLY on a genuine LIVE conflict —
  // dead records never create work here (has_active_* already exclude Closed
  // Lost/Lost/Dropped deals and Not Qualified/Junk/Lost/Converted leads):
  //   1. An ACTIVE lead is still being worked while the same company already
  //      exists as a real account / contact / active deal → CLOSE the redundant
  //      lead (wasted prospecting on an already-converted company).
  //   2. An existing-CLIENT deal (Paid / Agreement Signed / Closed Won / …)
  //      coexists with an active Sales deal or an active lead → CS conflict,
  //      route to Customer Success.
  // A plain Account + Contacts + Deals hierarchy with no active stray lead and
  // no client-vs-sales conflict is a legitimate hierarchy → hidden.
  const isActionable = (c: any): boolean => {
    const activeLead = !!c.has_active_lead; // implies total_leads > 0
    const activeDeal = !!c.has_active_deal; // implies total_deals > 0
    // A cross-module ALERT is ONLY a genuine LEAD ↔ DEAL conflict (Sample User
    // 2026-07-15): an ACTIVE lead AND an ACTIVE deal for the same company
    // coexisting — Sales is prospecting via a lead while a live deal already
    // exists → CLOSE the redundant lead. Contacts/Accounts are NEVER the
    // conflict; they're the expected hierarchy. So these are NOT cross-module:
    //   • Lead + Contact + Account, no deal   → an unconverted prospect + its
    //     records (nothing to reconcile until there's a deal to conflict with);
    //   • Deal + Contact + Account, no lead    → a normal account hierarchy /
    //     success story;
    //   • Contact + Account (± Deal), no active lead → normal hierarchy.
    // 2-module link gaps live on the Record Hint tab; open-sales-vs-client-deal
    // CS conflicts live on the CS Pipeline Overlap tab.
    return activeLead && activeDeal;
  };
  // Segment chip (Marketplace / ExampleOrg / Example Organization) — Sample User 2026-07-13: the chip
  // never reached this tab. Filter by the layouts present on the cluster's member
  // records (c.layouts, aggregated above). Marketplace = a Marketplace/Partner
  // Accounts layout present; Example Organization = a Example Organization layout present; ExampleOrg = a
  // corporate layout present (neither of those) OR no layout at all (legacy
  // default). Mirrors the server buildSegmentPredicate layout semantics.
  const _segNorm = (v: any) =>
    String(v ?? "").toLowerCase().replace(/[^a-z0-9]/g, "");
  const segMatch = (c: any): boolean => {
    const seg = opts.segment;
    if (!seg || seg === "all") return true;
    const layouts: string[] = Array.isArray(c.layouts) ? c.layouts : [];
    // Marketplace = layout CONTAINS "marketplace" (e.g. "Doam Marketplace") or
    // "partneraccounts" — substring, not exact (Sample User 2026-07-15). Mirrors the
    // SQL buildSegmentPredicate so this JS path segments identically.
    const _isMktLayout = (v: any) => {
      const n = _segNorm(v);
      return n.includes("marketplace") || n.includes("partneraccounts");
    };
    const isMkt = layouts.some(_isMktLayout);
    const isW1 = layouts.some((v) => _segNorm(v).includes("Example Organization"));
    if (seg === "marketplace") return isMkt;
    if (seg === "Example Organization") return isW1;
    // ExampleOrg / corporate: a corporate record present, or no layout at all.
    return (
      layouts.length === 0 ||
      layouts.some((v) => !_isMktLayout(v) && !_segNorm(v).includes("Example Organization"))
    );
  };

  const visible = realOverlaps.filter((c) => {
    if (!isActionable(c)) return false;
    if (!segMatch(c)) return false;
    if (statusOpt === "active" && (c as any).ledger_resolved) return false;
    // The Record Hint tab now owns the 3 strict 2-module LINKING pairings
    // (Contact↔Account, Contact↔Deal, Deal↔Account) — a cluster classified
    // as EXACTLY one of those no longer belongs on Cross-Module. `mixed`
    // (3+ modules) stays even if it contains one of those relationships,
    // since it's genuinely a compound cross-module case owned here.
    if (
      c.pairing === "contact_account" ||
      c.pairing === "contact_deal" ||
      c.pairing === "deal_account"
    )
      return false;
    return true;
  });

  // Pairing chip filter: a chip click sends pairing=lead_deal /
  // contact_account / etc. Under the refined rules a "Contact ↔ Account"
  // chip should ALSO include 3+ modules clusters that carry a Contact +
  // Account pair, not just the strict 2-module case. Likewise Lead ↔
  // Active Deal must require BOTH sides active. The match table below
  // mirrors the headline-tile semantics so chip filtering and tile
  // counts agree.
  const matchesPairingChip = (c: any, pairing: CrossModulePairing): boolean => {
    const leads = Number(c.total_leads || 0);
    const deals = Number(c.total_deals || 0);
    switch (pairing) {
      case "lead_deal":
        return (
          leads > 0 &&
          deals > 0 &&
          !!c.has_active_lead &&
          !!c.has_active_deal
        );
      case "mixed":
        return c.pairing === "mixed";
      // lead_contact / lead_account / contact_account / contact_deal /
      // deal_account chips are deprecated on this tab — the latter 3 now
      // live on the Record Hint tab (see the `visible` filter above, which
      // already drops those pairings from this endpoint's result set), and
      // lead_contact/lead_account never had a CRMProvider action here. The chip
      // filters never match; the frontend hides those chips entirely — this
      // just makes the backend safe if a stale client still sends them.
      case "lead_contact":
      case "lead_account":
      case "contact_account":
      case "contact_deal":
      case "deal_account":
        return false;
      default:
        return false;
    }
  };
  const filtered = opts.pairing
    ? visible.filter((c) => matchesPairingChip(c, opts.pairing!))
    : visible;

  // Counts: by_pairing keeps shape for back-compat (AssistantPersona tool etc.) but
  // is now computed over `visible` (the actionable set), so lead_contact
  // and lead_account always read 0 — operators should look at by_action.
  const byPairing: Record<string, number> = {};
  let arrTotal = 0;
  for (const c of visible) {
    const key = c.pairing ?? "unknown";
    byPairing[key] = (byPairing[key] ?? 0) + 1;
    arrTotal += Number(c.estimated_pipeline_value ?? 0);
  }
  const byAction = {
    lead_vs_active_deal: 0,
    contact_account_link: 0,
    deal_account_link: 0,
    contact_deal_link: 0,
    three_plus_modules: 0,
    existing_client_cs_owned: 0,
  };
  for (const c of visible as any[]) {
    const leads = Number(c.total_leads || 0);
    const contacts = Number(c.total_contacts || 0);
    const accounts = Number(c.total_accounts || 0);
    const deals = Number(c.total_deals || 0);
    if (
      leads > 0 &&
      deals > 0 &&
      c.has_active_lead &&
      c.has_active_deal
    )
      byAction.lead_vs_active_deal++;
    if (contacts > 0 && accounts > 0) byAction.contact_account_link++;
    if (deals > 0 && accounts > 0) byAction.deal_account_link++;
    if (contacts > 0 && deals > 0) byAction.contact_deal_link++;
    if (c.pairing === "mixed") byAction.three_plus_modules++;
    if (c.has_client_deal) byAction.existing_client_cs_owned++;
  }

  return {
    total: filtered.length,
    by_pairing: byPairing,
    by_action: byAction,
    arr_exposure_total: arrTotal,
    clusters: filtered,
  };
}

/**
 * Follow-up 3 — Bulk-close lead records in cross-module clusters.
 *
 * Context: cross-module clusters (R6) have a Lead alongside a Contact /
 * Account / Deal for the same domain. CRMProvider doesn't support cross-module
 * merges, so the recommended action is to CLOSE the lead — the company
 * is already represented by the canonical Account / Contact / Deal.
 * Operators were doing this one-by-one in CRMProvider; this helper does it in
 * bulk via the CRMProvider update-record API.
 *
 * Per cluster:
 *   1. Fetch the cluster's lead records (record_type='lead', has CRMProvider_record_id)
 *   2. For each lead, call CRMProvider `PUT /Leads/:id` with
 *      Lead_Status='Lost Lead' + a Description note explaining why.
 *      Already-Lost / already-Junk leads are skipped silently (idempotent).
 *   3. If every lead update succeeded, mark the cluster resolved via
 *      resolveCluster — this also captures a pre-resolve snapshot (R10)
 *      and logs the action in duplicate_merge_actions.
 *   4. If any lead update failed, the cluster is NOT marked resolved —
 *      partial-failure state is reported back so the operator can retry.
 *
 * Safety:
 *   - clusterIds is REQUIRED — callers explicitly enumerate which
 *     clusters to act on (no "close everything matching this filter").
 *   - maxClusters hard-clamps the batch size at 25 (default).
 *   - dryRun=true returns the per-cluster plan without writing.
 *   - Concurrency 3 — CRMProvider rate limits are real.
 */
export interface BulkCloseLeadResult {
  cluster_id: number;
  leads_closed: number;
  leads_skipped: number;
  leads_failed: number;
  cluster_resolved: boolean;
  errors: Array<{ CRMProvider_lead_id: string; message: string }>;
  notes: string;
}

export async function bulkCloseLeadsInClusters(opts: {
  clusterIds: number[];
  performedBy: string;
  dryRun?: boolean;
  maxClusters?: number;
}): Promise<{
  dry_run: boolean;
  examined: number;
  total_leads_closed: number;
  total_leads_skipped: number;
  total_leads_failed: number;
  clusters_resolved: number;
  per_cluster: BulkCloseLeadResult[];
}> {
  const dryRun = !!opts.dryRun;
  const cap = Math.min(25, Math.max(1, opts.maxClusters ?? 25));
  const ids = Array.isArray(opts.clusterIds)
    ? opts.clusterIds.slice(0, cap)
    : [];

  if (ids.length === 0) {
    return {
      dry_run: dryRun,
      examined: 0,
      total_leads_closed: 0,
      total_leads_skipped: 0,
      total_leads_failed: 0,
      clusters_resolved: 0,
      per_cluster: [],
    };
  }

  const { updateCRMProviderRecord, CRMProviderWritesAllowedInEnv } = await import("./CRMProviderCRM");

  // Env guardrail: bulk-close mutates live CRMProvider (Lead_Status → Lost Lead), so
  // a REAL run must be blocked outside production (dev shares prod's CRMProvider
  // credentials). Dry-run is always allowed (it writes nothing).
  if (!dryRun && !CRMProviderWritesAllowedInEnv()) {
    throw new Error(
      "Bulk-close is blocked outside production (dev shares production's CRMProvider credentials). " +
        "Run it from the deployed app, or set RESOLUTION_ALLOW_WRITES_OUTSIDE_PROD=true only for a dedicated non-prod CRMProvider org.",
    );
  }

  const closeOneLead = async (
    CRMProviderLeadId: string,
    clusterId: number,
    currentStatus: string | null,
  ): Promise<{ status: "closed" | "skipped" | "failed"; message?: string }> => {
    // Idempotency: skip leads already in a Lost / Junk terminal state so
    // re-running the batch doesn't spam CRMProvider with no-op updates.
    const lower = (currentStatus ?? "").trim().toLowerCase();
    if (lower === "lost lead" || lower === "junk lead") {
      return { status: "skipped", message: `Already ${currentStatus}` };
    }
    if (dryRun) return { status: "closed" }; // count as "would-close" in dry run
    try {
      await updateCRMProviderRecord("Leads", CRMProviderLeadId, {
        Lead_Status: "Lost Lead",
        Description: `Closed by Duplicate Radar bulk-close on cross-module cluster #${clusterId}. The company is represented in another module (Account / Contact / Deal) and a duplicate Lead is no longer needed.`,
      });
      return { status: "closed" };
    } catch (err) {
      return {
        status: "failed",
        message: (err as Error)?.message ?? String(err),
      };
    }
  };

  const perCluster: BulkCloseLeadResult[] = [];

  for (const clusterId of ids) {
    const leadsR = await pool.query<{
      id: number;
      CRMProvider_record_id: string | null;
      status: string | null;
    }>(
      `SELECT id, CRMProvider_record_id, status
         FROM duplicate_records
        WHERE cluster_id = $1
          AND record_type = 'lead'
          AND CRMProvider_record_id IS NOT NULL
          AND CRMProvider_record_id <> ''`,
      [clusterId],
    );

    const leads = leadsR.rows;
    if (leads.length === 0) {
      perCluster.push({
        cluster_id: clusterId,
        leads_closed: 0,
        leads_skipped: 0,
        leads_failed: 0,
        cluster_resolved: false,
        errors: [],
        notes: "No lead records with CRMProvider_record_id in this cluster",
      });
      continue;
    }

    const concurrency = 3;
    let closed = 0;
    let skipped = 0;
    let failed = 0;
    const errors: BulkCloseLeadResult["errors"] = [];

    for (let i = 0; i < leads.length; i += concurrency) {
      const batch = leads.slice(i, i + concurrency);
      const results = await Promise.all(
        batch.map((l) => closeOneLead(l.CRMProvider_record_id!, clusterId, l.status)),
      );
      for (let j = 0; j < results.length; j++) {
        const r = results[j]!;
        const lead = batch[j]!;
        if (r.status === "closed") closed++;
        else if (r.status === "skipped") skipped++;
        else {
          failed++;
          errors.push({
            CRMProvider_lead_id: lead.CRMProvider_record_id ?? "",
            message: r.message ?? "Unknown error",
          });
        }
      }
    }

    // Mark cluster resolved only when every lead either closed cleanly
    // or was already-skipped. A single failure leaves the cluster active
    // so the operator can investigate / retry without losing visibility.
    let clusterResolved = false;
    const allClean = failed === 0;
    if (allClean && !dryRun) {
      try {
        await resolveCluster(
          clusterId,
          "resolve",
          opts.performedBy,
          undefined,
          `Bulk-close: closed ${closed} lead${closed === 1 ? "" : "s"} in CRMProvider (cross-module cluster — company represented in another module)`,
        );
        clusterResolved = true;
      } catch (err) {
        // resolveCluster failing after the CRMProvider writes succeeded is a
        // partial state; surface the error but the leads ARE closed in
        // CRMProvider already. Operator can mark the cluster resolved manually.
        errors.push({
          CRMProvider_lead_id: "",
          message: `Cluster mark-resolved failed after CRMProvider updates: ${(err as Error).message}`,
        });
      }
    }

    perCluster.push({
      cluster_id: clusterId,
      leads_closed: closed,
      leads_skipped: skipped,
      leads_failed: failed,
      cluster_resolved: clusterResolved,
      errors,
      notes: dryRun
        ? `Dry run — would close ${closed} lead${closed === 1 ? "" : "s"} (${skipped} already-closed skipped)`
        : `Closed ${closed} lead${closed === 1 ? "" : "s"}, skipped ${skipped}, failed ${failed}`,
    });
  }

  const totalClosed = perCluster.reduce((a, c) => a + c.leads_closed, 0);
  const totalSkipped = perCluster.reduce((a, c) => a + c.leads_skipped, 0);
  const totalFailed = perCluster.reduce((a, c) => a + c.leads_failed, 0);
  const clustersResolved = perCluster.filter((c) => c.cluster_resolved).length;

  return {
    dry_run: dryRun,
    examined: ids.length,
    total_leads_closed: totalClosed,
    total_leads_skipped: totalSkipped,
    total_leads_failed: totalFailed,
    clusters_resolved: clustersResolved,
    per_cluster: perCluster,
  };
}

export async function getSyncState(
  module: string,
): Promise<CRMProviderSyncState | null> {
  const result = await pool.query(
    "SELECT * FROM CRMProvider_sync_state WHERE module = $1",
    [module],
  );
  return result.rows[0] || null;
}

export async function getAllSyncStates(): Promise<CRMProviderSyncState[]> {
  // Tasks module was removed platform-wide; filter out any stale rows so the
  // Sync Status badges only reflect modules we actively sync.
  const result = await pool.query(
    "SELECT * FROM CRMProvider_sync_state WHERE module NOT IN ('Tasks') ORDER BY module",
  );
  return result.rows;
}

/**
 * Record a module's sync state.
 *
 * `last_sync_at` is the INCREMENTAL WATERMARK — the next run asks CRMProvider for
 * records modified since it (If-Modified-Since). So it may only advance when a
 * sync actually COMPLETED.
 *
 * It used to be set to NOW() on every call, including the `syncing` mark at the
 * start of a run and the `failed` mark at the end. A sync that died partway had
 * therefore already moved the watermark to its own start time, and the next
 * incremental run asked for "changes since the moment the failed run began" —
 * so every record modified before that point was silently never fetched. The
 * same call also zeroed `total_synced`, which is why Accounts sat at
 * "0 (syncing)" for hours (observed 2026-08-19: Accounts stuck since 18:43
 * while Contacts, Deals and Leads all completed).
 *
 * On a non-completing status the watermark and the count are left exactly as
 * they were, so a failed run costs nothing but time.
 */
export async function upsertSyncState(
  module: string,
  totalSynced: number,
  status: string,
): Promise<void> {
  const completed = status === "completed";
  // Every placeholder is cast explicitly. $3 is both assigned to sync_status
  // (varchar, from the column) and compared to a literal (text, from the
  // operator) — Postgres deduces one type per parameter across the whole
  // statement and errors with "inconsistent types deduced for parameter $3"
  // rather than picking one. This is the first query a module sync runs, so
  // without the casts no sync starts at all.
  await pool.query(
    `INSERT INTO CRMProvider_sync_state (module, last_sync_at, total_synced, sync_status, sync_started_at)
     VALUES ($1::text, CASE WHEN $4::boolean THEN NOW() ELSE NULL END, $2::int, $3::text,
             CASE WHEN $3::text = 'syncing' THEN NOW() ELSE NULL END)
     ON CONFLICT (module) DO UPDATE SET
       last_sync_at = CASE WHEN $4::boolean THEN NOW() ELSE CRMProvider_sync_state.last_sync_at END,
       total_synced = CASE WHEN $4::boolean THEN $2::int ELSE CRMProvider_sync_state.total_synced END,
       sync_status  = $3::text,
       sync_started_at = CASE
         WHEN $3::text = 'syncing' THEN NOW()
         ELSE CRMProvider_sync_state.sync_started_at END`,
    [module, totalSynced, status, completed],
  );
}

/**
 * How long a `syncing` row may sit before it is treated as abandoned.
 *
 * Nothing gates on sync_status, so a stale row does not block the next run —
 * but it does tell an operator the module is working when the process behind it
 * died at a deploy or a timeout. Reported, not silently rewritten.
 */
export const SYNC_STALE_AFTER_MS = 30 * 60 * 1000;

/**
 * Mark abandoned `syncing` rows as `failed` (2026-08-30).
 *
 * A run killed by a deploy / timeout / instance recycle leaves its module stuck
 * on `syncing` forever — isSyncStale only REPORTED that, nothing acted on it, so
 * the chip claimed work was in progress indefinitely (observed: Leads sat
 * "syncing" while its watermark stayed 6h behind every other module).
 *
 * Flipping it to `failed` is purely cosmetic-but-honest: `upsertSyncState` only
 * advances `last_sync_at` / `total_synced` on a COMPLETED status, so a failed
 * mark leaves the watermark and the count exactly where they were — the next run
 * still re-fetches from the last GOOD point and cannot skip records. Returns the
 * modules it reset so the caller can log them.
 */
export async function failStaleSyncingModules(): Promise<string[]> {
  try {
    const r = await pool.query(
      `UPDATE CRMProvider_sync_state
          SET sync_status = 'failed'
        WHERE sync_status = 'syncing'
          AND (sync_started_at IS NULL
               OR sync_started_at < NOW() - ($1::int * INTERVAL '1 millisecond'))
        RETURNING module`,
      [SYNC_STALE_AFTER_MS],
    );
    return r.rows.map((x: any) => String(x.module));
  } catch (e) {
    logger.warn("[DuplicateRadar] stale-sync recovery skipped (non-fatal)", e);
    return [];
  }
}

export function isSyncStale(row: {
  sync_status?: string | null;
  sync_started_at?: Date | string | null;
}): boolean {
  if (row?.sync_status !== "syncing") return false;
  const started = row?.sync_started_at ? new Date(row.sync_started_at).getTime() : NaN;
  // A `syncing` row with no start time predates that column — treat it as
  // stale rather than as healthy, since it cannot be aged.
  if (!Number.isFinite(started)) return true;
  return Date.now() - started > SYNC_STALE_AFTER_MS;
}

export async function getDistinctOwners(): Promise<string[]> {
  const result = await pool.query(
    `SELECT DISTINCT owner_name FROM duplicate_records WHERE owner_name IS NOT NULL AND owner_name != '' ORDER BY owner_name`,
  );
  return result.rows.map((r) => r.owner_name);
}

export async function getDistinctLayouts(): Promise<string[]> {
  const result = await pool.query(
    `SELECT DISTINCT layout_name FROM duplicate_records WHERE layout_name IS NOT NULL AND layout_name != '' ORDER BY layout_name`,
  );
  return result.rows.map((r) => r.layout_name);
}

export async function getDistinctDomains(): Promise<string[]> {
  const result = await pool.query(
    `SELECT DISTINCT domain FROM duplicate_records WHERE domain IS NOT NULL AND domain != '' ORDER BY domain LIMIT 200`,
  );
  return result.rows.map((r) => r.domain);
}

export async function getDistinctProducts(): Promise<string[]> {
  const result = await pool.query(
    `SELECT DISTINCT products FROM duplicate_records WHERE products IS NOT NULL AND products != '' ORDER BY products`,
  );
  return result.rows.map((r) => r.products);
}

export async function getDistinctPipelines(): Promise<string[]> {
  const result = await pool.query(
    `SELECT DISTINCT pipeline FROM duplicate_records WHERE pipeline IS NOT NULL AND pipeline != '' ORDER BY pipeline`,
  );
  return result.rows.map((r) => r.pipeline);
}

// Distinct Deal stages — restricted to the Deals module since stage only
// applies to Deal records. Used to populate the Stage filter dropdown.
export async function getDistinctStages(): Promise<string[]> {
  const result = await pool.query(
    `SELECT DISTINCT stage FROM duplicate_records
       WHERE CRMProvider_module = 'Deals' AND stage IS NOT NULL AND stage != ''
       ORDER BY stage`,
  );
  return result.rows.map((r) => r.stage);
}

export async function getFilteredClusters(
  filters: DuplicateFilters,
  limit = 30,
  offset = 0,
): Promise<{ clusters: DuplicateCluster[]; total: number }> {
  // AI-status chip. This function only ever filtered on `c.status`, so the
  // chip did nothing here: every value returned the same list (verified live
  // 2026-08-19 — active / dismissed / resolved / tagged_pending / all all gave
  // a total of 88,525 and the same first cluster). The per-tab record
  // endpoints implemented the chip; the cluster grid never did, which is why
  // dismissing a cluster looked like it had no effect.
  //
  // Same semantics as that implementation, with `c` as the cluster alias.
  const HAS_PENDING =
    "EXISTS (SELECT 1 FROM duplicate_merge_actions ma WHERE ma.cluster_id = c.id AND ma.action_type = 'auto_merge_pending')";
  const HAS_RESOLVED_ACTION =
    "EXISTS (SELECT 1 FROM duplicate_merge_actions ma WHERE ma.cluster_id = c.id AND ma.action_type IN ('resolve','module_resolved'))";

  let whereConditions: string[] = [];
  let params: any[] = [];
  let paramIdx = 1;

  const aiStatus = (filters.ai_status || "").trim();
  if (aiStatus === "tagged_pending") {
    // Applied but NOT yet confirmed gone from CRMProvider.
    whereConditions.push("c.status NOT IN ('resolved','ignored')");
    whereConditions.push(`(${HAS_PENDING} OR ${HAS_RESOLVED_ACTION})`);
  } else if (aiStatus === "resolved") {
    whereConditions.push("c.status = 'resolved'");
  } else if (aiStatus === "dismissed") {
    // Operator false-positive: status 'ignored' with no AI action.
    whereConditions.push("c.status = 'ignored'");
    whereConditions.push(`NOT ${HAS_PENDING} AND NOT ${HAS_RESOLVED_ACTION}`);
  } else if (aiStatus === "active") {
    whereConditions.push("c.status = 'active'");
    whereConditions.push(`NOT ${HAS_PENDING} AND NOT ${HAS_RESOLVED_ACTION}`);
  } else if (aiStatus === "all") {
    // No status constraint at all.
  } else {
    // No chip supplied — preserve the original behaviour exactly.
    whereConditions.push(`c.status = $${paramIdx}`);
    params.push(filters.status || "active");
    paramIdx++;
  }

  // Hide placeholder / junk-name clusters (Sample User 2026-07-14) — same as the
  // direct Domain Clusters load (buildClusterFilterClause) so the Advanced-Filter
  // path stays consistent.
  whereConditions.push(`c.domain <> '${PLACEHOLDER_CLUSTER_DOMAIN}'`);
  whereConditions.push(
    `LOWER(BTRIM(COALESCE(c.company_name,''))) <> ALL($${paramIdx++}::text[])`,
  );
  params.push(PLACEHOLDER_COMPANY_NAMES_LOWER_ARR);

  if (filters.confidence_level) {
    whereConditions.push(`c.confidence_level = $${paramIdx++}`);
    params.push(filters.confidence_level);
  }

  if (filters.start_date) {
    whereConditions.push(`c.created_at >= $${paramIdx++}`);
    params.push(filters.start_date);
  }

  if (filters.end_date) {
    whereConditions.push(`c.created_at <= $${paramIdx++}`);
    params.push(filters.end_date);
  }

  let joinNeeded = false;
  let recordConditions: string[] = [];

  if (filters.modules && filters.modules.length > 0) {
    joinNeeded = true;
    recordConditions.push(
      `r.CRMProvider_module IN (${filters.modules.map((_, i) => `$${paramIdx + i}`).join(",")})`,
    );
    params.push(...filters.modules);
    paramIdx += filters.modules.length;
  }

  if (filters.owners && filters.owners.length > 0) {
    joinNeeded = true;
    recordConditions.push(
      `r.owner_name IN (${filters.owners.map((_, i) => `$${paramIdx + i}`).join(",")})`,
    );
    params.push(...filters.owners);
    paramIdx += filters.owners.length;
  }

  if (filters.layouts && filters.layouts.length > 0) {
    joinNeeded = true;
    recordConditions.push(
      `r.layout_name IN (${filters.layouts.map((_, i) => `$${paramIdx + i}`).join(",")})`,
    );
    params.push(...filters.layouts);
    paramIdx += filters.layouts.length;
  }

  if (filters.pipelines && filters.pipelines.length > 0) {
    joinNeeded = true;
    recordConditions.push(
      `r.pipeline IN (${filters.pipelines.map((_, i) => `$${paramIdx + i}`).join(",")})`,
    );
    params.push(...filters.pipelines);
    paramIdx += filters.pipelines.length;
  }

  if (filters.stages && filters.stages.length > 0) {
    joinNeeded = true;
    recordConditions.push(
      `r.stage IN (${filters.stages.map((_, i) => `$${paramIdx + i}`).join(",")})`,
    );
    params.push(...filters.stages);
    paramIdx += filters.stages.length;
  }

  if (filters.domain) {
    joinNeeded = true;
    recordConditions.push(`r.domain ILIKE $${paramIdx++}`);
    params.push(`%${filters.domain}%`);
  }

  const segmentClause = buildSegmentPredicate(filters.segment, paramIdx);
  if (segmentClause.condition) {
    joinNeeded = joinNeeded || segmentClause.needsRecordJoin;
    recordConditions.push(segmentClause.condition);
    params.push(...segmentClause.params);
    paramIdx += segmentClause.params.length;
  }

  const joinClause = joinNeeded
    ? "INNER JOIN duplicate_records r ON r.cluster_id = c.id"
    : "";
  const recordWhere =
    recordConditions.length > 0 ? "AND " + recordConditions.join(" AND ") : "";

  const countQuery = `SELECT COUNT(DISTINCT c.id) as total FROM duplicate_clusters c ${joinClause} WHERE ${whereConditions.join(" AND ")} ${recordWhere}`;
  const countResult = await pool.query(countQuery, params);
  const total = parseInt(countResult.rows[0].total);

  const dataParams = [...params, limit, offset];
  const dataQuery = `SELECT DISTINCT c.* FROM duplicate_clusters c ${joinClause} WHERE ${whereConditions.join(" AND ")} ${recordWhere} ORDER BY c.confidence_score DESC, c.total_records DESC LIMIT $${paramIdx++} OFFSET $${paramIdx++}`;
  const dataResult = await pool.query(dataQuery, dataParams);

  return { clusters: dataResult.rows, total };
}

export async function getFilteredSummary(
  filters: DuplicateFilters,
): Promise<any> {
  let whereConditions = ["c.status = 'active'"];
  let params: any[] = [];
  let paramIdx = 1;

  // Hide placeholder / junk-name clusters (Sample User 2026-07-14) — keep the summary
  // KPIs consistent with the filtered cluster list.
  whereConditions.push(`c.domain <> '${PLACEHOLDER_CLUSTER_DOMAIN}'`);
  whereConditions.push(
    `LOWER(BTRIM(COALESCE(c.company_name,''))) <> ALL($${paramIdx++}::text[])`,
  );
  params.push(PLACEHOLDER_COMPANY_NAMES_LOWER_ARR);

  let joinNeeded = false;
  let recordConditions: string[] = [];

  if (filters.modules && filters.modules.length > 0) {
    joinNeeded = true;
    recordConditions.push(
      `r.CRMProvider_module IN (${filters.modules.map((_, i) => `$${paramIdx + i}`).join(",")})`,
    );
    params.push(...filters.modules);
    paramIdx += filters.modules.length;
  }

  if (filters.owners && filters.owners.length > 0) {
    joinNeeded = true;
    recordConditions.push(
      `r.owner_name IN (${filters.owners.map((_, i) => `$${paramIdx + i}`).join(",")})`,
    );
    params.push(...filters.owners);
    paramIdx += filters.owners.length;
  }

  if (filters.stages && filters.stages.length > 0) {
    joinNeeded = true;
    recordConditions.push(
      `r.stage IN (${filters.stages.map((_, i) => `$${paramIdx + i}`).join(",")})`,
    );
    params.push(...filters.stages);
    paramIdx += filters.stages.length;
  }

  if (filters.domain) {
    joinNeeded = true;
    recordConditions.push(`r.domain ILIKE $${paramIdx++}`);
    params.push(`%${filters.domain}%`);
  }

  const segmentClause = buildSegmentPredicate(filters.segment, paramIdx);
  if (segmentClause.condition) {
    joinNeeded = joinNeeded || segmentClause.needsRecordJoin;
    recordConditions.push(segmentClause.condition);
    params.push(...segmentClause.params);
    paramIdx += segmentClause.params.length;
  }

  const joinClause = joinNeeded
    ? "INNER JOIN duplicate_records r ON r.cluster_id = c.id"
    : "";
  const recordWhere =
    recordConditions.length > 0 ? "AND " + recordConditions.join(" AND ") : "";

  const query = `
    SELECT
      COUNT(DISTINCT c.id) as total_clusters,
      COUNT(DISTINCT CASE WHEN c.confidence_level = 'high' THEN c.id END) as high_confidence,
      COUNT(DISTINCT CASE WHEN c.confidence_level = 'medium' THEN c.id END) as medium_confidence,
      COUNT(DISTINCT CASE WHEN c.confidence_level = 'low' THEN c.id END) as low_confidence,
      COALESCE(SUM(c.estimated_pipeline_value), 0) as pipeline_inflation
    FROM duplicate_clusters c ${joinClause}
    WHERE ${whereConditions.join(" AND ")} ${recordWhere}
  `;

  const result = await pool.query(query, params);
  const row = result.rows[0];

  // Actionable per-module duplicate counts under the SAME filter — matches
  // the act_leads/act_deals/act_contacts/act_accounts logic in
  // getEnhancedSummary so the Executive Summary tiles can rescope by segment
  // (or any other filter) without lying. r.is_primary = false EXCLUDES the
  // survivor in each cluster — these are the records the team actually has
  // to act on. Reuses the SAME r alias that recordConditions/segmentClause
  // were written against, so the filter applies cleanly and we count out of
  // exactly one join.
  const actionableQuery = `
    SELECT
      COUNT(*) FILTER (WHERE r.record_type = 'lead'    AND c.total_leads    > 1 AND r.is_primary = false) AS act_leads,
      COUNT(*) FILTER (WHERE r.record_type = 'deal'    AND c.total_deals    > 1 AND r.is_primary = false) AS act_deals,
      COUNT(*) FILTER (WHERE r.record_type = 'contact' AND c.total_contacts > 1 AND r.is_primary = false) AS act_contacts,
      COUNT(*) FILTER (WHERE r.record_type = 'account' AND c.total_accounts > 1 AND r.is_primary = false) AS act_accounts
    FROM duplicate_clusters c
    INNER JOIN duplicate_records r ON r.cluster_id = c.id
    WHERE ${whereConditions.join(" AND ")} ${recordWhere}
  `;
  const actionable = await pool.query(actionableQuery, params).then(
    (r) => r.rows[0],
    () => null,
  );

  return {
    totalClusters: parseInt(row.total_clusters),
    highConfidence: parseInt(row.high_confidence),
    mediumConfidence: parseInt(row.medium_confidence),
    lowConfidence: parseInt(row.low_confidence),
    estimatedPipelineInflation: parseFloat(row.pipeline_inflation),
    totalDuplicateLeads: actionable ? parseInt(actionable.act_leads) || 0 : 0,
    totalDuplicateDeals: actionable ? parseInt(actionable.act_deals) || 0 : 0,
    totalDuplicateContacts: actionable ? parseInt(actionable.act_contacts) || 0 : 0,
    totalDuplicateAccounts: actionable ? parseInt(actionable.act_accounts) || 0 : 0,
  };
}

export async function upsertTask(
  task: Omit<DuplicateRecordTask, "id" | "created_at">,
): Promise<DuplicateRecordTask> {
  const result = await pool.query(
    `INSERT INTO duplicate_record_tasks (CRMProvider_task_id, related_record_id, cluster_id, subject, due_date, status, owner_name, description)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
     ON CONFLICT (CRMProvider_task_id) DO UPDATE SET
       subject = EXCLUDED.subject, due_date = EXCLUDED.due_date, status = EXCLUDED.status,
       owner_name = EXCLUDED.owner_name, description = EXCLUDED.description
     RETURNING *`,
    [
      task.CRMProvider_task_id,
      task.related_record_id,
      task.cluster_id,
      task.subject,
      task.due_date,
      task.status,
      task.owner_name,
      task.description,
    ],
  );
  return result.rows[0];
}

export async function getTasksForRecords(
  recordIds: string[],
): Promise<DuplicateRecordTask[]> {
  if (recordIds.length === 0) return [];
  const placeholders = recordIds.map((_, i) => `$${i + 1}`).join(",");
  const result = await pool.query(
    `SELECT * FROM duplicate_record_tasks WHERE related_record_id IN (${placeholders}) ORDER BY due_date DESC`,
    recordIds,
  );
  return result.rows;
}

export async function getTaskCountForCluster(
  clusterId: number,
): Promise<number> {
  const result = await pool.query(
    `SELECT COUNT(*) as cnt FROM duplicate_record_tasks WHERE cluster_id = $1`,
    [clusterId],
  );
  return parseInt(result.rows[0].cnt);
}

export async function calculateEnhancedScore(
  record1: DuplicateRecord,
  record2: DuplicateRecord,
): Promise<{ score: number; signals: string[] }> {
  const base = calculateMultiSignalScore(
    {
      email: record1.email,
      domain: record1.domain,
      phone: record1.phone,
      company_name: record1.company_name,
    },
    {
      email: record2.email,
      domain: record2.domain,
      phone: record2.phone,
      company_name: record2.company_name,
    },
  );

  let score = base.score;
  const signals = [...base.signals];

  if (record1.mobile && record2.mobile) {
    const m1 = normalizePhone(record1.mobile);
    const m2 = normalizePhone(record2.mobile);
    if (m1 && m2 && m1.length >= 7 && m1 === m2) {
      score += 25;
      signals.push("mobile_match");
    }
  }

  if (
    record1.cr_number &&
    record2.cr_number &&
    record1.cr_number === record2.cr_number
  ) {
    score += 35;
    signals.push("cr_number_match");
  }

  if (
    record1.vat_number &&
    record2.vat_number &&
    record1.vat_number === record2.vat_number
  ) {
    score += 30;
    signals.push("vat_number_match");
  }

  if (record1.website && record2.website) {
    const w1 = record1.website
      .toLowerCase()
      .replace(/^https?:\/\/(www\.)?/, "")
      .split("/")[0];
    const w2 = record2.website
      .toLowerCase()
      .replace(/^https?:\/\/(www\.)?/, "")
      .split("/")[0];
    if (w1 === w2) {
      score += 20;
      signals.push("website_match");
    }
  }

  return { score: Math.min(score, 100), signals };
}

export interface DataQualityResult {
  score: number;
  flags: string[];
  isJunk: boolean;
}

const GIBBERISH_REGEX = /^[a-zA-Z]{20,}$/;
const RANDOM_MIXED_REGEX = /^[a-zA-Z0-9]{25,}$/;
const CONSECUTIVE_CAPS_REGEX = /[A-Z]{8,}/;
const NAME_GARBAGE = [
  "test",
  "testing",
  "asdf",
  "qwerty",
  "xxx",
  "yyy",
  "zzz",
  "demo",
  "sample",
  "unknown",
  "n/a",
  "na",
  "-",
  ".",
  "..",
  "null",
];

function isGibberishName(name: string): boolean {
  if (!name) return false;
  const trimmed = name.trim();
  if (trimmed.length < 2) return true;

  const words = trimmed.split(/\s+/);
  if (words.some((w) => w.length > 25 && /^[a-zA-Z]+$/.test(w))) return true;
  if (GIBBERISH_REGEX.test(trimmed.replace(/\s/g, ""))) return true;
  if (RANDOM_MIXED_REGEX.test(trimmed.replace(/\s/g, ""))) return true;

  const latinLetters = (trimmed.match(/[a-zA-Z]/g) || []).length;
  const upperCase = (trimmed.match(/[A-Z]/g) || []).length;
  if (latinLetters > 10 && upperCase / latinLetters > 0.6) return true;
  if (CONSECUTIVE_CAPS_REGEX.test(trimmed)) return true;

  const consonants = (
    trimmed.toLowerCase().match(/[bcdfghjklmnpqrstvwxyz]/g) || []
  ).length;
  const vowels = (trimmed.toLowerCase().match(/[aeiou]/g) || []).length;
  if (latinLetters > 10 && vowels === 0) return true;
  if (
    latinLetters > 15 &&
    consonants > 0 &&
    vowels > 0 &&
    consonants / vowels > 8
  )
    return true;

  return false;
}

function isSuspiciousEmail(email: string): boolean {
  if (!email) return false;
  const local = email.split("@")[0] || "";
  if (/\d{6,}/.test(local)) return true;
  if (local.length > 30 && /^[a-z0-9.]+$/.test(local)) {
    const dots = (local.match(/\./g) || []).length;
    if (dots > 4) return true;
  }
  return false;
}

export function assessDataQuality(record: {
  recordName?: string;
  companyName?: string;
  email?: string;
  phone?: string;
  mobile?: string;
  ownerName?: string;
  domain?: string | null;
}): DataQualityResult {
  const flags: string[] = [];
  let score = 100;

  const name = record.recordName || "";
  const nameLower = name.toLowerCase().trim();
  if (!name || nameLower === "-" || nameLower === ".") {
    flags.push("missing_name");
    score -= 20;
  } else if (NAME_GARBAGE.includes(nameLower)) {
    flags.push("garbage_name");
    score -= 40;
  } else if (isGibberishName(name)) {
    flags.push("gibberish_name");
    score -= 50;
  }

  const company = record.companyName || "";
  if (!company || company === "Unknown") {
    flags.push("missing_company");
    score -= 15;
  } else if (isGibberishName(company)) {
    flags.push("gibberish_company");
    score -= 30;
  }

  if (!record.email) {
    flags.push("missing_email");
    score -= 10;
  } else if (isSuspiciousEmail(record.email)) {
    flags.push("suspicious_email");
    score -= 15;
  }

  const phoneNorm = record.phone ? normalizePhone(record.phone) : "";
  const mobileNorm = record.mobile ? normalizePhone(record.mobile) : "";
  if (!phoneNorm && !mobileNorm) {
    flags.push("missing_phone");
    score -= 10;
  }

  if (!record.ownerName || record.ownerName === "Unknown") {
    flags.push("missing_owner");
    score -= 5;
  }

  if (!record.domain) {
    flags.push("no_business_domain");
    score -= 5;
  }

  return {
    score: Math.max(0, score),
    flags,
    isJunk:
      score <= 20 ||
      flags.includes("gibberish_name") ||
      flags.includes("garbage_name"),
  };
}

export async function lookupRecordsByCRMProviderIds(CRMProviderIds: string[]): Promise<{
  [CRMProviderId: string]: {
    clusterId: number;
    clusterDomain: string;
    clusterCompany: string | null;
    confidenceLevel: string;
    confidenceScore: number;
    totalInCluster: number;
    dataQualityScore: number;
    dataQualityFlags: string[];
    recordType: string;
    isJunk: boolean;
  };
}> {
  if (!CRMProviderIds.length) return {};
  const result = await pool.query(
    `SELECT dr.CRMProvider_record_id, dr.cluster_id, dr.record_type,
            dr.data_quality_score, dr.data_quality_flags,
            dc.domain, dc.company_name, dc.confidence_level,
            dc.confidence_score, dc.total_records
     FROM duplicate_records dr
     JOIN duplicate_clusters dc ON dc.id = dr.cluster_id
     WHERE dr.CRMProvider_record_id = ANY($1)`,
    [CRMProviderIds],
  );
  const map: Record<string, any> = {};
  for (const row of result.rows) {
    map[row.CRMProvider_record_id] = {
      clusterId: row.cluster_id,
      clusterDomain: row.domain,
      clusterCompany: row.company_name,
      confidenceLevel: row.confidence_level,
      confidenceScore: row.confidence_score,
      totalInCluster: row.total_records,
      dataQualityScore: row.data_quality_score ?? 100,
      dataQualityFlags: row.data_quality_flags || [],
      recordType: row.record_type,
      isJunk: row.cluster_id && row.domain === "__JUNK_RECORDS__",
    };
  }
  return map;
}

export async function runLiveQualityCheck(
  records: Array<{
    id: string;
    Full_Name?: string;
    Last_Name?: string;
    First_Name?: string;
    Company?: string;
    Account_Name?: any;
    Deal_Name?: string;
    Email?: string;
    Phone?: string;
    Mobile?: string;
    Owner?: any;
  }>,
): Promise<{
  [id: string]: { score: number; flags: string[]; isJunk: boolean };
}> {
  const results: Record<string, any> = {};
  for (const r of records) {
    const name =
      r.Full_Name ||
      r.Deal_Name ||
      (r.First_Name
        ? `${r.First_Name} ${r.Last_Name || ""}`.trim()
        : r.Last_Name) ||
      "";
    const company =
      typeof r.Company === "string"
        ? r.Company
        : (typeof r.Account_Name === "object"
            ? r.Account_Name?.name
            : r.Account_Name) || "";
    const owner = typeof r.Owner === "object" ? r.Owner?.name : r.Owner || "";
    const email = r.Email || "";
    const phone = r.Phone || "";
    const mobile = r.Mobile || "";
    const domain = email.includes("@") ? email.split("@")[1] : undefined;
    const dq = assessDataQuality({
      recordName: name,
      companyName: company,
      email,
      phone,
      mobile,
      ownerName: owner,
      domain,
    });
    results[r.id] = { score: dq.score, flags: dq.flags, isJunk: dq.isJunk };
  }
  return results;
}

// ─── CS-pipeline overlap detection (Phase 1) ──────────────────────────────────
// Scans duplicate_records belonging to a cluster, classifies any Deal records
// whose raw_data exposes the Customer Success section (Phase + Churn Date),
// rolls up to a cluster-level verdict (BLOCK / REVIEW / WARN), and persists
// the verdict + ARR exposure + lifecycle state + sector on the cluster row.
// All thresholds and field names are env-configurable; see duplicateRadarCsOverlap.

import {
  classifyClusterOverlap,
  extractCsFieldsFromRawData,
  extractDealStage,
  type ClusterDealInfo,
  type CsLifecycleState,
  type CsOverlapVerdict,
  type ClientSector,
} from "./duplicateRadarCsOverlap";

export interface CsOverlapScanResult {
  cluster_id: number;
  verdict: CsOverlapVerdict;
  lifecycle_state: CsLifecycleState;
  sector: ClientSector;
  arr_exposure: number;
  classified_records: number;
}

/**
 * Scan a single cluster's records and persist the cs_overlap verdict.
 * Returns the persisted summary, or { verdict: null } if no CS deals found.
 */
export async function scanClusterForCsOverlap(
  clusterId: number,
): Promise<CsOverlapScanResult> {
  const clusterRow = await pool.query(
    `SELECT id, domain FROM duplicate_clusters WHERE id = $1`,
    [clusterId],
  );
  if (clusterRow.rows.length === 0) {
    return {
      cluster_id: clusterId,
      verdict: null,
      lifecycle_state: null,
      sector: null,
      arr_exposure: 0,
      classified_records: 0,
    };
  }
  const domain = clusterRow.rows[0].domain as string;

  const recordsRow = await pool.query(
    `SELECT id, CRMProvider_module, raw_data, gov_type
       FROM duplicate_records
       WHERE cluster_id = $1
         AND CRMProvider_module = 'Deals'
         AND cleanup_class IS NULL`,
    [clusterId],
  );
  // cleanup_class IS NULL (Sample User 2026-07-14): exclude empty/test/junk/orphaned/
  // tagged + ghost deals from the overlap classification — same records the tab
  // and modal already hide. A hidden junk/ghost deal (often stage-less) was
  // being counted as a phantom "open sales deal", so a cluster with only a real
  // Agreement-Signed/Paid deal (a normal signed customer, NO open sales deal)
  // was wrongly flagged BLOCK and its ARR double-counted.

  // Build the cluster-level deal list: every Deal record's Stage + CS section
  // + ARR. The new classifier (Sample User 2026-06-11) needs the WHOLE set
  // so it can detect "OPEN sales deal + Paid/Agreement-Signed handoff deal
  // coexist" — the per-deal classifier alone can't see that co-existence.
  const deals: ClusterDealInfo[] = [];
  let classifiedCount = 0;
  for (const rec of recordsRow.rows) {
    const fields = extractCsFieldsFromRawData(rec.raw_data, { domain });
    // gov_type column is preferred over raw_data lookup if present
    if (rec.gov_type) fields.gov_type = rec.gov_type;
    const stage = extractDealStage(rec.raw_data);
    deals.push({
      stage,
      cs: fields,
      arr_value: typeof fields.arr_value === "number" ? fields.arr_value : null,
    });
    // Count any deal with a readable CS phase as "classified" for the
    // cluster-level metric the route already exposes.
    if (fields.phase && String(fields.phase).trim() !== "") classifiedCount++;
  }

  const verdictPick = classifyClusterOverlap(deals);

  await pool.query(
    `UPDATE duplicate_clusters
       SET cs_overlap_verdict       = $2,
           pipeline_lifecycle_state = $3,
           client_sector            = $4,
           arr_exposure             = $5,
           updated_at               = NOW()
       WHERE id = $1`,
    [
      clusterId,
      verdictPick.verdict,
      verdictPick.lifecycle_state,
      verdictPick.sector,
      verdictPick.arr_exposure,
    ],
  );

  return {
    cluster_id: clusterId,
    verdict: verdictPick.verdict,
    lifecycle_state: verdictPick.lifecycle_state,
    sector: verdictPick.sector,
    arr_exposure: verdictPick.arr_exposure,
    classified_records: classifiedCount,
  };
}

export interface CsOverlapBatchResult {
  scanned: number;
  flagged: number;
  block_count: number;
  review_count: number;
  warn_count: number;
  total_arr_exposure: number;
  duration_ms: number;
}

/**
 * Scan every cluster that has at least one Deal record. Idempotent — safe to
 * re-run any time (e.g. nightly, or on-demand after CRMProvider resync).
 */
export async function scanAllClustersForCsOverlap(): Promise<CsOverlapBatchResult> {
  const t0 = Date.now();
  const eligible = await pool.query(
    `SELECT DISTINCT c.id
       FROM duplicate_clusters c
       INNER JOIN duplicate_records r ON r.cluster_id = c.id
       WHERE r.CRMProvider_module = 'Deals'`,
  );

  const out: CsOverlapBatchResult = {
    scanned: 0,
    flagged: 0,
    block_count: 0,
    review_count: 0,
    warn_count: 0,
    total_arr_exposure: 0,
    duration_ms: 0,
  };

  // Per-cluster scan was sequential, which gave us 3 DB round-trips × N clusters
  // and a 504 from the gateway on datasets with several hundred eligible
  // clusters. Run a small batch in parallel (6 ≤ default pg pool size 10, so
  // the route handler's own connection still has room) — wall time drops by
  // roughly the batch size.
  const CONCURRENCY = 6;
  for (let i = 0; i < eligible.rows.length; i += CONCURRENCY) {
    const batch = eligible.rows.slice(i, i + CONCURRENCY);
    const results = await Promise.all(
      batch.map((row) => scanClusterForCsOverlap(row.id)),
    );
    for (const res of results) {
      out.scanned++;
      if (!res.verdict) continue;
      out.flagged++;
      if (res.verdict === "block") out.block_count++;
      else if (res.verdict === "review") out.review_count++;
      else if (res.verdict === "warn") out.warn_count++;
      out.total_arr_exposure += res.arr_exposure;
    }
  }

  out.duration_ms = Date.now() - t0;
  logger.info("[duplicateRadar] CS overlap scan complete", out);
  return out;
}

// ─── CS Lifecycle Compliance scan (Phase 4) ──────────────────────────────────
// Iterates every Deal record in duplicate_records and evaluates whether its
// Customer Success section violates any of the GRQ-defined CS process rules
// (onboarding duration, phase ↔ churn-date sync, phase-transition SLA).
// Pure computation in csLifecycleCompliance.ts; this layer only does the
// per-record fan-out and rollup.

import {
  evaluateCsLifecycle,
  summarizeViolations,
  type CsLifecycleEvaluation,
  type CsLifecycleSummary,
  type CsViolation,
  type CsViolationCode,
  type CsViolationSeverity,
} from "./csLifecycleCompliance";

export interface CsLifecycleViolationRow {
  record_id: number;
  cluster_id: number | null;
  CRMProvider_record_id: string | null;
  account_name: string | null;
  domain: string | null;
  current_phase: string | null;
  days_since_modified: number | null;
  cs_owner_name: string | null;
  customer_since: string | null;
  renewal_date: string | null;
  churn_date: string | null;
  // Last Contact Date — CS section's last-touch date (Sample User 2026-07-28),
  // surfaced as its own column so CS can spot silent accounts.
  last_contact_date: string | null;
  health: string | null;
  // ExtID (Admin) — CRMProvider custom field surfaced in the CS Lifecycle tab
  // (operator request 2026-05-30). Replaces the Health column in the
  // dashboard UI; Health stays on the row so existing CSV exports and
  // any future consumer keep both signals available.
  ext_id: string | null;
  // 2026-06-08 — surface the underlying CRMProvider Deal's Layout name + Stage
  // value on the row so the dashboard's Advanced Filters (Layout /
  // Stage / Pipeline multi-selects) can actually narrow the CS
  // Lifecycle violation list. Without these, selecting Layout=ExampleOrg
  // or Stage=Agreement Signed on this tab had no visible effect — the
  // client-side rowMatchesAdvancedFilter() had no field to match
  // against. Pulled from raw_data inside scanCsLifecycleViolations.
  layout: string | null;
  stage: string | null;
  pipeline: string | null;
  violation: CsViolation;
}

export interface CsLifecycleScanResult {
  summary: CsLifecycleSummary;
  violations: CsLifecycleViolationRow[];
  duration_ms: number;
}

/**
 * Scan every Deal record under duplicate_records for CS lifecycle violations.
 * Returns the summary plus a flat array of violation rows. No persistence —
 * the scan is cheap enough to recompute on demand (data is bounded to deals
 * the radar already indexes).
 */
/**
 * CS OWNER ROSTER (Sample User 2026-07-20). The platform stores no CS team list — the
 * owner lives per-deal in CRMProvider's "CS Owner Name" field, so nothing could answer
 * "who are the CS owners?" (AssistantPersona included). This derives the roster from the
 * <REDACTED_SCHEME> the DISTINCT CS Owner Name values across Deal records, with how many
 * deals/accounts each owns, plus how many CS deals have NO owner (the
 * missing_cs_owner gap). Tolerates CRMProvider's key variants and the lookup-object
 * shape ({name}) exactly like duplicateRadarCsOverlap's extractor.
 */
export interface CsOwnerRow {
  owner: string;
  deals: number;
  accounts: number;
  /** True when this name resolves to a member of the maintained CS roster. */
  on_roster: boolean;
  /** Roster mailbox when matched — the stable identity behind the display name. */
  email: string | null;
}
export async function getCsOwners(
  opts: { segment?: DuplicateFilters["segment"]; limit?: number } = {},
): Promise<{
  owners: CsOwnerRow[];
  totalOwners: number;
  totalCsDeals: number;
  dealsWithoutOwner: number;
  /** Roster members carrying NO deals — nobody assigned / new joiner. */
  roster_without_deals: Array<{ name: string; email: string }>;
  /** Names found on deals that are NOT on the roster — typo / ex-employee / non-CS person. */
  off_roster_names: string[];
  /** Size of the maintained roster (independent of the deal data). */
  roster_size: number;
}> {
  const limit = Math.max(1, Math.min(opts.limit ?? 200, 1000));
  // CRMProvider key variants — hardcoded constants (no injection surface). A lookup
  // field arrives as {name}; a picklist/text arrives as a bare string.
  const OWNER_KEYS = [
    "CS_Owner_Name",
    "CS_Owner",
    "CS_Owner1",
    "CSOwnerName",
    "cs_owner_name",
    "CS Owner Name",
  ];
  const PHASE_KEYS = ["Phase", "phase", "CS_Phase", "Customer_Phase"];
  const jsonText = (key: string) =>
    `CASE WHEN jsonb_typeof(r.raw_data->'${key}') = 'object' THEN NULLIF(BTRIM(r.raw_data->'${key}'->>'name'),'')` +
    ` WHEN jsonb_typeof(r.raw_data->'${key}') = 'string' THEN NULLIF(BTRIM(r.raw_data->>'${key}'),'') ELSE NULL END`;
  const ownerExpr = `COALESCE(${OWNER_KEYS.map(jsonText).join(", ")})`;
  const phaseExpr = `COALESCE(${PHASE_KEYS.map(jsonText).join(", ")})`;

  const params: any[] = [];
  const seg = buildSegmentPredicate(opts.segment, 1);
  let segmentCond = "";
  if (seg.condition) {
    segmentCond = ` AND ${seg.condition}`;
    params.push(...seg.params);
  }
  const baseCte = `
    WITH cs AS (
      SELECT ${ownerExpr} AS owner,
             ${phaseExpr} AS phase,
             r.account_name
        FROM duplicate_records r
       WHERE r.record_type = 'deal'
         AND r.cleanup_class IS NULL${segmentCond}
    )`;

  // These two are independent and each pays for its own scan of the CTE, which
  // extracts owner and phase out of raw_data across every deal record. Running
  // them concurrently is the right shape and cannot change the output —
  // identical SQL, identical results.
  //
  // MEASURED OUTCOME: no speedup. Median of 3 samples before 10,845ms, after
  // 11,104ms — inside the noise, if anything marginally worse. The change was
  // made expecting concurrency to halve the wall clock; that was WRONG. The
  // cost is Postgres doing raw_data JSON extraction across ~27k deal records
  // twice, and issuing both at once does not reduce that work — it just makes
  // the two scans compete.
  //
  // The real fix is to stop extracting owner and phase out of raw_data on every
  // request: an expression index, or promoting them to real columns. Note the
  // house rule that any ALTER TABLE ADD COLUMN must also appear in the
  // canonical CREATE TABLE, so that is a deliberate schema change, not a tweak.
  //
  // "CS deals" for the no-owner gap = deals that carry a CS Phase (i.e. are on
  // the CS pipeline). Counting every Deal would drown the number in sales deals.
  const [ownersQ, gapQ] = await Promise.all([
    pool.query<{ owner: string; deals: string; accounts: string }>(
      `${baseCte}
       SELECT owner,
              COUNT(*)::text AS deals,
              COUNT(DISTINCT NULLIF(BTRIM(account_name), ''))::text AS accounts
         FROM cs
        WHERE owner IS NOT NULL
        GROUP BY owner
        ORDER BY COUNT(*) DESC, owner ASC
        LIMIT $${params.length + 1}`,
      [...params, limit],
    ),
    pool.query<{ with_owner: string; without_owner: string }>(
      `${baseCte}
       SELECT COUNT(*) FILTER (WHERE owner IS NOT NULL)::text AS with_owner,
              COUNT(*) FILTER (WHERE owner IS NULL AND phase IS NOT NULL)::text AS without_owner
         FROM cs`,
      params,
    ),
  ]);
  // Cross-reference the derived names against the MAINTAINED roster. The two
  // answer different questions — the roster is who is ON the team, the query is
  // who actually carries deals — and the mismatch in either direction is the
  // useful signal (Sample User 2026-07-21).
  const { getCsTeamMembers, matchCsTeamMember } = await import("./csTeamMembers");
  const roster = getCsTeamMembers();
  const seenEmails = new Set<string>();
  const offRoster: string[] = [];
  const owners: CsOwnerRow[] = ownersQ.rows.map((r) => {
    const member = matchCsTeamMember(r.owner);
    if (member) seenEmails.add(member.email.toLowerCase());
    else if (r.owner) offRoster.push(r.owner);
    return {
      owner: r.owner,
      deals: parseInt(r.deals) || 0,
      accounts: parseInt(r.accounts) || 0,
      on_roster: !!member,
      email: member ? member.email : null,
    };
  });
  const rosterWithoutDeals = roster
    .filter((m) => !seenEmails.has(m.email.toLowerCase()))
    .map((m) => ({ name: m.name, email: m.email }));

  return {
    owners,
    totalOwners: owners.length,
    totalCsDeals: parseInt(gapQ.rows[0]?.with_owner || "0") || 0,
    dealsWithoutOwner: parseInt(gapQ.rows[0]?.without_owner || "0") || 0,
    roster_without_deals: rosterWithoutDeals,
    off_roster_names: offRoster,
    roster_size: roster.length,
  };
}

/**
 * DEAL STAGE AUDIT — READ-ONLY (Sample User 2026-07-21).
 *
 * A preflight run surfaced deals on BOTH "On Hold" and "Hold", i.e. the CRMProvider
 * Stage picklist carries near-duplicate values. That sample covered only 41
 * rows, so it could not show the real scale. This lists EVERY distinct Stage
 * value across all Deal records with its deal count, a corporate/marketplace
 * split (odd stages like "Partner Active" / "Welcome Communications" belong to
 * the Marketplace + CS pipelines, not corporate sales) and the pipelines each
 * stage appears on — so the true variant picture is visible before anyone edits
 * the picklist.
 *
 * Writes NOTHING. Re-staging records and removing a dead picklist option are
 * deliberate manual steps in CRMProvider — and in that order, since deleting an option
 * still in use orphans those deals.
 */
export interface DealStageAuditRow {
  stage: string;
  deals: number;
  corporate: number;
  marketplace: number;
  pipelines: string[];
}
export async function getDealStageAudit(): Promise<{
  stages: DealStageAuditRow[];
  suspected_variants: Array<{ group: string[]; note: string }>;
  total_deals: number;
  distinct_stages: number;
}> {
  const LAYOUT_NORM =
    "regexp_replace(LOWER(COALESCE(NULLIF(layout_name,''), raw_data#>>'{Layout,name}', raw_data#>>'{$layout,name}', raw_data->>'Layout','')), '[^a-z0-9]', '', 'g')";
  const IS_MKT = `(${LAYOUT_NORM} LIKE '%marketplace%' OR ${LAYOUT_NORM} LIKE '%partneraccount%')`;
  const q = await pool.query<{
    stage: string;
    deals: string;
    corporate: string;
    marketplace: string;
    pipelines: string[] | null;
  }>(
    `WITH d AS (
       SELECT COALESCE(NULLIF(BTRIM(stage),''), BTRIM(raw_data->>'Stage')) AS stage_raw,
              ${IS_MKT} AS is_mkt,
              COALESCE(NULLIF(BTRIM(pipeline),''), BTRIM(raw_data->>'Pipeline')) AS pipeline
         FROM duplicate_records
        WHERE record_type = 'deal'
          AND cleanup_class IS NULL
     )
     SELECT stage_raw AS stage,
            COUNT(*)::text AS deals,
            COUNT(*) FILTER (WHERE NOT is_mkt)::text AS corporate,
            COUNT(*) FILTER (WHERE is_mkt)::text AS marketplace,
            (ARRAY_AGG(DISTINCT pipeline) FILTER (WHERE pipeline IS NOT NULL AND pipeline <> ''))[1:6] AS pipelines
       FROM d
      WHERE stage_raw IS NOT NULL AND stage_raw <> ''
      GROUP BY stage_raw
      ORDER BY COUNT(*) DESC, stage_raw ASC`,
  );
  const stages: DealStageAuditRow[] = q.rows.map((r) => ({
    stage: r.stage,
    deals: parseInt(r.deals) || 0,
    corporate: parseInt(r.corporate) || 0,
    marketplace: parseInt(r.marketplace) || 0,
    pipelines: Array.isArray(r.pipelines) ? r.pipelines.filter(Boolean) : [],
  }));

  // Variant detection. Two flavours, both reported so the operator can judge:
  //   (1) SAME normalised form  — differs only by case/spacing/punctuation
  //       ("On Hold" vs "on-hold"). Almost certainly the same stage.
  //   (2) One normalised form CONTAINED in another ("hold" inside "onhold").
  //       A strong hint, not proof — flagged for human review, never merged.
  const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, "");
  const byNorm = new Map<string, string[]>();
  for (const s of stages) {
    const k = norm(s.stage);
    if (!k) continue;
    const arr = byNorm.get(k) || [];
    arr.push(s.stage);
    byNorm.set(k, arr);
  }
  const variants: Array<{ group: string[]; note: string }> = [];
  for (const [, names] of byNorm) {
    if (names.length > 1) {
      variants.push({
        group: names,
        note: "Identical once case/spacing/punctuation is ignored — same stage stored two ways.",
      });
    }
  }
  const keys = [...byNorm.keys()];
  for (let a = 0; a < keys.length; a++) {
    for (let b = 0; b < keys.length; b++) {
      const ka = keys[a]!;
      const kb = keys[b]!;
      if (a === b || ka.length >= kb.length) continue;
      if (kb.includes(ka)) {
        variants.push({
          group: [...(byNorm.get(ka) || []), ...(byNorm.get(kb) || [])],
          note: `"${byNorm.get(ka)![0]}" is contained in "${byNorm.get(kb)![0]}" — likely the same stage; confirm before consolidating.`,
        });
      }
    }
  }
  return {
    stages,
    suspected_variants: variants,
    total_deals: stages.reduce((a, s) => a + s.deals, 0),
    distinct_stages: stages.length,
  };
}

export async function scanCsLifecycleViolations(opts: {
  severity?: CsViolationSeverity;
  code?: CsViolationCode;
  limit?: number;
  segment?: DuplicateFilters["segment"];
  /**
   * Summary-only mode (Quality Reports Hub): compute `summary` but return an
   * EMPTY `violations` array. Unlike the stage-aging scan this still has to
   * read `raw_data` — evaluateCsLifecycle extracts the whole Customer Success
   * section from it, so there is no column projection to fall back on — but it
   * skips building, sorting and JSON-serialising thousands of violation rows
   * that the per-BU report never renders (it reads only
   * summary.total_violations). The CS Lifecycle tab keeps the full path.
   */
  summaryOnly?: boolean;
} = {}): Promise<CsLifecycleScanResult> {
  const t0 = Date.now();
  // Bumped default 2000 → 10000 and cap 5000 → 50000 so the scan covers
  // the full Deal corpus by default. The bulk CRMProvider sync currently caps
  // at 5,000 records per module, so 10000 comfortably scans every
  // synced Deal; the 50000 ceiling leaves headroom for a future CRMProvider
  // page-size bump without another deploy. Without this, the "CS Deals
  // Scanned" KPI was silently capped at the 2000 most-recently-modified
  // Deals — orgs with >2k Deals never saw every CS deal evaluated.
  const limit = Math.max(1, Math.min(opts.limit ?? 10000, 50000));

  // Segment scope. CS Lifecycle is the B2B CS team's domain, so it DEFAULTS to
  // the ExampleOrg (corporate) layout — a bare "all"/unset segment resolves to
  // ExampleOrg, NOT every layout, because Example Organization / Marketplace are not part of
  // the CS-B2B book (Sample User 2026-07-07). An explicit Marketplace/Example Organization chip
  // still overrides for ad-hoc inspection. Same layout_name predicate the radar
  // tabs use. Segment bind params come first ($1..$N); LIMIT is the last one.
  const csSegment: DuplicateFilters["segment"] =
    !opts.segment || opts.segment === "all" ? "ExampleOrg" : opts.segment;
  const params: any[] = [];
  const seg = buildSegmentPredicate(csSegment, 1);
  let segmentCond = "";
  if (seg.condition) {
    segmentCond = " AND " + seg.condition;
    params.push(...seg.params);
  }
  params.push(limit);
  const limitPh = "$" + params.length;

  // A deal IS a CS deal when it carries data in the CRM's Customer Success
  // section — that's the ONLY gate (evaluateCsLifecycle returns is_cs_deal=true
  // iff the CS "Phase" field is set). So the census must fetch EVERY ExampleOrg
  // Deal and let that gate decide (Sample User 2026-07-28). Previously the fetch
  // pre-filtered `cleanup_class IS NULL` (empty/junk) and active-cluster only,
  // which silently DROPPED real CS clients — especially domain-less ones that
  // trip the empty/junk classifier — so Adoption/Renewal/Onboarding undercounted
  // (140/126/10 instead of the true 179/171/13). Junk/test deals don't carry a
  // real CS Phase, so they still fall out at the is_cs_deal gate — the count
  // stays clean without narrowing by dedup/cleanup state.
  const dealRows = await pool.query(
    `SELECT r.id, r.cluster_id, r.CRMProvider_record_id, r.account_name,
            r.domain, r.modified_date, r.raw_data, r.gov_type
       FROM duplicate_records r
      WHERE r.CRMProvider_module = 'Deals'${segmentCond}
      ORDER BY r.modified_date DESC NULLS LAST
      LIMIT ${limitPh}`,
    params,
  );

  const evaluations: CsLifecycleEvaluation[] = [];
  const violations: CsLifecycleViolationRow[] = [];

  for (const row of dealRows.rows) {
    const ev = evaluateCsLifecycle({
      raw_data: row.raw_data,
      modified_date: row.modified_date,
      domain: row.domain,
      gov_type: row.gov_type,
    });
    evaluations.push(ev);
    if (!ev.is_cs_deal) continue;
    // Summary-only: `evaluations` above is all summarizeCsLifecycle needs.
    if (opts.summaryOnly) continue;

    // Pull the Customer Success section detail fields for display alongside
    // each violation (CS owner, customer-since, renewal/churn dates, health).
    // Same extractor evaluateCsLifecycle uses, so values stay consistent.
    const detail = extractCsFieldsFromRawData(row.raw_data, {
      domain: row.domain,
    });
    const fmtDate = (d: string | Date | null | undefined): string | null => {
      if (!d) return null;
      const s = typeof d === "string" ? d : d.toISOString();
      return s.slice(0, 10);
    };

    for (const v of ev.violations) {
      if (opts.severity && v.severity !== opts.severity) continue;
      if (opts.code && v.code !== opts.code) continue;
      // 2026-05-30 — operator request: the "Account" column on the CS
      // Lifecycle tab must be sourced from the Customer Success section's
      // Company custom field (the field the CS team curates) rather
      // than the Deal's standard Account_Name lookup that duplicate_records
      // .account_name was populated from at sync time. The two fields
      // are normally aligned, but if a CS team renames a customer in the
      // CS section without touching the top-level Account_Name lookup
      // the dashboard otherwise drifts from the CRM's CS view. Fall back
      // to the legacy Account_Name when the CS Company field is empty so
      // legacy data still shows something useful.
      const csAccountName =
        (detail.cs_company && detail.cs_company.trim()) ||
        row.account_name ||
        null;

      // 2026-06-08 — pull Layout / Stage / Pipeline straight off the
      // CRMProvider raw_data so the dashboard's Advanced Filters can match
      // against them. Layout in CRMProvider is an object { id, name }; Stage
      // and Pipeline are plain strings. Defensive .toString() in case
      // a tenant has the field with an unexpected shape.
      const rawDeal: any = (row.raw_data as any) ?? {};
      const _readObjOrStr = (v: any): string | null => {
        if (v == null) return null;
        if (typeof v === "string") return v.trim() || null;
        if (typeof v === "object" && typeof v.name === "string") {
          return v.name.trim() || null;
        }
        return null;
      };
      const dealLayout = _readObjOrStr(rawDeal.Layout);
      const dealStage = _readObjOrStr(rawDeal.Stage);
      const dealPipeline = _readObjOrStr(rawDeal.Pipeline);

      violations.push({
        record_id: row.id,
        cluster_id: row.cluster_id ?? null,
        CRMProvider_record_id: row.CRMProvider_record_id ?? null,
        account_name: csAccountName,
        domain: row.domain ?? null,
        current_phase: ev.current_phase,
        days_since_modified: ev.days_since_modified,
        cs_owner_name: detail.cs_owner_name ?? null,
        customer_since: fmtDate(detail.customer_since),
        renewal_date: fmtDate(detail.renewal_date),
        churn_date: fmtDate(detail.churn_date),
        last_contact_date: fmtDate(detail.last_contact_date),
        health: detail.health ?? null,
        ext_id: detail.ext_id ?? null,
        layout: dealLayout,
        stage: dealStage,
        pipeline: dealPipeline,
        violation: v,
      });
    }
  }

  // Severity ordering: critical → warning → info
  const sevOrder: Record<CsViolationSeverity, number> = {
    critical: 0,
    warning: 1,
    info: 2,
  };
  violations.sort((a, b) => {
    const s =
      sevOrder[a.violation.severity] - sevOrder[b.violation.severity];
    if (s !== 0) return s;
    return (b.days_since_modified ?? 0) - (a.days_since_modified ?? 0);
  });

  return {
    summary: summarizeViolations(evaluations),
    violations,
    duration_ms: Date.now() - t0,
  };
}

// ────────────────────────────────────────────────────────────────────────────
// Deal Stage Aging — scans the Deal corpus for stage-aging SOP violations.
// Mirrors scanCsLifecycleViolations but applies the Sales SOP per-stage SLA
// spec from salesStageSlaSpec.ts. Used by:
//   - GET /api/duplicates/deal-stage-aging
//   - dealStageAgingStatusTool (AssistantPersona)
//   - twice-daily digest (buildRadarTabStatus)
// ────────────────────────────────────────────────────────────────────────────

export interface DealStageAgingViolationRow {
  record_id: number;
  cluster_id: number | null;
  CRMProvider_record_id: string | null;
  deal_name: string | null;
  account_name: string | null;
  owner_name: string | null;
  owner_email: string | null;
  layout: string | null;
  pipeline: string | null;
  stage: string;
  amount: number | null;
  created_time: string | null;
  modified_date: string | null;
  violation: import("./dealStageAgingCompliance").DealStageAgingViolation;
}

export interface DealStageAgingScanResult {
  summary: import("./dealStageAgingCompliance").DealStageAgingSummary;
  violations: DealStageAgingViolationRow[];
  duration_ms: number;
}

export async function scanDealStageAgingViolations(
  opts: {
    severity?: "info" | "warning" | "critical";
    stage?: string;
    limit?: number;
    segment?: DuplicateFilters["segment"];
    /**
     * Summary-only mode (Quality Reports Hub): return `summary` and an EMPTY
     * `violations` array, reading the projected COLUMNS instead of `raw_data`.
     *
     * The full path selects `r.raw_data` for up to 10k deals — tens of MB of
     * JSONB detoasted, shipped over the wire and JSON-parsed in Node — purely
     * so the per-BU report could render ONE integer
     * (summary.total_violations). That single query is what pushed
     * GET /api/quality-reports/bus/:key past the HostingPlatform proxy timeout (504).
     *
     * The projection is semantically equivalent, not an approximation:
     *   - stage: `duplicate_records.stage` is populated from the same CRMProvider
     *     `d.Stage` string the full path reads out of raw_data
     *     (duplicateRadarRoutes.ts:1292), with the raw_data paths kept as a
     *     COALESCE fallback for rows whose column is blank. COALESCE is lazy,
     *     so a populated column skips the detoast entirely.
     *   - created_time: `duplicate_records.created_date` is the column form of
     *     raw_data.Created_Time, and evaluateDealStageAging only consults it as
     *     the last fallback after modified_date (dealStageAgingCompliance.ts:153).
     *
     * The Deals Lifecycle tab keeps using the full path unchanged — it needs
     * the violation rows (deal name / owner / amount) that this mode drops.
     */
    summaryOnly?: boolean;
  } = {},
): Promise<DealStageAgingScanResult> {
  const t0 = Date.now();
  const limit = Math.max(1, Math.min(opts.limit ?? 10000, 50000));

  const { evaluateDealStageAging, summarizeDealStageAging } = await import(
    "./dealStageAgingCompliance"
  );

  // Segment chip (ExampleOrg / Example Organization / Marketplace) — filter deals by their CRMProvider
  // Layout, using the SAME predicate the radar tabs use so "ExampleOrg" shows only
  // ExampleOrg-layout deals, etc. (Sample User 2026-07-07). Segment bind params come
  // first ($1..$N); the LIMIT is always the last placeholder.
  const params: any[] = [];
  const seg = buildSegmentPredicate(opts.segment, 1);
  let segmentCond = "";
  if (seg.condition) {
    segmentCond = " AND " + seg.condition;
    params.push(...seg.params);
  }
  params.push(limit);
  const limitPh = "$" + params.length;

  // Summary-only: same rows, same WHERE, same LIMIT — but three narrow columns
  // instead of the whole raw_data blob. See the summaryOnly doc comment above.
  if (opts.summaryOnly) {
    const lite = await pool.query(
      `SELECT r.modified_date,
              r.created_date,
              COALESCE(NULLIF(r.stage,''), r.raw_data#>>'{Stage,name}',
                       r.raw_data->>'Stage') AS stage
         FROM duplicate_records r
         LEFT JOIN duplicate_clusters dc ON dc.id = r.cluster_id
        WHERE r.CRMProvider_module = 'Deals'
          AND r.cleanup_class IS NULL
          AND (dc.status IS NULL OR dc.status = 'active')${segmentCond}
        ORDER BY r.modified_date DESC NULLS LAST
        LIMIT ${limitPh}`,
      params,
    );
    const liteEvaluations = lite.rows.map((row: any) =>
      evaluateDealStageAging({
        stage: typeof row.stage === "string" ? row.stage.trim() || null : null,
        modified_date: row.modified_date,
        created_time: row.created_date ?? null,
      }),
    );
    return {
      summary: summarizeDealStageAging(liteEvaluations),
      violations: [],
      duration_ms: Date.now() - t0,
    };
  }

  const dealRows = await pool.query(
    `SELECT r.id, r.cluster_id, r.CRMProvider_record_id, r.account_name,
            r.modified_date, r.raw_data
       FROM duplicate_records r
       LEFT JOIN duplicate_clusters dc ON dc.id = r.cluster_id
      WHERE r.CRMProvider_module = 'Deals'
        AND r.cleanup_class IS NULL
        AND (dc.status IS NULL OR dc.status = 'active')${segmentCond}
      ORDER BY r.modified_date DESC NULLS LAST
      LIMIT ${limitPh}`,
    params,
  );

  const evaluations: ReturnType<typeof evaluateDealStageAging>[] = [];
  const violations: DealStageAgingViolationRow[] = [];

  const fmtDate = (d: string | Date | null | undefined): string | null => {
    if (!d) return null;
    const s = typeof d === "string" ? d : d.toISOString();
    return s.slice(0, 10);
  };
  const readObjOrStr = (v: any): string | null => {
    if (v == null) return null;
    if (typeof v === "string") return v.trim() || null;
    if (typeof v === "object" && typeof v.name === "string") {
      return v.name.trim() || null;
    }
    return null;
  };

  for (const row of dealRows.rows) {
    const raw: any = (row.raw_data as any) ?? {};
    const stage = readObjOrStr(raw.Stage);
    const ev = evaluateDealStageAging({
      stage,
      modified_date: row.modified_date,
      created_time: raw.Created_Time ?? null,
    });
    evaluations.push(ev);
    if (!ev.violation) continue;
    if (opts.severity && ev.violation.severity !== opts.severity) continue;
    if (
      opts.stage &&
      ev.violation.stage.toLowerCase() !== opts.stage.toLowerCase()
    )
      continue;

    const owner = raw.Owner ?? null;
    const ownerName =
      (owner && typeof owner === "object" && typeof owner.name === "string"
        ? owner.name.trim() || null
        : null) ?? null;
    const ownerEmail =
      (owner && typeof owner === "object" && typeof owner.email === "string"
        ? owner.email.trim().toLowerCase() || null
        : null) ?? null;

    const amountRaw = raw.Amount;
    const amount =
      typeof amountRaw === "number"
        ? amountRaw
        : typeof amountRaw === "string" && amountRaw.trim() !== ""
          ? Number.parseFloat(amountRaw)
          : null;

    violations.push({
      record_id: row.id,
      cluster_id: row.cluster_id ?? null,
      CRMProvider_record_id: row.CRMProvider_record_id ?? null,
      deal_name: readObjOrStr(raw.Deal_Name),
      account_name: row.account_name ?? readObjOrStr(raw.Account_Name) ?? null,
      owner_name: ownerName,
      owner_email: ownerEmail,
      layout: readObjOrStr(raw.Layout),
      pipeline: readObjOrStr(raw.Pipeline),
      stage: ev.violation.stage,
      amount: Number.isFinite(amount as number) ? (amount as number) : null,
      created_time: fmtDate(raw.Created_Time ?? null),
      modified_date: fmtDate(row.modified_date),
      violation: ev.violation,
    });
  }

  const sevOrder: Record<"info" | "warning" | "critical", number> = {
    critical: 0,
    warning: 1,
    info: 2,
  };
  violations.sort((a, b) => {
    const s =
      sevOrder[a.violation.severity] - sevOrder[b.violation.severity];
    if (s !== 0) return s;
    return (b.violation.aging_calendar_days ?? 0) - (a.violation.aging_calendar_days ?? 0);
  });

  return {
    summary: summarizeDealStageAging(evaluations),
    violations,
    duration_ms: Date.now() - t0,
  };
}

export { pool };
