/**
 * Duplicate Resolution — deterministic merge PLANNER (Phase 1, Accounts).
 *
 * Pure, side-effect-free, DB-free. Given a cluster's records it produces a
 * `MergePlan` describing how the duplicates would be resolved:
 *   • which record survives (the "master") and why,
 *   • which field values would be migrated onto the master (gap-fills only —
 *     the master's existing values are never overwritten automatically),
 *   • which duplicates would be tagged `Duplicate-Delete` for the CRMProvider admin,
 *   • field-level conflicts and other warnings for the operator to eyeball.
 *
 * IMPORTANT: this module performs NO writes and contacts NO external service.
 * It is the trustworthy backbone of the agentic feature — the LLM agent (added
 * later) only narrates on top of this; it never authors the data decisions.
 * The execute path (separate, write-gated) consumes a plan produced here.
 *
 * Uses `import type` so importing this file never pulls the pg pool in
 * `duplicateRadarDatabase` into memory — keeps the planner unit-testable.
 */

import type { DuplicateRecord } from "./duplicateRadarDatabase";

/** CRM modules the agentic resolver supports. */
export type CrmModule = "Accounts" | "Leads" | "Deals" | "Contacts";

/** duplicate_records.record_type value for each module. */
export const MODULE_RECORD_TYPE: Record<CrmModule, string> = {
  Accounts: "account",
  Leads: "lead",
  Deals: "deal",
  Contacts: "contact",
};

/** Singular human label per module. */
const MODULE_LABEL: Record<CrmModule, string> = {
  Accounts: "Account",
  Leads: "Lead",
  Deals: "Deal",
  Contacts: "Contact",
};

/**
 * Normalize a (possibly Arabic) personal name for EQUALITY comparison in the
 * ≥2-attribute contact rule. Plain `trim().toLowerCase()` left visually-
 * identical Arabic names comparing UNEQUAL — a very common cause of "these are
 * obviously the same person but the modal won't let me merge them" (the plan
 * falls to link-only). Here we: Unicode-NFKC; strip bidi / zero-width marks,
 * tatweel and harakat (diacritics); fold the common Arabic letter variants
 * (آأإ→ا, ى→ي, ة→ه); collapse whitespace; lowercase. The ≥2-attribute rule
 * still requires a second signal (email or phone) to match, so the slightly
 * looser name match can't merge two genuinely different people on its own.
 * (Sample User 2026-06-22.)
 */
export function normalizePersonName(s: string | null | undefined): string {
  return String(s || "")
    .normalize("NFKC")
    .replace(/[\u200B-\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g, "") // zero-width + bidi marks
    .replace(/\u0640/g, "") // tatweel
    .replace(/[\u064B-\u0652\u0670]/g, "") // harakat / diacritics
    .replace(/[\u0622\u0623\u0625]/g, "\u0627") // alef variants -> alef
    .replace(/\u0649/g, "\u064A") // alef maqsura -> yaa
    .replace(/\u0629/g, "\u0647") // taa marbuta -> haa
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

/**
 * Generic / role mailboxes (info@, support@, sales@, e-store@, …). These are a
 * company's shared contact-point, NOT a person's identity — so two contacts that
 * share a phone where one carries a role mailbox are the same contact-point, not
 * two different people. Used by the Contacts merge gate's "shared phone + role
 * mailbox" bridge (Sample User 2026-06-26). Curated exact local-parts (not a prefix
 * match) so "infofahad@…" or "salesman@…" are NOT treated as role mailboxes.
 * Extend without a code change via env CONTACT_ROLE_MAILBOXES (comma-separated).
 */
const ROLE_MAILBOX_LOCALPARTS = new Set<string>([
  "info", "information", "support", "help", "helpdesk", "contact", "contactus",
  "contacts", "sales", "admin", "administrator", "office", "enquiry", "enquiries",
  "inquiry", "inquiries", "service", "services", "customercare", "customerservice",
  "care", "billing", "accounts", "accounting", "finance", "hr", "careers", "jobs",
  "recruitment", "marketing", "team", "mail", "email", "e-store", "estore", "store",
  "shop", "orders", "order", "reception", "general", "hello", "noreply", "no-reply",
  "donotreply", "do-not-reply", "webmaster", "postmaster", "abuse",
  ...String(process.env.CONTACT_ROLE_MAILBOXES || "")
    .split(",")
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean),
]);

/** True iff the email's local-part is a generic/role mailbox (info@, support@…). */
export function isRoleMailbox(email: string | null | undefined): boolean {
  const e = String(email || "").trim().toLowerCase();
  const at = e.indexOf("@");
  if (at <= 0) return false;
  return ROLE_MAILBOX_LOCALPARTS.has(e.slice(0, at));
}

// ── Output types ───────────────────────────────────────────────────────────

export type MergeFieldAction = "fill" | "conflict";

export interface MergeFieldDecision {
  /** CRMProvider API field name (Accounts module). */
  field: string;
  /** Human label for the UI. */
  label: string;
  action: MergeFieldAction;
  chosenValue: string | number | null;
  /** CRMProvider_record_id of the record supplying `chosenValue`. */
  fromCRMProviderId: string | null;
  reason: string;
  /** Other values seen for this field across the cluster (for operator review). */
  alternatives: Array<{
    CRMProviderId: string | null;
    recordName: string;
    value: string | number | null;
  }>;
}

export interface MergePlanRecordSummary {
  dbId: number | null;
  CRMProviderId: string | null;
  name: string;
  isMaster: boolean;
  /** Whether this record is in the merge set (false = operator-excluded, untouched). */
  included: boolean;
  /** 0..1 fraction of tracked Account fields that are populated. */
  completeness: number;
  createdDate: string | null;
  modifiedDate: string | null;
  owner: string | null;
  /** CRMProvider Layout / account category (e.g. "Corporate Accounts", "Partner Accounts"). Informational. */
  layout: string | null;
  /**
   * CRMProvider Account_Name (parent Account) when the record has one. Surfaced in
   * the Contacts merge modal in place of the 📎 attachments chip — for
   * Contacts the parent-Account context is the more useful merge-decision
   * signal (which company does each duplicate belong to?). Null for records
   * with no Account_Name (e.g. orphan Contacts, all Accounts/Leads).
   */
  accountName: string | null;
  /** Deal Stage (CRMProvider). Surfaced in the Deals merge modal in place of the
   *  attachments chip — the stage is the more useful merge-decision signal for
   *  Deals (don't merge away an open/won deal). Null for non-Deal records. */
  stage: string | null;
  /** CRMProvider Lead_Status. Surfaced in the Leads merge/preview table in place of the
   *  attachments chip — status is the key merge signal for Leads (don't merge a
   *  Converted lead away). Null for non-Lead records. */
  leadStatus: string | null;
  hasCRMProviderId: boolean;
}

/** Plain-language email/phone outcome for the Contacts merge preview panel.
 *  Each slot says which value lands where and where it came from. (Sample User
 *  2026-06-25 — make multi-email / multi-phone contact merges transparent.) */
export interface ContactDataSlot {
  value: string;
  from: string; // "survivor" or the duplicate's record name
}
export interface ContactDataSummary {
  emails: {
    primary: ContactDataSlot | null;
    secondary: ContactDataSlot | null;
    extras: ContactDataSlot[];
  };
  phones: {
    phone: ContactDataSlot | null;
    mobile: ContactDataSlot | null;
    extras: ContactDataSlot[];
  };
}

export interface MergePlan {
  clusterId: number;
  module: CrmModule;
  /** Phase 1 mechanism — migrate fields to master, tag duplicates for admin. */
  method: "migrate_tag";
  tagName: string;
  masterCRMProviderId: string | null;
  masterDbId: number | null;
  masterName: string;
  masterReason: string;
  /** CRMProvider_record_ids that would receive the delete tag. */
  duplicateCRMProviderIds: string[];
  duplicateDbIds: number[];
  fieldDecisions: MergeFieldDecision[];
  warnings: string[];
  /** Contacts-only: the email/phone outcome, plainly, for the review panel. */
  contactDataSummary?: ContactDataSummary;
  /** Deterministic, human-readable summary for the review panel. */
  rationale: string;
  records: MergePlanRecordSummary[];
  /** Accounts in the cluster the survivor can be linked to (Contacts/Deals only). */
  accountCandidates: { CRMProviderId: string; name: string }[];
  /** Account the survivor's Account_Name will be set to on apply (null = no link). */
  linkAccountCRMProviderId: string | null;
  /**
   * Cascade-only CRMProvider IDs (Contacts merge): records that should receive the
   * Account_Name cascade BUT are NOT tagged Duplicate-Delete because they
   * failed the ≥2-attribute strict rule against the survivor. They appear
   * as "Excluded" in the plan; the executor adds them to its Account_Name
   * cascade so every contact in the cluster lands under the surviving
   * Account, but no Duplicate-Delete tag is applied.
   */
  cascadeOnlyCRMProviderIds: string[];
  generatedBy: string;
  /** ISO timestamp; stamped by the caller (route), null if not provided. */
  generatedAt: string | null;
}

// ── Field catalogue (Accounts) ───────────────────────────────────────────────
// `CRMProvider` is the API field name applied during execute; `fallback` reads the
// structured column when raw_data lacks the key (older / pre-sync rows).
// NOTE: custom-field API names (CR_Number, VAT_Number) are ASSUMPTIONS and must
// be confirmed against the live CRMProvider org before the execute path is enabled —
// the planner emits a warning to that effect.

interface FieldSpec {
  CRMProvider: string;
  label: string;
  custom?: boolean;
  fallback?: (r: DuplicateRecord) => unknown;
}

// Per-module field catalogues. Standard CRMProvider API field names; if your org
// renamed a standard field or you want custom fields migrated, adjust here.
// `custom: true` fields are flagged to the operator as API-name assumptions.
const MODULE_FIELDS: Record<CrmModule, FieldSpec[]> = {
  Accounts: [
    { CRMProvider: "Account_Name", label: "Account Name", fallback: (r) => r.record_name || r.company_name },
    { CRMProvider: "Phone", label: "Phone", fallback: (r) => r.phone },
    { CRMProvider: "Website", label: "Website", fallback: (r) => r.website || r.domain },
    { CRMProvider: "Industry", label: "Industry", fallback: (r) => r.industry },
    { CRMProvider: "Employees", label: "Employees", fallback: (r) => r.no_of_employees },
    { CRMProvider: "Billing_Country", label: "Country", fallback: (r) => r.country },
    { CRMProvider: "Billing_State", label: "Region / State", fallback: (r) => r.region },
    { CRMProvider: "Account_Type", label: "Account Type", fallback: (r) => r.account_type },
    { CRMProvider: "CR_Number", label: "CR Number", custom: true, fallback: (r) => r.cr_number },
    { CRMProvider: "VAT_Number", label: "VAT Number", custom: true, fallback: (r) => r.vat_number },
  ],
  Leads: [
    { CRMProvider: "Last_Name", label: "Name", fallback: (r) => r.record_name },
    { CRMProvider: "Company", label: "Company", fallback: (r) => r.company_name },
    { CRMProvider: "Email", label: "Email", fallback: (r) => r.email },
    { CRMProvider: "Phone", label: "Phone", fallback: (r) => r.phone },
    { CRMProvider: "Mobile", label: "Mobile", fallback: (r) => r.mobile },
    { CRMProvider: "Lead_Status", label: "Lead Status", fallback: (r) => r.status },
    { CRMProvider: "Lead_Source", label: "Source", fallback: (r) => r.source },
    { CRMProvider: "Industry", label: "Industry", fallback: (r) => r.industry },
    { CRMProvider: "Website", label: "Website", fallback: (r) => r.website || r.domain },
  ],
  Deals: [
    { CRMProvider: "Deal_Name", label: "Deal Name", fallback: (r) => r.record_name },
    { CRMProvider: "Amount", label: "Amount", fallback: (r) => r.deal_value },
    { CRMProvider: "Stage", label: "Stage", fallback: (r) => r.stage },
    { CRMProvider: "Pipeline", label: "Pipeline", fallback: (r) => r.pipeline },
    { CRMProvider: "Closing_Date", label: "Closing Date" },
    { CRMProvider: "Account_Name", label: "Account", fallback: (r) => r.account_name },
    { CRMProvider: "Contact_Name", label: "Contact", fallback: (r) => r.contact_name },
    { CRMProvider: "Lead_Source", label: "Source", fallback: (r) => r.source },
  ],
  Contacts: [
    { CRMProvider: "Last_Name", label: "Name", fallback: (r) => r.record_name },
    { CRMProvider: "Email", label: "Email", fallback: (r) => r.email },
    { CRMProvider: "Phone", label: "Phone", fallback: (r) => r.phone },
    { CRMProvider: "Mobile", label: "Mobile", fallback: (r) => r.mobile },
    { CRMProvider: "Account_Name", label: "Account", fallback: (r) => r.account_name },
    { CRMProvider: "Title", label: "Title", fallback: (r) => r.title },
    { CRMProvider: "Lead_Source", label: "Source", fallback: (r) => r.source },
  ],
};

// ── Value helpers ────────────────────────────────────────────────────────────

function rawVal(r: DuplicateRecord, CRMProvider: string): unknown {
  const raw = r.raw_data;
  if (raw && typeof raw === "object" && !Array.isArray(raw) && CRMProvider in raw) {
    return (raw as Record<string, unknown>)[CRMProvider];
  }
  return undefined;
}

/** Coerce any CRMProvider/column value into a scalar string|number, or null if empty. */
function normalize(v: unknown): string | number | null {
  if (v === null || v === undefined) return null;
  if (typeof v === "number") return Number.isFinite(v) ? v : null;
  if (typeof v === "boolean") return v ? "Yes" : "No";
  if (typeof v === "string") {
    const t = v.trim();
    return t === "" ? null : t;
  }
  if (typeof v === "object") {
    // CRMProvider lookup / owner objects: { name, id } or { value }
    const o = v as Record<string, unknown>;
    if (typeof o.name === "string" && o.name.trim() !== "")
      return o.name.trim();
    if (typeof o.value === "string" && o.value.trim() !== "")
      return o.value.trim();
  }
  return null;
}

function fieldValue(r: DuplicateRecord, f: FieldSpec): string | number | null {
  const fromRaw = normalize(rawVal(r, f.CRMProvider));
  if (fromRaw !== null) return fromRaw;
  if (f.fallback) return normalize(f.fallback(r));
  return null;
}

function dateMs(d: Date | string | null | undefined): number {
  if (!d) return Number.POSITIVE_INFINITY; // unknown dates sort last for "oldest"
  const t = new Date(d).getTime();
  return Number.isNaN(t) ? Number.POSITIVE_INFINITY : t;
}

function modifiedMs(r: DuplicateRecord): number {
  const t = dateMs(r.modified_date);
  return t === Number.POSITIVE_INFINITY ? 0 : t; // unknown = oldest mod for "freshest"
}

function completeness(r: DuplicateRecord, fields: FieldSpec[]): number {
  if (!fields.length) return 0;
  let filled = 0;
  for (const f of fields) if (fieldValue(r, f) !== null) filled++;
  return filled / fields.length;
}

function recName(r: DuplicateRecord): string {
  return (
    r.record_name ||
    r.company_name ||
    r.CRMProvider_record_id ||
    `record #${r.id ?? "?"}`
  );
}

function isoOrNull(d: Date | string | null | undefined): string | null {
  if (!d) return null;
  const t = new Date(d);
  return Number.isNaN(t.getTime()) ? null : t.toISOString();
}

// CRMProvider Layout (account category, e.g. "Corporate Accounts" / "Partner
// Accounts"). Surfaced in the plan as INFO only — a layout difference between
// records is legitimate (corporate B2B/B2C vs merchant partner), NOT a merge
// conflict, so it is deliberately kept out of ACCOUNT_FIELDS / conflict logic.
function layoutOf(r: DuplicateRecord): string | null {
  const v = normalize(rawVal(r, "Layout"));
  if (v !== null) return String(v);
  return r.layout_name || null;
}

// CRMProvider Account_Name (the parent Account a Contact/Deal is linked to). normalize()
// already unwraps the CRMProvider lookup shape `{ name, id }` to the display name.
// Falls back to the denormalised `account_name` column when raw_data is empty
// (older / pre-sync rows). Returns null when the record has no parent Account.
function accountNameOf(r: DuplicateRecord): string | null {
  const v = normalize(rawVal(r, "Account_Name"));
  if (v !== null) return String(v);
  return r.account_name || null;
}

// CRMProvider Lead_Status (picklist string). Surfaced in the Leads merge/preview table
// in place of the 📎 attachments chip — the lead's status (Converted / Junk /
// Contacted / …) is the more useful merge-decision signal for Leads. Falls back
// to the denormalised `stage` column some syncs write Lead_Status into. Null for
// non-Lead records.
function leadStatusOf(r: DuplicateRecord): string | null {
  const v = normalize(rawVal(r, "Lead_Status"));
  if (v !== null) return String(v);
  return (r as any).lead_status || r.stage || null;
}

function sameScalar(
  a: string | number | null,
  b: string | number | null,
): boolean {
  if (a === null || b === null) return a === b;
  return String(a).trim().toLowerCase() === String(b).trim().toLowerCase();
}

// ── Master selection ─────────────────────────────────────────────────────────
// Deterministic priority: most-complete → oldest (canonical original) →
// has an owner → lowest db id (stable).

function pickMaster(
  records: DuplicateRecord[],
  fields: FieldSpec[],
): DuplicateRecord {
  return [...records].sort((a, b) => {
    const ca = completeness(a, fields);
    const cb = completeness(b, fields);
    if (cb !== ca) return cb - ca;
    const da = dateMs(a.created_date);
    const db = dateMs(b.created_date);
    if (da !== db) return da - db;
    const oa = a.owner_email || a.owner_name ? 0 : 1;
    const ob = b.owner_email || b.owner_name ? 0 : 1;
    if (oa !== ob) return oa - ob;
    return (a.id ?? 0) - (b.id ?? 0);
  })[0];
}

function masterReasonText(master: DuplicateRecord, fields: FieldSpec[]): string {
  const pct = Math.round(completeness(master, fields) * 100);
  const created = isoOrNull(master.created_date);
  const bits = [`most complete (${pct}% of tracked fields populated)`];
  if (created) bits.push(`oldest record (created ${created.slice(0, 10)})`);
  if (master.owner_name || master.owner_email)
    bits.push("has an assigned owner");
  return bits.join("; ");
}

// ── Plan builder ─────────────────────────────────────────────────────────────

export interface BuildPlanOptions {
  tagName?: string;
  generatedBy?: string;
  /** ISO timestamp; the route passes new Date().toISOString(). */
  generatedAt?: string | null;
  /**
   * Operator override: force this CRMProvider_record_id to be the survivor instead of
   * the deterministic pick. Ignored if it doesn't match an Account record in
   * the cluster (falls back to the automatic choice).
   */
  masterCRMProviderId?: string | null;
  /**
   * Operator-selected subset of account CRMProvider_record_ids to merge (must be >=2).
   * Records not in the selection are left untouched (shown as "Excluded").
   * Omitted/empty = merge all accounts in the cluster.
   */
  includeCRMProviderIds?: string[] | null;
  /**
   * Link the survivor's Account_Name to this account (Contacts/Deals). A non-
   * empty string = link to that account id; "" / null = explicitly don't link;
   * undefined = default to the cluster's primary/sole account if any.
   */
  linkAccountCRMProviderId?: string | null;
  /**
   * DB ids of Account records that have ALREADY been tagged Duplicate-Delete
   * by a prior Accounts merge on this cluster. They are filtered out of
   * accountCandidates so the LINK SURVIVOR TO ACCOUNT picker only shows alive
   * Accounts (the surviving record from a previous Accounts merge, or
   * Accounts not yet resolved). Without this, the operator would see zombie
   * buttons for the SLB / Slb duplicates they already merged into the
   * "Schlumberger (SLB)" survivor.
   */
  taggedAccountDbIds?: number[];
  /**
   * Operator FORCE-MERGE override (Contacts): bypass the ≥2-attribute
   * soft-exclusion and tag the selected non-survivor contacts as duplicates
   * even when they share fewer than 2 of {email, phone, name}. For verified
   * edge cases (e.g. the same person entered twice with different name
   * spellings, sharing only a phone). Migrate-then-tag still applies — nothing
   * is deleted. Use with an explicit operator confirmation + audit note.
   */
  forceMergeContacts?: boolean;
}

/**
 * Build a non-destructive merge plan for a cluster, scoped to one CRM module
 * (Accounts / Leads / Deals / Contacts). Same migrate-then-tag model for every
 * module — only the field catalogue and record_type differ. Throws if there are
 * fewer than 2 records of that module's type (nothing to merge).
 */
export function buildMergePlan(
  module: CrmModule,
  clusterId: number,
  allRecords: DuplicateRecord[],
  opts: BuildPlanOptions = {},
): MergePlan {
  const fields = MODULE_FIELDS[module];
  const recordType = MODULE_RECORD_TYPE[module];
  const label = MODULE_LABEL[module];
  const tagName = opts.tagName || "Duplicate-Delete";
  const warnings: string[] = [];

  const nonTarget = allRecords.filter((r) => r.record_type !== recordType);
  if (nonTarget.length > 0) {
    warnings.push(
      `${nonTarget.length} non-${label} record(s) in this cluster are ignored — this plan resolves ${module} only.`,
    );
  }

  const records = allRecords.filter((r) => r.record_type === recordType);
  if (records.length < 2) {
    throw new Error(
      `Cluster ${clusterId} has ${records.length} ${label} record(s); need at least 2 to plan a merge.`,
    );
  }

  // Operator may select a subset to merge (>=2). Records left out of the
  // selection are untouched (rendered as "Excluded" in the plan).
  const sel = (opts.includeCRMProviderIds || []).filter(Boolean);
  const selSet = new Set(sel);
  const mergeSet =
    sel.length > 0
      ? records.filter((r) => r.CRMProvider_record_id && selSet.has(r.CRMProvider_record_id))
      : records;
  // A LINK-ONLY (cascade) plan is valid with a single record: it sets
  // Account_Name on the cluster's contacts and tags/merges nothing. So the
  // "need 2 to merge" rule only applies when there is NO link target chosen
  // (a pure merge). When a real account is being linked, allow 1 selected.
  const isLinkOnly =
    typeof opts.linkAccountCRMProviderId === "string" &&
    opts.linkAccountCRMProviderId.trim().length > 0;
  if (sel.length > 0 && mergeSet.length < 1) {
    throw new Error(`Select at least 1 ${label} record (selected ${mergeSet.length}).`);
  }
  if (sel.length > 0 && mergeSet.length < 2 && !isLinkOnly) {
    throw new Error(
      `Select at least 2 ${label} records to merge — or pick an Account to link to for a link-only cascade (selected ${mergeSet.length}).`,
    );
  }
  if (sel.length > 0 && mergeSet.length < records.length) {
    warnings.push(
      `${records.length - mergeSet.length} ${label.toLowerCase()}(s) excluded from this merge by the operator — left untouched.`,
    );
  }

  const overridden =
    opts.masterCRMProviderId != null
      ? mergeSet.find((r) => r.CRMProvider_record_id === opts.masterCRMProviderId)
      : undefined;
  if (opts.masterCRMProviderId != null && !overridden) {
    warnings.push(
      `Requested master ${opts.masterCRMProviderId} is not in the selected merge set — using the recommended survivor instead.`,
    );
  }
  const master = overridden || pickMaster(mergeSet, fields);
  let duplicates = mergeSet.filter((r) => r !== master);

  // ── HARD RULE for Contacts ──────────────────────────────────────────────
  // Two contacts can only be tagged Duplicate-Delete of each other when they
  // share AT LEAST 2 of {lower(email), normalized phone, lower(record_name)}.
  // Sharing only a parent Account or company name is NOT duplicate evidence
  // — that's what the Account_Name cascade is for (everyone in the cluster
  // gets re-pointed to the surviving Account regardless). A non-matching
  // contact stays in the cluster but is moved to "softExcluded": rendered
  // as Excluded in the plan, untouched in CRMProvider.
  //
  // Reason: Sample User (2026-06-10) — the previous behaviour was tagging
  // genuinely different people who happened to sit in the same cluster.
  // See feedback-contact-merge-rule.md.
  const contactSoftExcluded: typeof duplicates = [];
  // Operator FORCE-MERGE bypasses the ≥2-attribute soft-exclusion: every
  // selected non-survivor contact is tagged as a duplicate (verified by a
  // human). Default behaviour (no force) keeps the safe rule.
  if (module === "Contacts" && duplicates.length > 0 && !opts.forceMergeContacts) {
    const masterEmail = (master.email || "").trim().toLowerCase();
    const masterPhone = (master.phone_normalized || "").trim();
    // Arabic-aware name normalization so visually-identical names (differing
    // only by invisible bidi marks / NFC-vs-NFKC / tatweel / ة-vs-ه) compare
    // equal instead of silently dropping a real duplicate to cascade-only.
    const masterName = normalizePersonName(master.record_name);
    const masterEmailIsRole = isRoleMailbox(masterEmail);
    // Returns WHY a contact qualifies as a duplicate of the survivor, or null.
    //  - "strict": the original ≥2-of-{email,phone,name} rule.
    //  - "same_personal_email": same exact PERSONAL email (a shared role mailbox
    //    is not an identity, so it doesn't bridge here) → same person; keep both
    //    phones (Sample User 2026-06-26).
    //  - "shared_phone_role_mailbox": same phone where the DUPLICATE carries a
    //    generic info@/support@ mailbox and the survivor has a real personal
    //    email → the role mailbox is the company contact-point, not a different
    //    person; absorb it (keep both emails). DIRECTIONAL on purpose: we never
    //    tag a real person as a duplicate of a role-mailbox survivor, so if the
    //    operator picks the info@ contact as survivor it stays link-only.
    const classifyDup = (
      r: DuplicateRecord,
    ): "strict" | "same_personal_email" | "shared_phone_role_mailbox" | null => {
      const rEmail = (r.email || "").trim().toLowerCase();
      const rPhone = (r.phone_normalized || "").trim();
      const rName = normalizePersonName(r.record_name);
      const emailEq = !!(masterEmail && rEmail && masterEmail === rEmail);
      const phoneEq = !!(masterPhone && rPhone && masterPhone === rPhone);
      const nameEq = !!(masterName && rName && masterName === rName);
      const matches = (emailEq ? 1 : 0) + (phoneEq ? 1 : 0) + (nameEq ? 1 : 0);
      if (matches >= 2) return "strict";
      if (emailEq && !masterEmailIsRole) return "same_personal_email";
      if (phoneEq && !emailEq && isRoleMailbox(rEmail) && !masterEmailIsRole)
        return "shared_phone_role_mailbox";
      return null;
    };
    const keep: typeof duplicates = [];
    const bridged: Array<{ r: DuplicateRecord; via: string }> = [];
    for (const r of duplicates) {
      const via = classifyDup(r);
      if (via) {
        keep.push(r);
        if (via !== "strict") bridged.push({ r, via });
      } else {
        contactSoftExcluded.push(r);
      }
    }
    duplicates = keep;
    // Transparency: the two relaxed bridges can merge contacts with DIFFERENT
    // names (operator-approved 2026-06-26), so call them out explicitly for
    // review before Apply. Both emails/phones are preserved on the survivor.
    if (bridged.length > 0) {
      const list = bridged
        .slice(0, 5)
        .map(
          (b) =>
            `"${recName(b.r)}"` +
            (b.via === "shared_phone_role_mailbox"
              ? " (shared phone + a generic info@/support@ mailbox)"
              : " (same email)"),
        )
        .join(", ");
      const more = bridged.length > 5 ? ` (+${bridged.length - 5} more)` : "";
      warnings.push(
        `${bridged.length} contact(s) merged by a relaxed rule — same personal email, or a shared phone where the other carries a generic info@/support@ mailbox: ${list}${more}. Both emails and phone numbers are preserved on the survivor (primary + Secondary_Email / Mobile). Confirm they are the same contact-point before Apply. Tip: pick the contact with the PERSONAL email as the survivor so the info@/support@ mailbox is kept as Secondary_Email.`,
      );
    }
    if (contactSoftExcluded.length > 0) {
      const names = contactSoftExcluded
        .slice(0, 5)
        .map((r) => recName(r))
        .join(", ");
      const more =
        contactSoftExcluded.length > 5
          ? ` (+${contactSoftExcluded.length - 5} more)`
          : "";
      warnings.push(
        `${contactSoftExcluded.length} contact(s) left UNTAGGED — they share fewer than 2 identity attributes (email/phone/name) with "${recName(master)}" and are NOT duplicates of it: ${names}${more}. Account_Name cascade will still re-point them to the surviving Account when a link target is chosen.`,
      );
    }
    if (duplicates.length === 0) {
      warnings.push(
        `Cascade-only plan — no genuine contact duplicates of "${recName(master)}" in this cluster. Apply will set Account_Name on every contact but tag none.`,
      );
    }
  } else if (module === "Contacts" && opts.forceMergeContacts && duplicates.length > 0) {
    warnings.push(
      `⚠ FORCE-MERGE — the operator confirmed the ${duplicates.length} selected contact(s) are the SAME person as "${recName(master)}" and overrode the ≥2-attribute rule. They will be tagged Duplicate-Delete (migrate-then-tag; nothing is deleted).`,
    );
    // Pull soft-excluded contacts out of mergeSet so the UI renders them
    // as "Excluded" (untouched) instead of "Duplicate-Delete". The
    // Account_Name cascade still covers them via plan.cascadeOnlyCRMProviderIds
    // (added to the executor below).
    if (contactSoftExcluded.length > 0) {
      const excluded = new Set(contactSoftExcluded);
      // mergeSet is a plain array; rebuild it without the soft-excluded set.
      for (let i = mergeSet.length - 1; i >= 0; i--) {
        if (excluded.has(mergeSet[i])) mergeSet.splice(i, 1);
      }
    }
  }

  // Cross-module link: accounts in the cluster the survivor can be linked to
  // (Contacts / Deals set their Account_Name lookup). Surfaced for the UI; the
  // executor applies it on apply when an account is chosen.
  const canLinkAccount = module === "Contacts" || module === "Deals";
  const taggedAccountSet = new Set<number>(opts.taggedAccountDbIds || []);
  const accountCandidates = canLinkAccount
    ? allRecords
        .filter(
          (r) =>
            r.record_type === "account" &&
            r.CRMProvider_record_id &&
            // Drop Accounts that were tagged Duplicate-Delete by a prior
            // Accounts merge on this cluster — they're zombies in CRMProvider and
            // must not appear as link targets.
            (r.id == null || !taggedAccountSet.has(r.id)),
        )
        .map((r) => ({
          CRMProviderId: r.CRMProvider_record_id as string,
          name: r.record_name || r.company_name || (r.CRMProvider_record_id as string),
        }))
    : [];
  const suggestedAccount =
    accountCandidates.find((a) =>
      allRecords.some((r) => r.CRMProvider_record_id === a.CRMProviderId && r.is_primary),
    )?.CRMProviderId ||
    (accountCandidates.length === 1 ? accountCandidates[0].CRMProviderId : null);
  let linkAccountCRMProviderId: string | null;
  if (opts.linkAccountCRMProviderId === undefined) {
    linkAccountCRMProviderId = suggestedAccount; // default suggestion on first preview
  } else if (!opts.linkAccountCRMProviderId) {
    linkAccountCRMProviderId = null; // explicit "don't link"
  } else {
    linkAccountCRMProviderId = accountCandidates.some(
      (a) => a.CRMProviderId === opts.linkAccountCRMProviderId,
    )
      ? opts.linkAccountCRMProviderId
      : null;
  }

  // Field decisions — gap-fills + conflicts only (keeps are omitted as noise).
  const fieldDecisions: MergeFieldDecision[] = [];
  let fillCount = 0;
  let conflictCount = 0;
  let usesCustomField = false;

  for (const f of fields) {
    const masterVal = fieldValue(master, f);
    const dupVals = duplicates
      .map((d) => ({
        CRMProviderId: d.CRMProvider_record_id ?? null,
        recordName: recName(d),
        value: fieldValue(d, f),
      }))
      .filter((x) => x.value !== null);

    if (masterVal === null) {
      if (dupVals.length === 0) continue; // nobody has it
      // Fill from the freshest duplicate that holds a value.
      const freshest = [...duplicates]
        .filter((d) => fieldValue(d, f) !== null)
        .sort((a, b) => modifiedMs(b) - modifiedMs(a))[0];
      const chosen = fieldValue(freshest, f);
      fieldDecisions.push({
        field: f.CRMProvider,
        label: f.label,
        action: "fill",
        chosenValue: chosen,
        fromCRMProviderId: freshest.CRMProvider_record_id ?? null,
        reason: `Master is empty; filled from "${recName(freshest)}" (most recently modified record holding a value).`,
        alternatives: dupVals.filter(
          (x) => x.CRMProviderId !== (freshest.CRMProvider_record_id ?? null),
        ),
      });
      fillCount++;
      if (f.custom) usesCustomField = true;
    } else {
      const conflicting = dupVals.filter(
        (x) => !sameScalar(x.value, masterVal),
      );
      if (conflicting.length > 0) {
        fieldDecisions.push({
          field: f.CRMProvider,
          label: f.label,
          action: "conflict",
          chosenValue: masterVal,
          fromCRMProviderId: master.CRMProvider_record_id ?? null,
          reason: `Kept master value; ${conflicting.length} duplicate value(s) differ — review before accepting.`,
          alternatives: conflicting,
        });
        conflictCount++;
        warnings.push(
          `Field "${f.label}" differs across records — kept master ("${masterVal}"). ${conflicting.length} alternative(s) available.`,
        );
        if (f.custom) usesCustomField = true;
      }
    }
  }

  // Preserve an alternate email on a CONTACT merge (Sample User 2026-06-22). The
  // survivor keeps its primary Email; a duplicate's DIFFERENT email would
  // otherwise be discarded when that duplicate is tagged for deletion. If the
  // survivor's Secondary_Email is still empty, capture the freshest distinct
  // alternate email into it so no email is lost. Gap-fill only — never
  // overwrites an existing Secondary_Email. CRMProvider Contacts has a single
  // Secondary_Email field, so if there are several alternates only one is
  // preserved and the rest are surfaced as alternatives + a warning.
  if (module === "Contacts") {
    const emailRaw = (r: DuplicateRecord): string =>
      String((rawVal(r, "Email") ?? r.email ?? "") as unknown).trim();
    const masterSecondary = String(
      (rawVal(master, "Secondary_Email") ?? "") as unknown,
    ).trim();
    if (!masterSecondary) {
      const dupsByFresh = [...duplicates].sort(
        (a, b) => modifiedMs(b) - modifiedMs(a),
      );
      // Effective primary email after merge: the master's, or — if the master
      // had none — whichever duplicate email the loop above used to gap-fill it.
      let primaryKey = emailRaw(master).toLowerCase();
      if (!primaryKey) {
        const filler = dupsByFresh.find((d) => emailRaw(d));
        primaryKey = filler ? emailRaw(filler).toLowerCase() : "";
      }
      const seen = new Set<string>();
      if (primaryKey) seen.add(primaryKey);
      const alts: { CRMProviderId: string | null; recordName: string; value: string }[] = [];
      for (const d of dupsByFresh) {
        const e = emailRaw(d);
        const k = e.toLowerCase();
        if (e && !seen.has(k)) {
          seen.add(k);
          alts.push({ CRMProviderId: d.CRMProvider_record_id ?? null, recordName: recName(d), value: e });
        }
      }
      if (alts.length > 0) {
        const chosen = alts[0]!;
        fieldDecisions.push({
          field: "Secondary_Email",
          label: "Secondary Email",
          action: "fill",
          chosenValue: chosen.value,
          fromCRMProviderId: chosen.CRMProviderId,
          reason: `Survivor's email differs from "${chosen.recordName}" — preserved its email in Secondary_Email so no email is lost on merge.`,
          alternatives: alts.slice(1),
        });
        fillCount++;
        if (alts.length > 1) {
          warnings.push(
            `${alts.length} distinct alternate email(s) found, but CRMProvider Contacts has a single Secondary_Email field — only "${chosen.value}" is preserved on the survivor. The rest are listed as alternatives; capture them manually if needed: ${alts
              .slice(1)
              .map((a) => a.value)
              .join(", ")}.`,
          );
        }
      }
    }
  }

  // Preserve an alternate PHONE on a CONTACT merge (Sample User 2026-06-24). Mirrors
  // the Secondary_Email logic above: the survivor keeps its primary Phone; a
  // duplicate's DIFFERENT number would otherwise be lost (it only surfaces as a
  // Phone CONFLICT alternative and is discarded when the duplicate is deleted).
  // If the survivor's Mobile slot is still empty (no Mobile decision was already
  // produced by the field loop), capture the freshest distinct alternate number
  // — from any duplicate's Phone OR Mobile — into Mobile so both numbers survive.
  // Saudi-normalised comparison (drop +966 / leading 0, last 9 digits) so the
  // same number in different formats isn't double-stored. Extras → warning.
  if (module === "Contacts") {
    const normPhone = (s: string): string =>
      String(s || "")
        .replace(/\D/g, "")
        .replace(/^966/, "")
        .replace(/^0+/, "")
        .slice(-9);
    const phoneRaw = (r: DuplicateRecord, field: "Phone" | "Mobile"): string =>
      String(
        (rawVal(r, field) ?? (field === "Phone" ? r.phone : r.mobile) ?? "") as unknown,
      ).trim();
    const masterMobile = phoneRaw(master, "Mobile");
    const hasMobileDecision = fieldDecisions.some((d) => d.field === "Mobile");
    if (!masterMobile && !hasMobileDecision) {
      const dupsByFresh = [...duplicates].sort(
        (a, b) => modifiedMs(b) - modifiedMs(a),
      );
      // Effective primary number after merge: master's Phone, or — if the master
      // had none — whichever duplicate Phone the field loop used to gap-fill it.
      let primaryKey = normPhone(phoneRaw(master, "Phone"));
      if (!primaryKey) {
        const filler = dupsByFresh.find((d) => phoneRaw(d, "Phone"));
        primaryKey = filler ? normPhone(phoneRaw(filler, "Phone")) : "";
      }
      const seen = new Set<string>();
      if (primaryKey) seen.add(primaryKey);
      const alts: { CRMProviderId: string | null; recordName: string; value: string }[] = [];
      for (const d of dupsByFresh) {
        for (const field of ["Phone", "Mobile"] as const) {
          const p = phoneRaw(d, field);
          const k = normPhone(p);
          if (p && k && !seen.has(k)) {
            seen.add(k);
            alts.push({ CRMProviderId: d.CRMProvider_record_id ?? null, recordName: recName(d), value: p });
          }
        }
      }
      if (alts.length > 0) {
        const chosen = alts[0]!;
        fieldDecisions.push({
          field: "Mobile",
          label: "Mobile",
          action: "fill",
          chosenValue: chosen.value,
          fromCRMProviderId: chosen.CRMProviderId,
          reason: `Survivor's phone differs from "${chosen.recordName}" — preserved its number in Mobile so no number is lost on merge.`,
          alternatives: alts.slice(1),
        });
        fillCount++;
        if (alts.length > 1) {
          warnings.push(
            `${alts.length} distinct alternate number(s) found, but CRMProvider Contacts holds one in Mobile — only "${chosen.value}" is preserved on the survivor. The rest are listed as alternatives; capture them manually if needed: ${alts
              .slice(1)
              .map((a) => a.value)
              .join(", ")}.`,
          );
        }
      }
    }
  }

  // Contacts-only: the plain-language email/phone outcome for the preview panel
  // (Sample User 2026-06-25). Survivor's own value is slot 1 (kept); the next distinct
  // value lands in Secondary_Email / Mobile; the rest are extras CRMProvider can't store.
  // Mirrors the executor's gap-fill order (master wins; else freshest duplicate
  // fills + Saudi-normalised phone de-dupe), so the panel matches exactly what
  // Apply does.
  let contactDataSummary: ContactDataSummary | undefined;
  if (module === "Contacts") {
    const emailOf = (r: DuplicateRecord): string =>
      String((rawVal(r, "Email") ?? r.email ?? "") as unknown).trim();
    const secEmailOf = (r: DuplicateRecord): string =>
      String((rawVal(r, "Secondary_Email") ?? "") as unknown).trim();
    const phoneOf = (r: DuplicateRecord, field: "Phone" | "Mobile"): string =>
      String((rawVal(r, field) ?? (field === "Phone" ? r.phone : r.mobile) ?? "") as unknown).trim();
    const normP = (s: string): string =>
      String(s || "").replace(/\D/g, "").replace(/^966/, "").replace(/^0+/, "").slice(-9);
    const ordered = [master, ...[...duplicates].sort((a, b) => modifiedMs(b) - modifiedMs(a))];

    const emails: ContactDataSlot[] = [];
    const seenE = new Set<string>();
    for (const r of ordered) {
      for (const e of [emailOf(r), secEmailOf(r)]) {
        const k = e.toLowerCase();
        if (e && !seenE.has(k)) {
          seenE.add(k);
          emails.push({ value: e, from: r === master ? "survivor" : recName(r) });
        }
      }
    }
    const phones: ContactDataSlot[] = [];
    const seenP = new Set<string>();
    for (const r of ordered) {
      for (const field of ["Phone", "Mobile"] as const) {
        const p = phoneOf(r, field);
        const k = normP(p);
        if (p && k && !seenP.has(k)) {
          seenP.add(k);
          phones.push({ value: p, from: r === master ? "survivor" : recName(r) });
        }
      }
    }
    contactDataSummary = {
      emails: { primary: emails[0] ?? null, secondary: emails[1] ?? null, extras: emails.slice(2) },
      phones: { phone: phones[0] ?? null, mobile: phones[1] ?? null, extras: phones.slice(2) },
    };
  }

  // Preserve alternate (EN/AR) names on an ACCOUNT merge (Sample User 2026-06-22).
  // The Account Name field is bilingual — one record may hold the English name,
  // another the Arabic — so a straight merge keeps the survivor's name and the
  // other-language name is lost when the admin deletes the duplicate. There's no
  // dedicated Arabic-name field, so we APPEND the distinct alternate name(s) to
  // the survivor's Description as "Also known as: …" (non-destructive, keeps
  // Account_Name clean for reporting). Gap-aware: appends to any existing
  // Description rather than overwriting.
  if (module === "Accounts") {
    const nameOf = (r: DuplicateRecord): string =>
      String(
        ((r.raw_data as any)?.Account_Name ?? r.record_name ?? r.company_name ?? "") as unknown,
      ).trim();
    const masterName = nameOf(master);
    const masterKey = masterName.toLowerCase();
    const seenNames = new Set<string>();
    if (masterKey) seenNames.add(masterKey);
    const altNames: string[] = [];
    for (const d of duplicates) {
      const n = nameOf(d);
      const k = n.toLowerCase();
      if (n && !seenNames.has(k)) {
        seenNames.add(k);
        altNames.push(n);
      }
    }
    if (altNames.length > 0) {
      const existingDesc = String(
        ((master.raw_data as any)?.Description ?? "") as unknown,
      ).trim();
      const aka = `Also known as: ${altNames.join(" | ")}`;
      const newDesc = existingDesc
        ? existingDesc.includes(aka)
          ? existingDesc
          : `${existingDesc}\n${aka}`
        : aka;
      if (newDesc !== existingDesc) {
        fieldDecisions.push({
          field: "Description",
          label: "Description (alternate names)",
          action: "fill",
          chosenValue: newDesc,
          fromCRMProviderId: master.CRMProvider_record_id ?? null,
          reason: `Preserved ${altNames.length} alternate name(s) (EN/AR) on the survivor so no name is lost when the duplicate is deleted.`,
          alternatives: altNames.map((n) => ({ CRMProviderId: null, recordName: n, value: n })),
        });
        fillCount++;
      }
    }
  }

  // Structural warnings.
  const untaggable = duplicates.filter((d) => !d.CRMProvider_record_id);
  if (untaggable.length > 0) {
    warnings.push(
      `${untaggable.length} duplicate(s) have no CRMProvider record id — they cannot be tagged or migrated (synthetic / pre-sync rows).`,
    );
  }
  if (!master.CRMProvider_record_id) {
    warnings.push(
      "Proposed master has no CRMProvider record id — it cannot be written to. Review the cluster before resolving.",
    );
  }
  const flaggedPrimary = records.find((r) => r.is_primary);
  if (flaggedPrimary && flaggedPrimary !== master) {
    warnings.push(
      `Recommended master ("${recName(master)}") differs from the currently flagged primary ("${recName(flaggedPrimary)}"). Override in the panel if the flag is correct.`,
    );
  }
  if (usesCustomField) {
    warnings.push(
      "Plan touches custom fields (CR Number / VAT Number) whose CRMProvider API names are assumptions — confirm them against the org before enabling the execute path.",
    );
  }

  const duplicateCRMProviderIds = duplicates
    .map((d) => d.CRMProvider_record_id)
    .filter((x): x is string => typeof x === "string" && x.length > 0);
  const duplicateDbIds = duplicates
    .map((d) => d.id)
    .filter((x): x is number => typeof x === "number");
  // Cascade-only ids — soft-excluded Contacts that should still receive the
  // Account_Name cascade but never the Duplicate-Delete tag. Stays an empty
  // array for every other module.
  const cascadeOnlyCRMProviderIds = contactSoftExcluded
    .map((r) => r.CRMProvider_record_id)
    .filter((x): x is string => typeof x === "string" && x.length > 0);

  const records_summary: MergePlanRecordSummary[] = records.map((r) => ({
    dbId: r.id ?? null,
    CRMProviderId: r.CRMProvider_record_id ?? null,
    name: recName(r),
    isMaster: r === master,
    included: mergeSet.includes(r),
    completeness: Math.round(completeness(r, fields) * 100) / 100,
    createdDate: isoOrNull(r.created_date),
    modifiedDate: isoOrNull(r.modified_date),
    owner: r.owner_name || r.owner_email || null,
    layout: layoutOf(r),
    accountName: accountNameOf(r),
    stage: r.stage ?? null,
    leadStatus: leadStatusOf(r),
    hasCRMProviderId: !!r.CRMProvider_record_id,
  }));

  const masterReason = overridden
    ? `Operator-selected survivor — ${Math.round(completeness(master, fields) * 100)}% of tracked fields populated`
    : masterReasonText(master, fields);
  // LINK-ONLY rationale for Contacts (Sample User 2026-06-10):
  // when 0 contacts qualify as duplicates under the ≥2-attribute rule,
  // the plan is "link cascade only" — no tagging happens. The rationale
  // text must say that explicitly so chat/agent/log consumers don't read
  // "0 duplicate(s) would be tagged" as a noisy merge proposal.
  const linkOnlyMode =
    module === "Contacts" &&
    duplicates.length === 0 &&
    cascadeOnlyCRMProviderIds.length > 0;
  const rationale = linkOnlyMode
    ? `Link-only plan for "${recName(master)}"` +
      (master.CRMProvider_record_id ? ` (${master.CRMProvider_record_id})` : "") +
      `. ${cascadeOnlyCRMProviderIds.length} other contact(s) in this cluster do NOT pairwise share ≥2 of {email, phone, name} with the survivor — they are different people at the same Account, not duplicates of each other. ` +
      `On Apply, every contact's Account_Name is updated to the chosen Account. No record is tagged "${tagName}"; the platform deletes nothing.`
    : `Proposed survivor: "${recName(master)}"` +
      (master.CRMProvider_record_id ? ` (${master.CRMProvider_record_id})` : "") +
      ` — ${masterReason}. ${duplicates.length} duplicate(s) would be tagged "${tagName}" for the CRMProvider admin to delete. ` +
      `${fillCount} field(s) would be migrated onto the survivor; ${conflictCount} field conflict(s) flagged for review. ` +
      `The platform deletes nothing — it only edits the survivor and tags the duplicates.`;

  return {
    clusterId,
    module,
    method: "migrate_tag",
    tagName,
    masterCRMProviderId: master.CRMProvider_record_id ?? null,
    masterDbId: master.id ?? null,
    masterName: recName(master),
    masterReason,
    duplicateCRMProviderIds,
    duplicateDbIds,
    fieldDecisions,
    warnings,
    contactDataSummary,
    rationale,
    records: records_summary,
    accountCandidates,
    linkAccountCRMProviderId,
    cascadeOnlyCRMProviderIds,
    generatedBy: opts.generatedBy || "duplicate-radar",
    generatedAt: opts.generatedAt ?? null,
  };
}

/** Back-compat convenience wrapper — Accounts merge plan. */
export function buildAccountMergePlan(
  clusterId: number,
  allRecords: DuplicateRecord[],
  opts: BuildPlanOptions = {},
): MergePlan {
  return buildMergePlan("Accounts", clusterId, allRecords, opts);
}
