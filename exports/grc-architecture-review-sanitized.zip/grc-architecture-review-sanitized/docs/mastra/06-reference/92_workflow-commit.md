---
title: "Reference: Workflow.commit() | Workflows | Mastra Docs"
description: Documentation for the `Workflow.commit()` method in workflows, which finalizes the workflow and returns the final result.
---

# Workflow.commit()
[EN] Source: <REDACTED_URL>

The `.commit()` method finalizes the workflow and returns the final result.

## Usage example

```typescript copy
workflow.then(step1).commit();
```

## Returns

<PropertiesTable
  content={[
    {
      name: "workflow",
      type: "Workflow",
      description: "The workflow instance for method chaining",
    },
  ]}
/>

## Related

- [Control Flow](../../../docs/workflows/control-flow.mdx)


