---
title: "Reference: Memory.deleteMessages() | Memory | Mastra Docs"
description: "Documentation for the `Memory.deleteMessages()` method in Mastra, which deletes multiple messages by their IDs."
---

# Memory.deleteMessages()
[EN] Source: <REDACTED_URL>

The `.deleteMessages()` method deletes multiple messages by their IDs.

## Usage Example

```typescript copy
await memory?.deleteMessages(["<REDACTED_PHONE>-4000-8000-<REDACTED_PHONE>"]);
```

## Parameters

<PropertiesTable
  content={[
    {
      name: "messageIds",
      type: "string[]",
      description: "Array of message IDs to delete",
      isOptional: false,
    },
  ]}
/>

## Returns

<PropertiesTable
  content={[
    {
      name: "void",
      type: "Promise<void>",
      description: "A promise that resolves when all messages are deleted",
    },
  ]}
/>

## Extended usage example

```typescript filename="src/test-memory.ts" showLineNumbers copy
import { mastra } from "./mastra";
import { UIMessageWithMetadata } from "@mastra/core/agent";

const agent = mastra.getAgent("agent");
const memory = await agent.getMemory();

const { uiMessages } = await memory!.query({ threadId: "thread-123" });

const messageIds = uiMessages.map((message: UIMessageWithMetadata) => message.id);
await memory?.deleteMessages([...messageIds]);
```

## Related

- [Memory Class Reference](/reference/memory/Memory.mdx)
- [query](/reference/memory/query.mdx)
- [Getting Started with Memory](/docs/memory/overview.mdx)


